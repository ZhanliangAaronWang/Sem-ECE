"""Build xAI rerun batch inputs for truncated samples only.

Identifies custom_ids where completion_tokens >= 95% of current max,
then filters original batch input files, rewriting max_tokens to NEW_MAX.
"""
import json, glob, os
from collections import defaultdict

ROOT = os.path.dirname(os.path.abspath(__file__))
NEW_MAX = 2048


def find_truncated(raw_pat, current_max):
    """Return set of truncated custom_ids."""
    ids = set()
    for p in sorted(glob.glob(raw_pat)):
        with open(p) as f:
            for line in f:
                r = json.loads(line)
                if r.get('status') != 'success':
                    continue
                ct = r.get('completion_tokens')
                if ct is None:
                    ct = (r.get('usage', {}) or {}).get('completion_tokens', 0) or 0
                if ct >= int(current_max * 0.95):
                    ids.add(r['custom_id'])
    return ids


def filter_input(input_path, ids, out_path, new_max):
    n_out = 0
    with open(input_path) as fin, open(out_path, 'w') as fout:
        for line in fin:
            r = json.loads(line)
            if r['custom_id'] not in ids:
                continue
            r['body']['max_tokens'] = new_max
            fout.write(json.dumps(r, ensure_ascii=False) + '\n')
            n_out += 1
    return n_out


def main():
    out_dir = os.path.join(ROOT, "xai_rerun", "batch_inputs")
    os.makedirs(out_dir, exist_ok=True)

    print("Scanning P2 truncated...")
    p2_ids = find_truncated(
        os.path.join(ROOT, "phase2", "batch_outputs", "xai_raw_w*.jsonl"),
        current_max=512,
    )
    print(f"  P2: {len(p2_ids):,} truncated")

    print("Scanning P3 truncated...")
    p3_ids = find_truncated(
        os.path.join(ROOT, "phase3", "batch_outputs", "xai_raw_chunk0.jsonl"),
        current_max=1024,
    )
    print(f"  P3: {len(p3_ids):,} truncated")

    # Filter original inputs
    p2_out = os.path.join(out_dir, "xai_p2_rerun.jsonl")
    p3_out = os.path.join(out_dir, "xai_p3_rerun.jsonl")

    n2 = filter_input(
        os.path.join(ROOT, "phase2", "batch_inputs", "xai_hle.jsonl"),
        p2_ids, p2_out, NEW_MAX,
    )
    print(f"Wrote {n2:,} rows -> {p2_out}")

    n3 = filter_input(
        os.path.join(ROOT, "phase3", "batch_inputs", "xai_math.jsonl"),
        p3_ids, p3_out, NEW_MAX,
    )
    print(f"Wrote {n3:,} rows -> {p3_out}")

    # Missing check
    p2_missing = p2_ids - set(
        json.loads(l)['custom_id'] for l in open(p2_out)
    )
    p3_missing = p3_ids - set(
        json.loads(l)['custom_id'] for l in open(p3_out)
    )
    if p2_missing:
        print(f"WARN: {len(p2_missing)} P2 ids missing from input: {list(p2_missing)[:3]}")
    if p3_missing:
        print(f"WARN: {len(p3_missing)} P3 ids missing from input: {list(p3_missing)[:3]}")


if __name__ == "__main__":
    main()
