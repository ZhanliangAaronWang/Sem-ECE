"""Build Phase 3 (MATH-500 + AIME) generation batch input files for 4 providers.

Same system prompt and config as Phase 2 (HLE), max_output_tokens=1024 (math may need more).
50 samples per question.
"""
import os, json, math

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
INPUT = os.path.join(CAL_BASE, "data", "phase3", "math_preprocessed.jsonl")
OUT_DIR = os.path.join(BASE, "batch_inputs")
os.makedirs(OUT_DIR, exist_ok=True)

SYSTEM_PROMPT = """You are answering questions for a research benchmark. Be concise and precise.

Your response MUST end with EXACTLY these two lines, with nothing after them:
Answer: <your final answer>
Confidence: <integer between 0 and 100>%

Keep <your final answer> as short as possible — ideally a single name, number, date, or short phrase. Do not put explanations or reasoning on the Answer line itself.

If you genuinely do not know, write:
Answer: I don't know
Confidence: 0%"""

N_SAMPLES = 50
MAX_TOKENS = 1024  # math often needs longer

questions = []
with open(INPUT) as f:
    for line in f:
        questions.append(json.loads(line))
print(f"Loaded {len(questions)} questions", flush=True)


def build_openai():
    """OpenAI: 7 sub-batches per question (6×n=8 + 1×n=2 = 50)."""
    for ci in range(7):
        n = 8 if ci < 6 else 2
        rows = []
        for q in questions:
            rows.append({
                "custom_id": f"{q['qid']}__chunk{ci}",
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": "gpt-5.4",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": q["question_final"]},
                    ],
                    "max_completion_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "reasoning_effort": "none",
                    "n": n,
                    "seed": ci,
                },
            })
        path = os.path.join(OUT_DIR, f"openai_math_chunk{ci}.jsonl")
        with open(path, "w") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  openai: {len(questions)*7} rows -> 7 chunks", flush=True)


def build_gemini():
    rows = []
    for q in questions:
        for si in range(N_SAMPLES):
            rows.append({
                "custom_id": f"{q['qid']}__sample{si:02d}",
                "contents": q["question_final"],
                "config": {
                    "system_instruction": SYSTEM_PROMPT,
                    "max_output_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "thinking_config": {"thinking_budget": 0},
                    "seed": si,
                },
            })
    path = os.path.join(OUT_DIR, "gemini_math.jsonl")
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  gemini: {len(rows)} rows -> {path}", flush=True)


def build_xai():
    rows = []
    for q in questions:
        for si in range(N_SAMPLES):
            rows.append({
                "custom_id": f"{q['qid']}__sample{si:02d}",
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": "grok-4.20-0309-non-reasoning",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": q["question_final"]},
                    ],
                    "max_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "seed": si + 1,  # xAI rejects seed=0
                },
            })
    path = os.path.join(OUT_DIR, "xai_math.jsonl")
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  xai: {len(rows)} rows -> {path}", flush=True)


def build_mistral():
    rows = []
    for q in questions:
        for si in range(N_SAMPLES):
            rows.append({
                "custom_id": f"{q['qid']}__sample{si:02d}",
                "body": {
                    "model": "mistral-large-latest",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": q["question_final"]},
                    ],
                    "max_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "random_seed": si,
                },
            })
    # Split into chunks of ~43260 for Mistral batch API
    chunk_size = 43260
    for ci in range(0, len(rows), chunk_size):
        chunk = rows[ci:ci + chunk_size]
        path = os.path.join(OUT_DIR, f"mistral_math_chunk{ci // chunk_size}.jsonl")
        with open(path, "w") as f:
            for r in chunk:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    path_all = os.path.join(OUT_DIR, "mistral_math.jsonl")
    with open(path_all, "w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  mistral: {len(rows)} rows", flush=True)


build_openai()
build_gemini()
build_xai()
build_mistral()

nq = len(questions)
print(f"\n=== Cost Estimate (Phase 3) ===")
print(f"  Questions: {nq}")
print(f"  Samples per question: {N_SAMPLES}")
for prov, in_price, out_price, note in [
    ("openai", 1.25, 10.0, "batch 50% off"),
    ("gemini", 0.10, 0.40, "batch"),
    ("xai", 2.0, 10.0, "batch"),
    ("mistral", 2.0, 6.0, "batch 33% off"),
]:
    calls = nq * N_SAMPLES
    in_tok = 300 * calls
    out_tok = 300 * calls  # math answers longer
    discount = 0.5
    cost = (in_tok * in_price * discount + out_tok * out_price * discount) / 1e6
    print(f"  {prov:10s}: {calls:,} calls, ~${cost:.2f}")
