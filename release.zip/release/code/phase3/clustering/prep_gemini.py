"""Phase 3 (MATH+AIME) Step 1 — Extract answers from Gemini batch/worker outputs and build clustering batch.

Sources (all merged; dedup by custom_id preferring successful samples with text):
  phase3/batch_outputs/gemini_batch_raw.jsonl    (Batch API output — majority of data)
  phase3/batch_outputs/gemini_raw_w*.jsonl       (original async worker)
  phase3/batch_outputs/gemini_raw_w*_retry.jsonl (retry worker)

Outputs:
  phase3/clustering/gemini_extracted.jsonl
  phase3/clustering/batch_inputs/gemini_clustering.jsonl
"""
import os, json, re, statistics, glob
from collections import defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BATCH_DIR = os.path.join(ROOT, "phase3", "batch_outputs")
GOLD_FILE = os.path.join(ROOT, "data", "phase3", "math_preprocessed.jsonl")
EXTRACTED = os.path.join(ROOT, "phase3", "clustering", "gemini_extracted.jsonl")
BATCH_OUT = os.path.join(ROOT, "phase3", "clustering", "batch_inputs", "gemini_clustering.jsonl")

JUDGE_MODEL = "gpt-5.2"
ANS_RE = re.compile(r"Answer:\s*(.+?)(?=\nConfidence|\Z)", re.DOTALL)
CONF_RE = re.compile(r"Confidence:\s*([0-9]+(?:\.[0-9]+)?)\s*%?")
NULL_ANS = {"see above", "as stated", "as mentioned", "as noted"}

SYSTEM_PROMPT = """You are a semantic clustering assistant for a research benchmark. You will receive a question and a list of model-generated answers, indexed 0 through N-1. Your job is to partition the answers into groups such that two answers are in the same group if and only if they express the same underlying answer to the question.

Rules:
- Cluster by SEMANTIC meaning, not surface form. "Leo Tolstoy", "Tolstoy", "Leo Tolstoy (1869)", and "the Russian novelist Leo Tolstoy" all belong to the same cluster.
- Surface variations to ignore: capitalization, punctuation, articles (a/the), trailing dates or qualifiers, formal vs informal name forms, units that express the same physical quantity ("1.5 mM" = "0.0015 M"), and explanatory parentheticals.
- Different specific answers belong to different clusters even if related: "Tolstoy" and "Dostoevsky" are different; "Paris" and "France" are different; "1869" and "1865" are different.
- Each answer index must appear in exactly one cluster. Every index 0 to N-1 must be assigned.
- Use as few clusters as faithfully captures the semantic distinctions. Do not over-fragment over trivial differences.

Output format: a single JSON object with one field, "clusters", whose value is an array of cluster objects. Each cluster object has two fields:
- "label": a short canonical string representing the cluster's answer (e.g., "Leo Tolstoy", "1869")
- "members": a sorted array of integer indices (0-indexed) of the answers in that cluster

Example output:
{"clusters": [
  {"label": "Leo Tolstoy", "members": [0, 1, 3, 5, 8, 12, 15, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46, 49]},
  {"label": "Fyodor Dostoevsky", "members": [2, 6, 11, 17, 24, 30, 38, 44]},
  {"label": "Anton Chekhov", "members": [4, 9, 14, 20, 27, 33, 41, 47]},
  {"label": "I don't know", "members": [7, 10, 13, 16, 18, 21, 23, 26, 29, 32, 35, 36, 39, 42, 45, 48]}
]}

Output ONLY the JSON object, with no preamble, no code fences, no commentary."""


def extract_answer(raw):
    if not raw:
        return "", "fallback_tail"
    m = ANS_RE.search(raw)
    if m:
        ans = m.group(1).strip()
        if ans and ans.lower() not in NULL_ANS:
            return ans, "answer_line"
    return raw[-200:].strip(), "fallback_tail"


def extract_conf(raw):
    if not raw:
        return None, "missing"
    m = CONF_RE.search(raw)
    if not m:
        return None, "missing"
    try:
        v = float(m.group(1)) / 100.0
    except ValueError:
        return None, "missing"
    return max(0.0, min(1.0, v)), "regex_match"


def main():
    gold = {}
    with open(GOLD_FILE) as f:
        for l in f:
            d = json.loads(l)
            gold[d["qid"]] = d

    # Dedup: prefer successful with text
    q_samples = defaultdict(dict)  # qid -> {sample_idx: text}
    sources = (
        sorted(glob.glob(os.path.join(BATCH_DIR, "gemini_batch_raw.jsonl")))
        + sorted(glob.glob(os.path.join(BATCH_DIR, "gemini_raw_w*.jsonl")))
    )
    total, ok = 0, 0
    for path in sources:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                total += 1
                try:
                    r = json.loads(line)
                except Exception:
                    continue
                if r.get("status") != "success":
                    continue
                text = r.get("text")
                if not text:
                    continue
                ok += 1
                cid = r.get("custom_id", "")
                if "__sample" not in cid:
                    continue
                qid, samp = cid.split("__sample")
                idx = int(samp)
                # Prefer first good hit (deduplicate)
                if idx not in q_samples[qid]:
                    q_samples[qid][idx] = text

    print(f"Read {total} lines, {ok} success", flush=True)
    complete = {qid: s for qid, s in q_samples.items() if len(s) == 50}
    incomplete = [(qid, len(s)) for qid, s in q_samples.items() if len(s) != 50]
    print(f"Total qids: {len(q_samples)}, complete 50/50: {len(complete)}, incomplete: {len(incomplete)}", flush=True)
    if incomplete:
        print(f"  incomplete sample counts: {sorted(set(v for _, v in incomplete))[:10]}", flush=True)

    os.makedirs(os.path.dirname(EXTRACTED), exist_ok=True)
    os.makedirs(os.path.dirname(BATCH_OUT), exist_ok=True)

    fallback_count = 0
    missing_conf_count = 0
    all_conf = []
    extracted_rows, batch_rows = [], []

    for qid in sorted(complete):
        samples = complete[qid]
        results = [samples[i] for i in range(50)]

        ans_list, ext_method, conf_list, conf_method = [], [], [], []
        for raw in results:
            a, em = extract_answer(raw)
            c, cm = extract_conf(raw)
            ans_list.append(a); ext_method.append(em)
            conf_list.append(c); conf_method.append(cm)
            if em == "fallback_tail":
                fallback_count += 1
            if cm == "missing":
                missing_conf_count += 1
            else:
                all_conf.append(c)

        # Missing verbalized confidence is imputed as 1.0 (model didn't bother to express uncertainty -> assume max conf).
        imputed_conf = [1.0 if c is None else c for c in conf_list]
        verb_mean = sum(imputed_conf) / len(imputed_conf) if imputed_conf else 1.0
        verb_n = sum(1 for c in conf_list if c is not None)

        gold_row = gold[qid]
        extracted_rows.append({
            "id": qid,
            "question": gold_row["question_final"],
            "gold_answer": gold_row["gold_answer"],
            "model": "gemini",
            "n_samples": 50,
            "results": results,
            "answer_extracted": ans_list,
            "extraction_method": ext_method,
            "confidence_verbalized": conf_list,
            "confidence_extraction_method": conf_method,
            "verbalized_mean": verb_mean,
            "verbalized_n_extracted": verb_n,
        })

        ans_block = "\n".join(f"[{i}] {a}" for i, a in enumerate(ans_list))
        user_msg = f"Question: {gold_row['question_final']}\n\nAnswers (50 total, indexed 0 to 49):\n{ans_block}"
        batch_rows.append({
            "custom_id": f"gemini__{qid}",
            "method": "POST",
            "url": "/v1/chat/completions",
            "body": {
                "model": JUDGE_MODEL,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_msg},
                ],
                "reasoning_effort": "none",
                "temperature": 0.0,
                "max_completion_tokens": 1500,
                "response_format": {"type": "json_object"},
                "seed": 0,
            },
        })

    with open(EXTRACTED, "w") as f:
        for r in extracted_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"Wrote {len(extracted_rows)} rows -> {EXTRACTED}", flush=True)

    with open(BATCH_OUT, "w") as f:
        for r in batch_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"Wrote {len(batch_rows)} rows -> {BATCH_OUT}", flush=True)

    total_samples = len(complete) * 50
    print(f"\n=== Step 1 stats (Gemini, P3 MATH+AIME) ===", flush=True)
    print(f"  samples: {total_samples}", flush=True)
    print(f"  fallback (answer): {fallback_count} ({fallback_count*100/max(1,total_samples):.2f}%)", flush=True)
    print(f"  missing (confidence): {missing_conf_count} ({missing_conf_count*100/max(1,total_samples):.2f}%)", flush=True)
    if all_conf:
        print(f"  mean verbalized conf: {statistics.mean(all_conf):.3f}  median: {statistics.median(all_conf):.3f}", flush=True)

    n_calls = len(batch_rows)
    in_tok = 2500 * n_calls
    out_tok = 500 * n_calls
    cost = in_tok * (1.25 / 2 / 1e6) + out_tok * (10.0 / 2 / 1e6)
    print(f"\n=== Cost estimate ===\n  calls: {n_calls}  est: ${cost:.2f}", flush=True)


if __name__ == "__main__":
    main()
