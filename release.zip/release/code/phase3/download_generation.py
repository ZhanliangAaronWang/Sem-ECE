"""Phase 3 — Download completed generation batch outputs from OpenAI, xAI, and Mistral.

Writes to phase3/batch_outputs/:
  - openai_math_chunk{0..6}.jsonl  (OpenAI batch envelope format; custom_id={qid}__chunk{ci})
  - xai_raw_chunk0.jsonl           (flat format: {custom_id, status, text, usage}; custom_id={qid}__sample{NN})
  - mistral_raw_chunk0.jsonl       (Mistral envelope format; custom_id={qid}__sample{NN})

Does NOT overwrite existing files.
"""
import os, json, time, sys
import requests
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
load_dotenv(os.path.join(CAL_BASE, "phase1", ".env"), override=True)

STATE_FILE = os.path.join(BASE, "batch_state.json")
OUTPUT_DIR = os.path.join(BASE, "batch_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)


def download_openai(state):
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    chunks = state.get("openai", {}).get("chunks", [])
    for ch in chunks:
        ci = ch["chunk"]
        out_path = os.path.join(OUTPUT_DIR, f"openai_math_chunk{ci}.jsonl")
        if os.path.exists(out_path) and os.path.getsize(out_path) > 0:
            print(f"  openai chunk{ci}: already exists ({os.path.getsize(out_path):,} bytes), skipping", flush=True)
            continue
        # Retrieve batch to get output_file_id
        b = client.batches.retrieve(ch["batch_id"])
        if b.status != "completed":
            print(f"  openai chunk{ci}: status={b.status}, skipping", flush=True)
            continue
        fid = b.output_file_id
        print(f"  openai chunk{ci}: downloading {fid}", flush=True)
        file_resp = client.files.content(fid)
        data = file_resp.read() if hasattr(file_resp, "read") else file_resp.content
        with open(out_path, "wb") as f:
            f.write(data)
        ch["output_file_id"] = fid
        print(f"    wrote {out_path} ({len(data):,} bytes)", flush=True)


def download_xai(state):
    """xAI batch results use pagination (100 per page). Each page returns
    'results' list of {batch_request_id, batch_result: {response: {chat_get_completion: ...}}}.

    We flatten into the P2-compatible format: {custom_id, status, text, usage}
    so prep_xai.py can reuse the same logic.
    """
    key = os.environ["XAI_API_KEY"]
    chunks = state.get("xai", {}).get("chunks", [])
    for ch in chunks:
        ci = ch["chunk"]
        out_path = os.path.join(OUTPUT_DIR, f"xai_raw_chunk{ci}.jsonl")
        if os.path.exists(out_path) and os.path.getsize(out_path) > 0:
            print(f"  xai chunk{ci}: already exists ({os.path.getsize(out_path):,} bytes), skipping", flush=True)
            continue
        bid = ch["batch_id"]
        print(f"  xai chunk{ci}: paginating results for {bid}", flush=True)
        n_rows = 0
        n_success = 0
        n_error = 0
        page_token = None
        with open(out_path, "w") as out_f:
            while True:
                url = f"https://api.x.ai/v1/batches/{bid}/results"
                params = {}
                if page_token:
                    params["pagination_token"] = page_token
                for attempt in range(6):
                    try:
                        r = requests.get(url, headers={"Authorization": f"Bearer {key}"}, params=params, timeout=120)
                        if r.status_code == 200:
                            break
                        print(f"    HTTP {r.status_code}: {r.text[:200]}", flush=True)
                    except Exception as e:
                        print(f"    attempt {attempt+1}: {e}", flush=True)
                    time.sleep(min(60, 5 * 2 ** attempt))
                else:
                    raise RuntimeError(f"xAI page fetch failed for bid={bid} token={page_token}")
                data = r.json()
                results = data.get("results", [])
                for item in results:
                    cid = item.get("batch_request_id", "")
                    br = item.get("batch_result", {}) or {}
                    resp = br.get("response", {}) or {}
                    cgc = resp.get("chat_get_completion", {}) or {}
                    choices = cgc.get("choices", []) or []
                    if choices:
                        text = choices[0].get("message", {}).get("content", "") or ""
                        status = "success"
                        n_success += 1
                    else:
                        text = ""
                        status = "error"
                        n_error += 1
                    usage = cgc.get("usage", {}) or {}
                    flat = {
                        "custom_id": cid,
                        "status": status,
                        "text": text,
                        "usage": usage,
                    }
                    out_f.write(json.dumps(flat, ensure_ascii=False) + "\n")
                    n_rows += 1
                page_token = data.get("pagination_token")
                if not page_token:
                    break
                if n_rows % 2000 == 0:
                    print(f"    ... {n_rows} rows so far (next token: {page_token})", flush=True)
        print(f"    wrote {out_path} ({n_rows} rows; success={n_success} error={n_error})", flush=True)


def download_mistral(state):
    from mistralai.client import Mistral
    client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
    chunks = state.get("mistral", {}).get("chunks", [])
    for ch in chunks:
        ci = ch["chunk"]
        out_path = os.path.join(OUTPUT_DIR, f"mistral_raw_chunk{ci}.jsonl")
        if os.path.exists(out_path) and os.path.getsize(out_path) > 0:
            print(f"  mistral chunk{ci}: already exists ({os.path.getsize(out_path):,} bytes), skipping", flush=True)
            continue
        job = client.batch.jobs.get(job_id=ch["batch_id"])
        output_file = getattr(job, "output_file", None)
        if not output_file:
            print(f"  mistral chunk{ci}: no output_file attr, status={job.status}", flush=True)
            continue
        print(f"  mistral chunk{ci}: downloading {output_file}", flush=True)
        resp = client.files.download(file_id=output_file)
        content = resp.read() if hasattr(resp, "read") else bytes(resp)
        with open(out_path, "wb") as f:
            f.write(content)
        ch["output_file_id"] = output_file
        print(f"    wrote {out_path} ({len(content):,} bytes)", flush=True)


def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)


def main():
    with open(STATE_FILE) as f:
        state = json.load(f)

    providers = sys.argv[1:] or ["openai", "xai", "mistral"]
    if "openai" in providers:
        print("=== Downloading OpenAI ===", flush=True)
        download_openai(state)
        save_state(state)
    if "xai" in providers:
        print("\n=== Downloading xAI ===", flush=True)
        download_xai(state)
        save_state(state)
    if "mistral" in providers:
        print("\n=== Downloading Mistral ===", flush=True)
        download_mistral(state)
        save_state(state)
    print("\nDone.", flush=True)


if __name__ == "__main__":
    main()
