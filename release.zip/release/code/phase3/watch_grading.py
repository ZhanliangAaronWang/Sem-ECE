"""Phase 3 grading watcher.

Polls the 3 OpenAI grading batch IDs (openai/xai/mistral) every 10 minutes.
When all 3 are terminal:
  - Runs `phase3/grading/collect_and_check.py --providers openai xai mistral`
    to download grading outputs and write `{provider}_simpleqa_graded.jsonl`.
  - Runs `phase3/confidence/compute_ece.py --providers openai xai mistral
    --impute-verbalized 1.0`.
  - Writes marker file `phase3/.grading_done`.

Safe to re-run: collect overwrites its outputs; compute_ece overwrites CSV.
"""
import os, sys, json, time, subprocess
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI

GRADING_DIR = os.path.join(ROOT, "phase3", "grading")
CONF_DIR = os.path.join(ROOT, "phase3", "confidence")
BATCH_IDS_FILE = os.path.join(GRADING_DIR, "batch_ids.json")
DONE_MARKER = os.path.join(ROOT, "phase3", ".grading_done")

POLL_INTERVAL = 600   # 10 min
MAX_HOURS = 30        # safety

PROVIDERS = ["openai", "xai", "mistral"]
TERMINAL = {"completed", "failed", "expired", "cancelled"}

client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])


def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)


def load_batch_ids():
    with open(BATCH_IDS_FILE) as f:
        return json.load(f)


def poll_all():
    """Return (all_terminal, status_by_provider)."""
    bids = load_batch_ids()
    status_by_prov = {}
    all_done = True
    for prov in PROVIDERS:
        if prov not in bids:
            log(f"  {prov}: missing from batch_ids.json")
            all_done = False
            status_by_prov[prov] = "missing"
            continue
        bid = bids[prov]["batch_id"]
        try:
            b = client.batches.retrieve(bid)
            rc = b.request_counts
            log(f"  {prov} ({bid}): {b.status}  done={rc.completed}/{rc.total} fail={rc.failed}")
            status_by_prov[prov] = b.status
            if b.status not in TERMINAL:
                all_done = False
        except Exception as e:
            log(f"  {prov} retrieve error: {e}")
            status_by_prov[prov] = "error"
            all_done = False
    return all_done, status_by_prov


def run_cmd(cmd, tag):
    log(f"Running {tag}: {' '.join(cmd)}")
    res = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log(f"{tag} exit={res.returncode}")
    for line in res.stdout.splitlines():
        log(f"  [{tag}] {line}")
    return res.returncode == 0


def main():
    log(f"Phase 3 grading watcher starting. Poll interval={POLL_INTERVAL}s, max_hours={MAX_HOURS}")
    log(f"ROOT={ROOT}")
    start = time.time()
    while True:
        elapsed_h = (time.time() - start) / 3600
        if elapsed_h > MAX_HOURS:
            log(f"MAX_HOURS ({MAX_HOURS}) exceeded. Exiting.")
            sys.exit(2)

        all_done, status_by_prov = poll_all()
        log(f"Poll summary: " + "  ".join(f"{p}={status_by_prov.get(p, '?')}" for p in PROVIDERS))

        if all_done:
            log("All 3 grading batches terminal. Running collect_and_check + compute_ece.")

            collect_cmd = [
                sys.executable, "-u",
                os.path.join(GRADING_DIR, "collect_and_check.py"),
                "--providers", *PROVIDERS,
            ]
            ok_collect = run_cmd(collect_cmd, "collect_and_check")

            ece_cmd = [
                sys.executable, "-u",
                os.path.join(CONF_DIR, "compute_ece.py"),
                "--providers", *PROVIDERS,
                "--impute-verbalized", "1.0",
            ]
            ok_ece = run_cmd(ece_cmd, "compute_ece")

            with open(DONE_MARKER, "w") as f:
                f.write(json.dumps({
                    "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    "status_by_provider": status_by_prov,
                    "collect_ok": ok_collect,
                    "ece_ok": ok_ece,
                }, indent=2))
            log(f"Wrote marker: {DONE_MARKER}")
            if not (ok_collect and ok_ece):
                log("Watcher done with FAILURES -- inspect logs.")
                sys.exit(1)
            log("Watcher done OK.")
            return

        log(f"Sleeping {POLL_INTERVAL}s (elapsed={elapsed_h:.2f}h)")
        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    main()
