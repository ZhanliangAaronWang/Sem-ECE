"""Monitor all Phase 3 MATH+AIME generation batches. Sends email when done."""
import os, json, time, subprocess, glob
from email.mime.text import MIMEText
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
load_dotenv(os.path.join(CAL_BASE, "phase1", ".env"), override=True)

STATE_FILE = os.path.join(BASE, "batch_state.json")
OUTPUT_DIR = os.path.join(BASE, "batch_outputs")
POLL_INTERVAL = 300
TARGET_PER_PROVIDER = 28000  # 560 q × 50 samples


def check_openai(state):
    from openai import OpenAI
    c = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    chunks = state.get("openai", {}).get("chunks", [])
    total = done = failed = 0
    for ch in chunks:
        try:
            b = c.batches.retrieve(ch["batch_id"])
            rc = b.request_counts
            total += rc.total
            done += rc.completed
            failed += rc.failed
            ch["last_status"] = b.status
        except Exception:
            pass
    all_terminal = all(ch.get("last_status") in ("completed", "failed", "expired", "cancelled") for ch in chunks)
    return {"provider": "openai", "total": total, "done": done, "failed": failed, "terminal": all_terminal}


def check_gemini(state):
    n_success = 0
    for p in glob.glob(os.path.join(OUTPUT_DIR, "gemini_*.jsonl")):
        with open(p) as f:
            for l in f:
                try:
                    r = json.loads(l)
                    if r.get("status") == "success":
                        n_success += 1
                except Exception:
                    pass
    return {"provider": "gemini", "total": TARGET_PER_PROVIDER, "done": n_success, "failed": 0,
            "terminal": n_success >= TARGET_PER_PROVIDER}


def check_xai(state):
    import requests
    key = os.environ["XAI_API_KEY"]
    chunks = state.get("xai", {}).get("chunks", [])
    total = done = failed = 0
    all_terminal = True
    for ch in chunks:
        try:
            r = requests.get(
                f"https://api.x.ai/v1/batches/{ch['batch_id']}",
                headers={"Authorization": f"Bearer {key}"},
                timeout=30,
            )
            if r.status_code == 200:
                b = r.json()
                ch["last_status"] = b.get("state", {})
                st_obj = b.get("state", {})
                n_req = st_obj.get("num_requests", 0)
                n_succ = st_obj.get("num_success", 0)
                n_fail = st_obj.get("num_failed", 0)
                n_done = n_succ + n_fail
                total += n_req
                done += n_succ
                failed += n_fail
                if b.get("state_type") not in ("completed", "failed", "cancelled", "expired"):
                    if n_req == 0 or n_done < n_req:
                        all_terminal = False
        except Exception:
            all_terminal = False
    return {"provider": "xai", "total": total or TARGET_PER_PROVIDER, "done": done, "failed": failed, "terminal": all_terminal}


def check_mistral(state):
    from mistralai.client import Mistral
    c = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
    chunks = state.get("mistral", {}).get("chunks", [])
    total_done = 0
    all_terminal = True
    for ch in chunks:
        try:
            job = c.batch.jobs.get(job_id=ch["batch_id"])
            st = str(job.status).upper()
            ch["last_status"] = st
            if "SUCCESS" in st or "COMPLETED" in st:
                total_done += ch["n_rows"]
            elif "FAIL" in st or "CANCEL" in st or "EXPIRE" in st:
                pass
            else:
                all_terminal = False
        except Exception:
            all_terminal = False
    return {"provider": "mistral", "total": TARGET_PER_PROVIDER, "done": total_done, "failed": 0, "terminal": all_terminal}


def send_email(subject, body):
    try:
        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = "monitor@calibration"
        msg["To"] = os.environ.get("NOTIFY_EMAIL", "anonymous@example.invalid")
        proc = subprocess.run(
            ["sendmail", "-t"], input=msg.as_string(), capture_output=True, text=True, timeout=30,
        )
        if proc.returncode == 0:
            print("Email sent.", flush=True)
        else:
            with open(os.path.join(BASE, "NOTIFICATION.txt"), "w") as f:
                f.write(f"Subject: {subject}\n\n{body}\n")
            print("Email fail, wrote NOTIFICATION.txt", flush=True)
    except Exception as e:
        with open(os.path.join(BASE, "NOTIFICATION.txt"), "w") as f:
            f.write(f"Subject: {subject}\n\n{body}\n")
        print(f"Email error: {e}", flush=True)


def main():
    print("Phase 3 Monitor started", flush=True)
    email_sent = False

    while True:
        try:
            with open(STATE_FILE) as f:
                state = json.load(f)
        except Exception:
            state = {}

        results = []
        for checker in [check_openai, check_gemini, check_xai, check_mistral]:
            try:
                r = checker(state)
                results.append(r)
            except Exception as e:
                results.append({"provider": checker.__name__.replace("check_", ""),
                               "total": 0, "done": 0, "failed": 0, "terminal": False,
                               "error": str(e)[:100]})

        with open(STATE_FILE, "w") as f:
            json.dump(state, f, indent=2)

        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"\n[{ts}] Phase 3 Status:", flush=True)
        all_done = True
        for r in results:
            pct = r["done"] * 100 / r["total"] if r["total"] > 0 else 0
            status = "DONE" if r["terminal"] else "running"
            print(f"  {r['provider']:10s}: {r['done']:>6d}/{r['total']:<6d} ({pct:5.1f}%) [{status}]  fail={r['failed']}", flush=True)
            if not r["terminal"]:
                all_done = False

        if all_done and not email_sent:
            body = f"Phase 3 MATH+AIME Generation Complete\n\n"
            for r in results:
                body += f"  {r['provider']}: {r['done']}/{r['total']} (fail={r['failed']})\n"
            body += f"\nTimestamp: {ts}\n"
            send_email("[Calibration] Phase 3 MATH+AIME Generation COMPLETE", body)
            email_sent = True
            print("\nAll done. Exiting.", flush=True)
            break

        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    main()
