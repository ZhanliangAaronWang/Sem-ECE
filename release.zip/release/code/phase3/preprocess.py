"""Phase 3 preprocessing: MATH-500 + AIME 2024 + AIME 2025.

Produces data/phase3/math_preprocessed.jsonl with unified schema:
{qid, question_final, gold_answer, dataset, metadata}
"""
import os, json, statistics, random
from datasets import load_dataset

OUT = "/path/to/calibration/data/phase3/math_preprocessed.jsonl"


def load_math500():
    ds = load_dataset("HuggingFaceH4/MATH-500", split="test")
    rows = []
    for i, r in enumerate(ds):
        rows.append({
            "qid": f"math500_{r['unique_id'].replace('/', '_').replace('.json', '')}",
            "question_final": r["problem"].strip(),
            "gold_answer": str(r["answer"]).strip(),
            "dataset": "math500",
            "metadata": {"subject": r["subject"], "level": r["level"]},
        })
    return rows


def load_aime2024():
    ds = load_dataset("HuggingFaceH4/aime_2024", split="train")
    rows = []
    for r in ds:
        rows.append({
            "qid": f"aime2024_{r['id']}",
            "question_final": r["problem"].strip(),
            "gold_answer": str(r["answer"]).strip(),
            "dataset": "aime2024",
            "metadata": {"year": r.get("year", 2024)},
        })
    return rows


def load_aime2025():
    ds = load_dataset("math-ai/aime25", split="test")
    rows = []
    for r in ds:
        rows.append({
            "qid": f"aime2025_{r['id']}",
            "question_final": r["problem"].strip(),
            "gold_answer": str(r["answer"]).strip(),
            "dataset": "aime2025",
            "metadata": {"year": 2025},
        })
    return rows


def main():
    all_rows = []
    for loader, name in [(load_math500, "MATH-500"),
                         (load_aime2024, "AIME 2024"),
                         (load_aime2025, "AIME 2025")]:
        rows = loader()
        print(f"  {name}: {len(rows)}", flush=True)
        all_rows.extend(rows)

    with open(OUT, "w") as f:
        for r in all_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"\nWrote {len(all_rows)} rows -> {OUT}", flush=True)

    # Stats
    from collections import Counter
    ds_counts = Counter(r["dataset"] for r in all_rows)
    print(f"\nBy dataset: {dict(ds_counts)}", flush=True)
    q_lens = [len(r["question_final"]) for r in all_rows]
    a_lens = [len(r["gold_answer"]) for r in all_rows]
    print(f"Question length: mean={statistics.mean(q_lens):.0f}, median={statistics.median(q_lens):.0f}", flush=True)
    print(f"Answer length: mean={statistics.mean(a_lens):.1f}, median={statistics.median(a_lens):.0f}", flush=True)

    # 3 samples
    random.seed(0)
    print(f"\n=== 3 random samples ===", flush=True)
    for r in random.sample(all_rows, 3):
        print(json.dumps(r, indent=2, ensure_ascii=False)[:600])
        print()


if __name__ == "__main__":
    main()
