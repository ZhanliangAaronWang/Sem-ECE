"""Submit Phase 3 (MATH-500 + AIME) generation batches for all 4 providers."""
import os, json, time, math, glob
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
load_dotenv(os.path.join(CAL_BASE, "phase1", ".env"), override=True)

BATCH_DIR = os.path.join(BASE, "batch_inputs")
STATE_FILE = os.path.join(BASE, "batch_state.json")


def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            return json.load(f)
    return {}


def save_state(s):
    with open(STATE_FILE, "w") as f:
        json.dump(s, f, indent=2)


def submit_openai(state):
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    if "openai" not in state:
        state["openai"] = {"chunks": []}
    existing = {c["chunk"] for c in state["openai"]["chunks"]}

    for ci in range(7):
        if ci in existing:
            continue
        path = os.path.join(BATCH_DIR, f"openai_math_chunk{ci}.jsonl")
        for attempt in range(8):
            try:
                with open(path, "rb") as f:
                    fobj = client.files.create(file=f, purpose="batch")
                batch = client.batches.create(
                    input_file_id=fobj.id, endpoint="/v1/chat/completions",
                    completion_window="24h",
                    metadata={"phase": "phase3_gen", "provider": "openai", "chunk": str(ci)},
                )
                print(f"  openai chunk{ci}: {batch.id} {batch.status}", flush=True)
                state["openai"]["chunks"].append({
                    "chunk": ci, "batch_id": batch.id, "n_rows": 560,
                    "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                })
                save_state(state)
                break
            except Exception as e:
                print(f"  openai chunk{ci} attempt {attempt+1}: {str(e)[:120]}", flush=True)
                time.sleep(min(60, 5 * 2 ** attempt))


def submit_gemini(state):
    from google import genai
    from google.genai import types
    client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])
    if "gemini" not in state:
        state["gemini"] = {"batches": []}

    all_rows = []
    with open(os.path.join(BATCH_DIR, "gemini_math.jsonl")) as f:
        for line in f:
            all_rows.append(json.loads(line))

    submitted = set()
    for b in state["gemini"]["batches"]:
        submitted.update(b.get("custom_ids", []))
    remaining = [r for r in all_rows if r["custom_id"] not in submitted]
    if not remaining:
        return

    # Start with 5000-row chunks (what worked for Phase 2)
    chunk_size = 5000
    n_chunks = math.ceil(len(remaining) / chunk_size)
    print(f"  gemini: {len(remaining)} rows, {n_chunks} chunks of {chunk_size}", flush=True)

    for ci in range(n_chunks):
        chunk = remaining[ci * chunk_size:(ci + 1) * chunk_size]
        inlined = []
        for r in chunk:
            cfg = r["config"]
            inlined.append({
                "contents": r["contents"],
                "config": {
                    "system_instruction": cfg["system_instruction"],
                    "max_output_tokens": cfg["max_output_tokens"],
                    "temperature": cfg["temperature"],
                    "top_p": cfg["top_p"],
                    "thinking_config": {"thinking_budget": cfg["thinking_config"]["thinking_budget"]},
                    "seed": cfg.get("seed"),
                },
                "metadata": {"custom_id": r["custom_id"]},
            })
        try:
            job = client.batches.create(
                model="gemini-3-flash-preview",
                src=inlined,
                config=types.CreateBatchJobConfig(display_name=f"math_gen_{ci}"),
            )
            print(f"  gemini batch {ci}: {job.name}", flush=True)
            state["gemini"]["batches"].append({
                "name": job.name, "n_rows": len(chunk),
                "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "custom_ids": [r["custom_id"] for r in chunk],
            })
            save_state(state)
        except Exception as e:
            print(f"  gemini batch {ci} FAILED: {str(e)[:150]}", flush=True)
            print(f"  Stopping gemini. {ci} submitted.", flush=True)
            break


def submit_xai(state):
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["XAI_API_KEY"], base_url="https://api.x.ai/v1")
    if "xai" not in state:
        state["xai"] = {"chunks": []}
    existing = {c["chunk"] for c in state["xai"]["chunks"]}

    path = os.path.join(BATCH_DIR, "xai_math.jsonl")
    with open(path) as f:
        all_lines = f.readlines()

    chunk_size = 50000
    n_chunks = math.ceil(len(all_lines) / chunk_size)

    for ci in range(n_chunks):
        if ci in existing:
            continue
        chunk_lines = all_lines[ci * chunk_size:(ci + 1) * chunk_size]
        tmp = f"/tmp/xai_math_chunk{ci}.jsonl"
        with open(tmp, "w") as f:
            f.writelines(chunk_lines)
        for attempt in range(5):
            try:
                with open(tmp, "rb") as f:
                    fobj = client.files.create(
                        file=(os.path.basename(tmp), f.read(), "application/jsonl"),
                        purpose="batch",
                    )
                batch = client.batches.create(
                    input_file_id=fobj.id, endpoint="/v1/chat/completions",
                    completion_window="24h",
                )
                print(f"  xai chunk{ci}: {batch.id} ({len(chunk_lines)} rows)", flush=True)
                state["xai"]["chunks"].append({
                    "chunk": ci, "batch_id": batch.id, "n_rows": len(chunk_lines),
                    "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                })
                save_state(state)
                break
            except Exception as e:
                print(f"  xai chunk{ci} attempt {attempt+1}: {str(e)[:150]}", flush=True)
                time.sleep(min(60, 5 * 2 ** attempt))


def submit_mistral(state):
    from mistralai.client import Mistral
    client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
    if "mistral" not in state:
        state["mistral"] = {"chunks": []}
    existing = {c["chunk"] for c in state["mistral"]["chunks"]}

    chunk_files = sorted(glob.glob(os.path.join(BATCH_DIR, "mistral_math_chunk*.jsonl")))
    if not chunk_files:
        chunk_files = [os.path.join(BATCH_DIR, "mistral_math.jsonl")]

    for ci, path in enumerate(chunk_files):
        if ci in existing:
            continue
        n_rows = sum(1 for _ in open(path))
        for attempt in range(5):
            try:
                with open(path, "rb") as f:
                    batch_data = client.files.upload(
                        file={"file_name": os.path.basename(path), "content": f.read()},
                        purpose="batch",
                    )
                job = client.batch.jobs.create(
                    input_files=[batch_data.id],
                    model="mistral-large-latest",
                    endpoint="/v1/chat/completions",
                    metadata={"phase": "phase3", "chunk": str(ci)},
                )
                print(f"  mistral chunk{ci}: {job.id} ({n_rows} rows)", flush=True)
                state["mistral"]["chunks"].append({
                    "chunk": ci, "batch_id": job.id, "file_id": batch_data.id,
                    "n_rows": n_rows,
                    "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                })
                save_state(state)
                break
            except Exception as e:
                print(f"  mistral chunk{ci} attempt {attempt+1}: {str(e)[:200]}", flush=True)
                time.sleep(min(60, 5 * 2 ** attempt))


def main():
    state = load_state()

    print("=== OpenAI ===", flush=True)
    submit_openai(state)

    print("\n=== Gemini ===", flush=True)
    submit_gemini(state)

    print("\n=== xAI ===", flush=True)
    submit_xai(state)

    print("\n=== Mistral ===", flush=True)
    submit_mistral(state)

    print(f"\nDone. State -> {STATE_FILE}", flush=True)


if __name__ == "__main__":
    main()
