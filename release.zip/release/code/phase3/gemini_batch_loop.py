"""Sequential Gemini batch submission loop for Phase 3 (MATH+AIME).

Submits 5000-row batches one at a time, waiting for each to complete
before submitting the next. 28,000 / 5000 = 6 batches.
"""
import os, json, time, glob
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
load_dotenv(os.path.join(CAL_BASE, "phase1", ".env"), override=True)

from google import genai
from google.genai import types

INPUT_FILE = os.path.join(BASE, "batch_inputs", "gemini_math.jsonl")
OUTPUT_DIR = os.path.join(BASE, "batch_outputs")
STATE_FILE = os.path.join(BASE, "gemini_batch_state.json")
MASTER_OUT = os.path.join(OUTPUT_DIR, "gemini_batch_raw.jsonl")
CHUNK_SIZE = 5000
TARGET = 28000

os.makedirs(OUTPUT_DIR, exist_ok=True)
client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])


def get_done_ids():
    done = set()
    for p in glob.glob(os.path.join(OUTPUT_DIR, "gemini_*.jsonl")):
        with open(p) as f:
            for l in f:
                try:
                    r = json.loads(l)
                    if r.get("status") == "success":
                        done.add(r["custom_id"])
                except:
                    pass
    return done


def collect_job(job_name, done_ids):
    job = client.batches.get(name=job_name)
    state = str(job.state).split(".")[-1]
    if state != "JOB_STATE_SUCCEEDED":
        return 0, state
    dest = getattr(job, "dest", None)
    inlined = getattr(dest, "inlined_responses", None) if dest else None
    if not inlined:
        return 0, state
    new = 0
    with open(MASTER_OUT, "a") as f:
        for resp in inlined:
            md = getattr(resp, "metadata", None) or {}
            cid = md.get("custom_id", "")
            if cid in done_ids:
                continue
            response = getattr(resp, "response", None)
            if not response:
                continue
            try:
                text = response.text
            except:
                continue
            um = getattr(response, "usage_metadata", None)
            f.write(json.dumps({
                "custom_id": cid, "text": text,
                "prompt_tokens": getattr(um, "prompt_token_count", None) if um else None,
                "completion_tokens": getattr(um, "candidates_token_count", None) if um else None,
                "status": "success",
            }, ensure_ascii=False) + "\n")
            new += 1
            done_ids.add(cid)
    return new, state


def main():
    all_rows = []
    with open(INPUT_FILE) as f:
        for l in f:
            all_rows.append(json.loads(l))

    state = []
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE) as f:
            state = json.load(f)

    done_ids = get_done_ids()
    print(f"Starting. Done: {len(done_ids)}/{TARGET}", flush=True)

    # Collect any previously completed
    for s in state:
        if s.get("collected"):
            continue
        n, st = collect_job(s["name"], done_ids)
        if st == "JOB_STATE_SUCCEEDED":
            s["collected"] = True
        elif st in ("JOB_STATE_FAILED", "JOB_STATE_CANCELLED", "JOB_STATE_EXPIRED"):
            s["collected"] = True
            s["failed"] = True
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

    while len(done_ids) < TARGET:
        remaining = [r for r in all_rows if r["custom_id"] not in done_ids]
        if not remaining:
            break
        print(f"\nDone: {len(done_ids)}/{TARGET}, remaining: {len(remaining)}", flush=True)

        chunk = remaining[:CHUNK_SIZE]
        inlined = []
        for r in chunk:
            cfg = r["config"]
            inlined.append({
                "contents": r["contents"],
                "config": {
                    "system_instruction": cfg["system_instruction"],
                    "max_output_tokens": cfg["max_output_tokens"],
                    "temperature": cfg["temperature"],
                    "top_p": cfg["top_p"],
                    "thinking_config": {"thinking_budget": cfg["thinking_config"]["thinking_budget"]},
                    "seed": cfg.get("seed"),
                },
                "metadata": {"custom_id": r["custom_id"]},
            })

        try:
            job = client.batches.create(
                model="gemini-3-flash-preview",
                src=inlined,
                config=types.CreateBatchJobConfig(display_name=f"math_seq_{len(state)}"),
            )
            print(f"  submitted: {job.name} ({len(chunk)} rows)", flush=True)
            entry = {"name": job.name, "n_rows": len(chunk),
                     "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%S")}
            state.append(entry)
            with open(STATE_FILE, "w") as f:
                json.dump(state, f, indent=2)
        except Exception as e:
            print(f"  submit failed: {str(e)[:200]}", flush=True)
            print(f"  waiting 10 min and retrying...", flush=True)
            time.sleep(600)
            continue

        # Poll until done
        while True:
            time.sleep(60)
            try:
                j = client.batches.get(name=job.name)
                st = str(j.state).split(".")[-1]
                print(f"    [{time.strftime('%H:%M')}] {st}", flush=True)
                if st in ("JOB_STATE_SUCCEEDED", "JOB_STATE_FAILED", "JOB_STATE_CANCELLED", "JOB_STATE_EXPIRED"):
                    break
            except:
                pass

        done_ids = get_done_ids()
        n, st = collect_job(job.name, done_ids)
        entry["collected"] = True
        if st != "JOB_STATE_SUCCEEDED":
            entry["failed"] = True
        print(f"  collected: +{n} rows, total: {len(done_ids)}", flush=True)
        with open(STATE_FILE, "w") as f:
            json.dump(state, f, indent=2)

    print(f"\nDone! {len(done_ids)}/{TARGET}", flush=True)


if __name__ == "__main__":
    main()
