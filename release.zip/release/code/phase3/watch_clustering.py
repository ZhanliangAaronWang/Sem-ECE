"""Phase 3 clustering watcher.

Polls the 3 OpenAI batch IDs (openai/xai/mistral judges) every 10 minutes.
When all 3 are terminal:
  - On `completed`: patches the {provider}_chunks.json state file with
    `final_status`, `output_file_id`, and `error_file_id`.
  - Then runs `phase3/clustering/collect_{provider}.py` for each provider
    to download outputs and write `{provider}_simpleqa_clustered.jsonl`.
  - Writes marker file `phase3/.clustering_done`.

Terminal states: completed, failed, expired, cancelled.
Only `completed` triggers collection. Failed chunks are reported in the log.

Safe to re-run: idempotent w.r.t. state files; collect scripts overwrite
their output JSONL.
"""
import os, sys, json, time, subprocess
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI

CLUSTERING_DIR = os.path.join(ROOT, "phase3", "clustering")
DONE_MARKER = os.path.join(ROOT, "phase3", ".clustering_done")

POLL_INTERVAL = 600  # 10 min
MAX_HOURS = 30       # safety: bail after 30 h

PROVIDERS = ["openai", "xai", "mistral"]
TERMINAL = {"completed", "failed", "expired", "cancelled"}

client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])


def log(msg):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{ts}] {msg}", flush=True)


def load_state(provider):
    path = os.path.join(CLUSTERING_DIR, f"{provider}_chunks.json")
    with open(path) as f:
        return path, json.load(f)


def save_state(path, state):
    with open(path, "w") as f:
        json.dump(state, f, indent=2)


def poll_provider(provider):
    """Return (all_terminal, statuses_per_chunk)."""
    path, state = load_state(provider)
    statuses = []
    all_done = True
    dirty = False
    for ch in state["chunks"]:
        if ch.get("final_status") in TERMINAL:
            statuses.append(ch["final_status"])
            continue
        bid = ch["batch_id"]
        try:
            b = client.batches.retrieve(bid)
        except Exception as e:
            log(f"  {provider} chunk {ch['chunk']} retrieve error: {e}")
            all_done = False
            statuses.append("error")
            continue
        statuses.append(b.status)
        if b.status in TERMINAL:
            ch["final_status"] = b.status
            ch["output_file_id"] = getattr(b, "output_file_id", None)
            ch["error_file_id"] = getattr(b, "error_file_id", None)
            dirty = True
            log(f"  {provider} chunk {ch['chunk']} -> {b.status}  "
                f"out={ch['output_file_id']}  err={ch['error_file_id']}")
        else:
            all_done = False
    if dirty:
        save_state(path, state)
    return all_done, statuses


def run_collect(provider):
    script = os.path.join(CLUSTERING_DIR, f"collect_{provider}.py")
    log(f"Running collect_{provider}.py ...")
    res = subprocess.run(
        [sys.executable, "-u", script],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        text=True,
    )
    log(f"collect_{provider} exit={res.returncode}")
    # echo the output so it ends up in the job log
    for line in res.stdout.splitlines():
        log(f"  [{provider}] {line}")
    return res.returncode == 0


def main():
    log(f"Watcher starting. Poll interval={POLL_INTERVAL}s, max_hours={MAX_HOURS}")
    log(f"ROOT={ROOT}")
    start = time.time()
    while True:
        elapsed_h = (time.time() - start) / 3600
        if elapsed_h > MAX_HOURS:
            log(f"MAX_HOURS ({MAX_HOURS}) exceeded. Exiting.")
            sys.exit(2)

        all_terminal_overall = True
        status_by_prov = {}
        for prov in PROVIDERS:
            done, statuses = poll_provider(prov)
            status_by_prov[prov] = statuses
            if not done:
                all_terminal_overall = False
        log(f"Poll: " + "  ".join(
            f"{p}={','.join(status_by_prov[p])}" for p in PROVIDERS
        ))

        if all_terminal_overall:
            log("All 3 providers terminal. Running collectors.")
            any_fail = False
            for prov in PROVIDERS:
                # only run collector if ALL this provider's chunks are `completed`
                _, state = load_state(prov)
                if all(c.get("final_status") == "completed" for c in state["chunks"]):
                    ok = run_collect(prov)
                    if not ok:
                        any_fail = True
                else:
                    log(f"SKIP collect_{prov}: not all chunks completed "
                        f"(states={[c.get('final_status') for c in state['chunks']]})")
                    any_fail = True

            with open(DONE_MARKER, "w") as f:
                f.write(json.dumps({
                    "completed_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    "status_by_provider": status_by_prov,
                    "collect_all_ok": not any_fail,
                }, indent=2))
            log(f"Wrote marker: {DONE_MARKER}")
            if any_fail:
                log("Watcher done with FAILURES — inspect logs.")
                sys.exit(1)
            log("Watcher done OK.")
            return

        log(f"Sleeping {POLL_INTERVAL}s (elapsed={elapsed_h:.2f}h)")
        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    main()
