"""Phase 3 Gemini one-shot pipeline watcher.

Chain:
  1. Poll clustering batch (from phase3/clustering/gemini_chunks.json)
  2. On completion: run phase3/clustering/collect_gemini.py
  3. Submit grading: phase3/grading/prep_and_submit.py --providers gemini --submit
  4. Poll grading batch
  5. On completion: run phase3/grading/collect_and_check.py (which recomputes ECE)

Writes marker file phase3/.gemini_pipeline_done when done.
"""
import os, json, time, subprocess
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI
client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

P3 = os.path.join(ROOT, "phase3")
CHUNKS_FILE = os.path.join(P3, "clustering", "gemini_chunks.json")
BATCH_IDS_FILE = os.path.join(P3, "grading", "batch_ids.json")
DONE_MARKER = os.path.join(P3, ".gemini_pipeline_done")

POLL = 300  # 5 min
TERMINAL = {"completed", "failed", "expired", "cancelled"}


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def poll_batch(batch_id, label):
    log(f"polling {label} {batch_id}")
    while True:
        b = client.batches.retrieve(batch_id)
        log(f"  {label}: {b.status}  req={b.request_counts.completed}/{b.request_counts.total}")
        if b.status in TERMINAL:
            return b
        time.sleep(POLL)


def run(cmd, cwd=None):
    log(f"$ {cmd}")
    r = subprocess.run(cmd, shell=True, cwd=cwd)
    if r.returncode != 0:
        raise RuntimeError(f"FAILED: {cmd}")


def main():
    # Step 1: poll clustering
    state = json.load(open(CHUNKS_FILE))
    for c in state["chunks"]:
        bid = c["batch_id"]
        b = poll_batch(bid, f"cluster_c{c['chunk']}")
        c["final_status"] = b.status
        if b.status == "completed":
            c["output_file_id"] = b.output_file_id
            c["error_file_id"] = b.error_file_id
    with open(CHUNKS_FILE, "w") as f:
        json.dump(state, f, indent=2)

    if not all(c.get("final_status") == "completed" for c in state["chunks"]):
        log("CLUSTERING not all completed -- aborting")
        return

    # Step 2: collect clustering
    run("python phase3/clustering/collect_gemini.py", cwd=ROOT)

    # Step 3: submit grading
    run("python phase3/grading/prep_and_submit.py --providers gemini --submit", cwd=ROOT)

    # Step 4: poll grading
    ids = json.load(open(BATCH_IDS_FILE))
    grade_bid = ids["gemini"]["batch_id"]
    b = poll_batch(grade_bid, "grading")
    if b.status != "completed":
        log(f"GRADING ended {b.status} -- aborting")
        return

    # Step 5: collect + ECE
    run("python phase3/grading/collect_and_check.py", cwd=ROOT)

    with open(DONE_MARKER, "w") as f:
        f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
    log("GEMINI PIPELINE DONE")


if __name__ == "__main__":
    main()
