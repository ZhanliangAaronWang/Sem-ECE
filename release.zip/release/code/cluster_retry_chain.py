"""Cluster-retry chain runner.

Once cluster_retry/batch_input.jsonl has been submitted (cluster_retry.py --submit),
this script:
  1. Polls the OpenAI batch every 3 min until terminal.
  2. Downloads output, parses each retry response, validates the partition.
  3. Appends newly-clustered rows to each cell's *_clustered.jsonl.
  4. Builds + submits a small grading batch for the newly-clustered rows
     (one OpenAI batch covering all 9 cells).
  5. Polls grading until terminal, downloads, appends to each *_graded.jsonl.
  6. Recomputes confidence + ECE for each phase.
  7. Re-runs experiment_n_sweep.py + experiment_bootstrap_ci.py + make_ece_figure.py.

Logs to cluster_retry/chain.log and stdout.
"""
import os, json, time, subprocess, sys, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RETRY_DIR = ROOT / "cluster_retry"
LOG = RETRY_DIR / "chain.log"
STATE = RETRY_DIR / "batch_state.json"
GRADE_STATE = RETRY_DIR / "grade_state.json"

POLL_S = 180  # 3 min
TERMINAL = {"completed", "failed", "expired", "cancelled"}

CELLS = [
    ("phase1", "openai",  "simpleqa"),
    ("phase1", "gemini",  "simpleqa"),
    ("phase1", "mistral", "simpleqa"),
    ("phase2", "openai",  "simpleqa"),
    ("phase2", "gemini",  "simpleqa"),
    ("phase2", "mistral", "simpleqa"),
    ("phase4", "openai",  "popqa"),
    ("phase4", "gemini",  "popqa"),
    ("phase4", "mistral", "popqa"),
]

GRADE_SYSTEM_PROMPT = """You are a grader for a question-answering benchmark. You will receive a question, the official gold answer, and a predicted answer. Your job is to decide whether the predicted answer is semantically equivalent to the gold answer.

Rules:
- Accept different surface forms of the same answer: "Leo Tolstoy" matches "Tolstoy"; "1869" matches "1869 AD"; "Paris, France" matches "Paris"; "1.5 mM" matches "0.0015 M".
- Reject answers that are related but specifically different: "Tolstoy" vs "Dostoevsky" is INCORRECT; "1869" vs "1865" is INCORRECT; "Paris" vs "France" is INCORRECT.
- If the predicted answer is a refusal (e.g., "I don't know", "I cannot answer", "Unknown", "N/A", empty), output NOT_ATTEMPTED.
- Be lenient on capitalization, punctuation, articles (a/the), and minor formatting.

Output format: a single JSON object with one field, "grade", whose value is exactly one of the strings "CORRECT", "INCORRECT", or "NOT_ATTEMPTED".

Output ONLY the JSON object, no preamble, no commentary."""


def log(m):
    line = f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}] {m}"
    print(line, flush=True)
    with open(LOG, "a") as f:
        f.write(line + "\n")


def run(cmd, cwd=ROOT, ok_nonzero=False):
    log(f"$ {cmd}")
    r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    log(f"  exit={r.returncode}")
    for line in (r.stdout or "").splitlines()[-30:]:
        log(f"    {line}")
    if r.stderr.strip():
        for line in r.stderr.splitlines()[-15:]:
            log(f"    [stderr] {line}")
    if r.returncode != 0 and not ok_nonzero:
        raise RuntimeError(f"command failed: {cmd}")
    return r


def get_openai():
    sys.path.insert(0, str(ROOT))
    from dotenv import load_dotenv
    load_dotenv(ROOT / "phase1" / ".env", override=True)
    from openai import OpenAI
    return OpenAI(api_key=os.environ["OPENAI_API_KEY"])


def parse_clusters(raw_text):
    if raw_text is None:
        return None, "empty response"
    txt = raw_text.strip()
    if txt.startswith("```"):
        txt = re.sub(r"^```(?:json)?\s*", "", txt)
        txt = re.sub(r"\s*```$", "", txt)
    try:
        obj = json.loads(txt)
    except Exception as e:
        return None, f"json: {e}"
    if not isinstance(obj, dict) or "clusters" not in obj:
        return None, "missing clusters"
    return obj["clusters"], None


def build_assignments(clusters, n=50):
    assignments = [-1] * n
    labels = []
    for ci, c in enumerate(clusters):
        if not isinstance(c, dict): raise ValueError(f"cluster {ci} not dict")
        labels.append(str(c.get("label", "")))
        for m in c.get("members", []):
            if not isinstance(m, int) or not (0 <= m < n):
                raise ValueError(f"bad member {m}")
            if assignments[m] != -1:
                raise ValueError(f"index {m} appears twice")
            assignments[m] = ci
    if any(a == -1 for a in assignments):
        raise ValueError(f"unassigned: {[i for i,a in enumerate(assignments) if a==-1][:5]}")
    sizes = [assignments.count(k) for k in range(len(labels))]
    return assignments, labels, sizes


# -------------------------------------------------------------------
def phase1_wait_clustering(client):
    log("=" * 80)
    log("STEP 1: poll cluster-retry batch")
    log("=" * 80)
    state = json.load(open(STATE))
    bid = state["batch_id"]
    while True:
        b = client.batches.retrieve(bid)
        rc = b.request_counts
        log(f"  cluster_retry: {b.status} {rc.completed}/{rc.total} fail={rc.failed}")
        if b.status in TERMINAL:
            if b.status != "completed":
                raise RuntimeError(f"cluster_retry failed: {b.status}")
            state["output_file_id"] = b.output_file_id
            state["error_file_id"] = b.error_file_id
            json.dump(state, open(STATE, "w"), indent=2)
            return b
        time.sleep(POLL_S)


def phase2_collect_and_merge_clusters(client):
    log("=" * 80)
    log("STEP 2: download retry output, validate, append to *_clustered.jsonl")
    log("=" * 80)
    state = json.load(open(STATE))
    fid = state["output_file_id"]
    fr = client.files.content(fid)
    raw = (fr.read() if hasattr(fr, "read") else fr.content).decode()

    # Group lines by (phase, prov)
    by_cell = {}
    for line in raw.strip().splitlines():
        if not line.strip(): continue
        jr = json.loads(line)
        cid = jr["custom_id"]   # retry__<phase>__<prov>__<qid>
        try:
            _retry, phase, prov, qid = cid.split("__", 3)
        except ValueError:
            log(f"  WARN: unexpected custom_id {cid}")
            continue
        body = jr.get("response", {}).get("body", {})
        choices = body.get("choices", [])
        raw_judge = choices[0]["message"]["content"] if choices else None
        clusters, err = parse_clusters(raw_judge)
        if err:
            log(f"  parse fail {phase}/{prov}/{qid}: {err}")
            continue
        try:
            assignments, labels, sizes = build_assignments(clusters, n=50)
        except Exception as e:
            log(f"  partition fail {phase}/{prov}/{qid}: {e}")
            continue
        modal = sizes.index(max(sizes))
        by_cell.setdefault((phase, prov), []).append({
            "id": qid,
            "n_clusters": len(labels),
            "cluster_labels": labels,
            "cluster_assignments": assignments,
            "cluster_sizes": sizes,
            "modal_cluster": modal,
            "modal_cluster_label": labels[modal],
            "raw_judge_response": raw_judge,
        })

    # For each cell, load extracted (to get question/gold), enrich each new row,
    # and append to *_clustered.jsonl.
    new_rows_count = {}
    for phase, prov, ds in CELLS:
        new_rows = by_cell.get((phase, prov), [])
        if not new_rows:
            log(f"  {phase}/{prov}: 0 new rows recovered")
            new_rows_count[(phase, prov)] = 0
            continue
        ext_path = ROOT / phase / "clustering" / f"{prov}_extracted.jsonl"
        ext = {}
        with open(ext_path) as fh:
            for line in fh:
                r = json.loads(line)
                ext[r["id"]] = r
        clustered_path = ROOT / phase / "clustering" / f"{prov}_{ds}_clustered.jsonl"
        n_appended = 0
        with open(clustered_path, "a") as fh:
            for nr in new_rows:
                ext_row = ext.get(nr["id"])
                if ext_row is None:
                    log(f"  WARN no extracted row for {nr['id']}")
                    continue
                merged = dict(ext_row)
                merged.update(nr)
                fh.write(json.dumps(merged, ensure_ascii=False) + "\n")
                n_appended += 1
        log(f"  {phase}/{prov}: appended {n_appended} rows -> {clustered_path.name}")
        new_rows_count[(phase, prov)] = n_appended
    return new_rows_count


def phase3_submit_grading(client, new_rows_count):
    log("=" * 80)
    log("STEP 3: build + submit grading batch for newly-clustered rows")
    log("=" * 80)
    grade_rows = []
    for phase, prov, ds in CELLS:
        if new_rows_count.get((phase, prov), 0) == 0:
            continue
        clustered_path = ROOT / phase / "clustering" / f"{prov}_{ds}_clustered.jsonl"
        # find the rows we just appended (by qid in retry input)
        retry_qids = set()
        with open(RETRY_DIR / "batch_input.jsonl") as fh:
            for line in fh:
                r = json.loads(line)
                cid = r["custom_id"]   # retry__<phase>__<prov>__<qid>
                parts = cid.split("__", 3)
                if len(parts) == 4 and parts[1] == phase and parts[2] == prov:
                    retry_qids.add(parts[3])
        with open(clustered_path) as fh:
            for line in fh:
                r = json.loads(line)
                if r["id"] not in retry_qids:
                    continue
                user_msg = (
                    f"Question: {r['question']}\n"
                    f"Gold answer: {r['gold_answer']}\n"
                    f"Predicted answer: {r['modal_cluster_label']}"
                )
                grade_rows.append({
                    "custom_id": f"grade__{phase}__{prov}__{r['id']}",
                    "method": "POST",
                    "url": "/v1/chat/completions",
                    "body": {
                        "model": "gpt-5.2",
                        "messages": [
                            {"role": "system", "content": GRADE_SYSTEM_PROMPT},
                            {"role": "user", "content": user_msg},
                        ],
                        "reasoning_effort": "none",
                        "temperature": 0.0,
                        "max_completion_tokens": 50,
                        "response_format": {"type": "json_object"},
                        "seed": 0,
                    },
                })
    if not grade_rows:
        log("  no rows to grade")
        return None
    grade_in = RETRY_DIR / "grade_batch_input.jsonl"
    with open(grade_in, "w") as fh:
        for r in grade_rows:
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
    log(f"  built {len(grade_rows)} grading rows -> {grade_in.name}")

    fobj = client.files.create(file=open(grade_in, "rb"), purpose="batch")
    b = client.batches.create(
        input_file_id=fobj.id,
        endpoint="/v1/chat/completions",
        completion_window="24h",
        metadata={"phase": "cluster_retry_grading"},
    )
    json.dump({"batch_id": b.id, "input_file_id": fobj.id, "n_rows": len(grade_rows)},
              open(GRADE_STATE, "w"), indent=2)
    log(f"  grading batch_id: {b.id}  status: {b.status}")
    return b.id


def phase4_wait_grading(client, bid):
    log("=" * 80)
    log("STEP 4: poll grading batch")
    log("=" * 80)
    while True:
        b = client.batches.retrieve(bid)
        rc = b.request_counts
        log(f"  grading: {b.status} {rc.completed}/{rc.total} fail={rc.failed}")
        if b.status in TERMINAL:
            if b.status != "completed":
                raise RuntimeError(f"grading failed: {b.status}")
            st = json.load(open(GRADE_STATE))
            st["output_file_id"] = b.output_file_id
            st["error_file_id"] = b.error_file_id
            json.dump(st, open(GRADE_STATE, "w"), indent=2)
            return b
        time.sleep(POLL_S)


def phase5_collect_grading(client):
    log("=" * 80)
    log("STEP 5: append grading results to *_graded.jsonl")
    log("=" * 80)
    st = json.load(open(GRADE_STATE))
    fr = client.files.content(st["output_file_id"])
    raw = (fr.read() if hasattr(fr, "read") else fr.content).decode()

    # Load clustered rows we just appended (so we can fill the graded record's
    # question / gold / modal label like the original collect_and_check.py does).
    by_phaseprov = {}
    GRADE_RE = re.compile(r'"grade"\s*:\s*"([^"]+)"', re.I)
    for line in raw.strip().splitlines():
        if not line.strip(): continue
        jr = json.loads(line)
        cid = jr["custom_id"]   # grade__<phase>__<prov>__<qid>
        _g, phase, prov, qid = cid.split("__", 3)
        body = jr.get("response", {}).get("body", {})
        choices = body.get("choices", [])
        raw_text = choices[0]["message"]["content"] if choices else None
        grade = "PARSE_ERROR"
        if raw_text:
            try:
                grade = json.loads(raw_text).get("grade", "").upper()
                if grade not in ("CORRECT", "INCORRECT", "NOT_ATTEMPTED"):
                    grade = "PARSE_ERROR"
            except Exception:
                m = GRADE_RE.search(raw_text)
                if m: grade = m.group(1).upper()
        Y = 1 if grade == "CORRECT" else (None if grade == "PARSE_ERROR" else 0)
        by_phaseprov.setdefault((phase, prov), []).append({
            "id": qid, "model": prov, "grade": grade, "Y": Y, "raw_judge_response": raw_text,
        })

    for phase, prov, ds in CELLS:
        new = by_phaseprov.get((phase, prov), [])
        if not new: continue
        # filename pattern (same legacy quirk): phase2 also uses _simpleqa_graded
        graded_path = ROOT / phase / "grading" / f"{prov}_{ds}_graded.jsonl"
        # join with clustered to fill question/gold/modal
        clustered_path = ROOT / phase / "clustering" / f"{prov}_{ds}_clustered.jsonl"
        clu_by_id = {}
        with open(clustered_path) as fh:
            for line in fh:
                r = json.loads(line)
                clu_by_id[r["id"]] = r
        with open(graded_path, "a") as fh:
            n = 0
            for r in new:
                cr = clu_by_id.get(r["id"], {})
                row = {
                    "id": r["id"], "model": prov,
                    "question": cr.get("question", ""),
                    "gold_answer": cr.get("gold_answer", ""),
                    "modal_cluster_label": cr.get("modal_cluster_label", ""),
                    "grade": r["grade"], "Y": r["Y"],
                    "raw_judge_response": r["raw_judge_response"],
                }
                fh.write(json.dumps(row, ensure_ascii=False) + "\n")
                n += 1
            log(f"  {phase}/{prov}: appended {n} graded rows")


def phase6_recompute():
    log("=" * 80)
    log("STEP 6: recompute confidence + ECE for each phase")
    log("=" * 80)
    for phase in ("phase1", "phase2", "phase4"):
        run(f"python3 compute_confidence.py", cwd=ROOT / phase / "confidence")
        run(f"python3 compute_ece.py --providers openai anthropic gemini xai mistral",
            cwd=ROOT / phase / "confidence")


def phase7_replot():
    log("=" * 80)
    log("STEP 7: re-run plots and bootstrap CI")
    log("=" * 80)
    run("python3 experiment_n_sweep.py",       cwd=ROOT)
    run("python3 experiment_bootstrap_ci.py",  cwd=ROOT)
    run("python3 make_ece_figure.py",          cwd=ROOT)


def main():
    LOG.parent.mkdir(exist_ok=True)
    log("=" * 80)
    log(f"Cluster-retry chain started ({time.strftime('%Y-%m-%dT%H:%M:%S')})")
    log("=" * 80)

    client = get_openai()
    phase1_wait_clustering(client)
    new_rows_count = phase2_collect_and_merge_clusters(client)
    grade_bid = phase3_submit_grading(client, new_rows_count)
    if grade_bid is not None:
        phase4_wait_grading(client, grade_bid)
        phase5_collect_grading(client)
    phase6_recompute()
    phase7_replot()

    log("=" * 80)
    log("=== CLUSTER-RETRY PIPELINE COMPLETE ===")
    log("=" * 80)


if __name__ == "__main__":
    main()
