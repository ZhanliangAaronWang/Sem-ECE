"""Poll xAI rerun batches; download outputs as they complete.

Reads rerun_state.json, polls each active batch, downloads output to
outputs/{tag}_c{chunk}.jsonl. Writes .done sentinel when all complete.
"""
import os, json, time, requests
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

API_KEY = os.environ["XAI_API_KEY"]
HEADERS = {"Authorization": f"Bearer {API_KEY}"}
STATE = os.path.join(BASE, "rerun_state.json")
OUT_DIR = os.path.join(BASE, "outputs")
DONE_FLAG = os.path.join(BASE, ".rerun_done")
POLL_SECS = 300  # 5 min
PER_CALL_SLEEP = 2.0  # seconds between status calls to avoid 429


def status_of(batch_id):
    r = requests.get(f"https://api.x.ai/v1/batches/{batch_id}", headers=HEADERS, timeout=60)
    r.raise_for_status()
    return r.json()


def download_output(output_file_id, out_path):
    r = requests.get(f"https://api.x.ai/v1/files/{output_file_id}/content", headers=HEADERS, timeout=300)
    r.raise_for_status()
    with open(out_path, "wb") as f:
        f.write(r.content)


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    while True:
        state = json.load(open(STATE))
        all_chunks = []
        for tag in ("p2", "p3"):
            for c in state.get(tag, {}).get("chunks", []):
                all_chunks.append((tag, c))
        # Also poll stale 3 (they may have data for some subset)
        stale = state.get("_stale_3k_batches", [])

        n_total = len(all_chunks) + len(stale)
        n_done = 0
        n_inprog = 0
        n_fail = 0
        for tag, c in all_chunks:
            out_path = os.path.join(OUT_DIR, f"{tag}_c{c['chunk']}.jsonl")
            if os.path.exists(out_path):
                n_done += 1
                continue
            time.sleep(PER_CALL_SLEEP)
            try:
                info = status_of(c["batch_id"])
                # xAI batch has state.num_success + state.num_error + state.num_pending
                st = info.get("state", {})
                num_pending = st.get("num_pending", 0)
                num_success = st.get("num_success", 0)
                num_error = st.get("num_error", 0)
                output_file_id = info.get("output_file_id")
                error_file_id = info.get("error_file_id")
                # Consider done when no pending AND output_file_id present
                if num_pending == 0 and output_file_id:
                    download_output(output_file_id, out_path)
                    n_done += 1
                    print(f"  DONE {tag} c{c['chunk']}: success={num_success} err={num_error}", flush=True)
                else:
                    n_inprog += 1
            except Exception as e:
                print(f"  ERR {tag} c{c['chunk']}: {str(e)[:150]}", flush=True)
                n_fail += 1

        # Stale batches
        for bid in stale:
            out_path = os.path.join(OUT_DIR, f"stale_{bid[-8:]}.jsonl")
            if os.path.exists(out_path):
                n_done += 1
                continue
            time.sleep(PER_CALL_SLEEP)
            try:
                info = status_of(bid)
                st = info.get("state", {})
                output_file_id = info.get("output_file_id")
                if st.get("num_pending", 0) == 0 and output_file_id:
                    download_output(output_file_id, out_path)
                    n_done += 1
                    print(f"  DONE stale {bid[-8:]}", flush=True)
                else:
                    n_inprog += 1
            except Exception as e:
                print(f"  ERR stale {bid[-8:]}: {str(e)[:150]}", flush=True)

        print(f"[{time.strftime('%H:%M:%S')}] done={n_done} inprog={n_inprog} fail={n_fail} / total={n_total}", flush=True)

        if n_done == n_total:
            with open(DONE_FLAG, "w") as f:
                f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
            print("ALL DONE", flush=True)
            return
        time.sleep(POLL_SECS)


if __name__ == "__main__":
    main()
