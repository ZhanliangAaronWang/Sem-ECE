"""Submit xAI rerun batches for P2 and P3 truncated samples.

xAI batch limit: 1000 rows per batch. We chunk accordingly.
xAI quirks: (1) requires `name` via extra_body, (2) returns `batch_id` not `id`
 — the OpenAI SDK masks this, so we use raw REST.
"""
import os, json, time, math, requests
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)
BASE = os.path.dirname(os.path.abspath(__file__))
INPUT_DIR = os.path.join(BASE, "batch_inputs")
STATE = os.path.join(BASE, "rerun_state.json")

API_KEY = os.environ["XAI_API_KEY"]
HEADERS = {"Authorization": f"Bearer {API_KEY}"}
CHUNK_SIZE = 1000


def load_state():
    if os.path.exists(STATE):
        return json.load(open(STATE))
    return {}


def save_state(s):
    with open(STATE, "w") as f:
        json.dump(s, f, indent=2)


def upload_file(path):
    with open(path, "rb") as f:
        files = {"file": (os.path.basename(path), f, "application/jsonl")}
        data = {"purpose": "batch"}
        r = requests.post("https://api.x.ai/v1/files", headers=HEADERS, files=files, data=data, timeout=120)
    r.raise_for_status()
    return r.json()["id"]


def create_batch(file_id, name):
    body = {
        "input_file_id": file_id,
        "endpoint": "/v1/chat/completions",
        "completion_window": "24h",
        "name": name,
    }
    r = requests.post("https://api.x.ai/v1/batches", headers=HEADERS, json=body, timeout=120)
    r.raise_for_status()
    return r.json()["batch_id"]


def submit_phase(state, tag, input_file):
    if tag not in state:
        state[tag] = {"chunks": []}
    done_chunks = {c["chunk"] for c in state[tag]["chunks"]}

    with open(input_file) as f:
        all_lines = f.readlines()
    n_chunks = math.ceil(len(all_lines) / CHUNK_SIZE)
    print(f"[{tag}] {len(all_lines):,} rows -> {n_chunks} chunks (1000/chunk)", flush=True)

    for ci in range(n_chunks):
        if ci in done_chunks:
            continue
        chunk_lines = all_lines[ci * CHUNK_SIZE:(ci + 1) * CHUNK_SIZE]
        tmp = f"/tmp/xai_{tag}_c{ci}.jsonl"
        with open(tmp, "w") as f:
            f.writelines(chunk_lines)
        for attempt in range(5):
            try:
                fid = upload_file(tmp)
                bid = create_batch(fid, f"rerun_{tag}_c{ci}")
                print(f"  {tag} c{ci}: {bid} ({len(chunk_lines)} rows)", flush=True)
                state[tag]["chunks"].append({
                    "chunk": ci,
                    "batch_id": bid,
                    "input_file_id": fid,
                    "n_rows": len(chunk_lines),
                    "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                })
                save_state(state)
                break
            except Exception as e:
                print(f"  {tag} c{ci} attempt {attempt+1}: {str(e)[:200]}", flush=True)
                time.sleep(min(60, 5 * 2 ** attempt))
        else:
            print(f"  {tag} c{ci} FAILED after 5 attempts", flush=True)


def main():
    state = load_state()
    # Note: 3 stale batches from first attempt (c0 at old 25k chunk size); we ignore them
    # and resubmit everything in proper 1000-chunks. De-dup during merge.
    # Clear any previous state to avoid chunk-index collision.
    state = {"_stale_3k_batches": [
        "batch_b3fc1100-8a9d-4c6d-a4b6-b348f9397055",  # p3 first 1000
        "batch_aeee1431-3cf4-4ebe-a939-431950f94f53",  # p2 rows 25000-25999
        "batch_946a5e61-d31a-4439-a4f7-6fc6d260e3d3",  # p2 rows 0-999
    ]}
    save_state(state)

    submit_phase(state, "p2", os.path.join(INPUT_DIR, "xai_p2_rerun.jsonl"))
    submit_phase(state, "p3", os.path.join(INPUT_DIR, "xai_p3_rerun.jsonl"))

    n_p2 = len(state.get("p2", {}).get("chunks", []))
    n_p3 = len(state.get("p3", {}).get("chunks", []))
    print(f"\n=== Submitted: P2={n_p2} chunks, P3={n_p3} chunks ===")


if __name__ == "__main__":
    main()
