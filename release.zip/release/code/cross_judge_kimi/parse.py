"""Parse Kimi-K3 judge raw.jsonl -> clustering/{phase}_{provider}_kimik3_clustered.jsonl.

Handles preamble before JSON (strip to first {"clusters") and bracket repair.
"""
import os, json, glob, sys
from collections import defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
sys.path.insert(0, os.path.join(ROOT, "cross_judge"))
from collect import tolerant_parse  # noqa: E402

RAW = os.path.join(BASE, "batch_outputs", "raw.jsonl")
CLUSTER_DIR = os.path.join(BASE, "clustering")


def main():
    n_expected = {}
    for path in glob.glob(os.path.join(ROOT, "cross_judge", "batch_inputs", "*.jsonl")):
        for line in open(path):
            r = json.loads(line)
            n_expected[r["custom_id"]] = r["contents"][0]["parts"][0]["text"].count("\n[")

    best = {}
    with open(RAW) as f:
        for line in f:
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            cid = rec.get("custom_id")
            if not cid or best.get(cid) is not None:
                continue
            text = rec.get("text") or ""
            n = n_expected.get(cid)
            if not text or n is None:
                best.setdefault(cid, None); continue
            cut = text.find('{"clusters"')
            if cut < 0:
                cut = text.find("{")
            if cut > 0:
                text = text[cut:]
            try:
                obj = tolerant_parse(text)
                clusters = obj["clusters"]
                assign = [None] * n; labels = []
                for k, c in enumerate(clusters):
                    labels.append(str(c["label"]))
                    for i in c["members"]:
                        if not (0 <= int(i) < n) or assign[int(i)] is not None:
                            raise ValueError("bad")
                        assign[int(i)] = k
                if any(a is None for a in assign):
                    raise ValueError("incomplete")
                sizes = [assign.count(k) for k in range(len(labels))]
                modal = max(range(len(sizes)), key=lambda k: sizes[k])
                phase, prov, qid = cid.split("__", 2)
                best[cid] = {"id": qid, "model": prov, "phase": phase, "n_samples": n,
                             "n_clusters": len(labels), "cluster_labels": labels,
                             "cluster_assignments": assign, "cluster_sizes": sizes,
                             "modal_cluster": modal, "modal_cluster_label": labels[modal],
                             "judge": "moonshotai/Kimi-K2.5"}
            except Exception:
                best.setdefault(cid, None)

    cells, fails, failed = defaultdict(list), defaultdict(int), []
    for cid, row in best.items():
        phase, prov, _ = cid.split("__", 2)
        cell = f"{phase}_{prov}"
        (cells[cell].append(row) if row else (fails.__setitem__(cell, fails[cell] + 1), failed.append(cid)))
    os.makedirs(CLUSTER_DIR, exist_ok=True)
    with open(os.path.join(BASE, "batch_outputs", "failed_cids.json"), "w") as f:
        json.dump(sorted(failed), f, indent=1)
    print(f"\n{'cell':<20}{'parsed':>8}{'fails':>7}{'fail%':>8}")
    for cell in sorted(set(list(cells) + list(fails))):
        rows = cells[cell]
        with open(os.path.join(CLUSTER_DIR, f"{cell}_kimik25_clustered.jsonl"), "w") as f:
            for r in sorted(rows, key=lambda x: x["id"]):
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        tot = len(rows) + fails[cell]
        print(f"{cell:<20}{len(rows):>8}{fails[cell]:>7}{100*fails[cell]/max(tot,1):>7.1f}%")


if __name__ == "__main__":
    main()
