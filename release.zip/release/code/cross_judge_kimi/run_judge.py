"""Cross-judge clustering with Kimi-K3 via QUBRID (OpenAI-compatible, async).

Re-judges all 39,629 questions (paper's 15 cells) using the SAME byte-identical
prompts as Exp 1/4 (read from cross_judge/batch_inputs). QUBRID has no batch API,
so we use the real-time endpoint with bounded concurrency. Resumes from existing
raw.jsonl. Output: batch_outputs/raw.jsonl ({custom_id, text}).
"""
import os, json, glob, time, asyncio, argparse
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))
from openai import AsyncOpenAI

client = AsyncOpenAI(base_url="https://platform.qubrid.com/v1",
                     api_key=os.environ["QUBRID_KEY"])
MODEL = "moonshotai/Kimi-K2.5"
SRC = os.path.join(ROOT, "cross_judge", "batch_inputs")
RAW = os.path.join(BASE, "batch_outputs", "raw.jsonl")


def load_rows():
    rows = []
    for path in sorted(glob.glob(os.path.join(SRC, "*.jsonl"))):
        for line in open(path):
            r = json.loads(line)
            rows.append({"custom_id": r["custom_id"],
                         "system": r["config"]["system_instruction"],
                         "user": r["contents"][0]["parts"][0]["text"]})
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--concurrency", type=int, default=16)
    ap.add_argument("--rpm", type=int, default=600)
    ap.add_argument("--max-tokens", type=int, default=3000)
    args = ap.parse_args()

    rows = load_rows()
    done = set()
    if os.path.exists(RAW):
        for l in open(RAW):
            try:
                done.add(json.loads(l)["custom_id"])
            except Exception:
                pass
    remaining = [r for r in rows if r["custom_id"] not in done]
    print(f"{len(rows)} total, {len(done)} done, {len(remaining)} remaining", flush=True)
    if not remaining:
        print("all done"); return

    sem = asyncio.Semaphore(args.concurrency)
    rate_lock = asyncio.Lock()
    delay = 60.0 / args.rpm
    last = [0.0]
    buf, cnt, errs = [], [0], [0]

    async def one(row):
        async with sem:
            async with rate_lock:
                w = delay - (time.monotonic() - last[0])
                if w > 0:
                    await asyncio.sleep(w)
                last[0] = time.monotonic()
            for attempt in range(5):
                try:
                    resp = await client.chat.completions.create(
                        model=MODEL,
                        messages=[{"role": "system", "content": row["system"]},
                                  {"role": "user", "content": row["user"]}],
                        max_tokens=args.max_tokens, temperature=0.0)
                    buf.append({"custom_id": row["custom_id"],
                                "text": resp.choices[0].message.content})
                    cnt[0] += 1
                    if cnt[0] % 500 == 0:
                        print(f"  {cnt[0]}/{len(remaining)} ({errs[0]} err)", flush=True)
                    return
                except Exception as e:
                    es = str(e)
                    if "429" in es or "rate" in es.lower() or "500" in es or "503" in es:
                        await asyncio.sleep(2 ** attempt * 3)
                    else:
                        errs[0] += 1
                        buf.append({"custom_id": row["custom_id"], "text": "", "error": es[:150]})
                        return
            errs[0] += 1
            buf.append({"custom_id": row["custom_id"], "text": "", "error": "max retries"})

    async def flush():
        while True:
            await asyncio.sleep(10)
            if buf:
                with open(RAW, "a") as f:
                    while buf:
                        f.write(json.dumps(buf.pop(0), ensure_ascii=False) + "\n")

    async def run():
        ft = asyncio.create_task(flush())
        await asyncio.gather(*[one(r) for r in remaining])
        await asyncio.sleep(1); ft.cancel()
        if buf:
            with open(RAW, "a") as f:
                while buf:
                    f.write(json.dumps(buf.pop(0), ensure_ascii=False) + "\n")

    asyncio.run(run())
    print(f"done: {cnt[0]} ok, {errs[0]} err", flush=True)


if __name__ == "__main__":
    main()
