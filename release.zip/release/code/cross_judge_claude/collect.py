"""Poll Claude judge batches, parse into clustered jsonl (dataset-cell files).

Output: clustering/{phase}_{provider}_claudeopus46_clustered.jsonl
Reuses the tolerant bracket-repair parser from cross_judge/collect.py.
"""
import os, json, glob, time, argparse, sys
from collections import defaultdict
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))
sys.path.insert(0, os.path.join(ROOT, "cross_judge"))
from collect import tolerant_parse  # noqa: E402

from anthropic import Anthropic

JOBS = os.path.join(BASE, "batch_outputs", "jobs.json")
RAW = os.path.join(BASE, "batch_outputs", "raw.jsonl")
CLUSTER_DIR = os.path.join(BASE, "clustering")


def poll(client, jobs):
    all_done = True
    for j in jobs:
        if j.get("collected"):
            continue
        s = client.messages.batches.retrieve(j["batch_id"])
        c = s.request_counts
        print(f"  {j['batch_id'][:16]}…: {s.processing_status} "
              f"ok={c.succeeded} proc={c.processing} err={c.errored}")
        if s.processing_status != "ended":
            all_done = False
            continue
        with open(RAW, "a") as f:
            for res in client.messages.batches.results(j["batch_id"]):
                d = res.model_dump()
                f.write(json.dumps(d, default=str) + "\n")
        j["collected"] = True
        with open(JOBS, "w") as f:
            json.dump(jobs, f, indent=1)
        print(f"    downloaded {j['batch_id']}")
    return all_done


def extract_text(rec):
    """Anthropic batch result record -> assistant text or None."""
    res = rec.get("result") or {}
    if res.get("type") != "succeeded":
        return None
    msg = res.get("message") or {}
    for block in msg.get("content", []):
        if block.get("type") == "text":
            return block.get("text")
    return None


def parse_all():
    n_expected = {}
    for path in glob.glob(os.path.join(ROOT, "cross_judge", "batch_inputs", "*.jsonl")):
        with open(path) as f:
            for line in f:
                r = json.loads(line)
                n_expected[r["custom_id"]] = r["contents"][0]["parts"][0]["text"].count("\n[")

    best = {}
    with open(RAW) as f:
        for line in f:
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            cid = rec.get("custom_id")
            if not cid or best.get(cid) is not None:
                continue
            text = extract_text(rec)
            n = n_expected.get(cid)
            if not text or n is None:
                best.setdefault(cid, None)
                continue
            # Claude often prepends a reasoning preamble before the JSON despite
            # the "output only JSON" instruction; skip to the JSON object.
            cut = text.find('{"clusters"')
            if cut < 0:
                cut = text.find("{")
            if cut > 0:
                text = text[cut:]
            try:
                obj = tolerant_parse(text)
                clusters = obj["clusters"]
                assign = [None] * n
                labels = []
                for k, c in enumerate(clusters):
                    labels.append(str(c["label"]))
                    for i in c["members"]:
                        if not (0 <= int(i) < n) or assign[int(i)] is not None:
                            raise ValueError("bad")
                        assign[int(i)] = k
                if any(a is None for a in assign):
                    raise ValueError("incomplete")
                sizes = [assign.count(k) for k in range(len(labels))]
                modal = max(range(len(sizes)), key=lambda k: sizes[k])
                phase, prov, qid = cid.split("__", 2)
                best[cid] = {
                    "id": qid, "model": prov, "phase": phase, "n_samples": n,
                    "n_clusters": len(labels), "cluster_labels": labels,
                    "cluster_assignments": assign, "cluster_sizes": sizes,
                    "modal_cluster": modal, "modal_cluster_label": labels[modal],
                    "judge": "claude-opus-4-6",
                }
            except Exception:
                best.setdefault(cid, None)

    cells, fails, failed = defaultdict(list), defaultdict(int), []
    for cid, row in best.items():
        phase, prov, _ = cid.split("__", 2)
        cell = f"{phase}_{prov}"
        if row is None:
            fails[cell] += 1
            failed.append(cid)
        else:
            cells[cell].append(row)

    os.makedirs(CLUSTER_DIR, exist_ok=True)
    with open(os.path.join(BASE, "batch_outputs", "failed_cids.json"), "w") as f:
        json.dump(sorted(failed), f, indent=1)
    print(f"\n{'cell':<20}{'parsed':>8}{'fails':>7}{'fail%':>8}")
    for cell in sorted(set(list(cells) + list(fails))):
        rows = cells[cell]
        with open(os.path.join(CLUSTER_DIR, f"{cell}_claudeopus46_clustered.jsonl"), "w") as f:
            for r in sorted(rows, key=lambda x: x["id"]):
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        tot = len(rows) + fails[cell]
        print(f"{cell:<20}{len(rows):>8}{fails[cell]:>7}{100*fails[cell]/max(tot,1):>7.1f}%")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--interval", type=int, default=900)
    ap.add_argument("--parse-only", action="store_true")
    args = ap.parse_args()
    if args.parse_only:
        parse_all()
        return
    client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    with open(JOBS) as f:
        jobs = json.load(f)
    while True:
        done = poll(client, jobs)
        if done or not args.loop:
            break
        time.sleep(args.interval)
    if done:
        parse_all()


if __name__ == "__main__":
    main()
