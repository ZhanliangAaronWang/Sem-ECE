"""Submit cross-judge clustering to claude-opus-4-6 via Anthropic Message Batches.

Reads the same byte-identical prompts from cross_judge/batch_inputs (built for
Exp 1 / Gemini). Converts to Anthropic request format and submits in sub-batches
of <=100k. Idempotent: records batch ids in batch_outputs/jobs.json.
"""
import os, json, glob, time
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))

from anthropic import Anthropic

MODEL = "claude-opus-4-6"
MAX_TOKENS = 3000
SRC = os.path.join(ROOT, "cross_judge", "batch_inputs")
JOBS = os.path.join(BASE, "batch_outputs", "jobs.json")
CHUNK = 100_000


def build_requests():
    reqs = []
    for path in sorted(glob.glob(os.path.join(SRC, "*.jsonl"))):
        with open(path) as f:
            for line in f:
                r = json.loads(line)
                reqs.append({
                    "custom_id": r["custom_id"],
                    "params": {
                        "model": MODEL,
                        "max_tokens": MAX_TOKENS,
                        "temperature": 0.0,
                        "system": r["config"]["system_instruction"],
                        "messages": [{"role": "user",
                                      "content": r["contents"][0]["parts"][0]["text"]}],
                    },
                })
    return reqs


def main():
    os.makedirs(os.path.join(BASE, "batch_outputs"), exist_ok=True)
    client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

    jobs = []
    if os.path.exists(JOBS):
        with open(JOBS) as f:
            jobs = json.load(f)
    if jobs:
        print(f"already submitted: {[j['batch_id'] for j in jobs]}")
        return

    reqs = build_requests()
    print(f"total requests: {len(reqs)}")
    for i in range(0, len(reqs), CHUNK):
        chunk = reqs[i:i + CHUNK]
        batch = client.messages.batches.create(requests=chunk)
        jobs.append({"batch_id": batch.id, "n": len(chunk),
                     "submitted_at": time.strftime("%F %T")})
        with open(JOBS, "w") as f:
            json.dump(jobs, f, indent=1)
        print(f"  sub-batch {i//CHUNK}: {batch.id} ({len(chunk)} reqs)")
    print(f"{len(jobs)} batch(es) recorded")


if __name__ == "__main__":
    main()
