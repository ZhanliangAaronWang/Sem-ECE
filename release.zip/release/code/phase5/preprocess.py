"""Phase 5 — MedXpertQA Text preprocessing.

Stratified sample of 500 questions across question_type and medical_task.
"""
import json, os, random
from datasets import load_dataset

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "data", "phase5", "medxpertqa_preprocessed.jsonl")

N_TOTAL = 500
SEED = 0


def main():
    random.seed(SEED)
    ds = load_dataset("TsinghuaC3I/MedXpertQA", "Text", split="test")
    print(f"Loaded MedXpertQA Text: {len(ds)} rows")

    # Stratify by question_type
    by_type = {}
    for r in ds:
        by_type.setdefault(r["question_type"], []).append(r)
    print("Types:", {k: len(v) for k, v in by_type.items()})

    # Sample proportionally
    picked = []
    total = sum(len(v) for v in by_type.values())
    for t, rows in by_type.items():
        n_t = round(N_TOTAL * len(rows) / total)
        picked.extend(random.sample(rows, min(n_t, len(rows))))
    random.shuffle(picked)
    picked = picked[:N_TOTAL]
    print(f"Picked {len(picked)} questions")

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        for r in picked:
            row = {
                "qid": f"medx_{r['id']}",
                "question_final": r["question"],
                "options": r["options"],  # dict A..J
                "gold_letter": r["label"],
                "gold_answer": r["options"].get(r["label"], ""),
                "question_type": r["question_type"],
                "medical_task": r["medical_task"],
                "body_system": r["body_system"],
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(f"Wrote {len(picked)} -> {OUT}")


if __name__ == "__main__":
    main()
