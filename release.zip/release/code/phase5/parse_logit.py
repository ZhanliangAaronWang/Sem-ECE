"""Parse logit-based MCQA confidence from OpenAI batch output with top_logprobs.

Input: phase5/batch_outputs/openai_logit_raw.jsonl (from logit batch)
Output: phase5/confidence/logit_confidence.jsonl with:
  {qid, predicted_letter, conf_logit, p_per_letter: {A:..., B:..., ...}}

Logic:
  - Look at first output token logprobs
  - Extract logprob for each option letter A..J that appears in top_logprobs
  - Softmax over the collected (valid option) logprobs → conf_logit is the prob of
    the argmax option.
"""
import os, json, math

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IN_FILE = os.path.join(ROOT, "phase5", "batch_outputs", "openai_logit_v2_raw.jsonl")
OUT_FILE = os.path.join(ROOT, "phase5", "confidence", "logit_confidence.jsonl")
GOLD_FILE = os.path.join(ROOT, "data", "phase5", "medxpertqa_preprocessed.jsonl")


def main():
    gold = {r["qid"]: r for r in (json.loads(l) for l in open(GOLD_FILE))}

    rows_out = []
    fb_predicted = 0
    with open(IN_FILE) as f:
        for line in f:
            r = json.loads(line)
            cid = r["custom_id"]
            qid = cid.replace("__logit", "")
            body = r.get("response", {}).get("body", {})
            choices = body.get("choices", [])
            if not choices:
                continue
            choice = choices[0]
            content = (choice.get("message") or {}).get("content", "") or ""
            lp = choice.get("logprobs", {}) or {}
            content_lp = lp.get("content") or []
            # First token logprobs
            letter_lps = {}
            if content_lp:
                first = content_lp[0]
                top = first.get("top_logprobs", []) or []
                for item in top:
                    tok = (item.get("token") or "").strip().upper()
                    if len(tok) == 1 and tok in "ABCDEFGHIJ":
                        letter_lps[tok] = max(letter_lps.get(tok, -1e9), item.get("logprob", -1e9))
                # Also include the actually selected token
                sel = (first.get("token") or "").strip().upper()
                if len(sel) == 1 and sel in "ABCDEFGHIJ":
                    letter_lps[sel] = max(letter_lps.get(sel, -1e9), first.get("logprob", -1e9))

            if not letter_lps:
                # fallback: just use the content letter if present
                toks = content.strip().upper()
                if toks and toks[0] in "ABCDEFGHIJ":
                    predicted = toks[0]
                    conf = 0.5  # uniform prior
                    fb_predicted += 1
                    rows_out.append({
                        "qid": qid, "predicted_letter": predicted, "conf_logit": conf,
                        "p_per_letter": None, "fallback": True,
                    })
                continue

            # Softmax over collected valid-option logprobs
            m = max(letter_lps.values())
            exps = {k: math.exp(v - m) for k, v in letter_lps.items()}
            Z = sum(exps.values())
            probs = {k: v / Z for k, v in exps.items()}
            predicted = max(probs, key=probs.get)
            conf = probs[predicted]

            rows_out.append({
                "qid": qid,
                "predicted_letter": predicted,
                "conf_logit": conf,
                "p_per_letter": probs,
                "fallback": False,
            })

    # Add Y (correctness vs gold letter)
    for r in rows_out:
        gold_row = gold.get(r["qid"])
        if gold_row:
            r["gold_letter"] = gold_row.get("gold_letter")
            r["Y"] = int(r["predicted_letter"] == gold_row.get("gold_letter"))

    os.makedirs(os.path.dirname(OUT_FILE), exist_ok=True)
    with open(OUT_FILE, "w") as f:
        for r in rows_out:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    total = len(rows_out)
    acc = sum(r.get("Y", 0) for r in rows_out) / max(1, total)
    mean_conf = sum(r["conf_logit"] for r in rows_out) / max(1, total)
    print(f"Wrote {total} rows -> {OUT_FILE}")
    print(f"  acc={acc:.3f}  mean_conf={mean_conf:.3f}  fallback_only={fb_predicted}")


if __name__ == "__main__":
    main()
