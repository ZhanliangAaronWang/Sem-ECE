"""Wait for logit_v2 batch, download, run parse_logit, write .pipeline_done."""
import os, json, time, subprocess
from dotenv import load_dotenv
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)
from openai import OpenAI
client = OpenAI()

P5 = os.path.join(ROOT, "phase5")
OUT = os.path.join(P5, "batch_outputs", "openai_logit_v2_raw.jsonl")
DONE = os.path.join(P5, ".pipeline_done")

state = json.load(open(os.path.join(P5, "batch_state.json")))
bid = state["logit_v2"]["batch_id"]
print(f"polling {bid}", flush=True)
while True:
    b = client.batches.retrieve(bid)
    print(f"  {b.status} {b.request_counts.completed}/{b.request_counts.total}", flush=True)
    if b.status in {"completed", "failed", "expired", "cancelled"}:
        break
    time.sleep(120)
if b.status != "completed":
    raise SystemExit(f"logit v2 failed: {b.status}")
data = client.files.content(b.output_file_id).text
with open(OUT, "w") as f:
    f.write(data)
print(f"downloaded -> {OUT}", flush=True)

r = subprocess.run(["python", os.path.join(P5, "parse_logit.py")], cwd=ROOT)
if r.returncode != 0:
    raise SystemExit("parse_logit failed")

with open(DONE, "w") as f:
    f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
print("P5 DONE", flush=True)
