"""Phase 3 (MATH-500 + AIME 2024/2025) Step 6 -- Grading: build batch input, estimate cost, submit.

Mirrors phase2/grading/prep_and_submit.py. One grade call per question per provider,
using the modal_cluster_label as the predicted answer vs. the phase5 gold_answer.

Usage:
    python prep_and_submit.py --providers openai xai mistral --submit
"""
import os, json, time, argparse
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI

CLUSTER_DIR = os.path.join(ROOT, "phase5", "clustering")
BATCH_DIR = os.path.join(ROOT, "phase5", "grading", "batch_inputs")
BATCH_IDS_FILE = os.path.join(ROOT, "phase5", "grading", "batch_ids.json")

JUDGE_MODEL = "gpt-5.2"

SYSTEM_PROMPT = """You are a grader for a question-answering benchmark. You will receive a question, the official gold answer, and a predicted answer. Your job is to decide whether the predicted answer is semantically equivalent to the gold answer.

Rules:
- Accept different surface forms of the same answer: "Leo Tolstoy" matches "Tolstoy"; "1869" matches "1869 AD"; "Paris, France" matches "Paris"; "1.5 mM" matches "0.0015 M".
- Reject answers that are related but specifically different: "Tolstoy" vs "Dostoevsky" is INCORRECT; "1869" vs "1865" is INCORRECT; "Paris" vs "France" is INCORRECT.
- If the predicted answer is a refusal (e.g., "I don't know", "I cannot answer", "Unknown", "N/A", empty), output NOT_ATTEMPTED.
- Be lenient on capitalization, punctuation, articles (a/the), and minor formatting.

Output format: a single JSON object with one field, "grade", whose value is exactly one of the strings "CORRECT", "INCORRECT", or "NOT_ATTEMPTED".

Example outputs:
{"grade": "CORRECT"}
{"grade": "INCORRECT"}
{"grade": "NOT_ATTEMPTED"}

Output ONLY the JSON object, no preamble, no commentary."""


def build_batch(provider):
    clustered_path = os.path.join(CLUSTER_DIR, f"{provider}_medxpert_clustered.jsonl")
    if not os.path.exists(clustered_path):
        return None, 0
    rows = []
    with open(clustered_path) as f:
        for line in f:
            r = json.loads(line)
            user_msg = f"Question: {r['question']}\nGold answer: {r['gold_answer']}\nPredicted answer: {r['modal_cluster_label']}"
            rows.append({
                "custom_id": f"{provider}__{r['id']}",
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": JUDGE_MODEL,
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": user_msg},
                    ],
                    "reasoning_effort": "none",
                    "temperature": 0.0,
                    "max_completion_tokens": 50,
                    "response_format": {"type": "json_object"},
                    "seed": 0,
                },
            })
    os.makedirs(BATCH_DIR, exist_ok=True)
    out_path = os.path.join(BATCH_DIR, f"{provider}_grading.jsonl")
    with open(out_path, "w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    return out_path, len(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--providers", nargs="+", default=["openai"])
    ap.add_argument("--submit", action="store_true")
    args = ap.parse_args()
    providers = args.providers

    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

    batch_ids = {}
    if os.path.exists(BATCH_IDS_FILE):
        with open(BATCH_IDS_FILE) as f:
            batch_ids = json.load(f)

    total_cost = 0
    for prov in providers:
        path, n = build_batch(prov)
        if path is None:
            print(f"[{prov}] SKIP -- clustering file not found", flush=True)
            continue
        print(f"[{prov}] built {n} rows -> {path}", flush=True)

        in_tok = 200 * n
        out_tok = 10 * n
        # gpt-5.2 batch pricing: $1.25/$10 per 1M with 50% batch discount
        in_price = 1.25 / 2 / 1e6
        out_price = 10.0 / 2 / 1e6
        cost = in_tok * in_price + out_tok * out_price
        total_cost += cost
        print(f"  est cost: ${cost:.2f} ({in_tok:,} in + {out_tok:,} out)", flush=True)

        if args.submit:
            print(f"  submitting...", flush=True)
            for attempt in range(8):
                try:
                    with open(path, "rb") as f:
                        fobj = client.files.create(file=f, purpose="batch")
                    batch = client.batches.create(
                        input_file_id=fobj.id,
                        endpoint="/v1/chat/completions",
                        completion_window="24h",
                        metadata={"phase": "phase5_grading", "provider": prov},
                    )
                    print(f"  batch_id: {batch.id}  status: {batch.status}", flush=True)
                    batch_ids[prov] = {
                        "batch_id": batch.id,
                        "input_file_id": fobj.id,
                        "n_rows": n,
                        "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                    }
                    break
                except Exception as e:
                    print(f"  attempt {attempt+1} failed: {str(e)[:150]}", flush=True)
                    time.sleep(min(60, 5 * 2 ** attempt))

    print(f"\nTotal estimated cost: ${total_cost:.2f}", flush=True)

    if args.submit and batch_ids:
        with open(BATCH_IDS_FILE, "w") as f:
            json.dump(batch_ids, f, indent=2)
        print(f"Saved batch IDs -> {BATCH_IDS_FILE}", flush=True)


if __name__ == "__main__":
    main()
