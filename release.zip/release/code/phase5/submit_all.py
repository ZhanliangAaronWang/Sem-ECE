"""Submit Phase 5 (MedXpertQA Text) OpenAI batches — SCOPE + Logit protocols."""
import os, json, time
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
load_dotenv(os.path.join(CAL_BASE, "phase1", ".env"), override=True)

from openai import OpenAI
client = OpenAI()

BATCH_DIR = os.path.join(BASE, "batch_inputs")
STATE_FILE = os.path.join(BASE, "batch_state.json")


def load_state():
    return json.load(open(STATE_FILE)) if os.path.exists(STATE_FILE) else {}


def save_state(s):
    with open(STATE_FILE, "w") as f:
        json.dump(s, f, indent=2)


def submit_file(label, path):
    for attempt in range(5):
        try:
            with open(path, "rb") as f:
                fobj = client.files.create(file=f, purpose="batch")
            b = client.batches.create(
                input_file_id=fobj.id, endpoint="/v1/chat/completions",
                completion_window="24h",
                metadata={"phase": "phase5_gen", "label": label},
            )
            print(f"  {label}: {b.id} {b.status}")
            return {"batch_id": b.id, "file_id": fobj.id,
                    "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%S")}
        except Exception as e:
            print(f"  {label} attempt {attempt+1}: {str(e)[:150]}")
            time.sleep(min(60, 5 * 2 ** attempt))
    return None


def main():
    state = load_state()
    state.setdefault("scope", {"chunks": []})
    state.setdefault("logit", {})

    existing = {c["chunk"] for c in state["scope"]["chunks"]}
    for ci in range(7):
        if ci in existing:
            continue
        path = os.path.join(BATCH_DIR, f"openai_scope_chunk{ci}.jsonl")
        entry = submit_file(f"scope_c{ci}", path)
        if entry:
            entry["chunk"] = ci
            state["scope"]["chunks"].append(entry)
            save_state(state)

    if "batch_id" not in state["logit"]:
        entry = submit_file("logit", os.path.join(BATCH_DIR, "openai_logit.jsonl"))
        if entry:
            state["logit"].update(entry)
            save_state(state)

    print(f"\nState -> {STATE_FILE}")


if __name__ == "__main__":
    main()
