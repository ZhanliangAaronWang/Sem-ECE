"""Phase 5 MedXpertQA full pipeline watcher.

Chain:
  1. Poll 7 SCOPE batches + 1 logit batch
  2. Download all outputs -> phase5/batch_outputs/
  3. Run prep_openai (SCOPE) -> submit clustering batch -> poll -> collect
  4. Submit grading -> poll -> collect+ECE
  5. Parse logit batch -> compute_logit_confidence
  6. Compute combined calibration_metrics.csv (SCOPE-1, SCOPE-2, Verbalized, Logit)
Writes phase5/.pipeline_done when complete.
"""
import os, json, time, subprocess
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)
from openai import OpenAI
client = OpenAI()

P5 = os.path.join(ROOT, "phase5")
STATE = os.path.join(P5, "batch_state.json")
OUT_DIR = os.path.join(P5, "batch_outputs")
DONE = os.path.join(P5, ".pipeline_done")
POLL = 300
TERMINAL = {"completed", "failed", "expired", "cancelled"}


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def poll_done(batch_id, label):
    while True:
        b = client.batches.retrieve(batch_id)
        rc = b.request_counts
        log(f"  {label}: {b.status} {rc.completed}/{rc.total}")
        if b.status in TERMINAL:
            return b
        time.sleep(POLL)


def download(batch_id, out_path):
    b = client.batches.retrieve(batch_id)
    if b.output_file_id:
        data = client.files.content(b.output_file_id).text
        with open(out_path, "w") as f:
            f.write(data)
        log(f"  downloaded -> {out_path}")


def run(cmd):
    log(f"$ {cmd}")
    r = subprocess.run(cmd, shell=True, cwd=ROOT)
    if r.returncode != 0:
        raise RuntimeError(f"FAILED: {cmd}")


def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    state = json.load(open(STATE))

    # Poll + download SCOPE chunks
    for c in state["scope"]["chunks"]:
        b = poll_done(c["batch_id"], f"scope_c{c['chunk']}")
        if b.status != "completed":
            log(f"WARN: scope c{c['chunk']} ended {b.status}")
            continue
        out = os.path.join(OUT_DIR, f"openai_scope_chunk{c['chunk']}.jsonl")
        if not os.path.exists(out):
            download(b.id, out)

    # Poll + download logit
    lg = state["logit"]
    b = poll_done(lg["batch_id"], "logit")
    if b.status == "completed":
        out = os.path.join(OUT_DIR, "openai_logit_raw.jsonl")
        if not os.path.exists(out):
            download(b.id, out)

    # SCOPE pipeline
    run("python phase5/clustering/prep_openai.py")
    run("python phase5/clustering/submit_openai_chunked.py")
    cluster_state = json.load(open(os.path.join(P5, "clustering", "openai_chunks.json")))
    for c in cluster_state["chunks"]:
        bb = poll_done(c["batch_id"], f"cluster_c{c['chunk']}")
        c["final_status"] = bb.status
        if bb.status == "completed":
            c["output_file_id"] = bb.output_file_id
            c["error_file_id"] = bb.error_file_id
    with open(os.path.join(P5, "clustering", "openai_chunks.json"), "w") as f:
        json.dump(cluster_state, f, indent=2)
    run("python phase5/clustering/collect_openai.py")

    # Grading
    run("python phase5/grading/prep_and_submit.py --providers openai --submit")
    ids = json.load(open(os.path.join(P5, "grading", "batch_ids.json")))
    poll_done(ids["openai"]["batch_id"], "grade_openai")
    run("python phase5/grading/collect_and_check.py --providers openai")

    # Logit parse
    run("python phase5/parse_logit.py")

    with open(DONE, "w") as f:
        f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
    log("P5 PIPELINE DONE")


if __name__ == "__main__":
    main()
