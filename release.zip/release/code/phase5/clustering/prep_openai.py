"""Phase 4 (PopQA) Step 1 — Extract answers from OpenAI batch outputs and build clustering batch.

Inputs:
  phase5/batch_outputs/openai_scope_chunk{0-6}.jsonl  (OpenAI batch envelope format)
  data/phase5/medxpertqa_preprocessed.jsonl                (gold data: qid, question_final, gold_answer)

Outputs:
  phase5/clustering/openai_extracted.jsonl           (one row per question, with 50 extracted answers)
  phase5/clustering/batch_inputs/openai_clustering.jsonl  (clustering batch in OpenAI batch format)
"""
import os, json, re, statistics

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BATCH_DIR = os.path.join(ROOT, "phase5", "batch_outputs")
GOLD_FILE = os.path.join(ROOT, "data", "phase5", "medxpertqa_preprocessed.jsonl")
EXTRACTED = os.path.join(ROOT, "phase5", "clustering", "openai_extracted.jsonl")
BATCH_OUT = os.path.join(ROOT, "phase5", "clustering", "batch_inputs", "openai_clustering.jsonl")

JUDGE_MODEL = "gpt-5.2"
ANS_RE = re.compile(r"Answer:\s*(.+?)(?=\nConfidence|\Z)", re.DOTALL)
CONF_RE = re.compile(r"Confidence:\s*([0-9]+(?:\.[0-9]+)?)\s*%?")
NULL_ANS = {"see above", "as stated", "as mentioned", "as noted"}

SYSTEM_PROMPT = """You are a semantic clustering assistant for a research benchmark. You will receive a question and a list of model-generated answers, indexed 0 through N-1. Your job is to partition the answers into groups such that two answers are in the same group if and only if they express the same underlying answer to the question.

Rules:
- Cluster by SEMANTIC meaning, not surface form. "Leo Tolstoy", "Tolstoy", "Leo Tolstoy (1869)", and "the Russian novelist Leo Tolstoy" all belong to the same cluster.
- Surface variations to ignore: capitalization, punctuation, articles (a/the), trailing dates or qualifiers, formal vs informal name forms, units that express the same physical quantity ("1.5 mM" = "0.0015 M"), and explanatory parentheticals.
- Different specific answers belong to different clusters even if related: "Tolstoy" and "Dostoevsky" are different; "Paris" and "France" are different; "1869" and "1865" are different.
- Each answer index must appear in exactly one cluster. Every index 0 to N-1 must be assigned.
- Use as few clusters as faithfully captures the semantic distinctions. Do not over-fragment over trivial differences.

Output format: a single JSON object with one field, "clusters", whose value is an array of cluster objects. Each cluster object has two fields:
- "label": a short canonical string representing the cluster's answer (e.g., "Leo Tolstoy", "1869")
- "members": a sorted array of integer indices (0-indexed) of the answers in that cluster

Example output:
{"clusters": [
  {"label": "Leo Tolstoy", "members": [0, 1, 3, 5, 8, 12, 15, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46, 49]},
  {"label": "Fyodor Dostoevsky", "members": [2, 6, 11, 17, 24, 30, 38, 44]},
  {"label": "Anton Chekhov", "members": [4, 9, 14, 20, 27, 33, 41, 47]},
  {"label": "I don't know", "members": [7, 10, 13, 16, 18, 21, 23, 26, 29, 32, 35, 36, 39, 42, 45, 48]}
]}

Output ONLY the JSON object, with no preamble, no code fences, no commentary."""


def extract_answer(raw):
    m = ANS_RE.search(raw)
    if m:
        ans = m.group(1).strip()
        if ans and ans.lower() not in NULL_ANS:
            return ans, "answer_line"
    return raw[-200:].strip(), "fallback_tail"


def extract_conf(raw):
    m = CONF_RE.search(raw)
    if not m:
        return None, "missing"
    try:
        v = float(m.group(1)) / 100.0
    except ValueError:
        return None, "missing"
    return max(0.0, min(1.0, v)), "regex_match"


def main():
    # 1) Load gold data
    gold = {}
    with open(GOLD_FILE) as f:
        for l in f:
            d = json.loads(l)
            gold[d["qid"]] = d

    # 2) Gather raw generations grouped by qid
    #    OpenAI P3 generation: 7 chunks, each call has n=8 choices.
    #    custom_id format: "{qid}__chunk{ci}"
    raw_by_q = {}
    for ci in range(7):
        path = os.path.join(BATCH_DIR, f"openai_scope_chunk{ci}.jsonl")
        with open(path) as f:
            for line in f:
                r = json.loads(line)
                cid = r["custom_id"]  # "{qid}__chunk{ci}"
                qid, chunk = cid.rsplit("__", 1)
                choices = r["response"]["body"]["choices"]
                contents = [c["message"]["content"] for c in choices]
                raw_by_q.setdefault(qid, {})[chunk] = contents

    # Filter to questions with exactly 50 samples
    good_qids = sorted(q for q, d in raw_by_q.items()
                       if sum(len(v) for v in d.values()) == 50)
    bad = [q for q in raw_by_q if q not in set(good_qids)]
    if bad:
        print(f"WARN: {len(bad)} questions do not have 50 samples, skipping: {bad[:5]}")

    n_q = len(good_qids)
    print(f"Loaded {n_q} questions, each with 50 samples", flush=True)

    # 3) Per-sample extraction
    fallback_count = 0
    missing_conf_count = 0
    all_conf = []
    extracted_rows = []
    batch_rows = []

    for qid in good_qids:
        chunks = raw_by_q[qid]
        # Canonical order: chunk0..chunk6, within each by choice index
        results = []
        for ci in range(7):
            cname = f"chunk{ci}"
            if cname in chunks:
                results.extend(chunks[cname])
        assert len(results) == 50, f"{qid}: got {len(results)} samples"

        ans_list, ext_method, conf_list, conf_method = [], [], [], []
        for raw in results:
            a, em = extract_answer(raw)
            c, cm = extract_conf(raw)
            ans_list.append(a)
            ext_method.append(em)
            conf_list.append(c)
            conf_method.append(cm)
            if em == "fallback_tail":
                fallback_count += 1
            if cm == "missing":
                missing_conf_count += 1
            else:
                all_conf.append(c)

        # Missing verbalized confidence is imputed as 1.0 (model didn't bother to express uncertainty -> assume max conf).
        imputed_conf = [1.0 if c is None else c for c in conf_list]
        verb_mean = sum(imputed_conf) / len(imputed_conf) if imputed_conf else 1.0
        verb_n = sum(1 for c in conf_list if c is not None)

        gold_row = gold[qid]
        extracted_rows.append({
            "id": qid,
            "question": gold_row["question_final"],
            "gold_answer": gold_row["gold_answer"],
            "model": "openai",
            "n_samples": 50,
            "results": results,
            "answer_extracted": ans_list,
            "extraction_method": ext_method,
            "confidence_verbalized": conf_list,
            "confidence_extraction_method": conf_method,
            "verbalized_mean": verb_mean,
            "verbalized_n_extracted": verb_n,
        })

        # Build clustering batch row
        ans_block = "\n".join(f"[{i}] {a}" for i, a in enumerate(ans_list))
        user_msg = f"Question: {gold_row['question_final']}\n\nAnswers (50 total, indexed 0 to 49):\n{ans_block}"

        batch_rows.append({
            "custom_id": f"openai__{qid}",
            "method": "POST",
            "url": "/v1/chat/completions",
            "body": {
                "model": JUDGE_MODEL,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_msg},
                ],
                "reasoning_effort": "none",
                "temperature": 0.0,
                "max_completion_tokens": 1500,
                "response_format": {"type": "json_object"},
                "seed": 0,
            },
        })

    # 4) Write extracted
    os.makedirs(os.path.dirname(EXTRACTED), exist_ok=True)
    os.makedirs(os.path.dirname(BATCH_OUT), exist_ok=True)
    with open(EXTRACTED, "w") as f:
        for r in extracted_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"Wrote {len(extracted_rows)} rows to {EXTRACTED}", flush=True)

    # 5) Write batch input
    with open(BATCH_OUT, "w") as f:
        for r in batch_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"Wrote {len(batch_rows)} rows to {BATCH_OUT}", flush=True)

    # 6) Stats
    total_samples = n_q * 50
    print("\n=== Step 1 stats (OpenAI, Phase 4 PopQA) ===", flush=True)
    print(f"  total samples: {total_samples}", flush=True)
    print(f"  fallback (answer): {fallback_count} ({fallback_count*100/total_samples:.2f}%)", flush=True)
    print(f"  missing (confidence): {missing_conf_count} ({missing_conf_count*100/total_samples:.2f}%)", flush=True)
    if all_conf:
        print(f"  mean verbalized conf:   {statistics.mean(all_conf):.3f}", flush=True)
        print(f"  median verbalized conf: {statistics.median(all_conf):.3f}", flush=True)

    if fallback_count / total_samples > 0.05:
        print("  WARN: answer fallback rate > 5%", flush=True)
    if missing_conf_count / total_samples > 0.10:
        print("  WARN: confidence missing rate > 10%", flush=True)

    # 7) Cost estimate
    n_calls = n_q
    in_tok = 2500 * n_calls
    out_tok = 500 * n_calls
    in_price_batch = 1.25 / 2 / 1e6
    out_price_batch = 10.0 / 2 / 1e6
    cost = in_tok * in_price_batch + out_tok * out_price_batch
    print("\n=== Cost estimate (clustering, OpenAI batch) ===", flush=True)
    print(f"  calls: {n_calls}", flush=True)
    print(f"  input tokens (est): {in_tok:,}  @ ${in_price_batch*1e6:.4f}/1M = ${in_tok*in_price_batch:.2f}", flush=True)
    print(f"  output tokens (est): {out_tok:,} @ ${out_price_batch*1e6:.4f}/1M = ${out_tok*out_price_batch:.2f}", flush=True)
    print(f"  total estimated cost: ${cost:.2f}", flush=True)


if __name__ == "__main__":
    main()
