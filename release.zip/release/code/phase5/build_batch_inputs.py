"""Build MedXpertQA Text batch inputs for OpenAI — TWO protocols.

Protocol A: SCOPE (free-form, 50 samples per question)
  → standard pipeline: Answer: <letter/text>, Confidence: X%
  → output: openai_scope_chunk{0..6}.jsonl (7 chunks × n ∈ {8,8,8,8,8,8,2} = 50)

Protocol B: Logit-based MCQA (single call, constrained to letter, with logprobs)
  → prompt asks for ONLY the letter; max 3 tokens; top_logprobs=20
  → parse option token probabilities → softmax → calibrated logit confidence
  → output: openai_logit.jsonl (single batch, 500 rows)
"""
import os, json

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
INPUT = os.path.join(CAL_BASE, "data", "phase5", "medxpertqa_preprocessed.jsonl")
OUT_DIR = os.path.join(BASE, "batch_inputs")
os.makedirs(OUT_DIR, exist_ok=True)

# SCOPE system prompt — MCQA-aware free-form
SCOPE_SYSTEM = """You are answering multiple-choice medical questions for a research benchmark. Be concise and precise.

Your response MUST end with EXACTLY these two lines, with nothing after them:
Answer: <single letter from the options, e.g. "C">
Confidence: <integer between 0 and 100>%

If you genuinely do not know, write:
Answer: I don't know
Confidence: 0%"""

# Logit protocol system prompt — strict letter-only
LOGIT_SYSTEM = """You are answering multiple-choice medical questions. Output ONLY the single letter of the correct option (A, B, C, D, E, F, G, H, I, or J). No explanation, no prefix, no punctuation. Just the letter."""

N_SAMPLES = 50
MAX_TOK_SCOPE = 256
MAX_TOK_LOGIT = 3
MODEL = "gpt-5.4"

questions = [json.loads(l) for l in open(INPUT)]
print(f"Loaded {len(questions)} questions")


def build_scope():
    for ci in range(7):
        n = 8 if ci < 6 else 2
        rows = []
        for q in questions:
            rows.append({
                "custom_id": f"{q['qid']}__chunk{ci}",
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": MODEL,
                    "messages": [
                        {"role": "system", "content": SCOPE_SYSTEM},
                        {"role": "user", "content": q["question_final"]},
                    ],
                    "max_completion_tokens": MAX_TOK_SCOPE,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "reasoning_effort": "none",
                    "n": n,
                    "seed": ci,
                },
            })
        path = os.path.join(OUT_DIR, f"openai_scope_chunk{ci}.jsonl")
        with open(path, "w") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  SCOPE: {len(questions)*7} rows -> 7 chunks")


def build_logit():
    rows = []
    for q in questions:
        # Option list inline prompt (already in question_final), but repeat for clarity
        rows.append({
            "custom_id": f"{q['qid']}__logit",
            "method": "POST",
            "url": "/v1/chat/completions",
            "body": {
                "model": MODEL,
                "messages": [
                    {"role": "system", "content": LOGIT_SYSTEM},
                    {"role": "user", "content": q["question_final"]},
                ],
                "max_completion_tokens": MAX_TOK_LOGIT,
                "temperature": 0.0,
                "top_p": 1.0,
                "reasoning_effort": "none",
                "logprobs": True,
                "top_logprobs": 20,
                "seed": 0,
            },
        })
    path = os.path.join(OUT_DIR, "openai_logit.jsonl")
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  Logit: {len(rows)} rows -> {path}")


build_scope()
build_logit()

nq = len(questions)
print(f"\n=== Cost Estimate (Phase 5 MedXpertQA, OpenAI) ===")
print(f"  Questions: {nq}")
calls_scope = nq * N_SAMPLES
tok_in_scope = 400 * calls_scope  # question ~400 tokens incl options
tok_out_scope = 30 * calls_scope
cost_scope = (tok_in_scope * 1.25 * 0.5 + tok_out_scope * 10 * 0.5) / 1e6
print(f"  SCOPE: {calls_scope:,} calls, ~${cost_scope:.2f}")
calls_logit = nq
tok_in_logit = 400 * calls_logit
tok_out_logit = 3 * calls_logit
cost_logit = (tok_in_logit * 1.25 * 0.5 + tok_out_logit * 10 * 0.5) / 1e6
print(f"  Logit: {calls_logit:,} calls, ~${cost_logit:.2f}")
print(f"  Total: ~${cost_scope + cost_logit:.2f}")
