"""make_scope_figures.py — SCOPE NeurIPS figures + tables generator.

Reads:
  RESULTS.md   (the local equivalent of the markdown referenced in the prompt)
  phase{1..5}/confidence/calibration_metrics.csv   (authoritative numbers)
  phase{1..5}/confidence/{provider}_confidence.jsonl  (per-Q for regime plots)
  phase{1..5}/grading/{provider}_*_graded.jsonl       (per-Q correctness Y)

Writes everything to:
  paper_figures/

Usage:
  python make_scope_figures.py
"""
from __future__ import annotations

import json
import math
import os
import re
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import norm

# -----------------------------------------------------------------------------
# Paths and conventions
# -----------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
OUT = ROOT / "paper_figures"
OUT.mkdir(parents=True, exist_ok=True)
RESULTS_MD = ROOT / "RESULTS.md"

# Phase -> human dataset name (matches what the paper will say)
PHASE_DATASET = {
    "phase1": "SimpleQA",
    "phase2": "HLE",
    "phase3": "Math",
    "phase4": "PopQA",
    "phase5": "MedXpert",
}
PROVIDER_DISPLAY = {
    "openai": "GPT-5.4",
    "anthropic": "Claude-Opus-4.6",
    "gemini": "Gemini-3.1-Flash-Lite",
    "xai": "Grok-4.20",
    "mistral": "Mistral-Large",
}
METHOD_DISPLAY = {
    "conf_naive": "Naive",
    "conf_sssc": "SCOPE-2",
    "conf_verbalized": "Verbalized",
}
METHOD_ORDER = ["conf_naive", "conf_sssc", "conf_verbalized"]

plt.rcParams.update({
    "font.size": 9,
    "axes.titlesize": 10,
    "axes.labelsize": 9,
    "legend.fontsize": 8,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "figure.dpi": 150,
    "savefig.dpi": 300,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
})

# -----------------------------------------------------------------------------
# Step 1: Parse results
# -----------------------------------------------------------------------------
def load_metrics_csv() -> pd.DataFrame:
    """Authoritative source: per-phase calibration_metrics.csv.

    Returns long DataFrame with columns: phase, dataset, provider, method, n, ece, ace, brier, mean_conf, mean_acc.
    """
    rows = []
    for phase, dataset in PHASE_DATASET.items():
        csv_path = ROOT / phase / "confidence" / "calibration_metrics.csv"
        if not csv_path.exists():
            continue
        df = pd.read_csv(csv_path)
        df["phase"] = phase
        df["dataset"] = dataset
        rows.append(df)
    if not rows:
        raise RuntimeError("No calibration_metrics.csv files found")
    full = pd.concat(rows, ignore_index=True)
    return full[["phase", "dataset", "provider", "method", "n", "ece", "ace", "brier", "mean_conf", "mean_acc"]]


def parse_results_md_summary(path: Path) -> dict:
    """Light parse of RESULTS.md cross-check signals (counts, prose claims).

    Returns dict with: prose_claims (free text excerpts), table_block_counts.
    """
    if not path.exists():
        return {"prose_claims": [], "table_block_counts": 0}
    text = path.read_text()
    table_blocks = re.findall(r"^\|.*\|$", text, flags=re.MULTILINE)
    claims = []
    for line in text.splitlines():
        if "%" in line or "best" in line.lower() or "win" in line.lower() or "SSSC" in line:
            claims.append(line.strip())
    return {
        "prose_claims": claims[:20],
        "table_block_counts": len(table_blocks),
    }


def pivot_wide(long_df: pd.DataFrame) -> pd.DataFrame:
    """Long -> one row per (dataset, provider), columns per method for ECE / Brier."""
    long_df = long_df.copy()
    pivot_ece = long_df.pivot_table(index=["dataset", "provider"], columns="method", values="ece").reset_index()
    pivot_brier = long_df.pivot_table(index=["dataset", "provider"], columns="method", values="brier").reset_index()
    pivot_n = long_df.pivot_table(index=["dataset", "provider"], columns="method", values="n").reset_index()
    pivot_acc = long_df.pivot_table(index=["dataset", "provider"], columns="method", values="mean_acc").reset_index()

    wide = pivot_ece.rename(columns={m: f"ECE_{METHOD_DISPLAY[m].lower()}" for m in METHOD_ORDER})
    for m in METHOD_ORDER:
        wide[f"Brier_{METHOD_DISPLAY[m].lower()}"] = pivot_brier[m]
    wide["N"] = pivot_n[METHOD_ORDER[0]]
    wide["Accuracy"] = pivot_acc[METHOD_ORDER[0]]
    # winner = method with min ECE
    ece_cols = [f"ECE_{METHOD_DISPLAY[m].lower()}" for m in METHOD_ORDER]
    wide["Winner"] = wide[ece_cols].idxmin(axis=1).str.replace("ECE_", "")

    # Pretty provider name
    wide["Provider"] = wide["provider"].map(PROVIDER_DISPLAY).fillna(wide["provider"])
    wide = wide.rename(columns={"dataset": "Dataset"})
    cols = (
        ["Dataset", "Provider", "N", "Accuracy"]
        + [f"ECE_{m.lower()}" for m in ["naive", "scope-2", "verbalized"]]
        + [f"Brier_{m.lower()}" for m in ["naive", "scope-2", "verbalized"]]
        + ["Winner"]
    )
    return wide[cols]


# -----------------------------------------------------------------------------
# Step 2: Tables
# -----------------------------------------------------------------------------
def df_to_latex_full(wide: pd.DataFrame, path: Path) -> None:
    rows = []
    for _, r in wide.iterrows():
        ece_vals = [r["ECE_naive"], r["ECE_scope-2"], r["ECE_verbalized"]]
        brier_vals = [r["Brier_naive"], r["Brier_scope-2"], r["Brier_verbalized"]]
        best_e = int(np.argmin(ece_vals))
        best_b = int(np.argmin(brier_vals))

        def fmt(x, idx, best, fmt_str=".4f"):
            s = ("{:" + fmt_str + "}").format(x)
            return r"\textbf{" + s + "}" if idx == best else s

        rows.append(
            f"{r['Dataset']} & {r['Provider']} & {int(r['N'])} & {r['Accuracy']:.3f}"
            f" & {fmt(ece_vals[0], 0, best_e)} & {fmt(ece_vals[1], 1, best_e)} & {fmt(ece_vals[2], 2, best_e)}"
            f" & {fmt(brier_vals[0], 0, best_b)} & {fmt(brier_vals[1], 1, best_b)} & {fmt(brier_vals[2], 2, best_b)}"
            r" \\"
        )
    body = "\n".join(rows)
    tex = r"""\begin{table}[t]
\centering
\small
\setlength{\tabcolsep}{4pt}
\caption{Per benchmark--provider calibration. Best ECE/Brier per row in bold. Verbalized confidence imputes missing samples as $1.0$.}
\label{tab:full_results}
\begin{tabular}{llrrrrrrrr}
\toprule
Dataset & Provider & N & Acc & \multicolumn{3}{c}{ECE} & \multicolumn{3}{c}{Brier} \\
\cmidrule(lr){5-7} \cmidrule(lr){8-10}
 &  &  &  & Naive & SCOPE-2 & Verb. & Naive & SCOPE-2 & Verb. \\
\midrule
""" + body + r"""
\bottomrule
\end{tabular}
\end{table}
"""
    path.write_text(tex)


def make_summary_table(wide: pd.DataFrame) -> pd.DataFrame:
    """3 rows (Naive / SCOPE-2 / Verbalized) x summary columns."""
    methods = ["naive", "scope-2", "verbalized"]
    rows = []
    n_total = wide["N"].sum()
    for m in methods:
        ece = wide[f"ECE_{m}"].values
        bri = wide[f"Brier_{m}"].values
        n = wide["N"].values
        wins_best = (wide["Winner"] == m).sum()
        wins_vs_naive = (ece < wide["ECE_naive"].values).sum() if m != "naive" else None
        wins_vs_verb = (ece < wide["ECE_verbalized"].values).sum() if m != "verbalized" else None
        rows.append({
            "Method": {"naive": "Naive", "scope-2": "SCOPE-2", "verbalized": "Verbalized"}[m],
            "Mean ECE": ece.mean(),
            "Weighted ECE": np.average(ece, weights=n),
            "Mean Brier": bri.mean(),
            "Weighted Brier": np.average(bri, weights=n),
            "Best-on-cells": int(wins_best),
            "Wins vs Naive": "—" if wins_vs_naive is None else int(wins_vs_naive),
            "Wins vs Verbalized": "—" if wins_vs_verb is None else int(wins_vs_verb),
        })
    return pd.DataFrame(rows)


def summary_to_latex(summary: pd.DataFrame, path: Path, n_cells: int) -> None:
    body_rows = []
    # bold best per numeric column (lower better for ECE/Brier; higher better for counts)
    cols_lower_better = ["Mean ECE", "Weighted ECE", "Mean Brier", "Weighted Brier"]
    cols_higher_better = ["Best-on-cells", "Wins vs Naive", "Wins vs Verbalized"]

    def fmt_val(col, val):
        if val == "—":
            return "—"
        if col in cols_lower_better:
            return f"{val:.4f}"
        return f"{int(val)}"

    best_marker = {}
    for col in cols_lower_better:
        vals = summary[col].astype(float)
        best_marker[col] = int(np.argmin(vals.values))
    for col in cols_higher_better:
        vals = []
        for v in summary[col]:
            vals.append(-1 if v == "—" else float(v))
        best_marker[col] = int(np.argmax(vals))

    for i, r in summary.iterrows():
        cells = [r["Method"]]
        for col in ["Mean ECE", "Weighted ECE", "Best-on-cells", "Wins vs Naive", "Wins vs Verbalized", "Mean Brier", "Weighted Brier"]:
            s = fmt_val(col, r[col])
            if best_marker[col] == i and s != "—":
                s = r"\textbf{" + s + "}"
            cells.append(s)
        body_rows.append(" & ".join(cells) + r" \\")
    body = "\n".join(body_rows)
    tex = r"""\begin{table}[t]
\centering
\small
\caption{Aggregate calibration across all benchmark--provider cells. Cell counts are out of """ + str(n_cells) + r""" cells (see Table~\ref{tab:full_results}).}
\label{tab:summary}
\begin{tabular}{lrrrrrrr}
\toprule
Method & Mean ECE & Weighted ECE & Best-on-cells & Wins vs Naive & Wins vs Verb. & Mean Brier & Weighted Brier \\
\midrule
""" + body + r"""
\bottomrule
\end{tabular}
\end{table}
"""
    path.write_text(tex)


# -----------------------------------------------------------------------------
# Step 3: Empirical plots
# -----------------------------------------------------------------------------
def fig_heatmap_all_cells(wide: pd.DataFrame, path_pdf: Path, path_png: Path) -> None:
    methods = ["naive", "scope-2", "verbalized"]
    method_disp = ["Naive", "SCOPE-2", "Verbalized"]
    # Sort: by dataset (custom order), then provider
    dataset_order = ["SimpleQA", "PopQA", "MedXpert", "Math", "HLE"]
    wide = wide.copy()
    wide["__d"] = wide["Dataset"].map({d: i for i, d in enumerate(dataset_order)}).fillna(99)
    wide = wide.sort_values(["__d", "Provider"]).reset_index(drop=True)
    labels = [f"{r['Dataset']} · {r['Provider']}" for _, r in wide.iterrows()]
    M = np.array([wide[f"ECE_{m}"].values for m in methods]).T  # (rows, 3)

    fig, ax = plt.subplots(figsize=(5.5, max(3.5, 0.32 * len(labels))))
    im = ax.imshow(M, aspect="auto", cmap="Reds", vmin=0, vmax=max(0.85, M.max()))
    ax.set_xticks(range(3))
    ax.set_xticklabels(method_disp)
    ax.set_yticks(range(len(labels)))
    ax.set_yticklabels(labels)
    for i in range(M.shape[0]):
        best = int(np.argmin(M[i]))
        for j in range(M.shape[1]):
            color = "white" if M[i, j] > 0.55 else "black"
            weight = "bold" if j == best else "normal"
            ax.text(j, i, f"{M[i,j]:.3f}", ha="center", va="center", color=color, fontsize=7.5, fontweight=weight)
    cbar = fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02)
    cbar.set_label("ECE", fontsize=8)
    ax.set_xlabel("Confidence method")
    fig.tight_layout()
    fig.savefig(path_pdf)
    fig.savefig(path_png)
    plt.close(fig)


def fig_winner_counts(wide: pd.DataFrame, path_pdf: Path, path_png: Path) -> None:
    counts = wide["Winner"].value_counts().reindex(["naive", "scope-2", "verbalized"]).fillna(0)
    labels = ["Naive", "SCOPE-2", "Verbalized"]
    fig, ax = plt.subplots(figsize=(3.6, 2.6))
    bars = ax.bar(labels, counts.values, color=["#888", "#1f6f9f", "#d97a4a"])
    for bar, v in zip(bars, counts.values):
        ax.text(bar.get_x() + bar.get_width() / 2, v + 0.2, str(int(v)), ha="center", va="bottom", fontsize=9)
    ax.set_ylabel("Cells with lowest ECE")
    ax.set_ylim(0, counts.values.max() * 1.2 + 1)
    fig.tight_layout()
    fig.savefig(path_pdf)
    fig.savefig(path_png)
    plt.close(fig)


def fig_per_benchmark_grouped(wide: pd.DataFrame, path_pdf: Path, path_png: Path) -> None:
    """Provider-wise grouped bars within each benchmark (chosen for clarity)."""
    methods = ["naive", "scope-2", "verbalized"]
    method_disp = ["Naive", "SCOPE-2", "Verb."]
    colors = ["#888", "#1f6f9f", "#d97a4a"]
    dataset_order = ["SimpleQA", "PopQA", "MedXpert", "Math", "HLE"]
    fig, axes = plt.subplots(1, 5, figsize=(13.5, 3.0), sharey=False)
    for ax, ds in zip(axes, dataset_order):
        sub = wide[wide["Dataset"] == ds].sort_values("Provider").reset_index(drop=True)
        if len(sub) == 0:
            ax.set_visible(False)
            continue
        x = np.arange(len(sub))
        width = 0.27
        for i, (m, c) in enumerate(zip(methods, colors)):
            ax.bar(x + (i - 1) * width, sub[f"ECE_{m}"].values, width, color=c, label=method_disp[i])
        ax.set_xticks(x)
        ax.set_xticklabels([p.replace("Claude-Opus-4.6", "Claude").replace("Gemini-3.1-Flash-Lite", "Gemini")
                            .replace("GPT-5.4", "GPT").replace("Mistral-Large", "Mistral").replace("Grok-4.20", "Grok")
                            for p in sub["Provider"]], rotation=30, ha="right", fontsize=7.5)
        ax.set_title(f"{ds} (n={int(sub['N'].sum())})")
        ax.set_ylabel("ECE" if ds == dataset_order[0] else "")
        ax.grid(axis="y", linestyle=":", alpha=0.4)
    axes[0].legend(loc="upper left", frameon=False, fontsize=7.5)
    fig.tight_layout()
    fig.savefig(path_pdf)
    fig.savefig(path_png)
    plt.close(fig)


def fig_failure_cases(wide: pd.DataFrame, path_pdf: Path, path_png: Path) -> None:
    fail = wide[wide["ECE_verbalized"] < wide["ECE_scope-2"]].copy()
    if len(fail) == 0:
        # Make an empty placeholder
        fig, ax = plt.subplots(figsize=(4, 2.4))
        ax.text(0.5, 0.5, "No verbalized<SCOPE-2 cells", ha="center", va="center", transform=ax.transAxes)
        ax.set_axis_off()
        fig.savefig(path_pdf); fig.savefig(path_png); plt.close(fig)
        return
    fail["label"] = fail["Dataset"] + " · " + fail["Provider"]
    fail = fail.sort_values("ECE_verbalized")
    methods = ["naive", "scope-2", "verbalized"]
    method_disp = ["Naive", "SCOPE-2", "Verb."]
    colors = ["#888", "#1f6f9f", "#d97a4a"]
    x = np.arange(len(fail))
    width = 0.27
    fig, ax = plt.subplots(figsize=(max(5.5, 1.6 * len(fail)), 3.6))
    for i, (m, c) in enumerate(zip(methods, colors)):
        ax.bar(x + (i - 1) * width, fail[f"ECE_{m}"].values, width, color=c, label=method_disp[i])
    ax.set_xticks(x)
    ax.set_xticklabels(fail["label"].values, rotation=15, ha="right", fontsize=8.5)
    ax.set_ylabel("ECE")
    ax.set_title("Cells where Verbalized beats SCOPE-2 (proxy-gap regime)")
    ax.set_ylim(0, fail["ECE_naive"].max() * 1.25)
    ax.legend(loc="upper left", frameon=False, ncol=3)
    ax.grid(axis="y", linestyle=":", alpha=0.4)
    fig.tight_layout()
    fig.savefig(path_pdf); fig.savefig(path_png); plt.close(fig)


# -----------------------------------------------------------------------------
# Step 4: Theory illustrative plots
# -----------------------------------------------------------------------------
def fig_theory_optimism_bounds(path_pdf: Path, path_png: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(8.5, 3.2))
    ns = np.arange(5, 201)
    # Panel 1: generic Hoeffding-style bound for K
    ax = axes[0]
    for K in [2, 5, 10]:
        ax.plot(ns, np.sqrt(np.log(max(K, 2)) / (2 * ns)), label=f"K={K}")
    ax.set_xlabel("n (samples)")
    ax.set_ylabel(r"$\sqrt{\log K / (2n)}$")
    ax.set_yscale("log")
    ax.set_title("Generic optimism bound (theoretical)")
    ax.legend(frameon=False)
    ax.grid(linestyle=":", alpha=0.4)

    # Panel 2: margin-dependent bound exp(-n*Delta^2/2)
    ax = axes[1]
    for delta in [0.05, 0.10, 0.20, 0.40]:
        ax.plot(ns, np.exp(-ns * delta**2 / 2), label=fr"$\Delta$={delta}")
    ax.set_xlabel("n (samples)")
    ax.set_ylabel(r"$e^{-n\Delta^2/2}$")
    ax.set_yscale("log")
    ax.set_title("Margin-dependent bound (theoretical)")
    ax.legend(frameon=False)
    ax.grid(linestyle=":", alpha=0.4)
    fig.tight_layout()
    fig.savefig(path_pdf); fig.savefig(path_png); plt.close(fig)


def fig_theory_local_law(path_pdf: Path, path_png: Path) -> None:
    """Low-margin local law: sqrt(n)*E[c1 - theta_n] -> phi(2lambda)."""
    fig, ax = plt.subplots(figsize=(5.0, 3.2))
    lams = np.linspace(-3, 3, 401)
    ax.plot(lams, norm.pdf(2 * lams), color="black", lw=1.8, label=r"$\varphi(2\lambda)$ (theory)")

    # Monte Carlo overlay
    rng = np.random.default_rng(0)
    markers = {"50": "o", "100": "s", "200": "^"}
    colors = {"50": "#1f6f9f", "100": "#d97a4a", "200": "#5fa45f"}
    n_lams_mc = 21
    lams_mc = np.linspace(-3, 3, n_lams_mc)
    R_TRIALS = 4000
    for n in [50, 100, 200]:
        ys = []
        for lam in lams_mc:
            p = 0.5 + lam / np.sqrt(n)
            p = float(np.clip(p, 1e-6, 1 - 1e-6))
            X = rng.binomial(1, p, size=(R_TRIALS, n))
            phat = X.mean(axis=1)
            c1 = np.maximum(phat, 1 - phat)
            theta = np.where(phat >= 0.5, p, 1 - p)
            v = np.mean(np.sqrt(n) * (c1 - theta))
            ys.append(v)
        ax.plot(lams_mc, ys, marker=markers[str(n)], linestyle="none", markersize=4, color=colors[str(n)], label=f"MC n={n}")

    ax.axhline(0, color="grey", lw=0.6)
    ax.set_xlabel(r"$\lambda$")
    ax.set_ylabel(r"$\sqrt{n}\,(\hat c_1 - \theta_n)$")
    ax.set_title("Low-margin local law (theoretical + Monte Carlo)")
    ax.legend(frameon=False, fontsize=7.5)
    ax.grid(linestyle=":", alpha=0.4)
    fig.tight_layout()
    fig.savefig(path_pdf); fig.savefig(path_png); plt.close(fig)


def make_regime_examples_table(out_csv: Path, out_tex: Path) -> bool:
    """5 representative per-Q examples spanning the regime, as a CSV + LaTeX table.

    Each row shows: regime label, nΔ², dataset/provider, K, top cluster sizes,
    Δ, ĉ_naive, ĉ_sssc, ĉ_verb, Y, brief Q description.
    """
    import glob

    KNOWN_PROVIDERS = {"openai", "anthropic", "gemini", "xai", "mistral"}
    qs = []
    for ph in PHASE_DATASET:
        confs, grades = {}, {}
        for cf in glob.glob(str(ROOT / ph / "confidence" / "*_confidence.jsonl")):
            prov = os.path.basename(cf).replace("_confidence.jsonl", "")
            if prov not in KNOWN_PROVIDERS:
                continue
            with open(cf) as fh:
                for line in fh:
                    r = json.loads(line)
                    confs[(prov, r["id"])] = r
        for gf in glob.glob(str(ROOT / ph / "grading" / "*_graded.jsonl")):
            prov = os.path.basename(gf).split("_")[0]
            if prov not in KNOWN_PROVIDERS:
                continue
            with open(gf) as fh:
                for line in fh:
                    r = json.loads(line)
                    if r.get("Y") is not None:
                        grades[(prov, r["id"])] = r["Y"]
        for f in glob.glob(str(ROOT / ph / "clustering" / "*_clustered.jsonl")):
            prov = os.path.basename(f).split("_")[0]
            if prov not in KNOWN_PROVIDERS:
                continue
            with open(f) as fh:
                for line in fh:
                    r = json.loads(line)
                    cs = r.get("cluster_sizes")
                    if not cs:
                        continue
                    n = sum(cs)
                    if n < 30:
                        continue
                    cs_sorted = sorted(cs, reverse=True)
                    delta = cs_sorted[0] / n - (cs_sorted[1] / n if len(cs_sorted) > 1 else 0)
                    cf_r = confs.get((prov, r["id"]), {})
                    Y = grades.get((prov, r["id"]))
                    if cf_r.get("conf_naive") is None or Y is None:
                        continue
                    qs.append({
                        "phase": ph, "dataset": PHASE_DATASET[ph], "provider": prov,
                        "id": r["id"], "n": n, "K": len(cs_sorted), "delta": delta,
                        "ndelta2": n * delta ** 2,
                        "cluster_sizes": cs_sorted,
                        "question": (r.get("question") or "")[:160],
                        "modal_label": (r.get("modal_cluster_label") or "")[:60],
                        "gold": (r.get("gold_answer") or "")[:60],
                        "conf_naive": cf_r["conf_naive"],
                        "conf_sssc": cf_r["conf_sssc"],
                        "conf_verb": cf_r.get("conf_verbalized"),
                        "Y": Y,
                    })

    targets = [
        (0.5, r"low ($n\Delta^2{<}1$)"),
        (2.3, r"transition ($\approx \log K$)"),
        (8.0, r"intermediate"),
        (25.0, r"large ($> 5\log K$)"),
        (50.0, r"deep large"),
    ]
    used = set()
    picks = []
    for t, lbl in targets:
        cands = sorted(qs, key=lambda q: abs(q["ndelta2"] - t))
        for c in cands[:300]:
            if c["id"] not in used:
                used.add(c["id"])
                picks.append((t, lbl, c))
                break

    # Build CSV
    rows_csv = []
    for t, lbl, p in picks:
        cs6 = p["cluster_sizes"][:6]
        cs_str = "-".join(str(x) for x in cs6)
        if len(p["cluster_sizes"]) > 6:
            cs_str += f"…(+{len(p['cluster_sizes'])-6})"
        rows_csv.append({
            "regime_label": lbl,
            "n_delta2": round(p["ndelta2"], 1),
            "dataset_provider": f"{p['dataset']}·{PROVIDER_DISPLAY[p['provider']]}",
            "n": p["n"], "K": p["K"], "delta": round(p["delta"], 3),
            "cluster_sizes_top6": cs_str,
            "conf_naive": round(p["conf_naive"], 3),
            "conf_sssc": round(p["conf_sssc"], 3),
            "conf_verb": round(p["conf_verb"], 3) if p["conf_verb"] is not None else "",
            "Y": p["Y"],
            "question_brief": p["question"],
            "modal_answer": p["modal_label"],
            "gold_answer": p["gold"],
        })
    pd.DataFrame(rows_csv).to_csv(out_csv, index=False)

    # Build LaTeX
    def latex_escape(s):
        return (s.replace("&", r"\&").replace("%", r"\%")
                  .replace("$", r"\$").replace("#", r"\#")
                  .replace("_", r"\_").replace("{", r"\{").replace("}", r"\}"))

    latex_rows = []
    for t, lbl, p in picks:
        cs6 = p["cluster_sizes"][:6]
        cs_str = "-".join(str(x) for x in cs6)
        if len(p["cluster_sizes"]) > 6:
            cs_str += f"\\ldots(+{len(p['cluster_sizes'])-6})"
        ds_prov = f"{p['dataset']}\\,$\\cdot$\\,{p['provider']}"
        cv = f"{p['conf_verb']:.2f}" if p["conf_verb"] is not None else "--"
        # Truncate question for table
        qshort = p["question"][:55].rstrip()
        if len(p["question"]) > 55:
            qshort += "\\ldots"
        latex_rows.append(
            f"{lbl} & {p['ndelta2']:.1f} & {ds_prov} & {p['K']} & "
            f"{cs_str} & {p['delta']:.2f} & {p['conf_naive']:.2f} & {p['conf_sssc']:.2f} & "
            f"{cv} & {p['Y']} & \\textit{{{latex_escape(qshort)}}} \\\\"
        )
    body = "\n".join(latex_rows)
    tex = r"""\begin{table}[t]
\centering
\scriptsize
\setlength{\tabcolsep}{3.5pt}
\caption{Five representative questions spanning the $n\Delta^2$ regimes. ``cluster sizes'' lists the top-six cluster sample counts (largest first). $\hat c_1{=}$ Naive, $\hat c_2{=}$ SCOPE-2, $\hat c_v{=}$ Verbalized, $Y\in\{0,1\}{=}$ correctness. As $n\Delta^2$ grows, the cluster distribution concentrates and $\hat c_1$ approaches $\hat c_2$.}
\label{tab:regime_examples}
\begin{tabular}{llllcccccc l}
\toprule
Regime & $n\Delta^2$ & Dataset $\cdot$ Provider & $K$ & Cluster sizes (top-6) & $\Delta$ & $\hat c_1$ & $\hat c_2$ & $\hat c_v$ & $Y$ & Question (excerpt) \\
\midrule
""" + body + r"""
\bottomrule
\end{tabular}
\end{table}
"""
    out_tex.write_text(tex)
    return True


def fig_regime_map_examples(path_pdf: Path, path_png: Path) -> bool:
    """Regime map with 5 representative *per-Q* examples (not cell averages),
    one per regime region, with cluster-size mini-charts.
    """
    import glob

    # Load all per-Q clustered records to find representatives
    qs = []
    for ph in ["phase1", "phase2", "phase3", "phase4", "phase5"]:
        for f in glob.glob(str(ROOT / ph / "clustering" / "*_clustered.jsonl")):
            prov = os.path.basename(f).split("_")[0]
            with open(f) as fh:
                for line in fh:
                    r = json.loads(line)
                    cs = r.get("cluster_sizes")
                    if not cs:
                        continue
                    n = sum(cs)
                    if n < 30:
                        continue
                    cs_sorted = sorted(cs, reverse=True)
                    delta = cs_sorted[0] / n - (cs_sorted[1] / n if len(cs_sorted) > 1 else 0)
                    qs.append({
                        "phase": ph, "prov": prov, "id": r.get("id", "?"),
                        "n": n, "K": len(cs_sorted), "delta": delta,
                        "ndelta2": n * delta ** 2,
                        "cluster_sizes": cs_sorted,
                        "modal_label": (r.get("modal_cluster_label") or "")[:42],
                        "dataset": PHASE_DATASET[ph],
                        "provider_disp": PROVIDER_DISPLAY.get(prov, prov),
                    })

    targets = [0.5, 2.5, 8.0, 25.0, 50.0]
    picks = []
    used = set()
    for t in targets:
        cands = sorted(qs, key=lambda q: abs(q["ndelta2"] - t))
        # Prefer >=3 clusters and not already chosen
        pick = None
        for c in cands[:300]:
            if c["K"] >= 3 and c["n"] >= 46 and c["id"] not in used:
                pick = c
                break
        if pick is None:
            pick = next(c for c in cands if c["id"] not in used)
        used.add(pick["id"])
        picks.append((t, pick))

    # Build figure: top = regime map, bottom = 5 cluster-size bar minis
    fig = plt.figure(figsize=(12.5, 6.4))
    gs = fig.add_gridspec(2, 5, height_ratios=[2.2, 1.0], hspace=0.45, wspace=0.30)

    # === Top: regime map ===
    ax = fig.add_subplot(gs[0, :])
    ns = np.linspace(20, 80, 200)
    deltas = np.linspace(0.02, 1.0, 200)
    N, D = np.meshgrid(ns, deltas)
    Z = N * D ** 2
    pc = ax.pcolormesh(N, D, np.log10(Z + 1e-9), cmap="viridis", shading="auto", alpha=0.55)
    cbar = fig.colorbar(pc, ax=ax, fraction=0.04, pad=0.02)
    cbar.set_label(r"$\log_{10}(n\Delta^2)$")
    K = 10
    cs_lines = ax.contour(N, D, Z, levels=[1, np.log(K), 5 * np.log(K)],
                          colors=["white", "yellow", "red"], linewidths=1.4)
    ax.clabel(cs_lines, fmt={1: r"$n\Delta^2{=}1$",
                              float(np.log(K)): r"$\log K$",
                              float(5 * np.log(K)): r"$5\log K$"}, fontsize=8)

    # Place 5 example dots
    letters = "abcde"
    example_colors = ["#ffffff", "#ffe199", "#ffae5a", "#e84d2e", "#7d2410"]
    annotations = []
    for (t, pick), letter, col in zip(picks, letters, example_colors):
        x = pick["n"]
        y = pick["delta"]
        ax.scatter([x], [y], s=200, color=col, edgecolors="black", linewidths=1.2, zorder=10)
        ax.text(x, y, letter, ha="center", va="center", fontsize=9, fontweight="bold",
                color="black" if letter in "ab" else "white", zorder=11)
        annotations.append((letter, t, pick))

    # Region labels
    ax.text(28, 0.07, "low-margin\n(SCOPE-2 dominates)", color="white", fontsize=9.5, style="italic")
    ax.text(70, 0.92, "large-margin\n(naive ≈ SCOPE-2)", color="white", fontsize=9.5, ha="right", style="italic")

    ax.set_xlim(20, 80)
    ax.set_ylim(0.02, 1.0)
    ax.set_xlabel("n (samples per question)")
    ax.set_ylabel(r"$\Delta$ (top-two margin)")
    ax.set_title(r"Regime map ($K{=}10$) with five representative questions")

    # === Bottom: 5 cluster-size mini bar charts ===
    for i, ((letter, t, pick), col) in enumerate(zip(annotations, example_colors)):
        ax_i = fig.add_subplot(gs[1, i])
        cs = pick["cluster_sizes"]
        n_show = min(len(cs), 12)
        cs_show = cs[:n_show]
        # Sum the rest into "others"
        others = sum(cs[n_show:])
        labels_v = [f"#{j+1}" for j in range(len(cs_show))]
        if others > 0:
            cs_show = cs_show + [others]
            labels_v = labels_v + [f"+{len(cs)-n_show} more"]
        bar_colors = ["#1f6f9f"] + ["#bbbbbb"] * (len(cs_show) - 1)
        ypos = np.arange(len(cs_show))
        ax_i.barh(ypos, cs_show, color=bar_colors, edgecolor="white", linewidth=0.4)
        ax_i.set_yticks(ypos)
        ax_i.set_yticklabels(labels_v, fontsize=7)
        ax_i.invert_yaxis()
        ax_i.set_xlim(0, max(pick["n"], max(cs_show)) * 1.05)
        ax_i.set_xticks([0, pick["n"]])
        ax_i.set_xticklabels(["0", f"{pick['n']}"], fontsize=7)
        ax_i.set_title(f"({letter}) $n\\Delta^2{{=}}{pick['ndelta2']:.1f}$  K={pick['K']}\n"
                        f"{pick['dataset']}·{pick['provider_disp'].split('-')[0]}",
                        fontsize=8.5)
        ax_i.spines["right"].set_visible(False)
        ax_i.spines["top"].set_visible(False)
        # Highlight letter with same fill color in title-area
        ax_i.text(0.02, 1.18, letter, transform=ax_i.transAxes,
                  fontsize=11, fontweight="bold", color="black",
                  bbox=dict(boxstyle="circle,pad=0.18", facecolor=col, edgecolor="black", linewidth=0.8))

    fig.tight_layout()
    fig.savefig(path_pdf); fig.savefig(path_png); plt.close(fig)
    return True


def fig_regime_map_with_cells(perq: dict, wide: pd.DataFrame, path_pdf: Path, path_png: Path) -> bool:
    """Empirical overlay: regime map (theory background) + 19 (n, Δ̄) cells colored by winner."""
    # Compute per-cell Δ̄ (mean empirical margin) and median Δ
    cell_stats = []
    for (phase, prov), df in perq.items():
        m = df["empirical_margin"].dropna().values
        if len(m) == 0:
            continue
        cell_stats.append({
            "phase": phase, "dataset": PHASE_DATASET[phase], "provider": prov,
            "delta_mean": float(np.mean(m)),
            "delta_med": float(np.median(m)),
            "n_samples": 46 if (phase == "phase2" and prov == "anthropic") else 50,
        })
    cell_df = pd.DataFrame(cell_stats)

    # Join with winner from wide df (wide uses display Provider names)
    inv_disp = {v: k for k, v in PROVIDER_DISPLAY.items()}
    merged = []
    for _, c in cell_df.iterrows():
        prov_disp_target = PROVIDER_DISPLAY.get(c["provider"], c["provider"])
        match = wide[(wide["Dataset"] == c["dataset"]) & (wide["Provider"] == prov_disp_target)]
        if len(match) == 0:
            continue
        m0 = match.iloc[0]
        merged.append({**c.to_dict(),
                       "winner": m0["Winner"],
                       "ece_naive": m0["ECE_naive"],
                       "ece_sssc": m0["ECE_scope-2"],
                       "ece_verb": m0["ECE_verbalized"],
                       "gain_sssc_vs_naive": m0["ECE_naive"] - m0["ECE_scope-2"],
                       "n_questions": len(perq[(c["phase"], c["provider"])])})
    if not merged:
        return False
    cdf = pd.DataFrame(merged)

    # Theory regime map background
    ns = np.linspace(20, 80, 200)
    deltas = np.linspace(0.05, 1.0, 200)
    N, D = np.meshgrid(ns, deltas)
    Z = N * D ** 2

    fig, ax = plt.subplots(figsize=(6.4, 4.8))
    pc = ax.pcolormesh(N, D, np.log10(Z + 1e-9), cmap="viridis", shading="auto", alpha=0.55)
    cbar = fig.colorbar(pc, ax=ax, fraction=0.04, pad=0.02)
    cbar.set_label(r"$\log_{10}(n\Delta^2)$")
    K = 10
    cs = ax.contour(N, D, Z, levels=[1, np.log(K), 5 * np.log(K)],
                    colors=["white", "yellow", "red"], linewidths=1.4)
    fmt = {1: r"$n\Delta^2{=}1$", float(np.log(K)): r"$\log K$", float(5 * np.log(K)): r"$5\log K$"}
    ax.clabel(cs, fmt=fmt, fontsize=7.5)

    # Scatter cells (jitter x slightly so overlapping points are readable)
    rng = np.random.default_rng(0)
    color_map = {"naive": "#666666", "scope-2": "#1f6f9f", "verbalized": "#d97a4a"}
    label_map = {"naive": "Naive best", "scope-2": "SCOPE-2 best", "verbalized": "Verbalized best"}
    plotted = set()
    for _, r in cdf.iterrows():
        x = r["n_samples"] + rng.uniform(-1.0, 1.0)
        y = r["delta_mean"]
        c = color_map[r["winner"]]
        size = 60 + 40 * np.log10(max(1, r["n_questions"]))
        ax.scatter([x], [y], s=size, color=c, edgecolors="white", linewidths=0.8, zorder=5,
                   label=label_map[r["winner"]] if r["winner"] not in plotted else None)
        plotted.add(r["winner"])

    # Annotate notable cells: biggest SCOPE-2 win, biggest verbalized win, lowest Δ̄
    cdf_sorted = cdf.sort_values("gain_sssc_vs_naive", ascending=False)
    notable = []
    notable.append(("biggest SCOPE-2 gain", cdf_sorted.iloc[0]))
    notable.append(("biggest Verb gain", cdf[cdf["winner"] == "verbalized"].sort_values("ece_verb").iloc[0])
                   if (cdf["winner"] == "verbalized").any() else None)
    notable.append(("lowest Δ̄", cdf.sort_values("delta_mean").iloc[0]))
    placed = set()
    for tag, item in [n for n in notable if n is not None]:
        if id(item) in placed:
            continue
        placed.add(id(item))
        x = item["n_samples"] + 1.5
        y = item["delta_mean"]
        label = f"{item['dataset']}·\n{PROVIDER_DISPLAY.get(item['provider'], item['provider']).split('-')[0]}"
        ax.annotate(label, xy=(x - 1.5, y), xytext=(x + 5, y),
                    fontsize=7.5, ha="left", va="center",
                    arrowprops=dict(arrowstyle="-", color="black", lw=0.6, alpha=0.7))

    ax.set_xlim(20, 80)
    ax.set_ylim(0.05, 1.0)
    ax.set_xlabel("n (samples per question)")
    ax.set_ylabel(r"$\bar\Delta$ (per-cell mean top-two margin)")
    ax.set_title(r"Empirical cells on theory regime map ($K{=}10$)")
    # Region labels
    ax.text(25, 0.10, "low-margin\n(SCOPE-2 wins)", color="white", fontsize=8.5, ha="left", style="italic")
    ax.text(70, 0.92, "large-margin\n(naive ≈ SCOPE-2)", color="white", fontsize=8.5, ha="right", style="italic")
    # Legend (deduplicated)
    handles, labels = ax.get_legend_handles_labels()
    seen = {}
    for h, l in zip(handles, labels):
        if l not in seen:
            seen[l] = h
    ax.legend(seen.values(), seen.keys(), loc="lower right", frameon=True, fontsize=7.5,
              facecolor="white", edgecolor="gray")
    fig.tight_layout()
    fig.savefig(path_pdf); fig.savefig(path_png); plt.close(fig)
    return True


def fig_regime_strip(perq: dict, wide: pd.DataFrame, path_pdf: Path, path_png: Path) -> bool:
    """1D regime strip: cells sorted by nΔ̄², with ECE-per-method panel beside."""
    cell_stats = []
    for (phase, prov), df in perq.items():
        m = df["empirical_margin"].dropna().values
        if len(m) == 0:
            continue
        cell_stats.append({
            "phase": phase, "dataset": PHASE_DATASET[phase], "provider": prov,
            "delta_mean": float(np.mean(m)),
            "n_samples": 46 if (phase == "phase2" and prov == "anthropic") else 50,
        })
    cell_df = pd.DataFrame(cell_stats)

    merged = []
    for _, c in cell_df.iterrows():
        prov_disp_target = PROVIDER_DISPLAY.get(c["provider"], c["provider"])
        match = wide[(wide["Dataset"] == c["dataset"]) & (wide["Provider"] == prov_disp_target)]
        if len(match) == 0:
            continue
        m0 = match.iloc[0]
        merged.append({
            **c.to_dict(),
            "n_delta2": c["n_samples"] * c["delta_mean"] ** 2,
            "winner": m0["Winner"],
            "ece_naive": m0["ECE_naive"],
            "ece_sssc": m0["ECE_scope-2"],
            "ece_verb": m0["ECE_verbalized"],
            "label": f"{c['dataset']}·{prov_disp_target.split('-')[0]}",
        })
    if not merged:
        return False
    cdf = pd.DataFrame(merged).sort_values("n_delta2").reset_index(drop=True)

    K = 10
    logK = float(np.log(K))
    five_logK = 5 * logK

    color_map = {"naive": "#666666", "scope-2": "#1f6f9f", "verbalized": "#d97a4a"}
    label_map = {"naive": "Naive best", "scope-2": "SCOPE-2 best", "verbalized": "Verbalized best"}

    fig, axes = plt.subplots(1, 2, figsize=(10.5, 5.6),
                              gridspec_kw={"width_ratios": [1.4, 1.0], "wspace": 0.05},
                              sharey=True)

    ax = axes[0]
    # Regime band shading
    xmin, xmax = 0.7, max(60, cdf["n_delta2"].max() * 1.2)
    ax.axvspan(xmin, 1, color="#a3c8ec", alpha=0.30)
    ax.axvspan(1, logK, color="#cce5d6", alpha=0.30)
    ax.axvspan(logK, five_logK, color="#fff3cf", alpha=0.30)
    ax.axvspan(five_logK, xmax, color="#f5d6cc", alpha=0.30)
    for v, lbl in [(1, r"$n\Delta^2{=}1$"), (logK, r"$\log K$"), (five_logK, r"$5\log K$")]:
        ax.axvline(v, color="black", lw=0.6, ls="--", alpha=0.7)
        ax.text(v, len(cdf) - 0.4, lbl, ha="center", va="bottom", fontsize=7.5, rotation=0,
                bbox=dict(boxstyle="round,pad=0.2", facecolor="white", edgecolor="none", alpha=0.85))

    plotted = set()
    for i, r in cdf.iterrows():
        c = color_map[r["winner"]]
        ax.scatter([r["n_delta2"]], [i], s=110, color=c, edgecolors="white", linewidths=0.8, zorder=5,
                   label=label_map[r["winner"]] if r["winner"] not in plotted else None)
        plotted.add(r["winner"])
        ax.hlines(i, xmin, r["n_delta2"], color=c, lw=0.7, alpha=0.5, zorder=2)
    ax.set_xscale("log")
    ax.set_xlim(xmin, xmax)
    ax.set_ylim(-0.7, len(cdf) - 0.3)
    ax.set_yticks(range(len(cdf)))
    ax.set_yticklabels(cdf["label"].values, fontsize=8.5)
    ax.set_xlabel(r"$n\bar\Delta^2$  (per-cell, log scale)")
    ax.set_title("Regime position of empirical cells (sorted)")
    ax.invert_yaxis()
    # Region labels at top
    yt = -0.9
    ax.text(np.sqrt(xmin * 1), yt, "low\nmargin", ha="center", va="bottom", fontsize=7.5, color="#1a4d7a", style="italic", clip_on=False)
    ax.text(np.sqrt(1 * logK), yt, "transition", ha="center", va="bottom", fontsize=7.5, color="#2a6a3f", style="italic", clip_on=False)
    ax.text(np.sqrt(logK * five_logK), yt, "intermediate", ha="center", va="bottom", fontsize=7.5, color="#7a6a1a", style="italic", clip_on=False)
    ax.text(np.sqrt(five_logK * xmax), yt, "large\nmargin", ha="center", va="bottom", fontsize=7.5, color="#7a3a1a", style="italic", clip_on=False)
    ax.legend(loc="lower right", frameon=True, fontsize=7.5, facecolor="white")
    ax.grid(axis="x", linestyle=":", alpha=0.3)

    # Right panel: ECE per method, parallel coordinates
    ax2 = axes[1]
    method_colors = {"ece_naive": "#666666", "ece_sssc": "#1f6f9f", "ece_verb": "#d97a4a"}
    method_labels = {"ece_naive": "Naive", "ece_sssc": "SCOPE-2", "ece_verb": "Verbalized"}
    method_markers = {"ece_naive": "s", "ece_sssc": "o", "ece_verb": "^"}
    seen_m = set()
    for i, r in cdf.iterrows():
        # Connecting line across the 3 methods for this cell
        xs = [r["ece_naive"], r["ece_sssc"], r["ece_verb"]]
        ax2.plot(xs, [i] * 3, color="lightgray", lw=0.6, zorder=1)
        for col in ["ece_naive", "ece_sssc", "ece_verb"]:
            ax2.scatter([r[col]], [i], s=42, color=method_colors[col], marker=method_markers[col],
                        edgecolors="white", linewidths=0.5, zorder=4,
                        label=method_labels[col] if col not in seen_m else None)
            seen_m.add(col)
    # Highlight the winning method per row
    for i, r in cdf.iterrows():
        win_col = {"naive": "ece_naive", "scope-2": "ece_sssc", "verbalized": "ece_verb"}[r["winner"]]
        ax2.scatter([r[win_col]], [i], s=140, facecolors="none",
                    edgecolors=method_colors[win_col], linewidths=1.6, zorder=5)
    ax2.set_xlabel("ECE")
    ax2.set_xlim(0, max(0.85, cdf[["ece_naive", "ece_sssc", "ece_verb"]].max().max() * 1.05))
    ax2.set_title("ECE per method (winner circled)")
    ax2.invert_yaxis()
    ax2.legend(loc="lower right", frameon=True, fontsize=7.5, facecolor="white")
    ax2.grid(axis="x", linestyle=":", alpha=0.3)

    fig.tight_layout()
    fig.savefig(path_pdf); fig.savefig(path_png); plt.close(fig)
    return True


def fig_theory_regime_map(path_pdf: Path, path_png: Path) -> None:
    ns = np.linspace(5, 200, 200)
    deltas = np.linspace(0.01, 0.5, 200)
    N, D = np.meshgrid(ns, deltas)
    Z = N * D ** 2
    fig, ax = plt.subplots(figsize=(5.6, 3.4))
    pc = ax.pcolormesh(N, D, np.log10(Z + 1e-9), cmap="viridis", shading="auto")
    cbar = fig.colorbar(pc, ax=ax)
    cbar.set_label(r"$\log_{10}(n\Delta^2)$")
    K = 10
    cs = ax.contour(N, D, Z, levels=[1, np.log(K), 5 * np.log(K)], colors=["white", "yellow", "red"], linewidths=1.2)
    fmt = {1: r"$n\Delta^2{=}1$", float(np.log(K)): r"$n\Delta^2{=}\log K$", float(5 * np.log(K)): r"$5\log K$"}
    ax.clabel(cs, fmt=fmt, fontsize=7)
    # Region labels
    ax.text(40, 0.05, "low-margin\n(unstable)", color="white", fontsize=8.5, ha="center")
    ax.text(150, 0.40, "large-margin\n(stable)", color="white", fontsize=8.5, ha="center")
    ax.set_xlabel("n (samples)")
    ax.set_ylabel(r"$\Delta$ (top-two margin)")
    ax.set_title(r"Regime map: $n\Delta^2$ (theoretical, $K=10$)")
    fig.tight_layout()
    fig.savefig(path_pdf); fig.savefig(path_png); plt.close(fig)


def fig_theory_split_tradeoff(path_pdf: Path, path_png: Path) -> None:
    K = 5
    fig, axes = plt.subplots(1, 3, figsize=(10.5, 3.0), sharey=False)
    for ax, n_total in zip(axes, [20, 50, 100]):
        ss = np.arange(2, n_total - 1)
        for delta in [0.15, 0.25, 0.40]:
            U = 1.0 / (4 * (n_total - ss)) + (K - 1) * np.exp(-ss * delta**2 / 2) + (K - 1) * np.exp(-n_total * delta**2 / 2)
            ax.plot(ss / n_total, U, label=fr"$\Delta$={delta}")
        ax.set_xlabel("s/n (selection fraction)")
        ax.set_yscale("log")
        ax.set_title(f"n={n_total}")
        ax.grid(linestyle=":", alpha=0.4)
        if n_total == 20:
            ax.set_ylabel(r"Illustrative bound $U(s)$")
        ax.legend(frameon=False, fontsize=7.5)
    fig.suptitle("Split-ratio tradeoff (theoretical, K=5)", y=0.99)
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    fig.savefig(path_pdf); fig.savefig(path_png); plt.close(fig)


def fig_theory_stability_certificate(path_pdf: Path, path_png: Path) -> None:
    Rs = np.arange(5, 101)
    fig, ax = plt.subplots(figsize=(5.0, 3.0))
    for delta in [0.10, 0.05, 0.01]:
        ax.plot(Rs, np.sqrt(np.log(2 / delta) / (2 * Rs)), label=fr"$\delta$={delta}")
    ax.set_xlabel("R (repeated splits)")
    ax.set_ylabel(r"$\sqrt{\log(2/\delta)/(2R)}$")
    ax.set_title("Stability certificate Hoeffding correction (theoretical)")
    ax.legend(frameon=False)
    ax.grid(linestyle=":", alpha=0.4)
    fig.tight_layout()
    fig.savefig(path_pdf); fig.savefig(path_png); plt.close(fig)


# -----------------------------------------------------------------------------
# Step 5: Empirical regime plots from per-Q files
# -----------------------------------------------------------------------------
def load_per_q_data():
    """Returns {(phase, provider): DataFrame[id, conf_naive, conf_sssc, conf_verbalized, empirical_margin, modal_freq, Y]}."""
    out = {}
    for phase in PHASE_DATASET:
        conf_dir = ROOT / phase / "confidence"
        grade_dir = ROOT / phase / "grading"
        if not conf_dir.exists() or not grade_dir.exists():
            continue
        for cf in conf_dir.glob("*_confidence.jsonl"):
            provider = cf.stem.replace("_confidence", "")
            # Find matching graded file (variable suffix)
            graded_candidates = list(grade_dir.glob(f"{provider}_*_graded.jsonl"))
            if not graded_candidates:
                continue
            gf = graded_candidates[0]
            grades = {}
            with open(gf) as f:
                for line in f:
                    r = json.loads(line)
                    if r.get("Y") is not None:
                        grades[r["id"]] = r["Y"]
            recs = []
            with open(cf) as f:
                for line in f:
                    r = json.loads(line)
                    if r["id"] not in grades:
                        continue
                    recs.append({
                        "id": r["id"],
                        "phase": phase,
                        "provider": provider,
                        "conf_naive": r["conf_naive"],
                        "conf_sssc": r["conf_sssc"],
                        "conf_verbalized": r["conf_verbalized"],
                        "empirical_margin": r.get("empirical_margin"),
                        "modal_freq": r.get("modal_freq"),
                        "Y": grades[r["id"]],
                    })
            if recs:
                out[(phase, provider)] = pd.DataFrame(recs)
    return out


def fig_regime_margin(perq: dict, path_pdf: Path, path_png: Path) -> None:
    """SCOPE-2 ECE gain over Naive, stratified by empirical margin bins."""
    # Aggregate across all (phase, provider) cells, weighted equally
    rows = []
    for (phase, prov), df in perq.items():
        rows.append(df.assign(cell=f"{PHASE_DATASET[phase]}·{prov}"))
    if not rows:
        return False
    df = pd.concat(rows, ignore_index=True)
    df = df.dropna(subset=["empirical_margin"])

    # Bin by margin
    bins = [0, 0.05, 0.1, 0.2, 0.4, 0.7, 1.01]
    labels = ["[0,.05)", "[.05,.1)", "[.1,.2)", "[.2,.4)", "[.4,.7)", "[.7,1]"]
    df["bin"] = pd.cut(df["empirical_margin"], bins=bins, labels=labels, right=False, include_lowest=True)

    def per_bin_ece(g, col):
        return float(np.mean(np.abs(g[col].values - g["Y"].values)))

    rows2 = []
    for b, g in df.groupby("bin", observed=True):
        rows2.append({
            "bin": b,
            "n": len(g),
            "ece_naive_proxy": per_bin_ece(g, "conf_naive"),
            "ece_sssc_proxy": per_bin_ece(g, "conf_sssc"),
        })
    bin_df = pd.DataFrame(rows2)
    bin_df["gain"] = bin_df["ece_naive_proxy"] - bin_df["ece_sssc_proxy"]

    fig, ax = plt.subplots(figsize=(5.4, 3.0))
    x = np.arange(len(bin_df))
    bars = ax.bar(x, bin_df["gain"].values, color="#1f6f9f")
    for bar, n in zip(bars, bin_df["n"]):
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2, h + 0.001 * (1 if h >= 0 else -1),
                f"n={n}", ha="center", va="bottom" if h >= 0 else "top", fontsize=7)
    ax.axhline(0, color="black", lw=0.6)
    ax.set_xticks(x)
    ax.set_xticklabels(bin_df["bin"].astype(str).values)
    ax.set_xlabel(r"Empirical top-two margin $\hat\Delta$")
    ax.set_ylabel(r"$|\bar c_{\rm naive}-Y| - |\bar c_{\rm SCOPE\text{-}2}-Y|$ (per-Q)")
    ax.set_title("Margin-stratified per-Q calibration gain (empirical)")
    ax.grid(axis="y", linestyle=":", alpha=0.4)
    fig.tight_layout()
    fig.savefig(path_pdf); fig.savefig(path_png); plt.close(fig)
    return True


def fig_reliability_failure_case(perq: dict, wide: pd.DataFrame, path_pdf: Path, path_png: Path) -> bool:
    """Reliability diagram for a representative cell where Verbalized beats SCOPE-2."""
    fail = wide[wide["ECE_verbalized"] < wide["ECE_scope-2"]].copy()
    if len(fail) == 0:
        return False
    # Pick the largest-N failure cell
    fail = fail.sort_values("N", ascending=False)
    target = fail.iloc[0]
    dataset = target["Dataset"]
    provider_disp = target["Provider"]
    inv_disp = {v: k for k, v in PROVIDER_DISPLAY.items()}
    provider_short = inv_disp.get(provider_disp, provider_disp.lower())
    phase = {v: k for k, v in PHASE_DATASET.items()}[dataset]
    df = perq.get((phase, provider_short))
    if df is None or len(df) == 0:
        return False

    n_bins = 15
    edges = np.linspace(0, 1, n_bins + 1)

    def reliability(c, y):
        bin_means_c, bin_means_y, bin_n = [], [], []
        for i in range(n_bins):
            mask = (c >= edges[i]) & (c < edges[i + 1]) if i < n_bins - 1 else (c >= edges[i]) & (c <= edges[i + 1])
            if mask.sum() == 0:
                continue
            bin_means_c.append(c[mask].mean())
            bin_means_y.append(y[mask].mean())
            bin_n.append(mask.sum())
        return np.array(bin_means_c), np.array(bin_means_y), np.array(bin_n)

    fig, ax = plt.subplots(figsize=(4.6, 4.0))
    ax.plot([0, 1], [0, 1], color="black", lw=0.7, ls="--", label="ideal")
    Y = df["Y"].values.astype(float)
    for col, label, color in [("conf_sssc", "SCOPE-2", "#1f6f9f"),
                              ("conf_verbalized", "Verbalized", "#d97a4a")]:
        c = df[col].values.astype(float)
        bc, by, bn = reliability(c, Y)
        if len(bc) == 0:
            continue
        sizes = 8 + 60 * bn / bn.max()
        ax.plot(bc, by, "-", color=color, alpha=0.6, lw=1.0)
        ax.scatter(bc, by, s=sizes, color=color, label=label, edgecolors="white", linewidths=0.5)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    ax.set_xlabel("Mean confidence in bin")
    ax.set_ylabel("Mean accuracy in bin")
    ax.set_title(f"Reliability: {dataset} · {provider_disp}\n(verbalized<SCOPE-2 cell; bubble = bin n)")
    ax.legend(frameon=False, loc="upper left")
    ax.grid(linestyle=":", alpha=0.4)
    fig.tight_layout()
    fig.savefig(path_pdf); fig.savefig(path_png); plt.close(fig)
    return True


# -----------------------------------------------------------------------------
# Step 6: Blueprint and missing-data note
# -----------------------------------------------------------------------------
BLUEPRINT_TEXT = """# Figures & Tables Blueprint — SCOPE NeurIPS

## Main text (theory-first NeurIPS logic)

1. **Framework diagram** — `fig_framework_diagram.pdf` — pipeline schematic: question Q → n LLM samples → semantic clustering → naive (one-stage) vs. SCOPE-2 (sample-split) estimators, with the post-selection-bias warning on naive and the unbiasedness/calibration guarantees on SCOPE-2.

2. **Theory-signature plots** — `fig_theory_optimism_bounds.pdf` (one-stage optimism) and `fig_theory_local_law.pdf` (low-margin local law).
   *Story:* one-stage SC is biased upward, the bias has both a generic Hoeffding-style ceiling and a sharper margin-dependent ceiling, and the low-margin local law characterizes the regime where the bias does not vanish in n.

2b. **Regime examples table** — `regime_examples_table.tex` (and `.csv`).
   *Story:* five representative questions, one per $n\Delta^2$ regime, showing the cluster-size distribution, the three confidence estimates, and the correctness $Y$. Reading down the table the cluster mass concentrates and $\hat c_1$ collapses to $\hat c_2$ — concrete evidence that the SCOPE-2 vs. Naive gap is governed by the regime, not by dataset or provider. Designed for the experiment section beside the clean regime map (`fig_theory_regime_map.pdf`).

3. **Main summary table** — `summary_results_table.tex`.
   *Story:* SCOPE-2 wins on a clear majority of benchmark--provider cells under both mean and weighted ECE, dominates on Brier on average, and never increases ECE materially when Verbalized happens to be better.

4. **Per-benchmark grouped bars** — `fig_per_benchmark_grouped.pdf`.
   *Story:* dataset-level breakdown showing where SCOPE-2 wins decisively (HLE, SimpleQA), where it ties (Math, easy regime), and where verbalized takes over (a small set of high-accuracy or high-stable-error cells).

5. **Failure-case plot** — `fig_failure_cases.pdf` and reliability diagnostic `fig_reliability_failure_case.pdf` (if generated).
   *Story:* identifies the agreement-to-correctness gap regime — settings where consistent answers are systematically wrong, so estimator-side debiasing alone cannot fix the residual bias.

## Appendix

- **Full table** `full_results_table.tex` — every benchmark--provider row.
- **Heatmap** `fig_heatmap_all_cells.pdf` — at-a-glance ECE across all cells × methods.
- **Winner counts** `fig_winner_counts.pdf` — supports summary table.
- **Regime map** `fig_theory_regime_map.pdf` — visualizes the n·Δ² boundary between low- and large-margin regimes.
- **Split-ratio tradeoff** `fig_theory_split_tradeoff.pdf` — illustrates SCOPE's selection/evaluation budget tradeoff.
- **Stability certificate** `fig_theory_stability_certificate.pdf` — Hoeffding correction vs. R for the repeated-split certificate.
- **Empirical margin-stratified gain** `fig_regime_margin.pdf` (if generated) — SCOPE-2 gain vs. naive within margin bins, an empirical signature of the theory.
- **Missing-data note** `missing_data_for_regime_plots.md` — fields that would be needed for the not-yet-feasible regime plots.

## Notes
- All numbers in the tables and bars are sourced from per-phase `calibration_metrics.csv`. The markdown summary `RESULTS.md` is for human reading; numerical authority is the CSVs.
- Verbalized confidence imputes missing per-sample reports as 1.0 — applied uniformly across all phases as of 2026-04-27.
- Pending experiments (xAI HLE retry4, Math gemini/anthropic clustering, MedXpert non-OpenAI providers) are not yet in any figure.
"""

MISSING_DATA_TEXT = """# Missing Data for Empirical Regime Plots

The current per-Q records (`{phase}/confidence/{provider}_confidence.jsonl`) contain:
- `id`, `n_samples`, `n_clusters`, `modal_cluster`, `modal_cluster_label`
- `conf_naive`, `conf_sssc`, `conf_verbalized`, `empirical_margin`, `modal_freq`
- `verbalized_n_extracted`

Joined with `{phase}/grading/{provider}_*_graded.jsonl` (`Y` ∈ {{0,1}}).

This is sufficient to make:
- ✅ `fig_regime_margin` — empirical SCOPE-2 gain vs. naive stratified by `empirical_margin`.
- ✅ `fig_reliability_failure_case` — reliability diagram for any (phase, provider) cell.

What is **missing** to make the remaining empirical regime plots:

## Empirical Regime Plot 2: Stability-stratified gain
Needs the **per-Q repeated-split kappa hat** (`hat_kappa_R`):
- For each Q, compute R independent random half-splits of the n samples; on each split take the modal cluster of the selection half (S) and check whether it equals the modal cluster of the evaluation half (E); average.
- Currently `compute_confidence.py` only stores the mean SCOPE-2 confidence — not the per-split agreement vector or `hat_kappa_R` itself.
- **Fix:** extend `compute_confidence.py` to record:
  - `hat_kappa_R` (mean of indicator{z_S = z_E}),
  - optionally the full vector of R split outcomes for tightness / variance reporting.

## Reference-pool agreement (optional)
For "stable-but-wrong" diagnostics (anthropic on PopQA / SimpleQA failure cells):
- Cluster the union of all providers' samples for each Q,
- For each provider's modal answer, compute the cross-provider agreement rate.
- This requires a cross-provider clustering step that the current pipeline does not run.

## Recommended next step
- Re-extend `phaseN/confidence/compute_confidence.py` to emit `hat_kappa_R` per Q (a few lines of code; no new API calls).
- Re-run `compute_confidence.py` for each phase (cheap: pure local computation).
- Then re-run `make_scope_figures.py` to add `fig_regime_stability.pdf`.
"""


# -----------------------------------------------------------------------------
# Step 7: Main
# -----------------------------------------------------------------------------
def main():
    print("=" * 60)
    print("SCOPE figures & tables generator")
    print("=" * 60)

    long = load_metrics_csv()
    print(f"Loaded {len(long)} rows from per-phase calibration_metrics.csv")
    md_signal = parse_results_md_summary(RESULTS_MD)
    print(f"RESULTS.md table-block lines: {md_signal['table_block_counts']}")

    wide = pivot_wide(long)
    print(f"Pivoted to {len(wide)} (Dataset, Provider) cells")

    # ---------- Tables ----------
    long.to_csv(OUT / "results_parsed.csv", index=False)
    print(f"  wrote {OUT/'results_parsed.csv'}")

    wide_for_csv = wide.copy()
    wide_for_csv.to_csv(OUT / "full_results_table.csv", index=False)
    df_to_latex_full(wide, OUT / "full_results_table.tex")
    print(f"  wrote full_results_table.{{csv,tex}}")

    summary = make_summary_table(wide)
    summary.to_csv(OUT / "summary_results_table.csv", index=False)
    summary_to_latex(summary, OUT / "summary_results_table.tex", n_cells=len(wide))
    print(f"  wrote summary_results_table.{{csv,tex}}")

    print("\nSummary table:")
    print(summary.to_string(index=False))

    # ---------- Console summary ----------
    n_cells = len(wide)
    win_counts = wide["Winner"].value_counts().to_dict()
    print("\n=== Cells by winner ===")
    print(f"  total cells: {n_cells}")
    for m in ["scope-2", "naive", "verbalized"]:
        print(f"  {m}: {win_counts.get(m, 0)}")
    print("\n=== Per-method aggregate ECE ===")
    for m in ["naive", "scope-2", "verbalized"]:
        ece = wide[f"ECE_{m}"].values
        print(f"  {m:10s}  mean={ece.mean():.4f}  weighted={np.average(ece, weights=wide['N'].values):.4f}")

    # ---------- Empirical plots ----------
    print("\nGenerating empirical plots...")
    fig_heatmap_all_cells(wide, OUT / "fig_heatmap_all_cells.pdf", OUT / "fig_heatmap_all_cells.png")
    fig_winner_counts(wide, OUT / "fig_winner_counts.pdf", OUT / "fig_winner_counts.png")
    fig_per_benchmark_grouped(wide, OUT / "fig_per_benchmark_grouped.pdf", OUT / "fig_per_benchmark_grouped.png")
    fig_failure_cases(wide, OUT / "fig_failure_cases.pdf", OUT / "fig_failure_cases.png")

    # ---------- Theory plots ----------
    print("Generating theory plots...")
    fig_theory_optimism_bounds(OUT / "fig_theory_optimism_bounds.pdf", OUT / "fig_theory_optimism_bounds.png")
    fig_theory_local_law(OUT / "fig_theory_local_law.pdf", OUT / "fig_theory_local_law.png")
    fig_theory_regime_map(OUT / "fig_theory_regime_map.pdf", OUT / "fig_theory_regime_map.png")
    fig_theory_split_tradeoff(OUT / "fig_theory_split_tradeoff.pdf", OUT / "fig_theory_split_tradeoff.png")
    fig_theory_stability_certificate(OUT / "fig_theory_stability_certificate.pdf", OUT / "fig_theory_stability_certificate.png")

    # ---------- Empirical regime plots ----------
    print("Generating empirical regime plots...")
    perq = load_per_q_data()
    print(f"  loaded per-Q data for {len(perq)} cells")
    margin_ok = fig_regime_margin(perq, OUT / "fig_regime_margin.pdf", OUT / "fig_regime_margin.png")
    rel_ok = fig_reliability_failure_case(perq, wide, OUT / "fig_reliability_failure_case.pdf", OUT / "fig_reliability_failure_case.png")
    table_ok = make_regime_examples_table(OUT / "regime_examples_table.csv", OUT / "regime_examples_table.tex")
    print(f"  regime examples table (5 representative Qs): {'✓' if table_ok else '✗'}")
    # Remove old cluttered/scatter overlays (replaced by clean theory map + table)
    for stale in ("fig_regime_map_with_cells.pdf", "fig_regime_map_with_cells.png",
                  "fig_regime_strip.pdf", "fig_regime_strip.png",
                  "fig_regime_map_examples.pdf", "fig_regime_map_examples.png"):
        p = OUT / stale
        if p.exists():
            p.unlink()
    print(f"  margin-stratified gain: {'✓' if margin_ok else '✗'}")
    print(f"  reliability failure-case: {'✓' if rel_ok else '✗'}")

    # ---------- Blueprint and missing-data ----------
    (OUT / "figures_tables_blueprint.md").write_text(BLUEPRINT_TEXT)
    (OUT / "missing_data_for_regime_plots.md").write_text(MISSING_DATA_TEXT)
    print(f"  wrote blueprint and missing-data note")

    # ---------- Final inventory ----------
    print("\n" + "=" * 60)
    print("Generated files:")
    for p in sorted(OUT.iterdir()):
        print(f"  {p.name}  ({p.stat().st_size:,} bytes)")
    print("=" * 60)


if __name__ == "__main__":
    main()
