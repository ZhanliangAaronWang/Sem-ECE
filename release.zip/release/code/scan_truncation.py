"""Scan all raw outputs for truncation indicators across phases × providers."""
import json, os, glob, re
from collections import defaultdict

ROOT = os.path.dirname(os.path.abspath(__file__))

# (phase_num, max_tok, provider, file_glob)
TARGETS = [
    (1, 256,  "openai",    "phase1/batch_outputs/openai_raw.jsonl"),
    (1, 256,  "mistral",   "phase1/batch_outputs/mistral_raw.jsonl"),
    (1, 256,  "xai",       "phase1/batch_outputs/xai_raw.jsonl"),
    (1, 256,  "gemini",    "phase1/batch_outputs/gemini_raw.jsonl"),
    (1, 256,  "anthropic", "phase1/batch_outputs/anthropic_raw.jsonl"),
    (2, 512,  "openai",    "phase2/batch_outputs/openai_hle_chunk*.jsonl"),
    (2, 512,  "mistral",   "phase2/batch_outputs/mistral_raw_chunk*.jsonl"),
    (2, 512,  "xai",       "phase2/batch_outputs/xai_raw_w*.jsonl"),
    (3, 1024, "openai",    "phase3/batch_outputs/openai_math_chunk*.jsonl"),
    (3, 1024, "mistral",   "phase3/batch_outputs/mistral_raw_chunk*.jsonl"),
    (3, 1024, "xai",       "phase3/batch_outputs/xai_raw_chunk0.jsonl"),
]

ANS_RE = re.compile(r"Answer:\s*(.+?)(?=\nConfidence|\Z)", re.DOTALL)
CONF_RE = re.compile(r"Confidence:\s*[0-9]")


def iter_samples(path, provider):
    """Yield (completion_tokens, finish_reason, content) per sample."""
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except Exception:
                continue
            if provider == "openai":
                body = r.get("response", {}).get("body", {})
                usage = body.get("usage", {}) or {}
                choices = body.get("choices", []) or []
                total_ct = usage.get("completion_tokens", 0) or 0
                n = max(1, len(choices))
                per = total_ct // n  # approximate per-choice
                for c in choices:
                    content = (c.get("message") or {}).get("content") or ""
                    fr = c.get("finish_reason", "")
                    yield per, fr, content
            elif provider == "mistral":
                body = r.get("response", {}).get("body", {})
                usage = body.get("usage", {}) or {}
                choices = body.get("choices", []) or []
                ct = usage.get("completion_tokens", 0) or 0
                if choices:
                    c = choices[0]
                    content = (c.get("message") or {}).get("content") or ""
                    fr = c.get("finish_reason", "")
                    yield ct, fr, content
            elif provider == "xai" or provider == "gemini":
                if r.get("status") != "success":
                    continue
                # P1/P2 xAI has flat completion_tokens; P3 xAI nests it under usage
                ct = r.get("completion_tokens")
                if ct is None:
                    ct = (r.get("usage") or {}).get("completion_tokens", 0) or 0
                content = r.get("text") or ""
                yield ct, "", content
            elif provider == "anthropic":
                res = r.get("result") or {}
                if res.get("type") != "succeeded":
                    continue
                msg = res.get("message") or {}
                usage = msg.get("usage", {}) or {}
                ct = usage.get("output_tokens", 0) or 0
                parts = msg.get("content") or []
                content = parts[0].get("text", "") if parts else ""
                fr = msg.get("stop_reason", "")
                yield ct, fr, content


def scan():
    print(f"{'phase':>5} {'provider':>10} {'max':>5} {'N':>9} {'near_cap%':>9} {'len_fr%':>8} {'no_ans%':>8} {'no_conf%':>9}")
    print("-" * 76)
    rows = []
    for phase, maxtok, provider, pat in TARGETS:
        paths = sorted(glob.glob(os.path.join(ROOT, pat)))
        if not paths:
            continue
        n = near_cap = len_fr = no_ans = no_conf = 0
        for p in paths:
            for ct, fr, content in iter_samples(p, provider):
                n += 1
                if ct >= int(maxtok * 0.95):
                    near_cap += 1
                if fr == "length":
                    len_fr += 1
                if not ANS_RE.search(content):
                    no_ans += 1
                if not CONF_RE.search(content):
                    no_conf += 1
        if n == 0:
            continue
        rows.append((phase, provider, maxtok, n, near_cap, len_fr, no_ans, no_conf))
        print(f"{phase:>5} {provider:>10} {maxtok:>5} {n:>9,} "
              f"{near_cap*100/n:>8.2f}% {len_fr*100/n:>7.2f}% "
              f"{no_ans*100/n:>7.2f}% {no_conf*100/n:>8.2f}%")
    return rows


if __name__ == "__main__":
    scan()
