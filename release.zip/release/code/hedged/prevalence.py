"""How common are hedged / approximate answers, and how does the judge treat them?

Reviewer concern: answers like "roughly four", "between three and five", "about 1990"
force the clustering judge into an arbitrary call — merge them with the precise value or
not — and that call propagates into ĉ₁ and therefore into ECE.

Step 1 (this file): measure prevalence objectively over every extracted answer, and measure
what the judge currently *does* with them (same cluster as the precise value, or not).

No API calls.
"""
import os, re, json, argparse
from collections import defaultdict, Counter
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CELLS = {"SimpleQA": "phase1/clustering/{p}_simpleqa_clustered.jsonl",
         "HLE": "phase2/clustering/{p}_simpleqa_clustered.jsonl",
         "PopQA": "phase4/clustering/{p}_popqa_clustered.jsonl"}
PROVS = ["openai", "anthropic", "gemini", "xai", "mistral"]

# Narrow set: markers that make the answer itself imprecise.
APPROX = re.compile(r"\b(roughly|approximately|approx\.?|about|around|circa|ca\.|nearly|"
                    r"almost|some|or so|more or less|on the order of|in the region of)\b|~\s*\d",
                    re.I)
RANGE = re.compile(r"\b(between\s+[\w.]+\s+and\s+[\w.]+|from\s+[\d.]+\s+to\s+[\d.]+)\b"
                   r"|\b\d+(\.\d+)?\s*[-–—]\s*\d+(\.\d+)?\b", re.I)
BOUND = re.compile(r"\b(at least|at most|more than|less than|fewer than|greater than|"
                   r"no more than|no fewer than|up to|over|under)\s+[\d.]", re.I)
UNCERT = re.compile(r"\b(probably|likely|possibly|perhaps|maybe|i think|i believe|"
                    r"presumably|apparently|it seems|appears to be|not (?:entirely )?sure|"
                    r"unsure|uncertain|unclear|best guess|my guess)\b", re.I)
ALT = re.compile(r"\b(either\s+.+?\s+or\b|\bor possibly\b|\bor perhaps\b)", re.I)

FAMILIES = [("approximation", APPROX), ("range", RANGE), ("bound", BOUND),
            ("uncertainty", UNCERT), ("alternatives", ALT)]

# Strip a hedge to its numeric/entity core, so "roughly four" -> "four"
STRIP = re.compile(r"^\s*(?:roughly|approximately|approx\.?|about|around|circa|ca\.|nearly|"
                   r"almost|some|probably|likely|possibly|perhaps|maybe|i think(?: it'?s)?|"
                   r"i believe(?: it'?s)?|presumably|apparently|~)\s+", re.I)


def classify(text):
    """-> set of hedge families present."""
    t = text or ""
    return {name for name, rx in FAMILIES if rx.search(t)}


def norm_core(text):
    """lowercase, strip a leading hedge word, drop punctuation/space."""
    t = STRIP.sub("", (text or "").strip())
    t = re.sub(r"[^\w\s.]", "", t.lower())
    return re.sub(r"\s+", " ", t).strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                  "RESULTS_hedged_prevalence.md"))
    ap.add_argument("--examples", type=int, default=12)
    args = ap.parse_args()

    per_bench = defaultdict(lambda: {"n": 0, "hedged": 0, "fam": Counter()})
    per_cell = defaultdict(lambda: [0, 0])
    # judge behaviour: hedged answer whose stripped core matches another answer verbatim
    same_cluster, diff_cluster = defaultdict(int), defaultdict(int)
    examples = []

    for bench, pat in CELLS.items():
        for prov in PROVS:
            path = os.path.join(ROOT, pat.format(p=prov))
            if not os.path.exists(path):
                continue
            for line in open(path):
                r = json.loads(line)
                ans = r["answer_extracted"]
                asg = r["cluster_assignments"]
                cores = [norm_core(a) for a in ans]
                fams = [classify(a) for a in ans]
                for i, a in enumerate(ans):
                    per_bench[bench]["n"] += 1
                    per_cell[(bench, prov)][1] += 1
                    if fams[i]:
                        per_bench[bench]["hedged"] += 1
                        per_cell[(bench, prov)][0] += 1
                        for f in fams[i]:
                            per_bench[bench]["fam"][f] += 1
                # judge behaviour: for each hedged answer, find a non-hedged answer with the
                # same normalised core and see whether the judge merged them
                for i, a in enumerate(ans):
                    if not fams[i] or not cores[i]:
                        continue
                    for j, b in enumerate(ans):
                        if j == i or fams[j] or cores[j] != cores[i]:
                            continue
                        key = bench
                        if asg[i] == asg[j]:
                            same_cluster[key] += 1
                        else:
                            diff_cluster[key] += 1
                            if len(examples) < args.examples:
                                examples.append((bench, prov, r["id"], a, b))
                        break

    L = ["# How common are hedged / approximate answers, and what does the judge do with them?\n",
         "Motivation: a reviewer may worry that answers such as *\"roughly four\"*, *\"between "
         "three and five\"* or *\"about 1990\"* force the clustering judge into an arbitrary "
         "merge-or-split decision that then propagates into ĉ₁ and into ECE. This measures the "
         "size of the problem before we bound its effect.\n",
         "Detection is lexical and deliberately broad (it over-counts rather than under-counts): "
         "approximation words (*roughly, approximately, about, around, circa, ~*), explicit "
         "ranges (*between X and Y*, *3–5*), one-sided bounds (*at least 4*, *more than 100*), "
         "epistemic hedges (*probably, likely, I think, uncertain*), and stated alternatives "
         "(*either X or Y*).\n",
         "## 1. Prevalence, over every extracted answer in the corpus\n",
         "| benchmark | answers scanned | hedged | share |",
         "|---|---:|---:|---:|"]
    tot_n = tot_h = 0
    for b in ("SimpleQA", "HLE", "PopQA"):
        d = per_bench[b]
        if not d["n"]:
            continue
        tot_n += d["n"]; tot_h += d["hedged"]
        L.append(f"| {b} | {d['n']:,} | {d['hedged']:,} | **{d['hedged']/d['n']:.2%}** |")
    L.append(f"| **all** | **{tot_n:,}** | **{tot_h:,}** | **{tot_h/max(tot_n,1):.2%}** |")

    L += ["\n### by hedge family (share of all answers)\n",
          "| benchmark | approximation | range | bound | uncertainty | alternatives |",
          "|---|---:|---:|---:|---:|---:|"]
    for b in ("SimpleQA", "HLE", "PopQA"):
        d = per_bench[b]
        if not d["n"]:
            continue
        L.append(f"| {b} | " + " | ".join(
            f"{d['fam'][f]/d['n']:.2%}" for f, _ in FAMILIES) + " |")

    L += ["\n### by model (share of that model's answers that are hedged)\n",
          "| benchmark | " + " | ".join(PROVS) + " |",
          "|---|" + "---:|" * len(PROVS)]
    for b in ("SimpleQA", "HLE", "PopQA"):
        cells = [per_cell[(b, p)] for p in PROVS]
        if not any(c[1] for c in cells):
            continue
        L.append(f"| {b} | " + " | ".join(
            f"{c[0]/c[1]:.2%}" if c[1] else "—" for c in cells) + " |")

    L += ["\n## 2. What the judge actually does with them\n",
          "For every hedged answer we look for another answer in the same question whose text "
          "is identical after stripping the hedge (*\"roughly four\"* → *\"four\"*), and check "
          "whether the judge put the two in the same cluster. This isolates exactly the "
          "decision the reviewer is worried about.\n",
          "| benchmark | matched hedged/precise pairs | judge merged | judge separated | merge rate |",
          "|---|---:|---:|---:|---:|"]
    for b in ("SimpleQA", "HLE", "PopQA"):
        s, d = same_cluster[b], diff_cluster[b]
        if s + d == 0:
            continue
        L.append(f"| {b} | {s+d:,} | {s:,} | {d:,} | **{s/(s+d):.1%}** |")
    S, D = sum(same_cluster.values()), sum(diff_cluster.values())
    if S + D:
        L.append(f"| **all** | **{S+D:,}** | **{S:,}** | **{D:,}** | **{S/(S+D):.1%}** |")

    if examples:
        L += ["\n### cases where the judge *separated* a hedged answer from its precise twin\n"]
        for bench, prov, qid, a, b_ in examples:
            L.append(f"- `{bench}/{prov}/{qid}` — {a[:90]!r}  vs  {b_[:90]!r}")

    L.append("\n*Next step: `impact.py` bounds the effect on ECE by re-clustering every hedged "
             "answer both ways — forced into the modal cluster, and forced out of it.*")

    with open(args.out, "w") as f:
        f.write("\n".join(L) + "\n")
    print("\n".join(L[:40]))
    print("\nwrote", args.out)


if __name__ == "__main__":
    main()
