"""Bound the effect of hedged / approximate answers on the evaluation.

The clustering judge has to make a call on answers like "roughly four": merge it with
"four", or keep it separate. Rather than argue about which call is right, we take both
extremes and report the bracket:

  MERGE-ALL  every hedged answer is forced into the question's modal cluster
  SPLIT-ALL  every hedged answer is forced out, into its own singleton cluster

The truth is between the two rows. If Sem₁-ECE, Sem₂-ECE and the gap barely move across
that bracket, the convention does not matter for the paper's conclusions.

No API calls — a pure re-computation over the stored partitions.
"""
import os, json, sys, argparse
from collections import defaultdict
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
sys.path.insert(0, os.path.join(ROOT, "cross_judge"))
from compare import sssc_confidence, naive_confidence, ece_10bin      # noqa: E402
sys.path.insert(0, BASE)
from prevalence import classify                                       # noqa: E402

CELLS = {"SimpleQA": ("phase1/clustering/{p}_simpleqa_clustered.jsonl",
                      "phase1/grading/{p}_simpleqa_graded.jsonl"),
         "HLE": ("phase2/clustering/{p}_simpleqa_clustered.jsonl",
                 "phase2/grading/{p}_simpleqa_graded.jsonl"),
         "PopQA": ("phase4/clustering/{p}_popqa_clustered.jsonl",
                   "phase4/grading/{p}_popqa_graded.jsonl")}
PROVS = ["openai", "anthropic", "gemini", "xai", "mistral"]


def variants(assign, hedged_idx, modal):
    """-> (merge_all, split_all) reassignments."""
    a = np.asarray(assign)
    merge = a.copy()
    for i in hedged_idx:
        merge[i] = modal
    split = a.copy()
    nxt = int(a.max()) + 1
    for i in hedged_idx:
        split[i] = nxt; nxt += 1
    return merge.tolist(), split.tolist()


def sizes_of(a):
    return np.bincount(np.asarray(a)).tolist()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(BASE, "RESULTS_hedged_impact.md"))
    ap.add_argument("--exclude-xai", action="store_true",
                    help="also report excluding xAI, whose hedge rate is inflated by "
                         "answer-extraction fallback rather than genuine hedging")
    args = ap.parse_args()

    rows = defaultdict(list)          # (bench, prov) -> per-question records
    for bench, (cp, gp) in CELLS.items():
        for prov in PROVS:
            cpath, gpath = os.path.join(ROOT, cp.format(p=prov)), os.path.join(ROOT, gp.format(p=prov))
            if not (os.path.exists(cpath) and os.path.exists(gpath)):
                continue
            Y = {}
            for line in open(gpath):
                r = json.loads(line); Y.setdefault(r["id"], r["Y"])
            for line in open(cpath):
                r = json.loads(line)
                y = Y.get(r["id"])
                if y is None:
                    continue
                ans, asg = r["answer_extracted"], r["cluster_assignments"]
                hed = [i for i, a in enumerate(ans) if classify(a)]
                modal = int(np.argmax(r["cluster_sizes"]))
                rec = {"y": int(y), "n_hedged": len(hed),
                       "c1": naive_confidence(r["cluster_sizes"]),
                       "c2": sssc_confidence(asg)}
                if hed:
                    m, s = variants(asg, hed, modal)
                    rec["c1_m"] = naive_confidence(sizes_of(m))
                    rec["c2_m"] = sssc_confidence(m)
                    rec["c1_s"] = naive_confidence(sizes_of(s))
                    rec["c2_s"] = sssc_confidence(s)
                else:
                    rec["c1_m"] = rec["c1_s"] = rec["c1"]
                    rec["c2_m"] = rec["c2_s"] = rec["c2"]
                rows[(bench, prov)].append(rec)
            print(f"[{bench}/{prov}] {len(rows[(bench,prov)])} questions", flush=True)

    def block(sel, title, note=""):
        out = [f"\n### {title}\n" + (note + "\n" if note else ""),
               "| benchmark | N | questions with ≥1 hedged answer | Sem₁-ECE (orig / merge / split) "
               "| Sem₂-ECE (orig / merge / split) | **gap** (orig / merge / split) |",
               "|---|---:|---:|---|---|---|"]
        for bench in ("SimpleQA", "HLE", "PopQA"):
            rs = [r for (b, p), v in sel.items() if b == bench for r in v]
            if not rs:
                continue
            y = [r["y"] for r in rs]
            aff = sum(1 for r in rs if r["n_hedged"] > 0)
            e = {}
            for tag, k1, k2 in (("o", "c1", "c2"), ("m", "c1_m", "c2_m"), ("s", "c1_s", "c2_s")):
                e[tag] = (ece_10bin([r[k1] for r in rs], y), ece_10bin([r[k2] for r in rs], y))
            out.append(
                f"| {bench} | {len(rs):,} | {aff:,} ({aff/len(rs):.1%}) "
                f"| {e['o'][0]:.4f} / {e['m'][0]:.4f} / {e['s'][0]:.4f} "
                f"| {e['o'][1]:.4f} / {e['m'][1]:.4f} / {e['s'][1]:.4f} "
                f"| **{e['o'][0]-e['o'][1]:+.4f}** / {e['m'][0]-e['m'][1]:+.4f} "
                f"/ {e['s'][0]-e['s'][1]:+.4f} |")
        return out

    L = ["# Do hedged / approximate answers change the evaluation?\n",
         "A reviewer may object that answers like *\"roughly four\"*, *\"between three and "
         "five\"* or *\"about 1990\"* force the clustering judge into an arbitrary decision — "
         "merge with the precise value or keep separate — and that this arbitrary decision "
         "propagates into ĉ₁ and hence into ECE.\n",
         "Rather than argue for one convention, we bracket it. Every answer flagged as hedged "
         "by a deliberately broad lexical detector is re-assigned two ways and the whole "
         "evaluation is recomputed:\n",
         "- **MERGE-ALL** — every hedged answer is forced *into* the question's modal cluster "
         "(the most permissive convention possible).",
         "- **SPLIT-ALL** — every hedged answer is forced *out*, each into its own singleton "
         "(the most conservative convention possible).\n",
         "The judge's actual behaviour sits between these two, so the true value of every "
         "quantity lies inside the bracket. Prevalence and the judge's current behaviour are "
         "in `RESULTS_hedged_prevalence.md`: **3.68 %** of all answers are flagged, and where a "
         "hedged answer has an otherwise-identical precise twin the judge already merges them "
         "**87.3 %** of the time.\n",
         "## Bracket on the reported numbers\n"]
    L += block(rows, "All five providers")
    if args.exclude_xai:
        sel = {k: v for k, v in rows.items() if k[1] != "xai"}
        L += block(sel, "Excluding xAI",
                   "*xAI's flag rate (8–13 %) is inflated by answer-extraction fallback — its "
                   "stored 'answers' are long text fragments that happen to contain hedge "
                   "words — rather than by genuinely hedged short answers, so it is worth "
                   "seeing the bracket without it.*")

    L += ["\n## Reading\n",
          "The two extreme conventions are far more aggressive than anything a judge would do: "
          "MERGE-ALL hands every hedged answer to the modal cluster even when it contradicts it, "
          "and SPLIT-ALL isolates every hedged answer even when it is a verbatim restatement of "
          "the modal answer. If Sem₁-ECE, Sem₂-ECE and the gap stay close across that bracket, "
          "the hedging convention is not a threat to the paper's conclusions — the quantity the "
          "paper reports is not sensitive to the one arbitrary call the reviewer is worried "
          "about.\n",
          "Note also that the bracket applies **symmetrically to Sem₁ and Sem₂** — both read the "
          "same partition — so the *gap* is far more stable than either level.\n",
          "Driver: `hedged/prevalence.py` (detection + judge behaviour), `hedged/impact.py` "
          "(this bracket). Both are pure recomputation over the stored partitions."]

    with open(args.out, "w") as f:
        f.write("\n".join(L) + "\n")
    print("\nwrote", args.out)


if __name__ == "__main__":
    main()
