"""Master monitor: tracks Phase 2 Gemini HLE + Phase 3 all providers.

Auto-runs collect → clustering → grading → ECE pipelines when generation is done.
Emails to anonymous@example.invalid when everything is complete.
"""
import os, json, time, glob, subprocess, traceback
from collections import Counter
from email.mime.text import MIMEText
from dotenv import load_dotenv

BASE = "/path/to/calibration"
load_dotenv(os.path.join(BASE, "phase1", ".env"), override=True)

STATUS_FILE = os.path.join(BASE, "master_status.json")
LOG_FILE = os.path.join(BASE, "master_monitor.log")
POLL_INTERVAL = 900  # 15 min
EMAIL = "anonymous@example.invalid"

# Phase 3 targets
P3_TARGET = 28000  # 560 questions × 50 samples per provider
P2_GEMINI_TARGET = 107900  # 2158 questions × 50


def log(msg):
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line, flush=True)
    with open(LOG_FILE, "a") as f:
        f.write(line + "\n")


def load_status():
    if os.path.exists(STATUS_FILE):
        with open(STATUS_FILE) as f:
            return json.load(f)
    return {
        "phase2_gemini": {"gen_done": False, "collected": False, "clustered": False, "graded": False, "ece_done": False},
        "phase3_openai": {"gen_done": False, "collected": False, "clustered": False, "graded": False, "ece_done": False},
        "phase3_xai":    {"gen_done": False, "collected": False, "clustered": False, "graded": False, "ece_done": False},
        "phase3_mistral":{"gen_done": False, "collected": False, "clustered": False, "graded": False, "ece_done": False},
        "phase3_gemini": {"gen_done": False, "collected": False, "clustered": False, "graded": False, "ece_done": False},
    }


def save_status(s):
    with open(STATUS_FILE, "w") as f:
        json.dump(s, f, indent=2)


# --- Generation checkers ---

def check_p2_gemini_gen():
    q = Counter()
    for p in glob.glob(os.path.join(BASE, "phase2/batch_outputs/gemini_*.jsonl")):
        with open(p) as f:
            for l in f:
                try:
                    r = json.loads(l)
                    if r.get("status") == "success":
                        q[r["custom_id"].rsplit("__", 1)[0]] += 1
                except: pass
    complete = sum(1 for v in q.values() if v == 50)
    return complete, 2158


def check_p3_openai_gen():
    from openai import OpenAI
    c = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    with open(os.path.join(BASE, "phase3/batch_state.json")) as f:
        st = json.load(f)
    total = done = 0
    all_term = True
    for ch in st.get("openai", {}).get("chunks", []):
        try:
            b = c.batches.retrieve(ch["batch_id"])
            rc = b.request_counts
            total += rc.total
            done += rc.completed
            if b.status not in ("completed","failed","cancelled","expired"):
                all_term = False
        except: all_term = False
    return done, total if total else 3920, all_term


def check_p3_xai_gen():
    import requests
    key = os.environ["XAI_API_KEY"]
    with open(os.path.join(BASE, "phase3/batch_state.json")) as f:
        st = json.load(f)
    total = done = 0
    all_term = True
    for ch in st.get("xai", {}).get("chunks", []):
        try:
            r = requests.get(
                f"https://api.x.ai/v1/batches/{ch['batch_id']}",
                headers={"Authorization": f"Bearer {key}"}, timeout=30
            )
            if r.status_code == 200:
                b = r.json()
                sto = b.get("state", {})
                total += sto.get("num_requests", 0)
                done += sto.get("num_success", 0)
                pend = sto.get("num_pending", 0)
                if pend > 0:
                    all_term = False
        except: all_term = False
    return done, total or 28000, all_term


def check_p3_mistral_gen():
    from mistralai.client import Mistral
    c = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
    with open(os.path.join(BASE, "phase3/batch_state.json")) as f:
        st = json.load(f)
    done = 0
    all_term = True
    for ch in st.get("mistral", {}).get("chunks", []):
        try:
            job = c.batch.jobs.get(job_id=ch["batch_id"])
            s = str(job.status).upper()
            if "SUCCESS" in s or "COMPLETED" in s:
                done += ch["n_rows"]
            elif "FAIL" in s or "CANCEL" in s or "EXPIRE" in s:
                pass
            else:
                all_term = False
        except: all_term = False
    return done, 28000, all_term


def check_p3_gemini_gen():
    q = Counter()
    for p in glob.glob(os.path.join(BASE, "phase3/batch_outputs/gemini_*.jsonl")):
        with open(p) as f:
            for l in f:
                try:
                    r = json.loads(l)
                    if r.get("status") == "success":
                        q[r["custom_id"].rsplit("__", 1)[0]] += 1
                except: pass
    complete = sum(1 for v in q.values() if v == 50)
    return complete, 560


# --- Pipeline runner helpers ---

def run_cmd(cmd, cwd=None, timeout=3600):
    log(f"  RUN: {' '.join(cmd)[:100]}")
    try:
        p = subprocess.run(cmd, cwd=cwd, timeout=timeout, capture_output=True, text=True)
        if p.returncode != 0:
            log(f"    FAIL rc={p.returncode}: {p.stderr[:300]}")
            return False
        log(f"    OK")
        return True
    except Exception as e:
        log(f"    EXCEPTION: {e}")
        return False


# --- Send email ---
def send_email(subject, body):
    try:
        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = "monitor@calibration"
        msg["To"] = EMAIL
        proc = subprocess.run(
            ["sendmail", "-t"], input=msg.as_string(),
            capture_output=True, text=True, timeout=30,
        )
        if proc.returncode == 0:
            log("Email sent.")
        else:
            with open(os.path.join(BASE, "MASTER_DONE.txt"), "w") as f:
                f.write(f"Subject: {subject}\n\n{body}\n")
            log("Email failed, wrote MASTER_DONE.txt")
    except Exception as e:
        with open(os.path.join(BASE, "MASTER_DONE.txt"), "w") as f:
            f.write(f"Subject: {subject}\n\n{body}\n")
        log(f"Email err: {e}")


# --- Main loop ---
def main():
    log("=== Master monitor started ===")
    email_sent = False

    while True:
        try:
            status = load_status()

            # --- Gen checks ---
            try:
                p2g_comp, p2g_tgt = check_p2_gemini_gen()
                if p2g_comp >= p2g_tgt * 0.95:  # 95% threshold (some stragglers ok)
                    status["phase2_gemini"]["gen_done"] = True
                p2g_str = f"{p2g_comp}/{p2g_tgt}"
            except Exception as e:
                p2g_str = f"err({str(e)[:30]})"

            try:
                p3o_done, p3o_tgt, p3o_term = check_p3_openai_gen()
                if p3o_term and p3o_done >= p3o_tgt * 0.99:
                    status["phase3_openai"]["gen_done"] = True
                p3o_str = f"{p3o_done}/{p3o_tgt}" + (" DONE" if p3o_term else "")
            except Exception as e:
                p3o_str = f"err({str(e)[:30]})"

            try:
                p3x_done, p3x_tgt, p3x_term = check_p3_xai_gen()
                if p3x_term and p3x_done >= p3x_tgt * 0.95:
                    status["phase3_xai"]["gen_done"] = True
                p3x_str = f"{p3x_done}/{p3x_tgt}" + (" DONE" if p3x_term else "")
            except Exception as e:
                p3x_str = f"err({str(e)[:30]})"

            try:
                p3m_done, p3m_tgt, p3m_term = check_p3_mistral_gen()
                if p3m_term and p3m_done >= p3m_tgt * 0.99:
                    status["phase3_mistral"]["gen_done"] = True
                p3m_str = f"{p3m_done}/{p3m_tgt}" + (" DONE" if p3m_term else "")
            except Exception as e:
                p3m_str = f"err({str(e)[:30]})"

            try:
                p3g_comp, p3g_tgt = check_p3_gemini_gen()
                if p3g_comp >= p3g_tgt * 0.95:
                    status["phase3_gemini"]["gen_done"] = True
                p3g_str = f"{p3g_comp}/{p3g_tgt}"
            except Exception as e:
                p3g_str = f"err({str(e)[:30]})"

            log(f"Status: P2_gem={p2g_str} | P3_oai={p3o_str} | P3_xai={p3x_str} | P3_mis={p3m_str} | P3_gem={p3g_str}")

            save_status(status)

            # Check if all gens done
            all_gen_done = all(status[k]["gen_done"] for k in [
                "phase2_gemini", "phase3_openai", "phase3_xai", "phase3_mistral", "phase3_gemini"
            ])

            if all_gen_done and not email_sent:
                body = (
                    "All remaining generation tasks complete.\n\n"
                    "Still to run (manually):\n"
                    "- Phase 2 Gemini HLE: collect → cluster → grade → ECE\n"
                    "- Phase 3 (all 4 providers): collect → cluster → grade → ECE\n\n"
                    "Progress snapshot:\n"
                    f"  Phase 2 Gemini HLE:   {p2g_str} complete (50/50)\n"
                    f"  Phase 3 OpenAI MATH:  {p3o_str}\n"
                    f"  Phase 3 xAI MATH:     {p3x_str}\n"
                    f"  Phase 3 Mistral MATH: {p3m_str}\n"
                    f"  Phase 3 Gemini MATH:  {p3g_str} complete (50/50)\n"
                )
                send_email("[Calibration] ALL generation tasks done", body)
                email_sent = True
                log("All done — email sent, exiting.")
                break

        except Exception as e:
            log(f"Loop error: {e}\n{traceback.format_exc()[:500]}")

        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    main()
