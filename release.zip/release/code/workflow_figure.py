"""workflow_figure.py — pedagogical workflow illustration with a real HLE example.

A worked example walks the reader through the Sem-ECE pipeline:

  HLE question  →  LLM samples 50 answers  →  judge LLM clusters  →
        →  three confidence estimators  →  ECE on ground truth

Real data from phase2/clustering/openai_simpleqa_clustered.jsonl (qid
66eafb96b082c5e6a76a49c0).  This question has cluster sizes [21,16,11,2]
and is a good demonstrator: top cluster ("Countour") is wrong, the gold
answer ("Fool") is the third-largest cluster, and the three estimators
disagree (Sem_1=0.42, Sem_2=0.376, Ver=0.575).

Outputs: figures/workflow_example.{pdf,png}.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
from matplotlib import rcParams


# ---------------------------------------------------------------------------
# Real data (HLE / OpenAI gpt-5.4, qid 66eafb96b082c5e6a76a49c0)
# ---------------------------------------------------------------------------
QUESTION_LINES = [
    "What word does Chaucer NOT",
    "make a rhyme with in",
    "Book of the Duchess?",
]
CHOICES  = [
    ("A", "Wente"),
    ("B", "Here"),
    ("C", "Fool"),         # ← gold
    ("D", "Hool"),
    ("E", "Countour"),
    ("F", "None of the above"),
]
GOLD          = "Fool"
N_SAMPLES     = 50
CLUSTERS = [
    # (rep_label, size, color, is_correct)
    ("Countour",          21, "#3B7BB8", False),    # blue  (top)
    ("None of the above", 16, "#7A4FB7", False),    # purple
    ("Fool",              11, "#3DAF6E", True),     # green ← gold
    ("Here",               2, "#C9A23E", False),    # gold
]
SEM1   = 0.42
SEM2   = 0.376
VER    = 0.575
Y      = 0     # incorrect (top != gold)
ECE1   = abs(SEM1 - Y)   # 0.42
ECE2   = abs(SEM2 - Y)   # 0.376
ECE_V  = abs(VER  - Y)   # 0.575


# ---------------------------------------------------------------------------
# Style
# ---------------------------------------------------------------------------
rcParams.update({
    "font.family":      "serif",
    "font.serif":       ["DejaVu Serif", "Times New Roman", "Computer Modern Roman"],
    "mathtext.fontset": "cm",
    "pdf.fonttype":     42,
    "ps.fonttype":      42,
    "savefig.bbox":     "tight",
    "savefig.pad_inches": 0.10,
})

C_INPUT      = "#10B981"
C_INPUT_FILL = "#D1FAE5"
C_LLM        = "#2563EB"
C_LLM_FILL   = "#DBEAFE"
C_CLUSTER    = "#7C3AED"
C_CLUSTER_FILL = "#EDE9FE"
C_OUTPUT     = "#EA580C"
C_OUTPUT_FILL = "#FED7AA"
C_GOLD       = "#15803D"
C_BAD        = "#B91C1C"
C_NEUTRAL    = "#1F2937"
C_LIGHT      = "#9CA3AF"

ROOT = Path(__file__).resolve().parent
OUT  = ROOT / "figures"
OUT.mkdir(exist_ok=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def rounded_box(ax, x, y, w, h, *, fc, ec, lw=1.4, rad=0.025, alpha=1.0,
                zorder=2):
    box = FancyBboxPatch((x, y), w, h,
                         boxstyle=f"round,pad=0.005,rounding_size={rad}",
                         linewidth=lw, edgecolor=ec, facecolor=fc,
                         alpha=alpha, zorder=zorder)
    ax.add_patch(box)
    return box


def arrow(ax, xy0, xy1, *, color=C_NEUTRAL, lw=2.4, label=None,
          label_pos=0.5, label_offset=(0, 0.03), label_size=10):
    a = FancyArrowPatch(xy0, xy1, arrowstyle="-|>",
                        mutation_scale=18, color=color, lw=lw, zorder=3,
                        shrinkA=2, shrinkB=2)
    ax.add_patch(a)
    if label:
        mx = xy0[0] + label_pos * (xy1[0] - xy0[0]) + label_offset[0]
        my = xy0[1] + label_pos * (xy1[1] - xy0[1]) + label_offset[1]
        ax.text(mx, my, label, fontsize=label_size, color=C_NEUTRAL,
                ha="center", va="center", style="italic", zorder=4,
                bbox=dict(boxstyle="round,pad=0.18", fc="white",
                          ec="none", alpha=0.92))
    return a


# ---------------------------------------------------------------------------
# Stage drawers (each gets a (left, bottom, width, height) bbox in axes coords)
# ---------------------------------------------------------------------------
def draw_question(ax, x, y, w, h):
    rounded_box(ax, x, y, w, h, fc=C_INPUT_FILL, ec=C_INPUT, lw=1.6)
    # Header
    ax.text(x + 0.015, y + h - 0.025,
            "1. Question  q",
            fontsize=12, fontweight="bold", color=C_INPUT, va="top")
    ax.text(x + 0.015, y + h - 0.060,
            "from HLE benchmark",
            fontsize=9, color="#555", va="top", style="italic")

    # Question text — manually wrapped over 3 lines
    yy_q = y + h - 0.105
    ax.text(x + 0.015, yy_q,
            "“" + QUESTION_LINES[0],
            fontsize=10, color=C_NEUTRAL, va="top")
    ax.text(x + 0.015, yy_q - 0.030,
            QUESTION_LINES[1],
            fontsize=10, color=C_NEUTRAL, va="top")
    ax.text(x + 0.015, yy_q - 0.060,
            QUESTION_LINES[2] + "”",
            fontsize=10, color=C_NEUTRAL, va="top")

    # Choices
    yy = y + h - 0.225
    for letter, text in CHOICES:
        is_gold = (text == GOLD)
        bullet_color = C_GOLD if is_gold else "#6B7280"
        weight = "bold" if is_gold else "normal"
        ax.text(x + 0.022, yy,
                f"{letter}.  {text}",
                fontsize=9.5, color=bullet_color, fontweight=weight, va="top")
        if is_gold:
            ax.text(x + w - 0.020, yy,
                    "← gold",
                    fontsize=8.5, color=C_GOLD, va="top", ha="right",
                    style="italic")
        yy -= 0.030

    # Bottom strip
    ax.text(x + w / 2, y + 0.028,
            "answer space  =  6 multiple-choice options",
            fontsize=9, color="#555", ha="center", va="center", style="italic")


def draw_samples(ax, x, y, w, h):
    rounded_box(ax, x, y, w, h, fc=C_LLM_FILL, ec=C_LLM, lw=1.6)
    ax.text(x + 0.015, y + h - 0.025,
            "2. Sample  n = 50",
            fontsize=12, fontweight="bold", color=C_LLM, va="top")
    ax.text(x + 0.015, y + h - 0.060,
            "from LLM  πθ  (gpt-5.4)",
            fontsize=9, color="#555", va="top", style="italic")

    # Show 12 example samples with a colored dot indicating cluster
    sample_seq = (
        ["Countour"] * 5 + ["None of the above"] * 3 + ["Fool"] * 2
        + ["Here"] + ["Countour"]   # interleaved illustration
    )
    rep2color = {c[0]: c[2] for c in CLUSTERS}

    yy = y + h - 0.105
    for i, ans in enumerate(sample_seq):
        col = rep2color[ans]
        ax.scatter(x + 0.030, yy + 0.005, s=42, color=col, zorder=4,
                   edgecolor="white", linewidth=0.6)
        # quote the model's answer line (truncated)
        ax.text(x + 0.058, yy,
                f"a$_{{{i+1}}}$  →  “{ans}”",
                fontsize=9, color=C_NEUTRAL, va="center")
        yy -= 0.034

    ax.text(x + 0.058, yy + 0.001,
            "…  total 50 samples",
            fontsize=9, color="#666", style="italic", va="center")

    # Bottom strip — the 50-dot mini grid (visual summary of all 50 cluster ids)
    # 10 cols × 5 rows of dots colored by cluster.  We use the cluster size
    # totals to colour them; ordering is arbitrary but matches counts.
    grid_y = y + 0.035
    grid_x0 = x + 0.030
    flat = []
    for rep, sz, col, _ in CLUSTERS:
        flat.extend([col] * sz)
    # interleave a bit so grid looks varied
    flat = flat[::2] + flat[1::2]
    cols = 10
    for k, c in enumerate(flat):
        cx = grid_x0 + (k % cols) * 0.020
        cy = grid_y + (k // cols) * 0.018
        ax.scatter(cx, cy, s=22, color=c, edgecolor="white", linewidth=0.4,
                   zorder=4)
    ax.text(x + w - 0.020, grid_y + 0.038,
            "all 50",
            fontsize=8.5, color="#666", ha="right", va="center", style="italic")


def draw_clustering(ax, x, y, w, h):
    rounded_box(ax, x, y, w, h, fc=C_CLUSTER_FILL, ec=C_CLUSTER, lw=1.6)
    ax.text(x + 0.015, y + h - 0.025,
            "3. Semantic Clustering",
            fontsize=12, fontweight="bold", color=C_CLUSTER, va="top")
    ax.text(x + 0.015, y + h - 0.058,
            "judge LLM groups answers",
            fontsize=9, color="#555", va="top", style="italic")
    ax.text(x + 0.015, y + h - 0.076,
            "K = 4 clusters",
            fontsize=9, color="#555", va="top", style="italic")

    # Four cluster pills.  Layout per pill:
    #   line 1: cluster name (full width, bold)
    #   line 2: count "n/N"  +  proportional bar
    pill_x = x + 0.018
    pill_w = w - 0.036
    pill_h = 0.110
    yy = y + h - 0.110
    max_size = max(c[1] for c in CLUSTERS)

    # Truncate display name if it's likely to overflow at fontsize 11
    def fmt_name(rep, max_chars=14):
        return rep if len(rep) <= max_chars else (rep[:max_chars - 1] + "…")

    for rep, sz, col, is_correct in CLUSTERS:
        rounded_box(ax, pill_x, yy - pill_h, pill_w, pill_h,
                    fc="white", ec=col, lw=1.6 if is_correct else 1.2,
                    rad=0.018)

        # Line 1: cluster name (full width)
        disp_name = fmt_name(rep)
        weight = "bold" if is_correct else "normal"
        ax.text(pill_x + 0.012, yy - 0.022,
                disp_name,
                fontsize=10.5,
                color=C_GOLD if is_correct else col,
                fontweight=weight, va="top")
        if is_correct:
            ax.text(pill_x + pill_w - 0.012, yy - 0.022,
                    "✓ gold",
                    fontsize=9, color=C_GOLD, va="top", ha="right",
                    style="italic", fontweight="bold")

        # Line 2: count + bar
        count_x = pill_x + 0.012
        ax.text(count_x, yy - 0.058,
                f"{sz}/50",
                fontsize=10, color=C_NEUTRAL, va="top",
                fontweight="bold")
        # Bar: from after the count text to the right edge
        bar_x0 = count_x + 0.040
        bar_total_w = pill_w - 0.040 - 0.024
        bar_w = bar_total_w * (sz / max_size)
        bar_y = yy - 0.069
        ax.add_patch(Rectangle((bar_x0, bar_y),
                                bar_total_w, 0.012,
                                facecolor="#F3F4F6", edgecolor="none",
                                zorder=3))
        ax.add_patch(Rectangle((bar_x0, bar_y),
                                bar_w, 0.012,
                                facecolor=col, alpha=0.55, edgecolor=col,
                                lw=0.5, zorder=4))
        yy -= pill_h + 0.009

    ax.text(x + w / 2, y + 0.028,
            "top cluster ≠ gold  →  model is wrong",
            fontsize=9.5, color=C_BAD, ha="center", va="center", style="italic")


def draw_estimators(ax, x, y, w, h):
    rounded_box(ax, x, y, w, h, fc=C_CLUSTER_FILL, ec=C_CLUSTER, lw=1.6,
                alpha=0.55)
    ax.text(x + 0.015, y + h - 0.025,
            "4. Confidence Estimators",
            fontsize=12, fontweight="bold", color=C_CLUSTER, va="top")
    ax.text(x + 0.015, y + h - 0.058,
            "three scalars from 50 samples",
            fontsize=9, color="#555", va="top", style="italic")

    rows = [
        ("Sem$_1$", "naive plug-in",
         r"$c_1 = |{\rm top}|/n$",
         f"21/50 = {SEM1:.2f}",
         "#A78BFA",
         False),
        ("Sem$_2$", "SSSC  ★",
         r"split & match,  $R{=}10$",
         f"{SEM2:.3f}    (debiased ↓)",
         "#7C3AED",
         True),
        ("Ver",     "verbalized",
         "self-reported %",
         f"{VER:.3f}    (overconfident)",
         "#C4B5FD",
         False),
    ]
    yy = y + h - 0.095
    h_card = 0.135
    for i, (name, sub, formula, value, col, is_proposed) in enumerate(rows):
        bx = x + 0.018
        bw = w - 0.036
        rounded_box(ax, bx, yy - h_card, bw, h_card,
                    fc="white", ec=col, lw=2.4 if is_proposed else 1.2,
                    rad=0.018)
        # Header line: name (bold, large) + sub (small italic) on second line
        ax.text(bx + 0.012, yy - 0.024,
                f"{name}",
                fontsize=12, color=col, fontweight="bold", va="top")
        ax.text(bx + 0.062, yy - 0.025,
                f"({sub})",
                fontsize=9.5, color=col, va="top", style="italic")
        ax.text(bx + 0.012, yy - 0.062,
                formula,
                fontsize=10, color=C_NEUTRAL, va="top")
        ax.text(bx + 0.012, yy - 0.100,
                "= " + value,
                fontsize=10.5, color=C_NEUTRAL, va="top",
                fontweight="bold" if is_proposed else "normal")
        yy -= h_card + 0.011


def draw_eval(ax, x, y, w, h):
    rounded_box(ax, x, y, w, h, fc=C_OUTPUT_FILL, ec=C_OUTPUT, lw=1.6)
    ax.text(x + 0.015, y + h - 0.025,
            "5. Evaluation  →  ECE",
            fontsize=12, fontweight="bold", color=C_OUTPUT, va="top")
    ax.text(x + 0.015, y + h - 0.058,
            "vs. ground truth  Y",
            fontsize=9, color="#555", va="top", style="italic")

    # Y truth box (compact, 2-line)
    rounded_box(ax, x + 0.018, y + h - 0.165, w - 0.036, 0.090,
                fc="white", ec=C_BAD, lw=1.5, rad=0.018)
    ax.text(x + 0.030, y + h - 0.105,
            "Y = 0",
            fontsize=15, fontweight="bold", color=C_BAD, va="center")
    ax.text(x + 0.030, y + h - 0.140,
            "Countour ≠ Fool  (incorrect)",
            fontsize=9.5, color=C_BAD, va="center", style="italic")

    # Per-estimator |c - Y| rows
    rows = [
        ("Sem$_1$", SEM1, ECE1, "#A78BFA"),
        ("Sem$_2$", SEM2, ECE2, "#7C3AED"),
        ("Ver",     VER,  ECE_V,"#C4B5FD"),
    ]
    yy = y + h - 0.205
    h_row = 0.085
    for i, (name, c, e, col) in enumerate(rows):
        is_proposed = (i == 1)
        rounded_box(ax, x + 0.018, yy - h_row, w - 0.036, h_row,
                    fc="white", ec=col, lw=2.0 if is_proposed else 1.0,
                    rad=0.014)
        ax.text(x + 0.030, yy - h_row / 2 + 0.012,
                f"{name}",
                fontsize=11, fontweight="bold", color=col, va="center")
        ax.text(x + 0.030, yy - h_row / 2 - 0.014,
                f"|c − Y| = {e:.3f}",
                fontsize=10, color=C_NEUTRAL, va="center",
                fontweight="bold" if is_proposed else "normal")
        # Mini bar showing the error magnitude
        bar_x = x + 0.135
        bar_w = (w - 0.036 - 0.130) * (e / 0.65)
        ax.add_patch(Rectangle((bar_x, yy - h_row / 2 - 0.008),
                                bar_w, 0.016,
                                facecolor=col, alpha=0.45, edgecolor=col,
                                lw=0.6, zorder=3))
        yy -= h_row + 0.006

    ax.text(x + w / 2, y + 0.028,
            "Sem$_2$ closest to Y  →  best calibrated",
            fontsize=10, color=C_GOLD, ha="center", va="center",
            style="italic", fontweight="bold")


# ---------------------------------------------------------------------------
# Main figure
# ---------------------------------------------------------------------------
def main():
    fig, ax = plt.subplots(figsize=(18.0, 9.5))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_aspect("auto")
    ax.axis("off")

    # 5 columns — wider gaps so arrows + labels have room
    L_MARGIN = 0.008
    R_MARGIN = 0.008
    GAP      = 0.030
    avail_w  = 1.0 - L_MARGIN - R_MARGIN - 4 * GAP
    col_w    = avail_w / 5.0
    box_h    = 0.78
    box_y    = 0.10

    cols = []
    cur_x = L_MARGIN
    for _ in range(5):
        cols.append(cur_x)
        cur_x += col_w + GAP

    draw_question  (ax, cols[0], box_y, col_w, box_h)
    draw_samples   (ax, cols[1], box_y, col_w, box_h)
    draw_clustering(ax, cols[2], box_y, col_w, box_h)
    draw_estimators(ax, cols[3], box_y, col_w, box_h)
    draw_eval      (ax, cols[4], box_y, col_w, box_h)

    # Connecting arrows between columns
    for i in range(4):
        x0 = cols[i] + col_w + 0.001
        x1 = cols[i + 1] - 0.001
        y_arrow = box_y + box_h / 2
        labels = ["q",
                  "{aᵢ}",
                  "clusters",
                  "(c₁,c₂,c$_v$)"]
        arrow(ax,
              (x0, y_arrow),
              (x1, y_arrow),
              color=C_NEUTRAL, lw=2.6,
              label=labels[i],
              label_pos=0.5, label_offset=(0, 0.030),
              label_size=10)

    # Top title strip
    ax.text(0.5, 0.965,
            "Sem-ECE workflow  —  worked example on a real HLE question",
            fontsize=15, fontweight="bold", ha="center", va="center",
            color=C_NEUTRAL)
    ax.text(0.5, 0.935,
            "(OpenAI gpt-5.4,  qid 66eafb96…b082c5e6,  $K{=}4$ clusters,  "
            "$\\Delta_q = 0.10$  →  low-margin / JDR regime)",
            fontsize=11, ha="center", va="center", color="#555",
            style="italic")

    out_pdf = OUT / "workflow_example.pdf"
    out_png = OUT / "workflow_example.png"
    fig.savefig(out_pdf)
    fig.savefig(out_png, dpi=200)
    plt.close(fig)
    print(f"Saved {out_pdf}")
    print(f"Saved {out_png}")


if __name__ == "__main__":
    main()
