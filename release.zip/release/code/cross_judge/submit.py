"""Submit cross-judge clustering rows as Gemini inline batch jobs.

Chunks rows by byte size (inline batch payloads must stay well under 20MB).
Persists job metadata to batch_outputs/jobs.json; idempotent — skips
custom_ids already covered by a recorded job or already collected.
"""
import os, json, glob, time, argparse
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))

from google import genai

MODEL = "gemini-3.1-pro-preview"
JOBS_FILE = os.path.join(BASE, "batch_outputs", "jobs.json")
RAW_OUT = os.path.join(BASE, "batch_outputs", "raw.jsonl")
MAX_CHUNK_BYTES = 12 * 1024 * 1024
MAX_CHUNK_ROWS = 4000


def covered_ids():
    done = set()
    if os.path.exists(RAW_OUT):
        with open(RAW_OUT) as f:
            for line in f:
                try:
                    r = json.loads(line)
                    if r.get("status") == "success":
                        done.add(r["custom_id"])
                except Exception:
                    pass
    jobs = []
    if os.path.exists(JOBS_FILE):
        with open(JOBS_FILE) as f:
            jobs = json.load(f)
        for j in jobs:
            done.update(j.get("custom_ids", []))
    return done, jobs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--files", nargs="+", default=None,
                    help="specific batch_inputs files (default: all)")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()

    os.makedirs(os.path.join(BASE, "batch_outputs"), exist_ok=True)
    client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])

    files = args.files or sorted(glob.glob(os.path.join(BASE, "batch_inputs", "*.jsonl")))
    done, jobs = covered_ids()
    print(f"already covered custom_ids: {len(done)}")

    # gather remaining rows across all files (keep file order for locality)
    remaining = []
    for path in files:
        with open(path) as f:
            for line in f:
                r = json.loads(line)
                if r["custom_id"] not in done:
                    r["_bytes"] = len(line.encode())
                    remaining.append(r)
    print(f"rows to submit: {len(remaining)}")
    if not remaining:
        print("Nothing to do.")
        return

    # byte-capped chunks
    chunks, cur, cur_bytes = [], [], 0
    for r in remaining:
        if cur and (cur_bytes + r["_bytes"] > MAX_CHUNK_BYTES or len(cur) >= MAX_CHUNK_ROWS):
            chunks.append(cur); cur, cur_bytes = [], 0
        cur.append(r); cur_bytes += r["_bytes"]
    if cur:
        chunks.append(cur)
    print(f"chunks: {len(chunks)} (sizes: {[len(c) for c in chunks]})")
    if args.dry_run:
        return

    for ci, chunk in enumerate(chunks):
        inlined = [{
            "contents": r["contents"],
            "config": r["config"],
            "metadata": {"custom_id": r["custom_id"]},
        } for r in chunk]
        try:
            job = client.batches.create(
                model=MODEL,
                src=inlined,
                config={"display_name": f"crossjudge_{ci}_{len(chunk)}"},
            )
        except Exception as e:
            print(f"chunk {ci}: SUBMIT FAILED — {type(e).__name__}: {e}")
            print("Stopping; already-submitted jobs are recorded in jobs.json. Re-run to continue.")
            break
        jobs.append({
            "job_name": job.name,
            "n_rows": len(chunk),
            "custom_ids": [r["custom_id"] for r in chunk],
            "submitted_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "state": str(job.state),
        })
        with open(JOBS_FILE, "w") as f:
            json.dump(jobs, f, indent=1)
        print(f"chunk {ci}: submitted {job.name} ({len(chunk)} rows)")

    print(f"\n{len(jobs)} total jobs recorded in {JOBS_FILE}")


if __name__ == "__main__":
    main()
