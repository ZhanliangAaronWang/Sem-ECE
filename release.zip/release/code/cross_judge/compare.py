"""Compare Gemini-3.1-Pro judge vs GPT-5.2 judge (rebuttal robustness study).

Per (phase, provider) cell:
  1. Partition agreement per question: Rand index, adjusted Rand index,
     modal-cluster member-set Jaccard, modal "same deployed answer" rate.
  2. Recompute Sem1 (conf_naive) and Sem2 (conf_sssc, R=10, seed=0) from the
     Gemini partitions; ECE (10 equal-width bins) against the existing grades.
     Caveat: Y grades the GPT-judge modal answer; we report ECE both on all
     joined rows and restricted to the modal-agreement subset.
  3. Table: Sem1/Sem2-ECE under both judges, gap, gap sign preserved?

Output: RESULTS_cross_judge.md + stdout.
"""
import os, json, glob
import numpy as np
from collections import defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)

GPT_CELLS = {
    "phase1": ("phase1/clustering/{p}_simpleqa_clustered.jsonl",
               "phase1/grading/{p}_simpleqa_graded.jsonl", "SimpleQA"),
    "phase2": ("phase2/clustering/{p}_simpleqa_clustered.jsonl",
               "phase2/grading/{p}_simpleqa_graded.jsonl", "HLE"),
    "phase4": ("phase4/clustering/{p}_popqa_clustered.jsonl",
               "phase4/grading/{p}_popqa_graded.jsonl", "PopQA"),
}
PROVIDERS = ["openai", "anthropic", "gemini", "xai", "mistral"]


# ── estimators (identical to submission compute_confidence.py) ──────

def sssc_confidence(cluster_assignments, R=10, seed=0):
    a = np.asarray(cluster_assignments)
    n = len(a)
    half = n // 2
    rng = np.random.default_rng(seed)
    confidences = []
    for r in range(R):
        perm = rng.permutation(n)
        S_idx, E_idx = perm[:half], perm[half:]
        S_labels = a[S_idx]
        S_counts = np.bincount(S_labels, minlength=int(a.max()) + 1)
        z_S = int(np.argmax(S_counts))
        confidences.append(float(np.mean(a[E_idx] == z_S)))
    return float(np.mean(confidences))


def naive_confidence(cluster_sizes):
    s = np.asarray(cluster_sizes)
    return float(s.max() / s.sum())


def ece_10bin(conf, y):
    conf, y = np.asarray(conf, float), np.asarray(y, float)
    edges = np.linspace(0, 1, 11)
    idx = np.clip(np.digitize(conf, edges[1:-1]), 0, 9)
    ece = 0.0
    for b in range(10):
        m = idx == b
        if m.sum() == 0:
            continue
        ece += m.mean() * abs(y[m].mean() - conf[m].mean())
    return float(ece)


# ── partition agreement ─────────────────────────────────────────────

def rand_and_ari(a, b):
    a, b = np.asarray(a), np.asarray(b)
    n = len(a)
    # contingency
    ka, kb = a.max() + 1, b.max() + 1
    cont = np.zeros((ka, kb), dtype=np.int64)
    for i in range(n):
        cont[a[i], b[i]] += 1
    nij2 = (cont * (cont - 1) // 2).sum()
    ai2 = sum(x * (x - 1) // 2 for x in cont.sum(1))
    bj2 = sum(x * (x - 1) // 2 for x in cont.sum(0))
    npairs = n * (n - 1) // 2
    # Rand index
    agree_same = nij2
    agree_diff = npairs - ai2 - bj2 + nij2
    rand = (agree_same + agree_diff) / npairs
    # ARI
    expected = ai2 * bj2 / npairs if npairs else 0.0
    max_idx = (ai2 + bj2) / 2
    ari = (nij2 - expected) / (max_idx - expected) if max_idx != expected else 1.0
    return float(rand), float(ari)


def modal_overlap(a_assign, a_modal, b_assign, b_modal):
    A = {i for i, x in enumerate(a_assign) if x == a_modal}
    B = {i for i, x in enumerate(b_assign) if x == b_modal}
    jac = len(A & B) / len(A | B)
    return jac


# ── load ────────────────────────────────────────────────────────────

def load_jsonl(path, key="id"):
    d = {}
    with open(path) as f:
        for line in f:
            r = json.loads(line)
            d[r[key]] = d.get(r[key]) or r  # keep first
    return d


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--judge-dir", default=os.path.join(BASE, "clustering"))
    ap.add_argument("--suffix", default="gemini31pro")
    ap.add_argument("--judge-name", default="gemini-3.1-pro-preview")
    ap.add_argument("--out", default=os.path.join(BASE, "RESULTS_cross_judge.md"))
    args = ap.parse_args()
    lines = [f"# Cross-judge robustness: {args.judge_name} vs gpt-5.2\n"]
    hdr = ("| bench | provider | N joined | Rand | ARI | modal-Jacc | same-modal% "
           "| Sem1-ECE gpt | Sem1-ECE gem | Sem2-ECE gpt | Sem2-ECE gem "
           "| gap gpt | gap gem | sign ok |")
    sep = "|" + "---|" * 14
    lines += [hdr, sep]
    pooled = defaultdict(lambda: defaultdict(list))

    for phase, (cpat, gpat, bench) in GPT_CELLS.items():
        for prov in PROVIDERS:
            gem_path = os.path.join(args.judge_dir, f"{phase}_{prov}_{args.suffix}_clustered.jsonl")
            gpt_path = os.path.join(ROOT, cpat.format(p=prov))
            grade_path = os.path.join(ROOT, gpat.format(p=prov))
            if not (os.path.exists(gem_path) and os.path.exists(gpt_path) and os.path.exists(grade_path)):
                print(f"[{phase}/{prov}] missing inputs, skipped")
                continue
            gem = load_jsonl(gem_path)
            gpt = load_jsonl(gpt_path)
            grades = load_jsonl(grade_path)

            ids = sorted(set(gem) & set(gpt) & set(grades))
            rands, aris, jacs, same_modal = [], [], [], []
            rows = []
            for qid in ids:
                ge, gp = gem[qid], gpt[qid]
                if len(ge["cluster_assignments"]) != len(gp["cluster_assignments"]):
                    continue
                r_, ari_ = rand_and_ari(gp["cluster_assignments"], ge["cluster_assignments"])
                jac = modal_overlap(gp["cluster_assignments"], gp["modal_cluster"],
                                    ge["cluster_assignments"], ge["modal_cluster"])
                rands.append(r_); aris.append(ari_); jacs.append(jac)
                same = jac > 0.5
                same_modal.append(same)
                y = grades[qid]["Y"]
                rows.append({
                    "y": y, "same_modal": same,
                    "c1_gpt": naive_confidence(gp["cluster_sizes"]),
                    "c2_gpt": sssc_confidence(gp["cluster_assignments"]),
                    "c1_gem": naive_confidence(ge["cluster_sizes"]),
                    "c2_gem": sssc_confidence(ge["cluster_assignments"]),
                })
            if not rows:
                continue
            y = [r["y"] for r in rows]
            e1_gpt = ece_10bin([r["c1_gpt"] for r in rows], y)
            e2_gpt = ece_10bin([r["c2_gpt"] for r in rows], y)
            e1_gem = ece_10bin([r["c1_gem"] for r in rows], y)
            e2_gem = ece_10bin([r["c2_gem"] for r in rows], y)
            gap_gpt, gap_gem = e1_gpt - e2_gpt, e1_gem - e2_gem
            sign_ok = "Y" if (gap_gpt > 0) == (gap_gem > 0) else "N"
            lines.append(
                f"| {bench} | {prov} | {len(rows)} | {np.mean(rands):.3f} | {np.mean(aris):.3f} "
                f"| {np.mean(jacs):.3f} | {100*np.mean(same_modal):.1f} "
                f"| {e1_gpt:.4f} | {e1_gem:.4f} | {e2_gpt:.4f} | {e2_gem:.4f} "
                f"| {gap_gpt:+.4f} | {gap_gem:+.4f} | {sign_ok} |")
            for k in ("rand", "ari", "jacc"):
                pass
            pooled[bench]["rows"] += rows
            pooled[bench]["rand"] += rands
            pooled[bench]["ari"] += aris
            print(f"[{phase}/{prov}] N={len(rows)} rand={np.mean(rands):.3f} ari={np.mean(aris):.3f} "
                  f"same_modal={100*np.mean(same_modal):.1f}% gap: gpt {gap_gpt:+.4f} gem {gap_gem:+.4f}")

    # pooled per benchmark + modal-agree subset sensitivity
    lines.append("\n## Pooled per benchmark\n")
    lines.append("| bench | N | Rand | ARI | Sem1-ECE gpt/gem | Sem2-ECE gpt/gem | gap gpt/gem "
                 "| gap gem (modal-agree subset) |")
    lines.append("|" + "---|" * 8)
    for bench, d in pooled.items():
        rows = d["rows"]
        y = [r["y"] for r in rows]
        e1_gpt = ece_10bin([r["c1_gpt"] for r in rows], y)
        e2_gpt = ece_10bin([r["c2_gpt"] for r in rows], y)
        e1_gem = ece_10bin([r["c1_gem"] for r in rows], y)
        e2_gem = ece_10bin([r["c2_gem"] for r in rows], y)
        sub = [r for r in rows if r["same_modal"]]
        ys = [r["y"] for r in sub]
        gap_sub = ece_10bin([r["c1_gem"] for r in sub], ys) - ece_10bin([r["c2_gem"] for r in sub], ys)
        lines.append(f"| {bench} | {len(rows)} | {np.mean(d['rand']):.3f} | {np.mean(d['ari']):.3f} "
                     f"| {e1_gpt:.4f} / {e1_gem:.4f} | {e2_gpt:.4f} / {e2_gem:.4f} "
                     f"| {e1_gpt-e2_gpt:+.4f} / {e1_gem-e2_gem:+.4f} | {gap_sub:+.4f} |")

    lines.append("\n*Y labels grade the GPT-judge modal answer; 'modal-agree subset' restricts to "
                 "questions where both judges select the same deployed answer (member-set Jaccard > 0.5), "
                 "where the label is exactly valid for both.*")
    out = args.out
    with open(out, "w") as f:
        f.write("\n".join(lines) + "\n")
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
