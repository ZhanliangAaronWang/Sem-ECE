"""Retry residual parse failures with live calls (seed=SEED, larger output cap).

Mirrors the original gpt-5.2 cluster_retry protocol: same prompt, new seed.
Appends results to raw.jsonl; rerun `collect.py --parse-only` afterwards
(parse is last-success-wins).
"""
import os, json, time, argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))

from google import genai
from google.genai import types

SEED = 2
MODEL = "gemini-3.1-pro-preview"
RAW_OUT = os.path.join(BASE, "batch_outputs", "raw.jsonl")
FAILED = os.path.join(BASE, "batch_outputs", "failed_cids.json")


def load_inputs(cids):
    import glob
    want = set(cids)
    rows = {}
    for path in glob.glob(os.path.join(BASE, "batch_inputs", "*.jsonl")):
        with open(path) as f:
            for line in f:
                r = json.loads(line)
                if r["custom_id"] in want:
                    rows[r["custom_id"]] = r
    return rows


def call_one(client, row):
    cfg = row["config"]
    try:
        resp = client.models.generate_content(
            model=MODEL,
            contents=row["contents"],
            config=types.GenerateContentConfig(
                system_instruction=cfg["system_instruction"],
                max_output_tokens=8192,
                temperature=0.0,
                top_p=1.0,
                seed=SEED,
                response_mime_type=cfg["response_mime_type"],
                thinking_config=types.ThinkingConfig(thinking_budget=512),
            ),
        )
        text = resp.text
        if not text:
            parts = resp.candidates[0].content.parts
            text = "".join(p.text or "" for p in parts if not getattr(p, "thought", False))
        u = resp.usage_metadata
        return {"custom_id": row["custom_id"], "status": "success", "text": text,
                "usage": {"in": u.prompt_token_count, "out": u.candidates_token_count,
                          "think": getattr(u, "thoughts_token_count", None)},
                "retry": True}
    except Exception as e:
        return {"custom_id": row["custom_id"], "status": "error",
                "error": f"{type(e).__name__}: {e}", "retry": True}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    with open(FAILED) as f:
        cids = json.load(f)
    if args.limit:
        cids = cids[:args.limit]
    print(f"retrying {len(cids)} failed custom_ids")
    inputs = load_inputs(cids)
    client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])

    n_ok = n_err = 0
    with open(RAW_OUT, "a") as fout, ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(call_one, client, inputs[c]): c for c in cids if c in inputs}
        for i, fut in enumerate(as_completed(futs)):
            r = fut.result()
            fout.write(json.dumps(r, ensure_ascii=False) + "\n")
            fout.flush()
            if r["status"] == "success":
                n_ok += 1
            else:
                n_err += 1
                print(f"  ERROR {r['custom_id']}: {r['error'][:120]}")
            if (i + 1) % 50 == 0:
                print(f"  {i+1}/{len(futs)} done ({n_ok} ok, {n_err} err)")
    print(f"done: {n_ok} ok, {n_err} errors")


if __name__ == "__main__":
    main()
