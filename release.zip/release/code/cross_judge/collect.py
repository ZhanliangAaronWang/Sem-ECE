"""Collect Gemini cross-judge batch results and parse into clustered jsonl.

- Polls every job in batch_outputs/jobs.json; appends successes to raw.jsonl.
- Parses judge JSON (tolerant: raw_decode ignores trailing garbage like a
  stray closing brace) into partition rows, written per cell to
  clustering/{phase}_{provider}_gemini31pro_clustered.jsonl.
- Reports per-cell parse-failure rates.

Usage:
    python collect.py            # one polling pass + parse
    python collect.py --loop     # poll until all jobs terminal
"""
import os, json, time, argparse, glob
from collections import defaultdict
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))

from google import genai

JOBS_FILE = os.path.join(BASE, "batch_outputs", "jobs.json")
RAW_OUT = os.path.join(BASE, "batch_outputs", "raw.jsonl")
CLUSTER_DIR = os.path.join(BASE, "clustering")
TERMINAL = {"JOB_STATE_SUCCEEDED", "JOB_STATE_FAILED", "JOB_STATE_CANCELLED", "JOB_STATE_EXPIRED"}


def already_success():
    done = set()
    if os.path.exists(RAW_OUT):
        with open(RAW_OUT) as f:
            for line in f:
                try:
                    r = json.loads(line)
                    if r.get("status") == "success":
                        done.add(r["custom_id"])
                except Exception:
                    pass
    return done


def poll_once(client, jobs, done):
    """Returns (n_new, all_terminal)."""
    n_new, all_terminal = 0, True
    for j in jobs:
        if j.get("collected"):
            continue
        job = client.batches.get(name=j["job_name"])
        state = str(job.state).split(".")[-1]
        j["state"] = state
        if state not in TERMINAL:
            all_terminal = False
            print(f"  {j['job_name']}: {state}")
            continue
        if state != "JOB_STATE_SUCCEEDED":
            print(f"  {j['job_name']}: {state} (terminal, no results)")
            j["collected"] = True
            continue
        dest = getattr(job, "dest", None)
        inlined = getattr(dest, "inlined_responses", None) if dest else None
        if not inlined:
            inlined = getattr(job, "inlined_responses", None)
        if not inlined:
            print(f"  {j['job_name']}: SUCCEEDED but no inlined_responses!")
            j["collected"] = True
            continue
        rows = []
        for resp_obj in inlined:
            md = getattr(resp_obj, "metadata", None) or {}
            cid = md.get("custom_id", "")
            if not cid or cid in done:
                continue
            response = getattr(resp_obj, "response", None)
            err = getattr(resp_obj, "error", None)
            if err and not response:
                rows.append({"custom_id": cid, "status": "error", "error": str(err)})
                continue
            try:
                text = response.text
            except Exception:
                text = None
            if not text:
                # concatenate non-thought parts manually
                try:
                    parts = response.candidates[0].content.parts
                    text = "".join(p.text or "" for p in parts if not getattr(p, "thought", False))
                except Exception:
                    text = None
            if not text:
                rows.append({"custom_id": cid, "status": "error", "error": "empty response"})
                continue
            u = getattr(response, "usage_metadata", None)
            usage = {}
            if u:
                usage = {"in": getattr(u, "prompt_token_count", None),
                         "out": getattr(u, "candidates_token_count", None),
                         "think": getattr(u, "thoughts_token_count", None)}
            rows.append({"custom_id": cid, "status": "success", "text": text, "usage": usage})
            done.add(cid)
        with open(RAW_OUT, "a") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        n_new += len(rows)
        j["collected"] = True
        print(f"  {j['job_name']}: SUCCEEDED, wrote {len(rows)} rows")
    with open(JOBS_FILE, "w") as f:
        json.dump(jobs, f, indent=1)
    return n_new, all_terminal


def repair_brackets(text):
    """Balance {}/[] with a stack, tracking string state.

    Gemini 3.1 Pro's JSON mode frequently emits a complete object with the
    final `}` missing, or with one extra `]`/`}` at the tail. Drop unmatched
    closers and append missing ones.
    """
    out = []
    stack = []
    in_str = esc = False
    for ch in text:
        if in_str:
            out.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch in "{[":
            stack.append("}" if ch == "{" else "]")
        elif ch in "}]":
            if stack and stack[-1] == ch:
                stack.pop()
            else:
                continue  # extraneous closer — drop
        out.append(ch)
    if in_str:
        out.append('"')
    while stack:
        out.append(stack.pop())
    return "".join(out)


def tolerant_parse(text):
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.startswith("json"):
            text = text[4:]
    text = text.strip()
    try:
        obj, _ = json.JSONDecoder().raw_decode(text)
        return obj
    except json.JSONDecodeError:
        obj, _ = json.JSONDecoder().raw_decode(repair_brackets(text))
        return obj


def parse_all():
    """Parse raw.jsonl into per-cell clustered jsonl files."""
    n_expected = {}
    for path in glob.glob(os.path.join(BASE, "batch_inputs", "*.jsonl")):
        cell = os.path.basename(path)[:-6]
        with open(path) as f:
            for line in f:
                r = json.loads(line)
                n = r["contents"][0]["parts"][0]["text"].count("\n[")
                n_expected[r["custom_id"]] = n

    best = {}  # cid -> parsed row dict, or None if all attempts failed
    with open(RAW_OUT) as f:
        for line in f:
            r = json.loads(line)
            cid = r["custom_id"]
            if best.get(cid) is not None:
                continue  # already have a successful parse
            phase, prov, qid = cid.split("__", 2)
            if r["status"] != "success":
                best.setdefault(cid, None)
                continue
            n = n_expected.get(cid)
            try:
                obj = tolerant_parse(r["text"])
                clusters = obj["clusters"]
                assign = [None] * n
                labels = []
                for k, c in enumerate(clusters):
                    labels.append(str(c["label"]))
                    for i in c["members"]:
                        if not (0 <= int(i) < n) or assign[int(i)] is not None:
                            raise ValueError(f"bad index {i}")
                        assign[int(i)] = k
                if any(a is None for a in assign):
                    raise ValueError("incomplete partition")
                sizes = [assign.count(k) for k in range(len(labels))]
                modal = max(range(len(sizes)), key=lambda k: sizes[k])
                best[cid] = {
                    "id": qid, "model": prov, "phase": phase, "n_samples": n,
                    "n_clusters": len(labels), "cluster_labels": labels,
                    "cluster_assignments": assign, "cluster_sizes": sizes,
                    "modal_cluster": modal, "modal_cluster_label": labels[modal],
                    "judge": "gemini-3.1-pro-preview",
                }
            except Exception:
                best.setdefault(cid, None)

    cells = defaultdict(list)
    fails = defaultdict(int)
    failed_cids = []
    for cid, row in best.items():
        phase, prov, _ = cid.split("__", 2)
        cell = f"{phase}_{prov}"
        if row is None:
            fails[cell] += 1
            failed_cids.append(cid)
        else:
            cells[cell].append(row)

    os.makedirs(CLUSTER_DIR, exist_ok=True)
    with open(os.path.join(BASE, "batch_outputs", "failed_cids.json"), "w") as f:
        json.dump(sorted(failed_cids), f, indent=1)
    print(f"\n{'cell':<20}{'parsed':>8}{'fails':>7}{'fail%':>8}")
    for cell in sorted(set(list(cells) + list(fails))):
        rows = cells[cell]
        out = os.path.join(CLUSTER_DIR, f"{cell}_gemini31pro_clustered.jsonl")
        with open(out, "w") as f:
            for r in sorted(rows, key=lambda x: x["id"]):
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        tot = len(rows) + fails[cell]
        print(f"{cell:<20}{len(rows):>8}{fails[cell]:>7}{100*fails[cell]/max(tot,1):>7.1f}%")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--interval", type=int, default=600)
    ap.add_argument("--parse-only", action="store_true")
    args = ap.parse_args()

    if args.parse_only:
        parse_all()
        return

    client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])
    with open(JOBS_FILE) as f:
        jobs = json.load(f)
    done = already_success()
    while True:
        n_new, all_terminal = poll_once(client, jobs, done)
        print(f"collected {n_new} new rows; total success {len(done)}")
        if all_terminal or not args.loop:
            break
        time.sleep(args.interval)

    if all_terminal:
        parse_all()


if __name__ == "__main__":
    main()
