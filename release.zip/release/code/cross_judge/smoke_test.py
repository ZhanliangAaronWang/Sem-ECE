"""Live smoke test of gemini-3.1-pro-preview as clustering judge.

Runs a handful of real batch-input rows through the non-batch API to verify:
model ID, JSON-mode output, partition validity, and token usage (esp. thinking
tokens) for cost extrapolation.
"""
import os, json, sys
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))

from google import genai
from google.genai import types

MODEL = "gemini-3.1-pro-preview"

SAMPLES = [  # (file, line_no) — mix of short/long, easy/hard
    ("phase1_openai.jsonl", 0),
    ("phase1_xai.jsonl", 0),        # long fallback-tail answers
    ("phase2_gemini.jsonl", 0),     # HLE
    ("phase2_anthropic.jsonl", 0),  # N=46
    ("phase4_mistral.jsonl", 0),
]


def get_row(fname, lineno):
    with open(os.path.join(BASE, "batch_inputs", fname)) as f:
        for i, line in enumerate(f):
            if i == lineno:
                return json.loads(line)


def validate_partition(text, n):
    obj = json.loads(text)
    clusters = obj["clusters"]
    seen = []
    for c in clusters:
        seen += list(c["members"])
    ok = sorted(seen) == list(range(n))
    return ok, len(clusters)


def main():
    client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])
    tot_in = tot_out = tot_think = 0
    for fname, lineno in SAMPLES:
        row = get_row(fname, lineno)
        cfg = row["config"]
        n_answers = row["contents"][0]["parts"][0]["text"].count("\n[")
        try:
            resp = client.models.generate_content(
                model=MODEL,
                contents=row["contents"],
                config=types.GenerateContentConfig(
                    system_instruction=cfg["system_instruction"],
                    max_output_tokens=cfg["max_output_tokens"],
                    temperature=cfg["temperature"],
                    top_p=cfg["top_p"],
                    seed=cfg["seed"],
                    response_mime_type=cfg["response_mime_type"],
                    thinking_config=types.ThinkingConfig(
                        thinking_budget=cfg["thinking_config"]["thinking_budget"]),
                ),
            )
        except Exception as e:
            print(f"[{fname}] API ERROR: {type(e).__name__}: {e}")
            continue
        u = resp.usage_metadata
        think = getattr(u, "thoughts_token_count", None) or 0
        out = u.candidates_token_count or 0
        print(f"[{fname}] in={u.prompt_token_count} out={out} think={think}", end="  ")
        tot_in += u.prompt_token_count; tot_out += out; tot_think += think
        try:
            ok, k = validate_partition(resp.text, n_answers)
            print(f"parse=OK valid_partition={ok} K={k} (n={n_answers})")
        except Exception as e:
            print(f"parse=FAIL ({e}); head: {resp.text[:200]!r}")

    n = len(SAMPLES)
    print(f"\nAvg per call: in={tot_in//n} out={tot_out//n} think={tot_think//n}")
    N = 39629
    cost_in = N * (tot_in / n) / 1e6 * 1.0     # batch $1/M input
    cost_out = N * ((tot_out + tot_think) / n) / 1e6 * 6.0  # batch $6/M output(incl thinking)
    print(f"Extrapolated batch cost for {N} calls: input ${cost_in:.0f} + output ${cost_out:.0f} = ${cost_in+cost_out:.0f}")


if __name__ == "__main__":
    main()
