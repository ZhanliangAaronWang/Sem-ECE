"""Build Gemini cross-judge batch inputs from the paper's 15 clustered cells.

Re-judges the SAME extracted answers that gpt-5.2 clustered, using
gemini-3.1-pro-preview as an independent second judge (rebuttal robustness
experiment). Prompts are byte-identical to the original clustering prompts:
the system message is lifted verbatim from the original GPT batch input and
the user message is rebuilt with the same template, with N dynamic (50 for
most cells, 46 for HLE-Anthropic, 48 for some xAI rows).

Output: batch_inputs/{phase}_{provider}.jsonl, one row per question:
  {"custom_id": "{phase}__{provider}__{qid}", "contents": [...], "config": {...}}
in the same inline-batch shape phase1/gemini_batch_submit.py used.
"""
import os, json, argparse

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)

CELLS = {
    "phase1": ("phase1/clustering/{p}_simpleqa_clustered.jsonl", "simpleqa"),
    "phase2": ("phase2/clustering/{p}_simpleqa_clustered.jsonl", "hle"),
    "phase4": ("phase4/clustering/{p}_popqa_clustered.jsonl", "popqa"),
}
PROVIDERS = ["openai", "anthropic", "gemini", "xai", "mistral"]

MODEL = "gemini-3.1-pro-preview"
THINKING_BUDGET = 128          # Pro is reasoning-mandatory; keep the cap minimal
MAX_OUTPUT_TOKENS = 3000       # partition JSON; original GPT cap was 1500 completion


def load_system_prompt():
    """Lift the exact system message used for the gpt-5.2 judge."""
    src = os.path.join(ROOT, "phase1/clustering/batch_inputs/openai_clustering.jsonl")
    with open(src) as f:
        row = json.loads(f.readline())
    msg = row["body"]["messages"][0]
    assert msg["role"] == "system"
    return msg["content"]


def user_message(question, answers):
    n = len(answers)
    lines = [f"Question: {question}", "", f"Answers ({n} total, indexed 0 to {n-1}):"]
    lines += [f"[{i}] {a}" for i, a in enumerate(answers)]
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phases", nargs="+", default=list(CELLS))
    ap.add_argument("--providers", nargs="+", default=PROVIDERS)
    args = ap.parse_args()

    system_prompt = load_system_prompt()
    out_dir = os.path.join(BASE, "batch_inputs")
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(BASE, "system_prompt.txt"), "w") as f:
        f.write(system_prompt)

    total_rows, total_chars = 0, 0
    for phase in args.phases:
        pattern, ds = CELLS[phase]
        for prov in args.providers:
            src = os.path.join(ROOT, pattern.format(p=prov))
            if not os.path.exists(src):
                print(f"[{phase}/{prov}] MISSING {src}")
                continue
            out_path = os.path.join(out_dir, f"{phase}_{prov}.jsonl")
            n_rows, n_chars = 0, 0
            with open(src) as fin, open(out_path, "w") as fout:
                for line in fin:
                    r = json.loads(line)
                    answers = r["answer_extracted"]
                    usr = user_message(r["question"], answers)
                    row = {
                        "custom_id": f"{phase}__{prov}__{r['id']}",
                        "contents": [{"role": "user", "parts": [{"text": usr}]}],
                        "config": {
                            "system_instruction": system_prompt,
                            "max_output_tokens": MAX_OUTPUT_TOKENS,
                            "temperature": 0.0,
                            "top_p": 1.0,
                            "seed": 0,
                            "response_mime_type": "application/json",
                            "thinking_config": {"thinking_budget": THINKING_BUDGET},
                        },
                    }
                    fout.write(json.dumps(row, ensure_ascii=False) + "\n")
                    n_rows += 1
                    n_chars += len(usr)
            total_rows += n_rows
            total_chars += n_chars
            print(f"[{phase}/{prov}] {n_rows} rows -> {out_path} (avg user chars {n_chars//max(n_rows,1)})")

    print(f"\nTOTAL {total_rows} rows, est input tokens ~{int(total_chars/3.5 + total_rows*(len(system_prompt)/3.5 + 30)):,}")


if __name__ == "__main__":
    main()
