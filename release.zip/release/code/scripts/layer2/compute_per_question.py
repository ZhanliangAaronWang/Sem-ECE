"""Layer 2 Step 1 — compute per-question metrics (SCOPE-1/2, stability, margin, correctness).

Data sources (adapter):
  SimpleQA = phase1  (providers: openai, xai, mistral, gemini)
  HLE      = phase2  (providers: openai, xai, mistral)
  MATH     = phase3  (providers: openai, xai, mistral, gemini if available)

For each (dataset, provider), we read:
  clustering/{provider}_simpleqa_clustered.jsonl  -> cluster_assignments, modal_cluster
  grading/{provider}_simpleqa_graded.jsonl         -> Y for modal cluster
  confidence/{provider}_confidence.jsonl           -> conf_naive, conf_verbalized

For SCOPE-2 y_S handling:
  If z_hat_S == z_hat_n -> y_S = y_n.
  Else -> y_S is UNKNOWN for now; we mark it and later grade via OpenAI batch.
"""
import os, json, hashlib, glob
import numpy as np
import pandas as pd

ROOT = "/path/to/calibration"
RESULTS = os.path.join(ROOT, "results", "layer2")
os.makedirs(RESULTS, exist_ok=True)

DATASETS = {
    "simpleqa":   {"phase": "phase1", "providers": ["openai", "xai", "mistral", "gemini"], "tag": "simpleqa"},
    "hle":        {"phase": "phase2", "providers": ["openai", "mistral", "gemini"],        "tag": "simpleqa"},
    "popqa":      {"phase": "phase4", "providers": ["openai", "mistral", "gemini"],        "tag": "popqa"},
}

N = 50
S_SIZE = 30
E_SIZE = 20
R_STABILITY = 20


def per_qid_seed(qid: str) -> int:
    return int(hashlib.md5(str(qid).encode()).hexdigest()[:8], 16)


def scope2_and_stability(cluster_assignments, qid: str):
    """Return (z_hat_n, z_hat_S, c1, c2, kappa_R, margin_hat)."""
    ca = np.asarray(cluster_assignments, dtype=int)
    assert len(ca) == N
    # SCOPE-1
    cnt = np.bincount(ca)
    z_hat_n = int(np.argmax(cnt))  # tie-break: lowest index via argmax default
    c1 = float(cnt[z_hat_n]) / N
    sizes_sorted = np.sort(cnt)[::-1]
    margin_hat = float(sizes_sorted[0] - sizes_sorted[1]) / N if len(sizes_sorted) >= 2 else 1.0

    # SCOPE-2 main split (preregistered)
    seed = per_qid_seed(qid)
    rng = np.random.default_rng(seed)
    perm = rng.permutation(N)
    S_idx = perm[:S_SIZE]
    E_idx = perm[S_SIZE:]
    cnt_S = np.bincount(ca[S_idx], minlength=cnt.shape[0])
    z_hat_S = int(np.argmax(cnt_S))
    c2 = float(np.sum(ca[E_idx] == z_hat_S)) / E_SIZE

    # Stability: R=20 random subsets of size s=30 (independent streams seed+1..+R)
    matches = 0
    for r in range(R_STABILITY):
        rng_r = np.random.default_rng(seed + 1 + r)
        perm_r = rng_r.permutation(N)
        S_r = perm_r[:S_SIZE]
        cnt_r = np.bincount(ca[S_r], minlength=cnt.shape[0])
        z_r = int(np.argmax(cnt_r))
        if z_r == z_hat_n:
            matches += 1
    kappa_R = matches / R_STABILITY

    return z_hat_n, z_hat_S, c1, c2, kappa_R, margin_hat


def load_provider(dataset: str, phase: str, provider: str, tag: str = "simpleqa") -> pd.DataFrame | None:
    cl_path = os.path.join(ROOT, phase, "clustering", f"{provider}_{tag}_clustered.jsonl")
    gr_path = os.path.join(ROOT, phase, "grading", f"{provider}_{tag}_graded.jsonl")
    cf_path = os.path.join(ROOT, phase, "confidence", f"{provider}_confidence.jsonl")
    if not (os.path.exists(cl_path) and os.path.exists(gr_path) and os.path.exists(cf_path)):
        print(f"  SKIP {dataset}/{provider}: missing file(s)")
        return None

    grade_by_qid = {}
    with open(gr_path) as f:
        for l in f:
            r = json.loads(l)
            grade_by_qid[r["id"]] = int(r.get("Y", 0))

    conf_by_qid = {}
    with open(cf_path) as f:
        for l in f:
            r = json.loads(l)
            conf_by_qid[r["id"]] = {
                "conf_verbalized": r.get("conf_verbalized"),
                "verbalized_n": r.get("verbalized_n_extracted"),
            }

    rows = []
    with open(cl_path) as f:
        for l in f:
            r = json.loads(l)
            qid = r["id"]
            ca = r.get("cluster_assignments", [])
            if len(ca) != N:
                continue
            z_hat_n, z_hat_S, c1, c2, kR, mh = scope2_and_stability(ca, qid)
            conf = conf_by_qid.get(qid, {})
            y_n = grade_by_qid.get(qid)
            if y_n is None:
                continue
            # y_S: if S-cluster same as n-cluster -> y_n else unknown
            y_S = y_n if z_hat_S == z_hat_n else None
            rows.append({
                "qid": qid, "dataset": dataset, "provider": provider,
                "c1": c1, "c2": c2, "c_verb": conf.get("conf_verbalized"),
                "z_hat_n": z_hat_n, "z_hat_S": z_hat_S,
                "y_n": int(y_n), "y_S": None if y_S is None else int(y_S),
                "y_verb": int(y_n),  # verbalized uses same modal answer source
                "kappa_R": kR, "margin_hat": mh,
                "cluster_label_S": r.get("cluster_labels", [])[z_hat_S] if z_hat_S < len(r.get("cluster_labels", [])) else None,
                "cluster_label_n": r.get("modal_cluster_label"),
                "gold_answer": r.get("gold_answer"),
                "question": r.get("question"),
            })
    return pd.DataFrame(rows)


def main():
    dfs = []
    for ds, cfg in DATASETS.items():
        for prov in cfg["providers"]:
            print(f"Loading {ds}/{prov}...")
            df = load_provider(ds, cfg["phase"], prov, cfg.get("tag", "simpleqa"))
            if df is not None and len(df) > 0:
                print(f"  -> {len(df)} rows")
                dfs.append(df)
    if not dfs:
        print("No data loaded")
        return
    full = pd.concat(dfs, ignore_index=True)
    out_path = os.path.join(RESULTS, "per_question_metrics.parquet")
    full.to_parquet(out_path)
    print(f"\nTotal rows: {len(full):,}")
    print(full.groupby(["dataset", "provider"]).size())
    print(f"\nSCOPE-2 selected different cluster than SCOPE-1: "
          f"{(full['z_hat_S'] != full['z_hat_n']).sum()} rows "
          f"({(full['z_hat_S'] != full['z_hat_n']).mean()*100:.1f}%)")
    print(f"y_S missing: {full['y_S'].isna().sum()} rows")
    print(f"Saved -> {out_path}")


if __name__ == "__main__":
    main()
