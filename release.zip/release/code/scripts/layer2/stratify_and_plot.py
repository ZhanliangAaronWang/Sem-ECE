"""Layer 2 Steps 2-5: stratify, per-bin ECE, bootstrap CI, Figure 2.

Merges providers within each dataset. Produces:
  results/layer2/stratified_gains.csv
  results/layer2/signature_check.json
  results/layer2/figure2.pdf
"""
import os, json, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = "/path/to/calibration"
RESULTS = os.path.join(ROOT, "results", "layer2")
PARQUET = os.path.join(RESULTS, "per_question_metrics.parquet")

N = 50
N_BOOT = 1000
RNG = np.random.default_rng(0)
DATASETS = ["simpleqa", "hle", "popqa"]


def ece_equal_mass(conf: np.ndarray, y: np.ndarray, n_bins: int = 15) -> float:
    """15 equal-mass (quantile) bins; returns weighted |mean_conf - mean_acc|."""
    conf = np.asarray(conf, dtype=float)
    y = np.asarray(y, dtype=float)
    if len(conf) == 0:
        return np.nan
    # Drop NaN
    mask = ~(np.isnan(conf) | np.isnan(y))
    conf, y = conf[mask], y[mask]
    if len(conf) < 2:
        return np.nan
    effective_bins = min(n_bins, max(1, len(conf) // 3))
    qs = np.quantile(conf, np.linspace(0, 1, effective_bins + 1))
    # Ensure strictly increasing
    qs = np.unique(qs)
    if len(qs) < 2:
        return float(abs(conf.mean() - y.mean()))
    inds = np.digitize(conf, qs[1:-1], right=True)
    ece = 0.0
    n = len(conf)
    for b in range(len(qs) - 1):
        m = inds == b
        if m.sum() == 0:
            continue
        ece += (m.sum() / n) * abs(conf[m].mean() - y[m].mean())
    return float(ece)


def quintile_bins(v: np.ndarray, n_bins: int = 5) -> np.ndarray:
    """Return bin indices 0..n_bins-1 using quantile bins; fallback on ties."""
    v = np.asarray(v, dtype=float)
    try:
        edges = np.quantile(v, np.linspace(0, 1, n_bins + 1))
        edges_unique = np.unique(edges)
        if len(edges_unique) < n_bins + 1:
            raise ValueError("ties")
        bins = np.digitize(v, edges_unique[1:-1], right=True)
        bins = np.clip(bins, 0, n_bins - 1)
        return bins, "quintile", edges
    except Exception:
        # Fallback binning for stability: {<0.5}, {0.5-0.75}, {0.75-0.95}, {=1.0}
        edges_fb = [-np.inf, 0.5, 0.75, 0.95, 0.9999, np.inf]
        bins = np.digitize(v, edges_fb[1:-1], right=False)
        return np.clip(bins, 0, n_bins - 1), "fallback", np.array(edges_fb)


def paired_bootstrap(conf_a, y_a, conf_b, y_b, n_boot: int = N_BOOT):
    """Returns (mean_gain, ci_low, ci_high, p_gain_positive)."""
    conf_a, y_a = np.asarray(conf_a), np.asarray(y_a)
    conf_b, y_b = np.asarray(conf_b), np.asarray(y_b)
    n = len(conf_a)
    if n < 10:
        return np.nan, np.nan, np.nan, np.nan
    ece_a_full = ece_equal_mass(conf_a, y_a)
    ece_b_full = ece_equal_mass(conf_b, y_b)
    gains = []
    for _ in range(n_boot):
        idx = RNG.integers(0, n, size=n)
        ea = ece_equal_mass(conf_a[idx], y_a[idx])
        eb = ece_equal_mass(conf_b[idx], y_b[idx])
        gains.append(ea - eb)
    gains = np.array(gains)
    return (ece_a_full - ece_b_full,
            float(np.quantile(gains, 0.025)),
            float(np.quantile(gains, 0.975)),
            float(np.mean(gains > 0)))


def main():
    df = pd.read_parquet(PARQUET)
    print(f"Loaded {len(df):,} rows")

    # Clip confidences to [0,1]
    for c in ["c1", "c2", "c_verb"]:
        df[c] = pd.to_numeric(df[c], errors="coerce").clip(0, 1)
    # Drop rows with missing y_S or c_verb
    df = df.dropna(subset=["c1", "c2", "y_n", "y_S"]).copy()
    # For c_verb=NaN, fill with mean per provider (verbalized missing handled)
    df["c_verb"] = df["c_verb"].fillna(df["c_verb"].mean())
    df["y_verb"] = df["y_n"]
    print(f"After cleanup: {len(df):,}")

    rows = []
    sig = {}

    for ds in DATASETS:
        sub = df[df["dataset"] == ds].copy()
        if len(sub) == 0:
            continue
        print(f"\n=== {ds} (n={len(sub)}) ===")
        sig[ds] = {"n_total": int(len(sub))}

        for strat_name, v in [("stability", sub["kappa_R"].values),
                              ("margin", np.sqrt(N) * sub["margin_hat"].values)]:
            bins, scheme, edges = quintile_bins(v, n_bins=5)
            sub[f"bin_{strat_name}"] = bins
            sig[ds][f"{strat_name}_binning"] = scheme
            sig[ds][f"{strat_name}_edges"] = [float(e) if np.isfinite(e) else None for e in edges]
            print(f"  {strat_name} bins ({scheme}): sizes={np.bincount(bins, minlength=5).tolist()}")

            for b in range(5):
                mask = bins == b
                n_in = int(mask.sum())
                if n_in < 20:
                    print(f"    WARN: {strat_name} bin {b+1} has only {n_in} questions")
                if n_in < 5:
                    continue
                conf_v = sub.loc[mask, "c_verb"].values
                conf_1 = sub.loc[mask, "c1"].values
                conf_2 = sub.loc[mask, "c2"].values
                y_v = sub.loc[mask, "y_verb"].values
                y_1 = sub.loc[mask, "y_n"].values
                y_2 = sub.loc[mask, "y_S"].values
                ece_v = ece_equal_mass(conf_v, y_v)
                ece_1 = ece_equal_mass(conf_1, y_1)
                ece_2 = ece_equal_mass(conf_2, y_2)
                # Paired bootstrap (v vs 2 and 1 vs 2)
                g_v, lo_v, hi_v, p_v = paired_bootstrap(conf_v, y_v, conf_2, y_2)
                g_1, lo_1, hi_1, p_1 = paired_bootstrap(conf_1, y_1, conf_2, y_2)
                rows.append({
                    "dataset": ds, "stratifier": strat_name, "bin_index": b + 1,
                    "n_questions": n_in,
                    "ece_verb": ece_v, "ece_scope1": ece_1, "ece_scope2": ece_2,
                    "gain_vs_verb": g_v, "gain_vs_verb_ci_low": lo_v, "gain_vs_verb_ci_high": hi_v,
                    "gain_vs_scope1": g_1, "gain_vs_scope1_ci_low": lo_1, "gain_vs_scope1_ci_high": hi_1,
                    "p_gain_vs_scope1_positive": p_1,
                })
                print(f"    {strat_name} bin {b+1} (n={n_in}): "
                      f"ECE verb={ece_v:.3f} s1={ece_1:.3f} s2={ece_2:.3f}  "
                      f"Δs1={g_1:+.3f} [{lo_1:+.3f},{hi_1:+.3f}]")

            # Signature check: bin1 gain vs bin5 gain
            b1 = [r for r in rows if r["dataset"] == ds and r["stratifier"] == strat_name and r["bin_index"] == 1]
            b5 = [r for r in rows if r["dataset"] == ds and r["stratifier"] == strat_name and r["bin_index"] == 5]
            if b1 and b5:
                sig[ds][f"{strat_name}_bin1_minus_bin5_gain_vs_scope1"] = b1[0]["gain_vs_scope1"] - b5[0]["gain_vs_scope1"]

    # Save tables
    gains_df = pd.DataFrame(rows)
    gains_path = os.path.join(RESULTS, "stratified_gains.csv")
    gains_df.to_csv(gains_path, index=False)
    print(f"\nSaved -> {gains_path}")

    sig_path = os.path.join(RESULTS, "signature_check.json")
    with open(sig_path, "w") as f:
        json.dump(sig, f, indent=2, default=float)
    print(f"Saved -> {sig_path}")

    # Figure 2
    plot_figure2(gains_df)


def plot_figure2(gains: pd.DataFrame):
    plt.rcParams["font.family"] = "serif"
    fig, axes = plt.subplots(2, 3, figsize=(12, 7), sharey="row")
    row_labels = [
        r"Stratified by stability $\hat{\kappa}_R$",
        r"Stratified by margin $\sqrt{n}\hat{\Delta}$",
    ]
    for ri, strat in enumerate(["stability", "margin"]):
        for ci, ds in enumerate(DATASETS):
            ax = axes[ri, ci]
            sub = gains[(gains["dataset"] == ds) & (gains["stratifier"] == strat)]
            if len(sub) == 0:
                ax.set_title(f"{ds} (no data)")
                continue
            x = sub["bin_index"].values
            g1 = sub["gain_vs_verb"].values
            g2 = sub["gain_vs_scope1"].values
            lo1 = sub["gain_vs_verb_ci_low"].values
            hi1 = sub["gain_vs_verb_ci_high"].values
            lo2 = sub["gain_vs_scope1_ci_low"].values
            hi2 = sub["gain_vs_scope1_ci_high"].values
            l1 = ax.plot(x, g1, "-o", color="tab:blue", label="SCOPE-2 vs Verbalized", lw=2, mec="black")
            ax.fill_between(x, lo1, hi1, color="tab:blue", alpha=0.18)
            l2 = ax.plot(x, g2, "--^", color="tab:orange", label="SCOPE-2 vs SCOPE-1", lw=2, mec="black")
            ax.fill_between(x, lo2, hi2, color="tab:orange", alpha=0.18)
            ax.axhline(0, color="gray", ls=":", lw=0.8)
            ax.grid(True, alpha=0.2)
            if ri == 0:
                ax.set_title({"simpleqa":"SimpleQA","popqa":"PopQA","hle":"HLE","math":"MATH","medxpertqa":"MedXpertQA"}.get(ds, ds.upper()),
                             fontsize=11, fontweight="bold")
            if ci == 0:
                ax.set_ylabel(f"ECE gain\n({row_labels[ri]})", fontsize=9)
            ax.set_xlabel("Bin (low → high)", fontsize=9)
            ax.set_xticks([1, 2, 3, 4, 5])

    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="upper center", ncol=2, frameon=False,
               bbox_to_anchor=(0.5, 1.02), fontsize=10)
    plt.tight_layout(rect=[0, 0, 1, 0.97])
    out = os.path.join(RESULTS, "figure2.pdf")
    plt.savefig(out, bbox_inches="tight")
    plt.savefig(out.replace(".pdf", ".png"), dpi=150, bbox_inches="tight")
    print(f"Saved -> {out}")


if __name__ == "__main__":
    main()
