"""Grade z_hat_S cluster labels for questions where z_hat_S != z_hat_n.

Uses OpenAI gpt-5.2 synchronously with concurrency. Output written back
into per_question_metrics.parquet as y_S.
"""
import os, json, asyncio
from dotenv import load_dotenv
import pandas as pd

ROOT = "/path/to/calibration"
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import AsyncOpenAI

RESULTS = os.path.join(ROOT, "results", "layer2")
PARQUET = os.path.join(RESULTS, "per_question_metrics.parquet")
CACHE = os.path.join(RESULTS, "y_S_grades.jsonl")

MODEL = "gpt-5.2"
CONCURRENCY = 20

SYSTEM_PROMPT = """You are a grader for a question-answering benchmark. You will receive a question, the official gold answer, and a predicted answer. Your job is to decide whether the predicted answer is semantically equivalent to the gold answer.

Rules:
- Accept different surface forms of the same answer: "Leo Tolstoy" matches "Tolstoy"; "1869" matches "1869 AD"; "Paris, France" matches "Paris"; "1.5 mM" matches "0.0015 M".
- Reject answers that are related but specifically different.
- If the predicted answer is a refusal (e.g., "I don't know", "Unknown", "N/A", empty), output NOT_ATTEMPTED.
- Be lenient on capitalization, punctuation, articles, minor formatting.

Output format: a single JSON object with one field, "grade", whose value is exactly one of: "CORRECT", "INCORRECT", "NOT_ATTEMPTED".

Output ONLY the JSON object, no preamble."""


def load_cache() -> dict:
    cache = {}
    if os.path.exists(CACHE):
        with open(CACHE) as f:
            for line in f:
                try:
                    r = json.loads(line)
                    cache[r["key"]] = r["grade"]
                except Exception:
                    pass
    return cache


async def grade_one(client, sem, question, gold, pred):
    async with sem:
        try:
            resp = await client.chat.completions.create(
                model=MODEL,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": f"Question: {question}\nGold answer: {gold}\nPredicted answer: {pred}"},
                ],
                reasoning_effort="none",
                temperature=0.0,
                max_completion_tokens=20,
                response_format={"type": "json_object"},
                seed=0,
            )
            content = resp.choices[0].message.content
            obj = json.loads(content)
            g = obj.get("grade", "NOT_ATTEMPTED")
            return 1 if g == "CORRECT" else 0
        except Exception as e:
            return None


async def main():
    df = pd.read_parquet(PARQUET)
    mask = df["z_hat_S"] != df["z_hat_n"]
    todo = df[mask].copy()
    print(f"Total unstable rows: {len(todo):,}")

    cache = load_cache()

    # Build (key, question, gold, pred) list
    tasks_meta = []
    for _, r in todo.iterrows():
        key = f"{r['dataset']}|{r['provider']}|{r['qid']}|{r['z_hat_S']}"
        tasks_meta.append({
            "key": key,
            "question": r["question"],
            "gold": r["gold_answer"],
            "pred": r["cluster_label_S"] or "",
        })

    api_key = os.environ.get("OPENAI_API_KEY")
    client = AsyncOpenAI(api_key=api_key)
    sem = asyncio.Semaphore(CONCURRENCY)

    out_f = open(CACHE, "a")
    new_grades = {}
    batch_size = 100
    for i in range(0, len(tasks_meta), batch_size):
        chunk = tasks_meta[i:i + batch_size]
        pending = []
        for meta in chunk:
            if meta["key"] in cache:
                continue
            pending.append(meta)
        if not pending:
            continue
        coros = [grade_one(client, sem, m["question"], m["gold"], m["pred"]) for m in pending]
        results = await asyncio.gather(*coros)
        for meta, y in zip(pending, results):
            if y is None:
                continue
            out_f.write(json.dumps({"key": meta["key"], "grade": y}) + "\n")
            out_f.flush()
            cache[meta["key"]] = y
            new_grades[meta["key"]] = y
        done = sum(1 for m in tasks_meta[:i + len(chunk)] if m["key"] in cache)
        print(f"  progress: {done}/{len(tasks_meta)}")
    out_f.close()

    # Apply to dataframe
    y_S_new = []
    for _, r in df.iterrows():
        if pd.notna(r["y_S"]):
            y_S_new.append(int(r["y_S"]))
            continue
        key = f"{r['dataset']}|{r['provider']}|{r['qid']}|{r['z_hat_S']}"
        if key in cache:
            y_S_new.append(int(cache[key]))
        else:
            y_S_new.append(None)
    df["y_S"] = y_S_new
    df.to_parquet(PARQUET)
    print(f"\nUpdated y_S. Still missing: {df['y_S'].isna().sum()} rows")
    print(f"y_S dist: {df['y_S'].value_counts(dropna=False).to_dict()}")


if __name__ == "__main__":
    asyncio.run(main())
