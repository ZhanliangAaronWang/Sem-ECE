"""Exp 8 — submit / collect the three temperature-arm generation batches (OpenAI batch API).

State: batch_outputs/gen_jobs.json ; output: batch_outputs/{arm}_raw.jsonl
rows {custom_id: "{qid}__sample{i}", text}.
"""
import os, json, time, argparse
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))
from openai import OpenAI

OUTD = os.path.join(BASE, "batch_outputs")
STATE = os.path.join(OUTD, "gen_jobs.json")
ARMS = ["T_low", "T_high", "topp"]

# chunk -> (first sample index, n)   6 x n=8 then 1 x n=2  => 50 samples
CHUNK_BASE = {}
_s = 0
for ci in range(7):
    _n = 8 if ci < 6 else 2
    CHUNK_BASE[ci] = (_s, _n)
    _s += _n


def load_state():
    return json.load(open(STATE)) if os.path.exists(STATE) else {}


def save_state(s):
    json.dump(s, open(STATE, "w"), indent=1)


def submit(client):
    st = load_state()
    for arm in ARMS:
        if arm in st:
            print(f"{arm}: already submitted ({st[arm]['batch_id']})"); continue
        path = os.path.join(BASE, "batch_inputs", f"{arm}.jsonl")
        with open(path, "rb") as f:
            fo = client.files.create(file=f, purpose="batch")
        b = client.batches.create(input_file_id=fo.id, endpoint="/v1/chat/completions",
                                  completion_window="24h")
        st[arm] = {"file_id": fo.id, "batch_id": b.id, "submitted_at": time.strftime("%F %T")}
        save_state(st)
        print(f"{arm}: batch {b.id}")


def collect(client):
    st = load_state()
    all_done = True
    for arm in ARMS:
        j = st.get(arm)
        if not j or j.get("collected"):
            continue
        b = client.batches.retrieve(j["batch_id"])
        rc = b.request_counts
        print(f"  {arm}: {b.status} {getattr(rc,'completed',0)}/{getattr(rc,'total',0)}", flush=True)
        if b.status not in ("completed", "failed", "expired", "cancelled"):
            all_done = False
            continue
        if b.output_file_id:
            content = client.files.content(b.output_file_id).text
            out = os.path.join(OUTD, f"{arm}_raw.jsonl")
            n = 0
            with open(out, "w") as f:
                for line in content.splitlines():
                    r = json.loads(line)
                    cid = r["custom_id"]                    # {arm}__{qid}__chunk{i}
                    rest = cid.split("__", 1)[1]
                    qid, chunk = rest.rsplit("__chunk", 1)
                    base, _ = CHUNK_BASE[int(chunk)]
                    body = (r.get("response") or {}).get("body") or {}
                    for k, ch in enumerate(body.get("choices", [])):
                        f.write(json.dumps({"custom_id": f"{qid}__sample{base+k:02d}",
                                            "text": ch["message"]["content"]},
                                           ensure_ascii=False) + "\n")
                        n += 1
            print(f"    {arm}: wrote {n} samples")
        if b.error_file_id:
            print(f"    NOTE error_file {b.error_file_id}")
        j["collected"] = True
        save_state(st)
    return all_done


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--submit", action="store_true")
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--interval", type=int, default=600)
    args = ap.parse_args()
    os.makedirs(OUTD, exist_ok=True)
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    if args.submit:
        submit(client); return
    while True:
        if collect(client) or not args.loop:
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
