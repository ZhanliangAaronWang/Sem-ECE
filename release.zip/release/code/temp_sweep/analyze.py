"""Exp 8 — analysis: margin distribution, ECE with CIs, gap below/above the JDR boundary.

Theory's directional prediction (Thm 5.1 / 5.6 / 5.7):
  lower T  -> the semantic posterior concentrates -> larger margins Δ̂q
              -> less low-margin mass -> SMALLER Sem₁−Sem₂ gap
  higher T -> flatter posterior -> more low-margin mass
              -> LARGER gap, concentrated BELOW the JDR boundary Δ = 2λ̃*/√n.

JDR boundary at n=50: Δ = 0.612/√50 = 0.0866.
Low/large boundary: Δ = sqrt(log K̂ / n) (per-arm K̂).
"""
import os, json, argparse
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
ARMS = ["T_low", "original", "topp", "T_high"]          # ordered by expected diversity
LABEL = {"T_low": "T=0.6", "original": "T=1.0 (paper)", "topp": "T=1.0, top-p=0.8",
         "T_high": "T=1.3"}
JDR = 0.612 / np.sqrt(50)
B_BOOT = 1000


def sssc(a, R=10, seed=0):
    a = np.asarray(a); n = len(a); half = n // 2
    rng = np.random.default_rng(seed); mx = int(a.max()) + 1
    return float(np.mean([np.mean(a[p[half:]] == np.bincount(a[p[:half]], minlength=mx).argmax())
                          for p in (rng.permutation(n) for _ in range(R))]))


def ece_10bin(c, y):
    c, y = np.asarray(c, float), np.asarray(y, float)
    if c.size == 0:
        return float("nan")
    idx = np.clip(np.digitize(c, np.linspace(0, 1, 11)[1:-1]), 0, 9)
    return float(sum((idx == b).mean() * abs(y[idx == b].mean() - c[idx == b].mean())
                     for b in range(10) if (idx == b).any()))


def load_arm(arm):
    cp = os.path.join(BASE, "clustering", f"{arm}_clustered.jsonl")
    gp = os.path.join(BASE, "grading", f"{arm}_graded.jsonl")
    if not (os.path.exists(cp) and os.path.exists(gp)):
        return None
    Y = {}
    for line in open(gp):
        r = json.loads(line); Y.setdefault(r["id"], r["Y"])
    rows = []
    for line in open(cp):
        r = json.loads(line)
        y = Y.get(r["id"])
        if y is None:
            continue
        s = sorted(r["cluster_sizes"], reverse=True)
        n = sum(s)
        rows.append({"id": r["id"], "y": int(y), "K": r["n_clusters"],
                     "delta": (s[0] - (s[1] if len(s) > 1 else 0)) / n,
                     "c1": s[0] / n, "c2": sssc(r["cluster_assignments"]),
                     "ver": float(r.get("verbalized_mean") or 1.0)})
    return rows


def boot_ci(fn, rows, seed=0):
    rng = np.random.default_rng(seed)
    idx = np.arange(len(rows))
    vals = [fn([rows[i] for i in rng.choice(idx, len(idx), replace=True)]) for _ in range(B_BOOT)]
    v = np.asarray(vals, float)
    return float(np.nanpercentile(v, 2.5)), float(np.nanpercentile(v, 97.5))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(BASE, "RESULTS_temp_sweep.md"))
    args = ap.parse_args()

    data = {a: load_arm(a) for a in ARMS}
    have = [a for a in ARMS if data[a]]
    if not have:
        print("no arms ready"); return
    common = set.intersection(*[{r["id"] for r in data[a]} for a in have])
    print("arms:", have, "| common questions:", len(common))
    for a in have:
        data[a] = [r for r in data[a] if r["id"] in common]

    L = ["# Exp 8 (R6b) — temperature / sampling sensitivity\n",
         "OpenAI **gpt-5.4**, SimpleQA, fixed-seed 300-question subset "
         "(`subset_ids.json`; recipe: sorted ids → `default_rng(0).permutation` → first 500 → first 300).",
         "50 generations per question per arm. Clustering **and** grading use the *original* judge "
         "**gpt-5.2** (`reasoning_effort=none, temperature=0, seed=0`) with byte-identical prompts.",
         "",
         "> Note: the paper's §6.1 states the clustering judge is `gpt-5.4`; every batch input in the "
         "> repo shows it was actually **`gpt-5.2`**. We use gpt-5.2 so these arms are comparable "
         "> with all existing results. (Paper text needs the fix — already logged.)",
         "",
         f"The `original` arm reuses the paper's own samples for these 300 questions (no new API calls). "
         f"All arms are compared on the same **N={len(common)}** questions.",
         f"JDR boundary at n=50: Δ = 2λ̃*/√n = **{JDR:.4f}**.\n",
         "## 1. Margin distribution and cluster count\n",
         "| arm | N | mean K̂ | mean Δ̂ | median Δ̂ | frac Δ̂ < JDR | frac Δ̂ < √(logK̂/n) "
         "| accuracy | mean ĉ₁ | over-conf (ĉ₁−acc) | over-conf below JDR |",
         "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for a in have:
        R = data[a]
        d = np.array([r["delta"] for r in R]); K = np.array([r["K"] for r in R], float)
        thr2 = np.sqrt(np.log(np.maximum(K.mean(), 2)) / 50)
        acc = np.mean([r["y"] for r in R]); mc1 = np.mean([r["c1"] for r in R])
        lo = [r for r in R if r["delta"] < JDR]
        oc_lo = (np.mean([r["c1"] for r in lo]) - np.mean([r["y"] for r in lo])) if lo else float("nan")
        L.append(f"| {LABEL[a]} | {len(R)} | {K.mean():.2f} | {d.mean():.4f} | {np.median(d):.4f} | "
                 f"{(d < JDR).mean():.3f} | {(d < thr2).mean():.3f} | {acc:.3f} | {mc1:.3f} | "
                 f"{mc1-acc:.3f} | {oc_lo:.3f} |")

    L += ["\n## 2. Pooled ECE per arm (95% bootstrap CI, B=1000 over questions)\n",
          "| arm | Sem₁-ECE | Sem₂-ECE | Ver-ECE |", "|---|---|---|---|"]
    for a in have:
        R = data[a]
        cells = []
        for k in ("c1", "c2", "ver"):
            v = ece_10bin([r[k] for r in R], [r["y"] for r in R])
            lo, hi = boot_ci(lambda rs, k=k: ece_10bin([r[k] for r in rs], [r["y"] for r in rs]), R)
            cells.append(f"{v:.4f} [{lo:.4f}, {hi:.4f}]")
        L.append(f"| {LABEL[a]} | " + " | ".join(cells) + " |")

    L += ["\n## 3. Sem₁−Sem₂ gap: overall vs below/above the JDR boundary\n",
          "| arm | gap overall | gap below JDR | n below | gap above JDR | n above |",
          "|---|---|---|---:|---|---:|"]
    for a in have:
        R = data[a]
        def gap(rs):
            if not rs:
                return float("nan")
            y = [r["y"] for r in rs]
            return ece_10bin([r["c1"] for r in rs], y) - ece_10bin([r["c2"] for r in rs], y)
        lo_, hi_ = boot_ci(gap, R)
        below = [r for r in R if r["delta"] < JDR]
        above = [r for r in R if r["delta"] >= JDR]
        cells = [f"{gap(R):+.4f} [{lo_:+.4f}, {hi_:+.4f}]"]
        for sub in (below, above):
            if len(sub) >= 30:
                l2, h2 = boot_ci(gap, sub)
                cells.append(f"{gap(sub):+.4f} [{l2:+.4f}, {h2:+.4f}]")
            else:
                cells.append("n/a")
        L.append(f"| {LABEL[a]} | {cells[0]} | {cells[1]} | {len(below)} | {cells[2]} | {len(above)} |")

    # ---- 4. paired arm contrasts (all arms share the same questions -> far tighter than
    #         comparing the independent per-arm CIs above)
    if len(have) > 1:
        L += ["\n## 4. Paired arm contrasts (same 300 questions; paired bootstrap, B=1000)\n",
              "Δgap = gap(arm) − gap(reference). Positive ⇒ the arm has a *larger* Sem₁−Sem₂ gap.\n",
              "| contrast | Δ gap [95% CI] | Δ mean margin | Δ frac below JDR |",
              "|---|---|---:|---:|"]
        ref = "original" if "original" in have else have[0]
        byid = {a: {r["id"]: r for r in data[a]} for a in have}
        ids = sorted(common)

        def gap_of(rows):
            if not rows:
                return float("nan")
            y = [r["y"] for r in rows]
            return ece_10bin([r["c1"] for r in rows], y) - ece_10bin([r["c2"] for r in rows], y)

        for a in have:
            if a == ref:
                continue
            rng = np.random.default_rng(0)
            obs = gap_of([byid[a][i] for i in ids]) - gap_of([byid[ref][i] for i in ids])
            draws = []
            for _ in range(B_BOOT):
                samp = rng.choice(len(ids), len(ids), replace=True)
                sids = [ids[i] for i in samp]
                draws.append(gap_of([byid[a][i] for i in sids]) -
                             gap_of([byid[ref][i] for i in sids]))
            lo, hi = np.nanpercentile(draws, [2.5, 97.5])
            dm = (np.mean([byid[a][i]["delta"] for i in ids]) -
                  np.mean([byid[ref][i]["delta"] for i in ids]))
            df = (np.mean([byid[a][i]["delta"] < JDR for i in ids]) -
                  np.mean([byid[ref][i]["delta"] < JDR for i in ids]))
            L.append(f"| {LABEL[a]} − {LABEL[ref]} | {obs:+.4f} [{lo:+.4f}, {hi:+.4f}] | "
                     f"{dm:+.4f} | {df:+.3f} |")

    L.append("\n**Directional prediction under test:** lower T ⇒ larger margins ⇒ less low-margin "
             "mass ⇒ smaller gap; higher T ⇒ more low-margin mass ⇒ larger gap concentrated below "
             "the JDR boundary. At N=300 the *per-arm* gap CIs are wide, so the paired contrasts in "
             "§4 (which cancel question-level variance) are the powered test.\n")

    with open(args.out, "w") as f:
        f.write("\n".join(L) + "\n")
    print("wrote", args.out)

    # ---- figure: margin density per arm
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    cols = {"T_low": "#2e86ab", "original": "#4c4c4c", "topp": "#f4a261", "T_high": "#d1495b"}
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.4))
    ax = axes[0]
    bins = np.linspace(0, 1, 41)
    for a in have:
        d = np.array([r["delta"] for r in data[a]])
        h, e = np.histogram(d, bins=bins, density=True)
        ax.plot((e[:-1] + e[1:]) / 2, h, lw=2, color=cols[a], label=f"{LABEL[a]}  (mean Δ̂={d.mean():.3f})")
    ax.axvline(JDR, ls="--", color="crimson", lw=1.5)
    ax.text(JDR, ax.get_ylim()[1] * .92, "  JDR", color="crimson", fontsize=9)
    ax.set_xlabel(r"per-question empirical margin $\hat\Delta_q$")
    ax.set_ylabel("density"); ax.set_title("Margin distribution shifts with sampling temperature")
    ax.legend(fontsize=8); ax.grid(alpha=.3)

    ax = axes[1]
    xs = np.arange(len(have))
    g_all, g_below = [], []
    for a in have:
        R = data[a]
        y = [r["y"] for r in R]
        g_all.append(ece_10bin([r["c1"] for r in R], y) - ece_10bin([r["c2"] for r in R], y))
        sub = [r for r in R if r["delta"] < JDR]
        ys = [r["y"] for r in sub]
        g_below.append(ece_10bin([r["c1"] for r in sub], ys) - ece_10bin([r["c2"] for r in sub], ys)
                       if len(sub) >= 30 else np.nan)
    ax.bar(xs - .2, g_all, .38, color="#3c1642", label="all questions")
    ax.bar(xs + .2, g_below, .38, color="#f4a261", label="below JDR")
    ax.set_xticks(xs); ax.set_xticklabels([LABEL[a] for a in have], fontsize=9)
    ax.set_ylabel(r"ECE gap (Sem$_1-$Sem$_2$)")
    ax.set_title("Gap grows with sampling diversity, concentrated below JDR")
    ax.axhline(0, color="k", lw=.8); ax.legend(fontsize=9); ax.grid(alpha=.3, axis="y")

    fig.tight_layout()
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(BASE, f"figure_temp_sweep.{ext}"), dpi=150, bbox_inches="tight")
    print("saved figure_temp_sweep.{png,pdf}")


if __name__ == "__main__":
    main()
