"""Exp 8 — cluster + grade the temperature arms with the ORIGINAL judge.

NOTE ON THE JUDGE: the paper's §6.1 says the clustering judge is "gpt-5.4", but
every batch input in the repo shows the judge actually used was **gpt-5.2**
(reasoning_effort=none, temperature=0, seed=0) for BOTH clustering and grading.
We use gpt-5.2 so these arms are directly comparable with all existing data.
Prompts are lifted byte-identically from the original batch inputs.

Usage:
  python run_cluster_grade.py --stage cluster --submit
  python run_cluster_grade.py --stage cluster --loop
  python run_cluster_grade.py --stage grade   --submit
  python run_cluster_grade.py --stage grade   --loop
  python run_cluster_grade.py --stage original     # build the reused original arm
"""
import os, json, re, time, argparse, sys
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))
sys.path.insert(0, os.path.join(ROOT, "cross_judge"))
from collect import tolerant_parse                      # noqa: E402
from openai import OpenAI

OUTD = os.path.join(BASE, "batch_outputs")
CLUS = os.path.join(BASE, "clustering")
GRAD = os.path.join(BASE, "grading")
ARMS = ["T_low", "T_high", "topp"]

ANS_RE = re.compile(r"Answer:\s*(.+?)(?=\nConfidence|\Z)", re.DOTALL)
CONF_RE = re.compile(r"Confidence:\s*([0-9]+(?:\.[0-9]+)?)\s*%?")
BAD = {"see above", "as stated", "as mentioned", "as noted"}

CLUSTER_SYS = open(os.path.join(ROOT, "cross_judge", "system_prompt.txt")).read()
GRADE_SYS = json.loads(open(os.path.join(
    ROOT, "phase1", "grading", "batch_inputs",
    sorted(os.listdir(os.path.join(ROOT, "phase1", "grading", "batch_inputs")))[0]
)).readline())["body"]["messages"][0]["content"]


def extract(text):
    m = ANS_RE.search(text or "")
    ans = None
    if m:
        cand = m.group(1).strip()
        if cand and cand.lower() not in BAD:
            ans = cand
    if ans is None:
        ans = (text or "")[-200:].strip()
    cm = CONF_RE.search(text or "")
    conf = max(0.0, min(1.0, float(cm.group(1)) / 100.0)) if cm else None
    return ans, conf


def meta():
    """qid -> (question, gold) from the paper's phase1 clustered file."""
    d = {}
    with open(os.path.join(ROOT, "phase1", "clustering", "openai_simpleqa_clustered.jsonl")) as f:
        for line in f:
            r = json.loads(line)
            d[r["id"]] = (r["question"], r["gold_answer"])
    return d


def user_msg(q, answers):
    n = len(answers)
    return "\n".join([f"Question: {q}", "", f"Answers ({n} total, indexed 0 to {n-1})："
                      .replace("：", ":")] + [f"[{i}] {a}" for i, a in enumerate(answers)])


def state_path(stage):
    return os.path.join(OUTD, f"{stage}_jobs.json")


def load_state(stage):
    p = state_path(stage)
    return json.load(open(p)) if os.path.exists(p) else {}


def save_state(stage, s):
    json.dump(s, open(state_path(stage), "w"), indent=1)


# ── original arm (no API) ───────────────────────────────────────────
def build_original():
    ids = set(json.load(open(os.path.join(BASE, "subset_ids.json")))["used300"])
    os.makedirs(CLUS, exist_ok=True); os.makedirs(GRAD, exist_ok=True)
    n = 0
    with open(os.path.join(ROOT, "phase1", "clustering", "openai_simpleqa_clustered.jsonl")) as fin, \
         open(os.path.join(CLUS, "original_clustered.jsonl"), "w") as fout:
        for line in fin:
            r = json.loads(line)
            if r["id"] in ids:
                fout.write(json.dumps(r, ensure_ascii=False) + "\n"); n += 1
    m = 0
    with open(os.path.join(ROOT, "phase1", "grading", "openai_simpleqa_graded.jsonl")) as fin, \
         open(os.path.join(GRAD, "original_graded.jsonl"), "w") as fout:
        for line in fin:
            r = json.loads(line)
            if r["id"] in ids:
                fout.write(json.dumps(r, ensure_ascii=False) + "\n"); m += 1
    print(f"original arm reused from the paper: {n} clustered, {m} graded (no API calls)")


# ── clustering ──────────────────────────────────────────────────────
def build_cluster_inputs():
    M = meta()
    os.makedirs(os.path.join(BASE, "cluster_inputs"), exist_ok=True)
    for arm in ARMS:
        raw = os.path.join(OUTD, f"{arm}_raw.jsonl")
        if not os.path.exists(raw):
            print(f"[{arm}] raw missing, skip"); continue
        byq = {}
        with open(raw) as f:
            for line in f:
                r = json.loads(line)
                qid, s = r["custom_id"].rsplit("__sample", 1)
                byq.setdefault(qid, {})[int(s)] = r["text"]
        path = os.path.join(BASE, "cluster_inputs", f"{arm}.jsonl")
        n = 0
        with open(path, "w") as f:
            for qid, d in sorted(byq.items()):
                texts = [d[k] for k in sorted(d)]
                if len(texts) < 50:
                    continue
                answers = [extract(t)[0] for t in texts[:50]]
                q, _ = M[qid]
                f.write(json.dumps({
                    "custom_id": f"{arm}__{qid}",
                    "method": "POST", "url": "/v1/chat/completions",
                    "body": {"model": "gpt-5.2",
                             "messages": [{"role": "system", "content": CLUSTER_SYS},
                                          {"role": "user", "content": user_msg(q, answers)}],
                             "reasoning_effort": "none", "temperature": 0.0,
                             "max_completion_tokens": 3000,
                             "response_format": {"type": "json_object"}, "seed": 0}},
                    ensure_ascii=False) + "\n")
                n += 1
        print(f"[{arm}] {n} clustering rows -> {path}")


def parse_cluster(arm, texts):
    """texts: {qid: judge_text} -> clustered rows (with verbalized from raw)."""
    M = meta()
    verb = {}
    with open(os.path.join(OUTD, f"{arm}_raw.jsonl")) as f:
        for line in f:
            r = json.loads(line)
            qid, s = r["custom_id"].rsplit("__sample", 1)
            verb.setdefault(qid, {})[int(s)] = extract(r["text"])[1]
    rows, fails = [], 0
    for qid, text in texts.items():
        n = 50
        try:
            cut = text.find('{"clusters"')
            if cut < 0:
                cut = text.find("{")
            obj = tolerant_parse(text[cut:] if cut > 0 else text)
            assign = [None] * n; labels = []
            for k, c in enumerate(obj["clusters"]):
                labels.append(str(c["label"]))
                for i in c["members"]:
                    if not (0 <= int(i) < n) or assign[int(i)] is not None:
                        raise ValueError("bad")
                    assign[int(i)] = k
            if any(a is None for a in assign):
                raise ValueError("incomplete")
            sizes = [assign.count(k) for k in range(len(labels))]
            modal = max(range(len(sizes)), key=lambda k: sizes[k])
            vs = verb.get(qid, {})
            vv = [vs.get(i) for i in range(n)]
            got = [x for x in vv if x is not None]
            q, gold = M[qid]
            rows.append({"id": qid, "question": q, "gold_answer": gold, "model": "openai",
                         "arm": arm, "n_samples": n, "n_clusters": len(labels),
                         "cluster_labels": labels, "cluster_assignments": assign,
                         "cluster_sizes": sizes, "modal_cluster": modal,
                         "modal_cluster_label": labels[modal],
                         "confidence_verbalized": [1.0 if x is None else x for x in vv],
                         "verbalized_mean": (sum(got) / len(got)) if got else 1.0,
                         "verbalized_n_extracted": len(got)})
        except Exception:
            fails += 1
    return rows, fails


# ── grading ─────────────────────────────────────────────────────────
def build_grade_inputs():
    os.makedirs(os.path.join(BASE, "grade_inputs"), exist_ok=True)
    for arm in ARMS:
        cp = os.path.join(CLUS, f"{arm}_clustered.jsonl")
        if not os.path.exists(cp):
            print(f"[{arm}] clustered missing, skip"); continue
        path = os.path.join(BASE, "grade_inputs", f"{arm}.jsonl")
        n = 0
        with open(cp) as fin, open(path, "w") as f:
            for line in fin:
                r = json.loads(line)
                usr = (f"Question: {r['question']}\nGold answer: {r['gold_answer']}\n"
                       f"Predicted answer: {r['modal_cluster_label']}")
                f.write(json.dumps({
                    "custom_id": f"{arm}__{r['id']}",
                    "method": "POST", "url": "/v1/chat/completions",
                    "body": {"model": "gpt-5.2",
                             "messages": [{"role": "system", "content": GRADE_SYS},
                                          {"role": "user", "content": usr}],
                             "reasoning_effort": "none", "temperature": 0.0,
                             "max_completion_tokens": 50,
                             "response_format": {"type": "json_object"}, "seed": 0}},
                    ensure_ascii=False) + "\n")
                n += 1
        print(f"[{arm}] {n} grading rows -> {path}")


# ── generic submit / collect ────────────────────────────────────────
def submit(stage, client):
    st = load_state(stage)
    d = {"cluster": "cluster_inputs", "grade": "grade_inputs"}[stage]
    for arm in ARMS:
        if arm in st:
            print(f"{stage}/{arm}: already submitted"); continue
        p = os.path.join(BASE, d, f"{arm}.jsonl")
        if not os.path.exists(p):
            print(f"{stage}/{arm}: input missing"); continue
        with open(p, "rb") as f:
            fo = client.files.create(file=f, purpose="batch")
        b = client.batches.create(input_file_id=fo.id, endpoint="/v1/chat/completions",
                                  completion_window="24h")
        st[arm] = {"file_id": fo.id, "batch_id": b.id, "submitted_at": time.strftime("%F %T")}
        save_state(stage, st)
        print(f"{stage}/{arm}: batch {b.id}")


def collect(stage, client):
    st = load_state(stage)
    os.makedirs(CLUS, exist_ok=True); os.makedirs(GRAD, exist_ok=True)
    all_done = True
    for arm in ARMS:
        j = st.get(arm)
        if not j or j.get("collected"):
            continue
        b = client.batches.retrieve(j["batch_id"])
        rc = b.request_counts
        print(f"  {stage}/{arm}: {b.status} {getattr(rc,'completed',0)}/{getattr(rc,'total',0)}", flush=True)
        if b.status not in ("completed", "failed", "expired", "cancelled"):
            all_done = False; continue
        texts = {}
        if b.output_file_id:
            for line in client.files.content(b.output_file_id).text.splitlines():
                r = json.loads(line)
                _, qid = r["custom_id"].split("__", 1)
                body = (r.get("response") or {}).get("body") or {}
                try:
                    texts[qid] = body["choices"][0]["message"]["content"]
                except Exception:
                    pass
        if stage == "cluster":
            rows, fails = parse_cluster(arm, texts)
            with open(os.path.join(CLUS, f"{arm}_clustered.jsonl"), "w") as f:
                for r in sorted(rows, key=lambda x: x["id"]):
                    f.write(json.dumps(r, ensure_ascii=False) + "\n")
            print(f"    {arm}: clustered {len(rows)}, parse fails {fails}")
        else:
            n = 0
            with open(os.path.join(GRAD, f"{arm}_graded.jsonl"), "w") as f:
                for qid, t in sorted(texts.items()):
                    try:
                        g = tolerant_parse(t)["grade"].upper()
                    except Exception:
                        continue
                    f.write(json.dumps({"id": qid, "arm": arm, "grade": g,
                                        "Y": 1 if g == "CORRECT" else 0}) + "\n")
                    n += 1
            print(f"    {arm}: graded {n}")
        j["collected"] = True
        save_state(stage, st)
    return all_done


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", required=True, choices=["cluster", "grade", "original"])
    ap.add_argument("--submit", action="store_true")
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--interval", type=int, default=300)
    args = ap.parse_args()
    if args.stage == "original":
        build_original(); return
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    if args.submit:
        (build_cluster_inputs if args.stage == "cluster" else build_grade_inputs)()
        submit(args.stage, client); return
    while True:
        if collect(args.stage, client) or not args.loop:
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
