"""Exp 8 (R6b) — temperature / sampling sensitivity. Build subset + generation inputs.

Provider: OpenAI gpt-5.4 (probe confirmed temperature AND top_p are honoured:
n=8 draws gave 5/8 distinct at T=0.6, 7/8 at T=1.3, 5/8 at top_p=0.8).
Benchmark: SimpleQA.

Question subset (no such artifact pre-existed in the repo, so it is defined here
and is fully reproducible): take the ids of phase1/clustering/openai_simpleqa
sorted lexicographically, permute with numpy default_rng(0), take the first 500
("the fixed-seed 500-q subset"), then the first 300 of those.

Arms (T0 = 1.0, top_p0 = 1.0, read from the paper's generation config):
  original  T=1.0  top_p=1.0   -> REUSED from the paper's existing samples (no API)
  T_low     T=0.6  top_p=1.0   = max(T0-0.4, 0.2)
  T_high    T=1.3  top_p=1.0   = T0+0.3
  topp      T=1.0  top_p=0.8

50 generations per question per arm, using the paper's exact OpenAI batch layout
(7 rows/question: 6 x n=8 + 1 x n=2, seed = chunk index) and the byte-identical
system prompt.
"""
import os, json
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)

SRC_CLUSTER = os.path.join(ROOT, "phase1", "clustering", "openai_simpleqa_clustered.jsonl")
SRC_BATCH = os.path.join(ROOT, "phase1", "batch_inputs", "openai_simpleqa.jsonl")

ARMS = {                       # name -> (temperature, top_p)
    "T_low": (0.6, 1.0),
    "T_high": (1.3, 1.0),
    "topp": (1.0, 0.8),
}
N_SUBSET, N_USE = 500, 300


def main():
    os.makedirs(os.path.join(BASE, "batch_inputs"), exist_ok=True)
    SYSTEM = json.loads(open(SRC_BATCH).readline())["body"]["messages"][0]["content"]

    qs = {}
    with open(SRC_CLUSTER) as f:
        for line in f:
            r = json.loads(line)
            qs[r["id"]] = r["question"]
    ids_sorted = sorted(qs)
    perm = np.random.default_rng(0).permutation(len(ids_sorted))
    subset500 = [ids_sorted[i] for i in perm[:N_SUBSET]]
    use = subset500[:N_USE]
    with open(os.path.join(BASE, "subset_ids.json"), "w") as f:
        json.dump({"subset500": subset500, "used300": use,
                   "recipe": "sorted(openai simpleqa ids) -> default_rng(0).permutation -> [:500] -> [:300]"},
                  f, indent=1)
    print(f"subset: {len(subset500)} (500-q) -> using first {len(use)}")

    for arm, (T, tp) in ARMS.items():
        path = os.path.join(BASE, "batch_inputs", f"{arm}.jsonl")
        n = 0
        with open(path, "w") as f:
            for qid in use:
                for chunk in range(7):
                    n_val = 8 if chunk < 6 else 2
                    f.write(json.dumps({
                        "custom_id": f"{arm}__{qid}__chunk{chunk}",
                        "method": "POST", "url": "/v1/chat/completions",
                        "body": {
                            "model": "gpt-5.4",
                            "messages": [{"role": "system", "content": SYSTEM},
                                         {"role": "user", "content": qs[qid]}],
                            "max_completion_tokens": 256,
                            "temperature": T, "top_p": tp,
                            "reasoning_effort": "none",
                            "n": n_val, "seed": chunk,
                        }}, ensure_ascii=False) + "\n")
                    n += 1
        print(f"[{arm}] T={T} top_p={tp} -> {n} rows ({len(use)} q x 7 chunks = 50 samples/q)")


if __name__ == "__main__":
    main()
