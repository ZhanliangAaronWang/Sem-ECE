"""Phase 3 / R2 — human-audit sheet generator (build now, run after the two-judge comparison).

Reference judge = the paper's own clustering judge **gpt-5.2**
(the paper text says "gpt-5.4"; every batch input in the repo shows gpt-5.2 —
already logged as a paper-text fix). Second judge = gemini-3.1-pro-preview (Exp 1).

POOLS
  disagreement : answer pairs (i,j) where one judge puts them in the same cluster
                 and the other does not.
  agreement    : pairs both judges agree on, restricted to pairs touching the modal
                 or runner-up cluster; split into
                   cross  = modal vs runner-up, both judges say "different"
                   within = both in modal,      both judges say "same"
  Pairs whose two answer strings differ only by case / punctuation / whitespace are
  AUTO-RESOLVED as "agree" and never shown to a human.

QUOTAS (defaults, all overridable)
  disagreement 150   HLE 60% / SimpleQA 25% / PopQA 15%, prefer Δ̂q < 0.2,
                     max 3 pairs per question
  agreement    100   ≥60 modal-vs-runner-up cross-cluster, ≥40 modal within-cluster
  grading      150 modal-answer grades + 50 non-modal grades

SHEETS
  pairs   : 250 items, annotator A = items 1–170, B = 81–250 (90 overlap)
  grading : 200 items, annotator A = items 1–130, B = 71–200 (60 overlap)
  Columns carry NO judge decision and NO pool origin; rows are globally shuffled;
  answer_X / answer_Y order is randomised per item. A separate mapping file (kept
  out of the annotator folder) holds every hidden field.

Outputs
  audit/sheets/pairs_A.xlsx  pairs_B.xlsx  grading_A.xlsx  grading_B.xlsx (+ .csv)
  audit/mapping/pairs_mapping.json  grading_mapping.json      <-- DO NOT SHARE
"""
import os, json, re, csv, string, argparse
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)

CELLS = {                       # phase -> (gpt clustered, gemini clustered suffix, label)
    "phase1": ("phase1/clustering/{p}_simpleqa_clustered.jsonl", "SimpleQA"),
    "phase2": ("phase2/clustering/{p}_simpleqa_clustered.jsonl", "HLE"),
    "phase4": ("phase4/clustering/{p}_popqa_clustered.jsonl", "PopQA"),
}
GEM = "cross_judge/clustering/{phase}_{p}_gemini31pro_clustered.jsonl"
PROVIDERS = ["openai", "anthropic", "gemini", "xai", "mistral"]

TAG_LEGEND = [
    ("C", "Clear — unambiguously expresses one specific answer"),
    ("H", "Hedged — expresses uncertainty or offers several candidate answers"),
    ("E", "Extraction error — the shown text misrepresents the model's actual answer"),
    ("N", "Non-answer — 'I don't know', empty, or off-topic"),
    ("R", "Refusal — the model declines to answer"),
]
PUNCT = str.maketrans("", "", string.punctuation)


def norm_trivial(s):
    """case / punctuation / whitespace normalisation used for auto-resolution."""
    return re.sub(r"\s+", " ", (s or "").lower().translate(PUNCT)).strip()


def load_joined():
    """yield dicts per question that exist under BOTH judges with equal n."""
    for phase, (cpat, bench) in CELLS.items():
        for prov in PROVIDERS:
            gp = os.path.join(ROOT, cpat.format(p=prov))
            gg = os.path.join(ROOT, GEM.format(phase=phase, p=prov))
            if not (os.path.exists(gp) and os.path.exists(gg)):
                continue
            gem = {}
            with open(gg) as f:
                for line in f:
                    r = json.loads(line)
                    gem.setdefault(r["id"], r["cluster_assignments"])
            with open(gp) as f:
                for line in f:
                    r = json.loads(line)
                    ga = gem.get(r["id"])
                    if ga is None or len(ga) != len(r["cluster_assignments"]):
                        continue
                    yield {"bench": bench, "provider": prov, "qid": r["id"],
                           "question": r["question"], "gold": r["gold_answer"],
                           "answers": r["answer_extracted"],
                           "gpt": np.asarray(r["cluster_assignments"]),
                           "gem": np.asarray(ga),
                           "sizes": r["cluster_sizes"],
                           "labels": r["cluster_labels"],
                           "modal": r["modal_cluster"]}


def collect_candidates(rng, max_per_q=3):
    dis, agr_cross, agr_within = [], [], []
    n_auto = 0
    for q in load_joined():
        a, b = q["gpt"], q["gem"]
        n = len(a)
        same_a = a[:, None] == a[None, :]
        same_b = b[:, None] == b[None, :]
        iu = np.triu_indices(n, 1)
        dis_mask = same_a[iu] != same_b[iu]
        srt = np.argsort(q["sizes"])[::-1]
        modal = int(srt[0]); runner = int(srt[1]) if len(srt) > 1 else None
        tot = sum(q["sizes"])
        delta = (q["sizes"][modal] - (q["sizes"][runner] if runner is not None else 0)) / tot
        base = dict(bench=q["bench"], provider=q["provider"], qid=q["qid"],
                    question=q["question"], delta=float(delta))

        def add(pool, idxs, kind, cap):
            nonlocal n_auto
            out = []
            for i, j in idxs:
                ai, aj = q["answers"][i], q["answers"][j]
                if norm_trivial(ai) == norm_trivial(aj):
                    n_auto += 1
                    continue
                out.append({**base, "i": int(i), "j": int(j), "ans_i": ai, "ans_j": aj,
                            "gpt_same": bool(a[i] == a[j]), "gem_same": bool(b[i] == b[j]),
                            "pool": kind})
            if len(out) > cap:
                out = [out[k] for k in rng.choice(len(out), cap, replace=False)]
            pool.extend(out)

        # disagreement
        di, dj = iu[0][dis_mask], iu[1][dis_mask]
        if len(di):
            add(dis, list(zip(di, dj)), "disagreement", max_per_q)
        # agreement, modal vs runner-up, both judges say different
        if runner is not None:
            mi = np.where(a == modal)[0]
            ri = np.where(a == runner)[0]
            cand = [(i, j) for i in mi for j in ri
                    if (a[i] != a[j]) and (b[i] != b[j])]
            if cand:
                sel = [cand[k] for k in rng.choice(len(cand), min(len(cand), max_per_q),
                                                   replace=False)]
                add(agr_cross, sel, "agree_cross", max_per_q)
        # agreement, both inside modal, both judges say same
        mi = np.where(a == modal)[0]
        if len(mi) >= 2:
            cand = [(int(mi[x]), int(mi[y])) for x in range(len(mi)) for y in range(x + 1, len(mi))
                    if b[mi[x]] == b[mi[y]]]
            if cand:
                sel = [cand[k] for k in rng.choice(len(cand), min(len(cand), max_per_q),
                                                   replace=False)]
                add(agr_within, sel, "agree_within", max_per_q)
    return dis, agr_cross, agr_within, n_auto


def quota_sample(pool, n_want, rng, prefer=None):
    """sample n_want, drawing preferentially from `prefer`-satisfying items first."""
    if n_want <= 0 or not pool:
        return []
    idx = np.arange(len(pool))
    if prefer is not None:
        pri = np.array([bool(prefer(p)) for p in pool])
        first, rest = idx[pri], idx[~pri]
        rng.shuffle(first); rng.shuffle(rest)
        order = np.concatenate([first, rest])
    else:
        order = idx.copy(); rng.shuffle(order)
    return [pool[k] for k in order[:n_want]]


# ── xlsx / csv writers ──────────────────────────────────────────────
def write_sheet(path_xlsx, path_csv, header, rows, validations, title, instructions):
    import xlsxwriter
    with open(path_csv, "w", newline="") as f:
        w = csv.writer(f); w.writerow(header); w.writerows(rows)
    wb = xlsxwriter.Workbook(path_xlsx)
    fmt_h = wb.add_format({"bold": True, "bg_color": "#DCE6F1", "border": 1, "text_wrap": True,
                           "valign": "top"})
    fmt_t = wb.add_format({"text_wrap": True, "valign": "top", "border": 1})
    fmt_in = wb.add_format({"bg_color": "#FFF2CC", "border": 1, "valign": "top"})

    ws0 = wb.add_worksheet("instructions")
    ws0.set_column(0, 0, 110)
    for i, line in enumerate(instructions):
        ws0.write(i, 0, line, wb.add_format({"text_wrap": True, "valign": "top",
                                             "bold": line.endswith(":")}))
    ws = wb.add_worksheet(title)
    ws.freeze_panes(1, 0)
    widths = {"question": 60, "answer_X": 34, "answer_Y": 34,
              "gold_answer": 26, "predicted_answer": 30, "item_id": 12}
    for c, h in enumerate(header):
        ws.write(0, c, h, fmt_h)
        ws.set_column(c, c, widths.get(h, 12))
    for r, row in enumerate(rows, start=1):
        for c, v in enumerate(row):
            ws.write(r, c, v, fmt_in if header[c] in validations else fmt_t)
    for col, opts in validations.items():
        c = header.index(col)
        ws.data_validation(1, c, len(rows), c,
                           {"validate": "list", "source": opts,
                            "input_message": f"Allowed: {', '.join(opts)}"})
    wb.close()


def instructions_pairs():
    L = ["ANNOTATION TASK — do two model answers mean the same thing?", "",
         "For each row you see one QUESTION and two candidate ANSWERS (answer_X, answer_Y),",
         "both produced by a language model for that question.", "",
         "same_answer:",
         "  1 = the two answers express the SAME underlying answer to the question",
         "  0 = they express DIFFERENT answers",
         "  U = genuinely undecidable (please use sparingly, and say why in a note)", "",
         "Ignore surface differences: capitalisation, punctuation, articles, name order,",
         "trailing dates or qualifiers, and equivalent units (\"1.5 mM\" = \"0.0015 M\").",
         "Different specific answers stay different even if related (\"Paris\" vs \"France\").", "",
         "tag_X / tag_Y — describe each answer individually:"]
    L += [f"  {k} = {v}" for k, v in TAG_LEGEND]
    L += ["", "Please fill every yellow cell. Do not reorder or delete rows.",
          "You are not told what any automatic system decided — judge independently."]
    return L


def instructions_grading():
    L = ["ANNOTATION TASK — is the predicted answer correct?", "",
         "You see a QUESTION, the official GOLD ANSWER, and a model's PREDICTED ANSWER.", "",
         "correct:",
         "  1 = the predicted answer is semantically equivalent to the gold answer",
         "  0 = it is not",
         "  U = genuinely undecidable (use sparingly)", "",
         "Accept different surface forms of the same answer (\"Leo Tolstoy\" = \"Tolstoy\";",
         "\"1869\" = \"1869 AD\"; \"Paris, France\" = \"Paris\").", "",
         "tag — describe the predicted answer:"]
    L += [f"  {k} = {v}" for k, v in TAG_LEGEND]
    L += ["", "Please fill every yellow cell. Do not reorder or delete rows.",
          "You are not told what any automatic system decided — judge independently."]
    return L


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--n-dis", type=int, default=150)
    ap.add_argument("--n-agree-cross", type=int, default=60)
    ap.add_argument("--n-agree-within", type=int, default=40)
    ap.add_argument("--n-grade-modal", type=int, default=150)
    ap.add_argument("--n-grade-nonmodal", type=int, default=50)
    ap.add_argument("--max-per-q", type=int, default=3)
    args = ap.parse_args()

    rng = np.random.default_rng(args.seed)
    sheets = os.path.join(BASE, "sheets"); mapd = os.path.join(BASE, "mapping")
    os.makedirs(sheets, exist_ok=True); os.makedirs(mapd, exist_ok=True)

    print("scanning both judges' partitions ...", flush=True)
    dis, agr_cross, agr_within, n_auto = collect_candidates(rng, args.max_per_q)
    print(f"  candidates: disagreement {len(dis)}, agree-cross {len(agr_cross)}, "
          f"agree-within {len(agr_within)}; auto-resolved trivial pairs {n_auto}")

    # disagreement quota by benchmark, preferring low margin
    share = {"HLE": 0.60, "SimpleQA": 0.25, "PopQA": 0.15}
    want = {b: int(round(args.n_dis * s)) for b, s in share.items()}
    want["HLE"] += args.n_dis - sum(want.values())
    picked = []
    for b, k in want.items():
        sub = [p for p in dis if p["bench"] == b]
        got = quota_sample(sub, k, rng, prefer=lambda p: p["delta"] < 0.2)
        picked += got
        print(f"  disagreement {b}: want {k}, pool {len(sub)}, got {len(got)} "
              f"({sum(1 for g in got if g['delta'] < 0.2)} with Δ̂<0.2)")
    picked += quota_sample(agr_cross, args.n_agree_cross, rng)
    picked += quota_sample(agr_within, args.n_agree_within, rng)
    print(f"  total pair items: {len(picked)}")

    # item ids, random X/Y order, global shuffle
    alphabet = np.array(list(string.ascii_uppercase + string.digits))
    used = set()
    def new_id():
        while True:
            s = "".join(rng.choice(alphabet, 6))
            if s not in used:
                used.add(s); return s

    rng.shuffle(picked)
    pair_rows, pair_map = [], {}
    for pos, p in enumerate(picked, start=1):
        iid = new_id()
        swap = bool(rng.integers(2))
        aX, aY = (p["ans_j"], p["ans_i"]) if swap else (p["ans_i"], p["ans_j"])
        pair_rows.append([iid, p["question"], aX, aY, "", "", ""])
        pair_map[iid] = {**{k: p[k] for k in ("bench", "provider", "qid", "i", "j",
                                              "delta", "pool", "gpt_same", "gem_same")},
                         "position": pos, "swapped": swap, "answer_X": aX, "answer_Y": aY}

    hdr = ["item_id", "question", "answer_X", "answer_Y", "same_answer", "tag_X", "tag_Y"]
    val = {"same_answer": ["1", "0", "U"],
           "tag_X": [k for k, _ in TAG_LEGEND], "tag_Y": [k for k, _ in TAG_LEGEND]}
    for who, lo, hi in (("A", 1, 170), ("B", 81, 250)):
        rows = pair_rows[lo - 1:hi]
        write_sheet(os.path.join(sheets, f"pairs_{who}.xlsx"),
                    os.path.join(sheets, f"pairs_{who}.csv"),
                    hdr, rows, val, "pairs", instructions_pairs())
        print(f"  pairs_{who}: items {lo}-{hi} ({len(rows)} rows)")

    # ---- grading sheet
    qs = []
    for q in load_joined():
        qs.append(q)
    rng.shuffle(qs)
    grade_rows, grade_map = [], {}
    modal_q = qs[:args.n_grade_modal]
    nonmodal_q = qs[args.n_grade_modal:args.n_grade_modal + args.n_grade_nonmodal * 3]
    items = []
    for q in modal_q:
        items.append((q, int(q["modal"]), "modal"))
    added = 0
    for q in nonmodal_q:
        if added >= args.n_grade_nonmodal:
            break
        others = [k for k in range(len(q["sizes"])) if k != q["modal"]]
        if not others:
            continue
        items.append((q, int(rng.choice(others)), "nonmodal")); added += 1
    rng.shuffle(items)
    for pos, (q, k, kind) in enumerate(items, start=1):
        iid = new_id()
        grade_rows.append([iid, q["question"], q["gold"], q["labels"][k], "", ""])
        grade_map[iid] = {"bench": q["bench"], "provider": q["provider"], "qid": q["qid"],
                          "cluster": k, "kind": kind, "position": pos,
                          "predicted": q["labels"][k], "gold": q["gold"]}
    hdr_g = ["item_id", "question", "gold_answer", "predicted_answer", "correct", "tag"]
    val_g = {"correct": ["1", "0", "U"], "tag": [k for k, _ in TAG_LEGEND]}
    for who, lo, hi in (("A", 1, 130), ("B", 71, 200)):
        rows = grade_rows[lo - 1:hi]
        write_sheet(os.path.join(sheets, f"grading_{who}.xlsx"),
                    os.path.join(sheets, f"grading_{who}.csv"),
                    hdr_g, rows, val_g, "grading", instructions_grading())
        print(f"  grading_{who}: items {lo}-{hi} ({len(rows)} rows)")

    json.dump({"pairs": pair_map, "n_auto_resolved": n_auto,
               "quotas": vars(args)}, open(os.path.join(mapd, "pairs_mapping.json"), "w"), indent=1)
    json.dump({"grading": grade_map},
              open(os.path.join(mapd, "grading_mapping.json"), "w"), indent=1)
    print(f"\nsheets  -> {sheets}   (give these to the annotators)")
    print(f"mapping -> {mapd}   *** DO NOT SHARE WITH ANNOTATORS ***")


if __name__ == "__main__":
    main()
