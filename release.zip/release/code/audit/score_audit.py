"""Phase 3 / R2 — scoring for the human audit sheets.

Reads the filled annotator sheets (.xlsx or .csv) plus the hidden mapping and reports

  1. human–human agreement and Cohen's κ on the overlap block
  2. judge–human agreement and κ by stratum (pool × benchmark)
  3. arbitration split on the disagreement stratum: does the human side with the
     reference judge (gpt-5.2) or with gemini-3.1-pro?
  4. total clustering error rate
         ρ̂ = P(disagree)·P(wrong | disagree) + P(agree)·P(both wrong | agree)
     with **question-clustered** bootstrap CIs (questions are resampled, never pairs).
     P(disagree) is the exact population pair-disagreement rate between the two
     judges, computed from all 39,629 questions (1 − pair-weighted Rand index).
  5. ambiguity tag rates (H/E/N) per benchmark
  6. worst-case reassignment: for every question containing an H/E/N-tagged answer,
     push all ambiguous answers INTO the modal cluster, and alternatively OUT of it,
     and report the share of questions where the deployed answer ẑ flips and where
     ĉ₁ crosses one of the L=10 ECE bin boundaries.

Usage
  python score_audit.py --sheets audit/sheets_filled --mapping audit/mapping
"""
import os, re, csv, json, zipfile, argparse
import xml.etree.ElementTree as ET
from collections import defaultdict
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
AMBIG = {"H", "E", "N"}

CELLS = {"phase1": ("phase1/clustering/{p}_simpleqa_clustered.jsonl", "SimpleQA"),
         "phase2": ("phase2/clustering/{p}_simpleqa_clustered.jsonl", "HLE"),
         "phase4": ("phase4/clustering/{p}_popqa_clustered.jsonl", "PopQA")}
GEM = "cross_judge/clustering/{phase}_{p}_gemini31pro_clustered.jsonl"
PROVIDERS = ["openai", "anthropic", "gemini", "xai", "mistral"]


# ── minimal xlsx / csv reader ───────────────────────────────────────
def _col(ref):
    m = re.match(r"([A-Z]+)", ref)
    c = 0
    for ch in m.group(1):
        c = c * 26 + (ord(ch) - 64)
    return c - 1


def read_xlsx(path, want=("pairs", "grading")):
    z = zipfile.ZipFile(path)
    shared = []
    if "xl/sharedStrings.xml" in z.namelist():
        for si in ET.fromstring(z.read("xl/sharedStrings.xml")):
            shared.append("".join(t.text or "" for t in si.iter(f"{NS}t")))
    wb = ET.fromstring(z.read("xl/workbook.xml"))
    rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
    rid2tgt = {r.get("Id"): r.get("Target") for r in rels}
    target = None
    for sh in wb.iter(f"{NS}sheet"):
        rid = sh.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id")
        if sh.get("name") in want:
            target = rid2tgt[rid]
    if target is None:
        target = "worksheets/sheet1.xml"
    name = target if target.startswith("xl/") else "xl/" + target.lstrip("/")
    rows = []
    for row in ET.fromstring(z.read(name)).iter(f"{NS}row"):
        cur = {}
        for c in row.iter(f"{NS}c"):
            v = c.find(f"{NS}v")
            isx = c.find(f"{NS}is")
            if c.get("t") == "s" and v is not None:
                val = shared[int(v.text)]
            elif isx is not None:
                val = "".join(t.text or "" for t in isx.iter(f"{NS}t"))
            else:
                val = v.text if v is not None else ""
            cur[_col(c.get("r"))] = (val or "").strip()
        if cur:
            rows.append([cur.get(i, "") for i in range(max(cur) + 1)])
    return rows


def read_sheet(path):
    if path.lower().endswith(".csv"):
        with open(path, newline="") as f:
            rows = list(csv.reader(f))
    else:
        rows = read_xlsx(path)
    hdr = rows[0]
    return [dict(zip(hdr, r + [""] * (len(hdr) - len(r)))) for r in rows[1:] if any(r)]


# ── stats helpers ───────────────────────────────────────────────────
def kappa(a, b):
    a, b = list(a), list(b)
    cats = sorted(set(a) | set(b))
    if len(a) == 0 or len(cats) < 2:
        return float("nan")
    idx = {c: i for i, c in enumerate(cats)}
    M = np.zeros((len(cats), len(cats)))
    for x, y in zip(a, b):
        M[idx[x], idx[y]] += 1
    M /= M.sum()
    po = np.trace(M)
    pe = float((M.sum(0) * M.sum(1)).sum())
    return float((po - pe) / (1 - pe)) if pe < 1 else float("nan")


def population_disagreement():
    """exact pair-level judge disagreement rate over all jointly-judged questions."""
    tot_pairs = tot_dis = 0
    for phase, (cpat, bench) in CELLS.items():
        for prov in PROVIDERS:
            gp = os.path.join(ROOT, cpat.format(p=prov))
            gg = os.path.join(ROOT, GEM.format(phase=phase, p=prov))
            if not (os.path.exists(gp) and os.path.exists(gg)):
                continue
            gem = {}
            with open(gg) as f:
                for line in f:
                    r = json.loads(line)
                    gem.setdefault(r["id"], r["cluster_assignments"])
            with open(gp) as f:
                for line in f:
                    r = json.loads(line)
                    b = gem.get(r["id"])
                    a = r["cluster_assignments"]
                    if b is None or len(a) != len(b):
                        continue
                    a = np.asarray(a); b = np.asarray(b); n = len(a)
                    iu = np.triu_indices(n, 1)
                    sa = (a[:, None] == a[None, :])[iu]
                    sb = (b[:, None] == b[None, :])[iu]
                    tot_pairs += len(sa); tot_dis += int((sa != sb).sum())
    return (tot_dis / tot_pairs) if tot_pairs else float("nan"), tot_pairs


def q_boot(groups, fn, B=1000, seed=0):
    """question-clustered bootstrap: groups = {qid: [items]}."""
    keys = list(groups)
    if not keys:
        return float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(B):
        pick = rng.choice(len(keys), len(keys), replace=True)
        items = [it for k in pick for it in groups[keys[k]]]
        vals.append(fn(items))
    v = np.asarray(vals, float)
    return float(np.nanpercentile(v, 2.5)), float(np.nanpercentile(v, 97.5))


# ── main ────────────────────────────────────────────────────────────
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sheets", default=os.path.join(BASE, "sheets_filled"))
    ap.add_argument("--mapping", default=os.path.join(BASE, "mapping"))
    ap.add_argument("--out", default=os.path.join(BASE, "RESULTS_audit.md"))
    ap.add_argument("--boot", type=int, default=1000)
    args = ap.parse_args()

    pm = json.load(open(os.path.join(args.mapping, "pairs_mapping.json")))["pairs"]
    gm = json.load(open(os.path.join(args.mapping, "grading_mapping.json")))["grading"]

    def load(prefix):
        out = {}
        for who in ("A", "B"):
            for ext in ("xlsx", "csv"):
                p = os.path.join(args.sheets, f"{prefix}_{who}.{ext}")
                if os.path.exists(p):
                    out[who] = {r["item_id"]: r for r in read_sheet(p) if r.get("item_id")}
                    break
        return out
    P, G = load("pairs"), load("grading")
    if not P:
        print("no filled pair sheets found in", args.sheets); return
    L = ["# R2 human audit — results\n",
         f"Reference judge **gpt-5.2** (the paper's actual clustering judge) vs "
         f"**gemini-3.1-pro-preview**. Annotators A/B, overlap block by construction.\n"]

    # ---- 1. human-human on overlap
    L += ["## 1. Human–human agreement on the overlap block\n",
          "| sheet | overlap items both filled | agreement | κ (0/1, U dropped) | κ (0/1/U) |",
          "|---|---:|---:|---:|---:|"]
    for tag, S, col in (("pairs", P, "same_answer"), ("grading", G, "correct")):
        if len(S) < 2:
            continue
        both = sorted(set(S.get("A", {})) & set(S.get("B", {})))
        a = [S["A"][i].get(col, "").strip().upper() for i in both]
        b = [S["B"][i].get(col, "").strip().upper() for i in both]
        pair01 = [(x, y) for x, y in zip(a, b) if x in ("0", "1") and y in ("0", "1")]
        agr = np.mean([x == y for x, y in pair01]) if pair01 else float("nan")
        k01 = kappa([x for x, _ in pair01], [y for _, y in pair01])
        kall = kappa(a, b)
        L.append(f"| {tag} | {len(pair01)} / {len(both)} | {agr:.3f} | {k01:.3f} | {kall:.3f} |")

    # ---- merge annotators (A wins on overlap; B fills the rest)
    merged = {}
    for who in ("B", "A"):
        for iid, r in P.get(who, {}).items():
            merged[iid] = r
    items = []
    for iid, r in merged.items():
        m = pm.get(iid)
        if not m:
            continue
        h = r.get("same_answer", "").strip().upper()
        if h not in ("0", "1", "U"):
            continue
        items.append({**m, "human": h, "tag_X": r.get("tag_X", "").strip().upper(),
                      "tag_Y": r.get("tag_Y", "").strip().upper(), "item_id": iid})
    L.append(f"\nUsable annotated pair items: **{len(items)}** "
             f"({sum(1 for i in items if i['human']=='U')} marked U).\n")

    # ---- 2. judge-human by stratum
    L += ["## 2. Judge–human agreement by stratum\n",
          "| stratum | benchmark | n | gpt-5.2 agrees | κ | gemini agrees | κ |",
          "|---|---|---:|---:|---:|---:|---:|"]
    def blk(sel):
        s = [i for i in sel if i["human"] in ("0", "1")]
        if not s:
            return None
        hs = [i["human"] == "1" for i in s]
        gs = [bool(i["gpt_same"]) for i in s]
        ms = [bool(i["gem_same"]) for i in s]
        return (len(s), np.mean([h == g for h, g in zip(hs, gs)]),
                kappa([str(int(h)) for h in hs], [str(int(g)) for g in gs]),
                np.mean([h == m for h, m in zip(hs, ms)]),
                kappa([str(int(h)) for h in hs], [str(int(m)) for m in ms]))
    for pool in ("disagreement", "agree_cross", "agree_within"):
        for bench in ("SimpleQA", "HLE", "PopQA", "ALL"):
            sel = [i for i in items if i["pool"] == pool
                   and (bench == "ALL" or i["bench"] == bench)]
            r = blk(sel)
            if r:
                L.append(f"| {pool} | {bench} | {r[0]} | {r[1]:.3f} | {r[2]:.3f} | "
                         f"{r[3]:.3f} | {r[4]:.3f} |")

    # ---- 3. arbitration on disagreements
    dis = [i for i in items if i["pool"] == "disagreement" and i["human"] in ("0", "1")]
    L += ["\n## 3. Arbitration on the disagreement stratum\n"]
    if dis:
        side_gpt = sum(1 for i in dis if (i["human"] == "1") == bool(i["gpt_same"]))
        side_gem = sum(1 for i in dis if (i["human"] == "1") == bool(i["gem_same"]))
        grp = defaultdict(list)
        for i in dis:
            grp[i["qid"]].append(i)
        lo, hi = q_boot(grp, lambda its: np.mean([(x["human"] == "1") == bool(x["gpt_same"])
                                                  for x in its]) if its else np.nan,
                        B=args.boot)
        L += [f"- human sides with **gpt-5.2** on **{side_gpt}/{len(dis)}** "
              f"= {side_gpt/len(dis):.3f} [{lo:.3f}, {hi:.3f}] (question-clustered bootstrap)",
              f"- human sides with **gemini** on {side_gem}/{len(dis)} = {side_gem/len(dis):.3f}",
              "\n(On this stratum the two judges disagree by construction, so the two rates "
              "sum to 1 up to items the human marked U.)"]
    else:
        L.append("_no usable disagreement items_")

    # ---- 4. total error rate
    p_dis, npairs = population_disagreement()
    agr_items = [i for i in items if i["pool"] != "disagreement" and i["human"] in ("0", "1")]
    L += ["\n## 4. Total clustering error rate ρ̂\n",
          f"Population pair-disagreement rate between the two judges: "
          f"**P(disagree) = {p_dis:.5f}** (exact, over {npairs:,} answer pairs).\n"]

    def wrong_given_dis(its):
        s = [x for x in its if x["human"] in ("0", "1")]
        return np.mean([(x["human"] == "1") != bool(x["gpt_same"]) for x in s]) if s else np.nan

    def both_wrong_given_agr(its):
        s = [x for x in its if x["human"] in ("0", "1")]
        return np.mean([(x["human"] == "1") != bool(x["gpt_same"]) for x in s]) if s else np.nan

    if dis and agr_items:
        pw_d = wrong_given_dis(dis)
        pw_a = both_wrong_given_agr(agr_items)
        rho = p_dis * pw_d + (1 - p_dis) * pw_a
        gd = defaultdict(list); ga = defaultdict(list)
        for i in dis:
            gd[i["qid"]].append(i)
        for i in agr_items:
            ga[i["qid"]].append(i)
        rng = np.random.default_rng(0)
        kd, ka = list(gd), list(ga)
        draws = []
        for _ in range(args.boot):
            d1 = [it for k in rng.choice(len(kd), len(kd), replace=True) for it in gd[kd[k]]]
            a1 = [it for k in rng.choice(len(ka), len(ka), replace=True) for it in ga[ka[k]]]
            draws.append(p_dis * wrong_given_dis(d1) + (1 - p_dis) * both_wrong_given_agr(a1))
        lo, hi = np.nanpercentile(draws, [2.5, 97.5])
        # Clopper-Pearson bounds per stratum. These matter because a stratum with ZERO
        # observed errors bootstraps to an identically-zero term, which understates the
        # uncertainty badly when that stratum carries ~98% of the population weight.
        def cp(k, n, a=0.05):
            from scipy.stats import beta
            return (float(beta.ppf(a / 2, k, n - k + 1)) if k > 0 else 0.0,
                    float(beta.ppf(1 - a / 2, k + 1, n - k)) if k < n else 1.0)
        kd = sum(1 for x in dis if (x["human"] == "1") != bool(x["gpt_same"]))
        ka = sum(1 for x in agr_items if (x["human"] == "1") != bool(x["gpt_same"]))
        cd, ca = cp(kd, len(dis)), cp(ka, len(agr_items))
        rho_hi = p_dis * cd[1] + (1 - p_dis) * ca[1]
        rho_lo = p_dis * cd[0] + (1 - p_dis) * ca[0]
        L += ["| term | point | 95% Clopper–Pearson | weight in ρ̂ |", "|---|---:|---|---:|",
              f"| P(wrong \\| disagree) | {pw_d:.4f} | [{cd[0]:.4f}, {cd[1]:.4f}] (n={len(dis)}) "
              f"| {p_dis:.5f} |",
              f"| P(both wrong \\| agree) | {pw_a:.4f} | [{ca[0]:.4f}, {ca[1]:.4f}] (n={len(agr_items)}) "
              f"| {1-p_dis:.5f} |",
              f"| **ρ̂ (total pair error rate)** | **{rho:.5f}** | **[{rho_lo:.5f}, {rho_hi:.5f}]** | |",
              "",
              f"Question-clustered bootstrap on the same quantity gives [{lo:.5f}, {hi:.5f}], but that "
              "interval is **not trustworthy here**: the agreement stratum contributed "
              f"{ka}/{len(agr_items)} errors, and resampling an all-zero stratum returns zero every "
              "time. The Clopper–Pearson interval above is the one to quote — and note that its "
              f"upper end is dominated by the agreement term ({(1-p_dis)*ca[1]:.4f} of "
              f"{rho_hi:.4f}), not by the disagreement term ({p_dis*cd[1]:.4f}).",
              "",
              "**Design note:** because P(agree) ≈ 0.985, ρ̂ is dominated by the agreement stratum's "
              "conditional error rate, so a quota that spends 150 items on disagreements and only "
              "100 on agreements is allocated backwards for estimating ρ̂. The disagreement term is "
              "already pinned down; tightening ρ̂ requires many more *agreement* items.",
              "\n*P(disagree) is treated as known (estimated from 39,629 questions, so its own "
              "uncertainty is negligible next to the annotated terms).*",
              "\n**Note on the agreement stratum:** it is deliberately over-sampled on pairs "
              "touching the modal / runner-up cluster, so P(both wrong | agree) here is an "
              "upper bound for a uniformly random agreeing pair; ρ̂ is therefore conservative."]
    else:
        L.append("_need both strata filled to compute ρ̂_")

    # ---- 4b. grading judge vs annotator (modal items only — the paper only graded modal answers)
    if G:
        gmerged = {}
        for who in ("B", "A"):
            for iid, r in G.get(who, {}).items():
                gmerged[iid] = r
        orig = {}
        for phase, (cpat, bench) in CELLS.items():
            gdir = os.path.join(ROOT, phase, "grading")
            if not os.path.isdir(gdir):
                continue
            for fn in os.listdir(gdir):
                if not fn.endswith("_graded.jsonl"):
                    continue
                prov = fn.split("_")[0]
                with open(os.path.join(gdir, fn)) as f:
                    for line in f:
                        r = json.loads(line)
                        orig.setdefault((bench, prov, r["id"]), r["Y"])
        rows = []
        for iid, r in gmerged.items():
            m = gm.get(iid)
            h = r.get("correct", "").strip().upper()
            if not m or h not in ("0", "1"):
                continue
            if m["kind"] != "modal":
                continue
            y = orig.get((m["bench"], m["provider"], m["qid"]))
            if y is None:
                continue
            rows.append({"bench": m["bench"], "qid": m["qid"],
                         "human": int(h == "1"), "judge": int(y)})
        L += ["\n## 4b. Grading judge (gpt-5.2) vs annotator, modal answers only\n",
              "| benchmark | n | judge agrees | κ | judge says correct | annotator says correct |",
              "|---|---:|---:|---:|---:|---:|"]
        for bench in ("SimpleQA", "HLE", "PopQA", "ALL"):
            s = [r for r in rows if bench == "ALL" or r["bench"] == bench]
            if not s:
                continue
            ag = np.mean([r["human"] == r["judge"] for r in s])
            kp = kappa([str(r["human"]) for r in s], [str(r["judge"]) for r in s])
            L.append(f"| {bench} | {len(s)} | {ag:.3f} | {kp:.3f} | "
                     f"{np.mean([r['judge'] for r in s]):.3f} | "
                     f"{np.mean([r['human'] for r in s]):.3f} |")
        if rows:
            grp = defaultdict(list)
            for r in rows:
                grp[r["qid"]].append(r)
            lo, hi = q_boot(grp, lambda its: np.mean([x["human"] == x["judge"] for x in its])
                            if its else np.nan, B=args.boot)
            L.append(f"\nOverall judge–annotator agreement on modal grades: "
                     f"**{np.mean([r['human'] == r['judge'] for r in rows]):.3f}** "
                     f"[{lo:.3f}, {hi:.3f}] (question-clustered bootstrap).")

    # ---- 5. ambiguity tag rates
    L += ["\n## 5. Ambiguity tag rates (share of annotated answers tagged H / E / N)\n",
          "| benchmark | answers tagged | H | E | N | any ambiguous | C | R |",
          "|---|---:|---:|---:|---:|---:|---:|---:|"]
    for bench in ("SimpleQA", "HLE", "PopQA", "ALL"):
        tags = []
        for i in items:
            if bench != "ALL" and i["bench"] != bench:
                continue
            tags += [t for t in (i["tag_X"], i["tag_Y"]) if t]
        if not tags:
            continue
        n = len(tags)
        f = lambda t: sum(1 for x in tags if x == t) / n
        L.append(f"| {bench} | {n} | {f('H'):.3f} | {f('E'):.3f} | {f('N'):.3f} | "
                 f"{sum(1 for x in tags if x in AMBIG)/n:.3f} | {f('C'):.3f} | {f('R'):.3f} |")

    # ---- 6. worst-case reassignment
    L += ["\n## 6. Worst-case reassignment of ambiguous answers\n",
          "For every question containing at least one answer tagged H/E/N, we push **all** its "
          "ambiguous answers *into* the modal cluster, and alternatively *out of* it (each into "
          "its own singleton), and recompute the deployed answer ẑ and ĉ₁.\n"]
    amb = defaultdict(set)                       # (bench,provider,qid) -> {answer indices}
    for i in items:
        key = (i["bench"], i["provider"], i["qid"])
        if i["tag_X"] in AMBIG:
            amb[key].add(i["j"] if i["swapped"] else i["i"])
        if i["tag_Y"] in AMBIG:
            amb[key].add(i["i"] if i["swapped"] else i["j"])
    amb = {k: v for k, v in amb.items() if v}
    if amb:
        want = {(k[1], k[2]) for k in amb}
        clus = {}
        for phase, (cpat, bench) in CELLS.items():
            for prov in PROVIDERS:
                gp = os.path.join(ROOT, cpat.format(p=prov))
                if not os.path.exists(gp):
                    continue
                with open(gp) as f:
                    for line in f:
                        r = json.loads(line)
                        if (prov, r["id"]) in want:
                            clus[(bench, prov, r["id"])] = r
        flips = {"to_modal": 0, "out_modal": 0}
        binx = {"to_modal": 0, "out_modal": 0}
        tot = 0
        for key, idxs in amb.items():
            r = clus.get(key)
            if not r:
                continue
            tot += 1
            a0 = np.asarray(r["cluster_assignments"]); n = len(a0)
            m0 = int(np.bincount(a0).argmax())
            c0 = np.bincount(a0).max() / n
            for mode in ("to_modal", "out_modal"):
                a = a0.copy()
                if mode == "to_modal":
                    for i in idxs:
                        if i < n:
                            a[i] = m0
                else:
                    nxt = a.max() + 1
                    for i in idxs:
                        if i < n:
                            a[i] = nxt; nxt += 1
                cnt = np.bincount(a)
                m1 = int(cnt.argmax()); c1 = cnt.max() / n
                if m1 != m0:
                    flips[mode] += 1
                if min(int(c0 * 10), 9) != min(int(c1 * 10), 9):
                    binx[mode] += 1
        L += ["| reassignment | questions | ẑ flips | ĉ₁ crosses an L=10 bin edge |",
              "|---|---:|---:|---:|"]
        for mode in ("to_modal", "out_modal"):
            L.append(f"| all ambiguous → modal |" if mode == "to_modal" else
                     f"| all ambiguous → out of modal |")
            L[-1] += f" {tot} | {flips[mode]} ({flips[mode]/max(tot,1):.3f}) |" \
                     f" {binx[mode]} ({binx[mode]/max(tot,1):.3f}) |"
        L.append("\n*This brackets the worst case: the true partition lies between the two rows.*")
    else:
        L.append("_no answers tagged H/E/N yet_")

    with open(args.out, "w") as f:
        f.write("\n".join(L) + "\n")
    print("\n".join(L))
    print("\nwrote", args.out)


if __name__ == "__main__":
    main()
