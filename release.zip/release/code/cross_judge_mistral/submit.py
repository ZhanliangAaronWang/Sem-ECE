"""Upload chunks and create Mistral batch jobs (mistral-large-latest = Large 3)."""
import os, json, glob, time
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))

from mistralai.client import Mistral

MODEL = "mistral-large-latest"
STATE = os.path.join(BASE, "batch_outputs", "jobs.json")


def main():
    os.makedirs(os.path.join(BASE, "batch_outputs"), exist_ok=True)
    client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
    chunks = sorted(glob.glob(os.path.join(BASE, "batch_inputs", "chunk*.jsonl")))

    state = {"jobs": []}
    if os.path.exists(STATE):
        with open(STATE) as f:
            state = json.load(f)
    done_chunks = {j["chunk"] for j in state["jobs"]}

    for path in chunks:
        name = os.path.basename(path)
        if name in done_chunks:
            print(f"{name}: already submitted")
            continue
        for attempt in range(3):
            try:
                with open(path, "rb") as f:
                    fobj = client.files.upload(
                        file={"file_name": name, "content": f.read()},
                        purpose="batch", timeout_ms=600_000)
                job = client.batch.jobs.create(
                    model=MODEL, endpoint="/v1/chat/completions",
                    input_files=[fobj.id], timeout_hours=24)
                state["jobs"].append({"chunk": name, "file_id": fobj.id, "job_id": job.id,
                                      "submitted_at": time.strftime("%Y-%m-%d %H:%M:%S")})
                with open(STATE, "w") as f:
                    json.dump(state, f, indent=1)
                print(f"{name}: job {job.id}")
                break
            except Exception as e:
                print(f"{name}: attempt {attempt+1} failed — {str(e)[:150]}")
                time.sleep(30 * (attempt + 1))
        else:
            print(f"{name}: GIVING UP")

    print(f"\n{len(state['jobs'])} jobs recorded in {STATE}")


if __name__ == "__main__":
    main()
