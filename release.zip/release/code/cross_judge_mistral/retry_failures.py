"""Retry residual Mistral-judge parse failures with live calls (new random_seed)."""
import os, json, glob, argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))

from mistralai.client import Mistral

MODEL = "mistral-large-latest"
RAW_OUT = os.path.join(BASE, "batch_outputs", "raw.jsonl")
FAILED = os.path.join(BASE, "batch_outputs", "failed_cids.json")


def load_inputs(cids):
    want = set(cids)
    rows = {}
    for path in glob.glob(os.path.join(BASE, "batch_inputs", "chunk*.jsonl")):
        with open(path) as f:
            for line in f:
                r = json.loads(line)
                if r["custom_id"] in want:
                    rows[r["custom_id"]] = r
    return rows


def call_one(client, row, seed):
    body = dict(row["body"])
    body["random_seed"] = seed
    body["max_tokens"] = 8192
    try:
        resp = client.chat.complete(model=MODEL, **body)
        text = resp.choices[0].message.content
        # emit in the same shape as batch output rows so collect.parse_all reads it
        return {"custom_id": row["custom_id"],
                "response": {"status_code": 200,
                             "body": {"choices": [{"message": {"content": text}}]}},
                "retry_seed": seed}
    except Exception as e:
        return {"custom_id": row["custom_id"], "response": None,
                "error": f"{type(e).__name__}: {str(e)[:150]}", "retry_seed": seed}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--workers", type=int, default=6)
    args = ap.parse_args()

    with open(FAILED) as f:
        cids = json.load(f)
    print(f"retrying {len(cids)} failed custom_ids (seed={args.seed})")
    inputs = load_inputs(cids)
    client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])

    n_ok = n_err = 0
    with open(RAW_OUT, "a") as fout, ThreadPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(call_one, client, inputs[c], args.seed): c for c in cids if c in inputs}
        for i, fut in enumerate(as_completed(futs)):
            r = fut.result()
            fout.write(json.dumps(r, ensure_ascii=False) + "\n")
            fout.flush()
            if r.get("response"):
                n_ok += 1
            else:
                n_err += 1
                print(f"  ERROR {r['custom_id']}: {r.get('error','')[:100]}")
            if (i + 1) % 50 == 0:
                print(f"  {i+1}/{len(futs)} ({n_ok} ok)")
    print(f"done: {n_ok} ok, {n_err} errors")


if __name__ == "__main__":
    main()
