"""Convert cross_judge/batch_inputs (Gemini format) into Mistral batch chunks.

Same prompts byte-for-byte; Mistral chat-completions batch format:
  {"custom_id": ..., "body": {"messages": [...], "temperature": 0.0,
   "max_tokens": 4000, "response_format": {"type": "json_object"}, "random_seed": 0}}
Model is set at job-creation time (mistral-large-latest = Mistral Large 3).
"""
import os, json, glob

BASE = os.path.dirname(os.path.abspath(__file__))
SRC_DIR = os.path.join(os.path.dirname(BASE), "cross_judge", "batch_inputs")
OUT_DIR = os.path.join(BASE, "batch_inputs")
CHUNK_ROWS = 5000

def main():
    os.makedirs(OUT_DIR, exist_ok=True)
    rows = []
    for path in sorted(glob.glob(os.path.join(SRC_DIR, "*.jsonl"))):
        with open(path) as f:
            for line in f:
                r = json.loads(line)
                rows.append({
                    "custom_id": r["custom_id"],
                    "body": {
                        "messages": [
                            {"role": "system", "content": r["config"]["system_instruction"]},
                            {"role": "user", "content": r["contents"][0]["parts"][0]["text"]},
                        ],
                        "temperature": 0.0,
                        "max_tokens": 4000,
                        "response_format": {"type": "json_object"},
                        "random_seed": 0,
                    },
                })
    print(f"total rows: {len(rows)}")
    for ci in range(0, len(rows), CHUNK_ROWS):
        chunk = rows[ci:ci + CHUNK_ROWS]
        out = os.path.join(OUT_DIR, f"chunk{ci//CHUNK_ROWS:02d}.jsonl")
        with open(out, "w") as f:
            for r in chunk:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"  {out}: {len(chunk)} rows, {os.path.getsize(out)//(1<<20)}MB")

if __name__ == "__main__":
    main()
