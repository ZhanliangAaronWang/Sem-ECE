"""Live smoke test of mistral-large-latest (Large 3) as clustering judge."""
import os, json
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))

from mistralai.client import Mistral

MODEL = "mistral-large-latest"
SAMPLE_CIDS = [
    "phase1__openai__simpleqa_00000",
    "phase1__xai__simpleqa_00000",
    "phase2__gemini__",     # prefix match — first HLE gemini row
    "phase2__anthropic__",  # N=46
    "phase4__mistral__",
]


def get_rows():
    import glob
    got, want = [], list(SAMPLE_CIDS)
    for path in sorted(glob.glob(os.path.join(BASE, "batch_inputs", "chunk*.jsonl"))):
        with open(path) as f:
            for line in f:
                r = json.loads(line)
                for w in list(want):
                    if r["custom_id"] == w or (w.endswith("__") and r["custom_id"].startswith(w)):
                        got.append(r); want.remove(w)
                if not want:
                    return got
    return got


def validate(text, n):
    obj, _ = json.JSONDecoder().raw_decode(text.strip())
    seen = []
    for c in obj["clusters"]:
        seen += list(c["members"])
    return sorted(seen) == list(range(n)), len(obj["clusters"])


def main():
    client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
    tin = tout = 0
    for row in get_rows():
        n = row["body"]["messages"][1]["content"].count("\n[")
        resp = client.chat.complete(model=MODEL, **row["body"])
        text = resp.choices[0].message.content
        u = resp.usage
        tin += u.prompt_tokens; tout += u.completion_tokens
        print(f"[{row['custom_id']}] in={u.prompt_tokens} out={u.completion_tokens}", end="  ")
        try:
            ok, k = validate(text, n)
            print(f"parse=OK valid={ok} K={k} (n={n})")
        except Exception as e:
            print(f"parse=FAIL ({e}) head={text[:150]!r}")
    ncalls = 5
    N = 39629
    # Mistral Large 3 API pricing (verify): assume $2/$6 per M, batch 50% off
    for label, pi, po in [("$2/$6 (batch 1/3)", 1.0, 3.0), ("$0.5/$1.5 (batch .25/.75)", 0.25, 0.75)]:
        c = N*(tin/ncalls)/1e6*pi + N*(tout/ncalls)/1e6*po
        print(f"est cost @{label}: ${c:.0f}")


if __name__ == "__main__":
    main()
