"""Poll Mistral batch jobs, download outputs, parse into clustered jsonl.

Reuses the tolerant bracket-repair parser from cross_judge/collect.py.
Output: clustering/{phase}_{provider}_mistrallarge3_clustered.jsonl

Usage:
    python collect.py            # one pass (+parse if all terminal)
    python collect.py --loop     # poll until done
    python collect.py --parse-only
"""
import os, json, glob, time, argparse, sys
from collections import defaultdict
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))

sys.path.insert(0, os.path.join(ROOT, "cross_judge"))
from collect import repair_brackets, tolerant_parse  # noqa: E402

from mistralai.client import Mistral

STATE = os.path.join(BASE, "batch_outputs", "jobs.json")
RAW_OUT = os.path.join(BASE, "batch_outputs", "raw.jsonl")
CLUSTER_DIR = os.path.join(BASE, "clustering")
TERMINAL = {"SUCCESS", "FAILED", "CANCELLED", "TIMEOUT_EXCEEDED"}


def poll_once(client, state):
    all_terminal = True
    for j in state["jobs"]:
        if j.get("collected"):
            continue
        job = client.batch.jobs.get(job_id=j["job_id"])
        status = str(job.status).split(".")[-1].upper()
        comp = getattr(job, "completed_requests", 0) or 0
        tot = getattr(job, "total_requests", 0) or 0
        j["status"] = status
        print(f"  {j['chunk']}: {status} {comp}/{tot}")
        if status not in TERMINAL:
            all_terminal = False
            continue
        ofid = getattr(job, "output_file", None)
        if ofid:
            content = client.files.download(file_id=ofid)
            data = content.read() if hasattr(content, "read") else content
            if isinstance(data, bytes):
                data = data.decode()
            with open(RAW_OUT, "a") as f:
                f.write(data if data.endswith("\n") else data + "\n")
            print(f"    downloaded output_file {ofid}")
        efid = getattr(job, "error_file", None)
        if efid:
            print(f"    NOTE error_file present: {efid}")
        j["collected"] = True
        with open(STATE, "w") as f:
            json.dump(state, f, indent=1)
    return all_terminal


def parse_all():
    n_expected = {}
    for path in glob.glob(os.path.join(ROOT, "cross_judge", "batch_inputs", "*.jsonl")):
        with open(path) as f:
            for line in f:
                r = json.loads(line)
                n_expected[r["custom_id"]] = r["contents"][0]["parts"][0]["text"].count("\n[")

    def iter_objs(path):
        dec = json.JSONDecoder()
        with open(path) as f:
            for line in f:
                line = line.strip()
                while line:
                    try:
                        obj, end = dec.raw_decode(line)
                    except json.JSONDecodeError:
                        break
                    if isinstance(obj, dict):
                        yield obj
                    line = line[end:].lstrip()

    best = {}
    if True:
        for r in iter_objs(RAW_OUT):
            cid = r.get("custom_id")
            if not cid or best.get(cid) is not None:
                continue
            # Mistral batch output row: {"custom_id", "response": {"status_code", "body": {choices...}}}
            resp = r.get("response") or {}
            body = resp.get("body") or {}
            try:
                text = body["choices"][0]["message"]["content"]
            except Exception:
                best.setdefault(cid, None)
                continue
            n = n_expected.get(cid)
            try:
                obj = tolerant_parse(text)
                clusters = obj["clusters"]
                assign = [None] * n
                labels = []
                for k, c in enumerate(clusters):
                    labels.append(str(c["label"]))
                    for i in c["members"]:
                        if not (0 <= int(i) < n) or assign[int(i)] is not None:
                            raise ValueError("bad index")
                        assign[int(i)] = k
                if any(a is None for a in assign):
                    raise ValueError("incomplete")
                sizes = [assign.count(k) for k in range(len(labels))]
                modal = max(range(len(sizes)), key=lambda k: sizes[k])
                phase, prov, qid = cid.split("__", 2)
                best[cid] = {
                    "id": qid, "model": prov, "phase": phase, "n_samples": n,
                    "n_clusters": len(labels), "cluster_labels": labels,
                    "cluster_assignments": assign, "cluster_sizes": sizes,
                    "modal_cluster": modal, "modal_cluster_label": labels[modal],
                    "judge": "mistral-large-latest",
                }
            except Exception:
                best.setdefault(cid, None)

    cells, fails, failed_cids = defaultdict(list), defaultdict(int), []
    for cid, row in best.items():
        phase, prov, _ = cid.split("__", 2)
        cell = f"{phase}_{prov}"
        if row is None:
            fails[cell] += 1
            failed_cids.append(cid)
        else:
            cells[cell].append(row)

    os.makedirs(CLUSTER_DIR, exist_ok=True)
    with open(os.path.join(BASE, "batch_outputs", "failed_cids.json"), "w") as f:
        json.dump(sorted(failed_cids), f, indent=1)
    print(f"\n{'cell':<20}{'parsed':>8}{'fails':>7}{'fail%':>8}")
    for cell in sorted(set(list(cells) + list(fails))):
        rows = cells[cell]
        with open(os.path.join(CLUSTER_DIR, f"{cell}_mistrallarge3_clustered.jsonl"), "w") as f:
            for r in sorted(rows, key=lambda x: x["id"]):
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        tot = len(rows) + fails[cell]
        print(f"{cell:<20}{len(rows):>8}{fails[cell]:>7}{100*fails[cell]/max(tot,1):>7.1f}%")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--interval", type=int, default=900)
    ap.add_argument("--parse-only", action="store_true")
    args = ap.parse_args()

    if args.parse_only:
        parse_all()
        return

    client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
    with open(STATE) as f:
        state = json.load(f)
    while True:
        all_terminal = poll_once(client, state)
        if all_terminal or not args.loop:
            break
        time.sleep(args.interval)
    if all_terminal:
        parse_all()


if __name__ == "__main__":
    main()
