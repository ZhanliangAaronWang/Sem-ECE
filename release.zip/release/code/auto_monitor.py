"""Unified auto-monitor.

Watches for:
  (A) xAI account unlock -> re-launch xAI rerun watcher to collect 58 batches.
  (B) Gemini quota availability -> re-run phase4/submit_all.py to submit missing chunks.

Polls every 10 min. Logs to stdout. Exits once both monitors are satisfied.
"""
import os, json, time, subprocess, requests
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

POLL = 600  # 10 min
MAX_HOURS = 72

XAI_KEY = os.environ["XAI_API_KEY"]
XAI_HEADERS = {"Authorization": f"Bearer {XAI_KEY}"}
XAI_UNLOCK_MARKER = os.path.join(ROOT, "xai_rerun", ".unlocked")

P4_STATE = os.path.join(ROOT, "phase4", "batch_state.json")
GEMINI_DONE_MARKER = os.path.join(ROOT, "phase4", ".gemini_submit_done")


def log(m):
    print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {m}", flush=True)


def xai_unlocked() -> bool:
    try:
        r = requests.get("https://api.x.ai/v1/batches", headers=XAI_HEADERS,
                         params={"limit": 1}, timeout=20)
        return r.status_code == 200
    except Exception:
        return False


def relaunch_xai_watcher():
    # Submit the watcher SLURM job once unlock detected
    log("xAI unlocked — re-submitting watcher SLURM job")
    try:
        r = subprocess.run(
            ["sbatch", os.path.join(ROOT, "xai_rerun", "watch.sbatch")],
            capture_output=True, text=True, timeout=30,
        )
        log(f"  sbatch stdout: {r.stdout.strip()}")
        if r.stderr:
            log(f"  sbatch stderr: {r.stderr.strip()}")
        if r.returncode == 0:
            with open(XAI_UNLOCK_MARKER, "w") as f:
                f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
            return True
    except Exception as e:
        log(f"  sbatch FAILED: {e}")
    return False


def gemini_fully_submitted() -> bool:
    if not os.path.exists(P4_STATE):
        return False
    state = json.load(open(P4_STATE))
    gem = state.get("gemini", {}).get("batches", [])
    return len(gem) >= 5  # target is 5 chunks


def try_submit_gemini() -> bool:
    log("Attempting to submit remaining Gemini chunks via submit_all.py")
    try:
        r = subprocess.run(
            ["python", os.path.join(ROOT, "phase4", "submit_all.py")],
            capture_output=True, text=True, timeout=600, cwd=ROOT,
        )
        tail = "\n".join(r.stdout.splitlines()[-10:])
        log(f"  submit output tail:\n{tail}")
        return gemini_fully_submitted()
    except Exception as e:
        log(f"  submit FAILED: {e}")
        return False


def main():
    xai_done = os.path.exists(XAI_UNLOCK_MARKER)
    gemini_done = gemini_fully_submitted()
    start = time.time()

    while not (xai_done and gemini_done):
        if (time.time() - start) / 3600 > MAX_HOURS:
            log(f"TIMEOUT after {MAX_HOURS}h — exiting")
            break

        # xAI check
        if not xai_done:
            if xai_unlocked():
                if relaunch_xai_watcher():
                    xai_done = True
                    log("✅ xAI handled")
            else:
                log("xAI still locked (429)")

        # Gemini check
        if not gemini_done:
            if try_submit_gemini():
                gemini_done = True
                log("✅ Gemini fully submitted (5/5 chunks)")
                with open(GEMINI_DONE_MARKER, "w") as f:
                    f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))

        if xai_done and gemini_done:
            log("ALL MONITORS DONE — exiting")
            break

        log(f"sleeping {POLL}s (xai_done={xai_done}, gemini_done={gemini_done})")
        time.sleep(POLL)


if __name__ == "__main__":
    main()
