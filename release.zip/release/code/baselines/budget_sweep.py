"""Exp 7 — total-budget sweep B ∈ {5,10,20,30,50}. Pure local, no API calls.

Per question, draw S=20 independent subsamples WITHOUT replacement of size B from
the paper's n=50 (or 46/48) cluster labels, and recompute all three confidence
sources on each subsample:

  Sem1 : max cluster frequency over all B samples
  Sem2 : half-split (selection s / evaluation m) averaged over R repetitions
         B=5→3/2, 10→5/5, 20→10/10, 30→15/15, 50→25/25;  R=50 if B≤10 else R=10
  Ver  : mean of the B samples' parsed verbalized values (missing imputed 1.0)

Outputs (per benchmark, pooled over providers):
  1. ECE vs B for the three sources — mean ± 95% CI over the S subsample draws
  2. per-question confidence SD vs B (estimator variance)
  3. fraction of questions with empirical margin Δ̂ < sqrt(log K̄ / B) at each B
     (low-margin mass growth; K̄ = pooled mean K̂ at full n, held fixed across B
     so the growth is driven purely by B)

Correctness labels Y and the deployed answer are the paper's originals and are
identical across every source and every B.
"""
import os, json, argparse
import numpy as np
from collections import defaultdict

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)

CELLS = {
    "phase1": ("phase1/clustering/{p}_simpleqa_clustered.jsonl",
               "phase1/grading/{p}_simpleqa_graded.jsonl", "SimpleQA"),
    "phase2": ("phase2/clustering/{p}_simpleqa_clustered.jsonl",
               "phase2/grading/{p}_simpleqa_graded.jsonl", "HLE"),
    "phase4": ("phase4/clustering/{p}_popqa_clustered.jsonl",
               "phase4/grading/{p}_popqa_graded.jsonl", "PopQA"),
}
PROVIDERS = ["openai", "anthropic", "gemini", "xai", "mistral"]

BUDGETS = [5, 10, 20, 30, 50]
SPLIT = {5: 3, 10: 5, 20: 10, 30: 15, 50: 25}      # selection-block size s
R_OF = lambda B: 50 if B <= 10 else 10
S_DRAWS = 20


def ece_10bin(conf, y):
    conf, y = np.asarray(conf, float), np.asarray(y, float)
    if conf.size == 0:
        return float("nan")
    idx = np.clip(np.digitize(conf, np.linspace(0, 1, 11)[1:-1]), 0, 9)
    e = 0.0
    for b in range(10):
        m = idx == b
        if m.any():
            e += m.mean() * abs(y[m].mean() - conf[m].mean())
    return float(e)


def eval_question(a, v, B, rng):
    """Vectorised over S draws and R splits.

    a : (n,) int cluster labels;  v : (n,) float verbalized (imputed)
    returns sem1 (S,), sem2 (S,), ver (S,), delta (S,)
    """
    n = a.shape[0]
    K = int(a.max()) + 1
    s = SPLIT[B]
    R = R_OF(B)
    ar = np.arange(K)

    # S draws without replacement
    idx = np.argsort(rng.random((S_DRAWS, n)), axis=1)[:, :B]      # (S,B)
    a_sub = a[idx]                                                 # (S,B)
    v_sub = v[idx]                                                 # (S,B)

    # Sem1 + empirical margin
    counts = (a_sub[:, :, None] == ar).sum(axis=1)                 # (S,K)
    srt = np.sort(counts, axis=1)
    top1 = srt[:, -1]
    top2 = srt[:, -2] if K >= 2 else np.zeros_like(top1)
    sem1 = top1 / B
    delta = (top1 - top2) / B

    # Ver
    ver = v_sub.mean(axis=1)

    # Sem2: R half-splits per draw
    p2 = np.argsort(rng.random((S_DRAWS, R, B)), axis=2)           # (S,R,B)
    lab = np.take_along_axis(np.broadcast_to(a_sub[:, None, :], (S_DRAWS, R, B)), p2, axis=2)
    S_lab, E_lab = lab[:, :, :s], lab[:, :, s:]
    cS = (S_lab[:, :, :, None] == ar).sum(axis=2)                  # (S,R,K)
    z = cS.argmax(axis=-1)                                         # (S,R)
    sem2 = (E_lab == z[:, :, None]).mean(axis=2).mean(axis=1)      # (S,)

    return sem1, sem2, ver, delta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(BASE, "RESULTS_budget_sweep.md"))
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--min-n", type=int, default=0,
                    help="only keep questions with at least this many samples "
                         "(use 50 to hold the question set constant across all budgets)")
    args = ap.parse_args()

    # acc[bench][B] -> dict of stacked arrays
    store = {b: {B: {"sem1": [], "sem2": [], "ver": [], "delta": [], "y": []}
                 for B in BUDGETS} for b in ("SimpleQA", "HLE", "PopQA")}
    Kbar_acc = defaultdict(list)

    for phase, (cpat, gpat, bench) in CELLS.items():
        for prov in PROVIDERS:
            cpath = os.path.join(ROOT, cpat.format(p=prov))
            gpath = os.path.join(ROOT, gpat.format(p=prov))
            if not (os.path.exists(cpath) and os.path.exists(gpath)):
                print(f"[{bench}/{prov}] missing, skip", flush=True)
                continue
            grades = {}
            with open(gpath) as f:
                for line in f:
                    r = json.loads(line)
                    grades.setdefault(r["id"], r["Y"])
            rng = np.random.default_rng(args.seed)
            nq = 0
            with open(cpath) as f:
                for line in f:
                    r = json.loads(line)
                    y = grades.get(r["id"])
                    if y is None:
                        continue
                    if len(r["cluster_assignments"]) < args.min_n:
                        continue
                    a = np.asarray(r["cluster_assignments"], dtype=np.int64)
                    v = np.asarray([1.0 if x is None else float(x)
                                    for x in r["confidence_verbalized"]], dtype=np.float64)
                    if v.shape[0] != a.shape[0]:
                        v = np.resize(v, a.shape[0])
                    Kbar_acc[bench].append(r["n_clusters"])
                    for B in BUDGETS:
                        if B > a.shape[0]:      # e.g. B=50 on the n=46/48 cells
                            continue
                        s1, s2, vv, dd = eval_question(a, v, B, rng)
                        st = store[bench][B]
                        st["sem1"].append(s1); st["sem2"].append(s2)
                        st["ver"].append(vv);  st["delta"].append(dd); st["y"].append(y)
                    nq += 1
            print(f"[{bench}/{prov}] {nq} questions", flush=True)

    Kbar = {b: float(np.mean(v)) for b, v in Kbar_acc.items()}

    L = ["# Exp 7 — total-budget sweep  B ∈ {5, 10, 20, 30, 50}\n",
         "Subsampled **without replacement** from the paper's existing n=50 samples, "
         f"S={S_DRAWS} independent draws per question. **No new API calls.**",
         "Sem₂ split sizes s/m: 3/2, 5/5, 10/10, 15/15, 25/25; R=50 half-splits for B≤10, else R=10.",
         "Ver = mean of the B drawn samples' parsed values (missing imputed 1.0).",
         (f"**Question set held constant across all budgets** (only n≥{args.min_n} questions).\n"
          if args.min_n else ""),
         "ECE = 10 equal-width bins, pooled over providers; mean ± 95% CI over the "
         f"S={S_DRAWS} subsample draws.\n",
         f"Pooled mean K̂ at full n (held fixed across B): " +
         ", ".join(f"{b} K̄={Kbar[b]:.2f}" for b in ("SimpleQA", "HLE", "PopQA")) + "\n"]

    # ---- 1. ECE vs B
    L += ["## 1. Pooled ECE vs budget B (mean ± 95% CI over subsample draws)\n",
          "| bench | B | N | Sem₁-ECE | Sem₂-ECE | Ver-ECE | gap (Sem₁−Sem₂) |",
          "|---|---:|---:|---|---|---|---:|"]
    ece_curve = defaultdict(dict)
    for bench in ("SimpleQA", "HLE", "PopQA"):
        for B in BUDGETS:
            st = store[bench][B]
            if not st["y"]:
                continue
            y = np.asarray(st["y"])
            row = {}
            for src in ("sem1", "sem2", "ver"):
                M = np.stack(st[src])                      # (Nq, S)
                per_draw = np.array([ece_10bin(M[:, j], y) for j in range(M.shape[1])])
                row[src] = (per_draw.mean(), 1.96 * per_draw.std(ddof=1) / np.sqrt(len(per_draw)),
                            per_draw)
            gap = (row["sem1"][2] - row["sem2"][2])
            ece_curve[bench][B] = (row, gap)
            L.append(f"| {bench} | {B} | {len(y)} | "
                     f"{row['sem1'][0]:.4f} ± {row['sem1'][1]:.4f} | "
                     f"{row['sem2'][0]:.4f} ± {row['sem2'][1]:.4f} | "
                     f"{row['ver'][0]:.4f} ± {row['ver'][1]:.4f} | "
                     f"{gap.mean():+.4f} ± {1.96*gap.std(ddof=1)/np.sqrt(len(gap)):.4f} |")

    # ---- 2. per-question confidence SD vs B
    L += ["\n## 2. Per-question confidence SD vs B (mean over questions of the SD across the "
          f"{S_DRAWS} draws)\n",
          "| bench | B | SD(Sem₁) | SD(Sem₂) | SD(Ver) |",
          "|---|---:|---:|---:|---:|"]
    for bench in ("SimpleQA", "HLE", "PopQA"):
        for B in BUDGETS:
            st = store[bench][B]
            if not st["y"]:
                continue
            sds = [np.stack(st[s]).std(axis=1, ddof=1).mean() for s in ("sem1", "sem2", "ver")]
            L.append(f"| {bench} | {B} | {sds[0]:.4f} | {sds[1]:.4f} | {sds[2]:.4f} |")

    # ---- 3. low-margin mass
    L += ["\n## 3. Low-margin mass: fraction of questions with Δ̂ < √(log K̄ / B)\n",
          "| bench | B | threshold √(log K̄/B) | frac Δ̂ below |",
          "|---|---:|---:|---:|"]
    for bench in ("SimpleQA", "HLE", "PopQA"):
        for B in BUDGETS:
            st = store[bench][B]
            if not st["y"]:
                continue
            thr = np.sqrt(np.log(Kbar[bench]) / B)
            D = np.stack(st["delta"])                      # (Nq,S)
            L.append(f"| {bench} | {B} | {thr:.4f} | {float((D < thr).mean()):.4f} |")

    L.append("\n*Note: at B=50 the HLE-Anthropic (n=46), HLE-xAI and PopQA-xAI (n=48) cells "
             "cannot be drawn and are excluded, so N drops at B=50 for those benchmarks; "
             "at B=50 on n=50 cells the draw is the full sample, so Sem₁/Ver have zero "
             "draw-to-draw variance by construction (Sem₂ still varies over its random splits).*")

    with open(args.out, "w") as f:
        f.write("\n".join(L) + "\n")
    print("\nwrote", args.out, flush=True)


if __name__ == "__main__":
    main()
