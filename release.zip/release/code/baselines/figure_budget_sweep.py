"""Exp 7 figure — budget sweep B ∈ {5,10,20,30,50}.

Row 1: pooled ECE vs B for Sem1 / Sem2 / Ver (with 95% CI), per benchmark —
       shows convergence from opposite sides and the flat Ver control.
Row 2: Sem1−Sem2 gap vs B on log–log with fitted slope and a 1/sqrt(B)
       reference, plus the low-margin mass frac(Delta_hat < sqrt(log Kbar / B))
       on a twin axis.

Reads the constant-question-set results file.
"""
import os, re
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(BASE, "RESULTS_budget_sweep_constN.md")
BENCH = ["SimpleQA", "HLE", "PopQA"]
C1, C2, CV, CG, CM = "#d1495b", "#2e86ab", "#8d99ae", "#3c1642", "#f4a261"


def parse():
    ece, mass = {b: {} for b in BENCH}, {b: {} for b in BENCH}
    sec = 0
    for line in open(SRC):
        if line.startswith("## 1."):
            sec = 1; continue
        if line.startswith("## 2."):
            sec = 2; continue
        if line.startswith("## 3."):
            sec = 3; continue
        if sec == 1:
            m = re.match(r"\|\s*(\w+)\s*\|\s*(\d+)\s*\|\s*(\d+)\s*\|\s*([\d.]+) ± ([\d.]+)"
                         r"\s*\|\s*([\d.]+) ± ([\d.]+)\s*\|\s*([\d.]+) ± ([\d.]+)"
                         r"\s*\|\s*([+\-][\d.]+) ± ([\d.]+)", line)
            if m and m.group(1) in BENCH:
                b, B = m.group(1), int(m.group(2))
                ece[b][B] = dict(N=int(m.group(3)),
                                 s1=(float(m.group(4)), float(m.group(5))),
                                 s2=(float(m.group(6)), float(m.group(7))),
                                 ver=(float(m.group(8)), float(m.group(9))),
                                 gap=(float(m.group(10)), float(m.group(11))))
        elif sec == 3:
            m = re.match(r"\|\s*(\w+)\s*\|\s*(\d+)\s*\|\s*([\d.]+)\s*\|\s*([\d.]+)", line)
            if m and m.group(1) in BENCH:
                mass[m.group(1)][int(m.group(2))] = (float(m.group(3)), float(m.group(4)))
    return ece, mass


def main():
    ece, mass = parse()
    fig, axes = plt.subplots(2, 3, figsize=(14, 7.4))

    for j, b in enumerate(BENCH):
        Bs = sorted(ece[b])
        x = np.array(Bs, float)

        # ---- row 1: ECE curves
        ax = axes[0, j]
        for key, col, lab, mk in ((("s1"), C1, r"Sem$_1$-ECE", "o"),
                                  (("s2"), C2, r"Sem$_2$-ECE", "s"),
                                  (("ver"), CV, "Ver-ECE", "^")):
            mu = np.array([ece[b][B][key][0] for B in Bs])
            ci = np.array([ece[b][B][key][1] for B in Bs])
            ax.errorbar(x, mu, yerr=ci, marker=mk, color=col, lw=2, ms=6,
                        capsize=3, label=lab)
        ax.set_xscale("log"); ax.set_xticks(Bs); ax.set_xticklabels(Bs)
        ax.set_xlabel("total budget B (samples / question)")
        if j == 0:
            ax.set_ylabel("pooled ECE")
        ax.set_title(f"{b}   (N = {ece[b][Bs[0]]['N']:,})", fontsize=11)
        ax.grid(alpha=0.3); ax.legend(fontsize=9)

        # ---- row 2: gap log-log + low-margin mass
        ax = axes[1, j]
        g = np.array([ece[b][B]["gap"][0] for B in Bs])
        gci = np.array([ece[b][B]["gap"][1] for B in Bs])
        ax.errorbar(x, g, yerr=gci, marker="o", color=CG, lw=2, ms=6, capsize=3,
                    label=r"Sem$_1-$Sem$_2$ gap")
        sl, ic = np.polyfit(np.log(x), np.log(g), 1)
        ax.plot(x, np.exp(ic) * x ** sl, "--", color=CG, alpha=.6,
                label=f"fit slope {sl:.2f}")
        ax.plot(x, g[-1] * (x / x[-1]) ** -0.5, ":", color="gray",
                label=r"$1/\sqrt{B}$ ref")
        ax.set_xscale("log"); ax.set_yscale("log")
        ax.set_xticks(Bs); ax.set_xticklabels(Bs)
        ax.set_xlabel("total budget B")
        if j == 0:
            ax.set_ylabel(r"ECE gap (Sem$_1-$Sem$_2$)")
        ax.grid(alpha=0.3, which="both")

        ax2 = ax.twinx()
        fm = np.array([mass[b][B][1] for B in Bs])
        ax2.plot(x, fm, marker="d", color=CM, lw=1.8, ms=5, alpha=.9,
                 label=r"low-margin mass")
        ax2.set_ylim(0, 1)
        if j == 2:
            ax2.set_ylabel(r"frac $\hat\Delta<\sqrt{\log \bar K/B}$", color=CM)
        ax2.tick_params(axis="y", colors=CM)

        h1, l1 = ax.get_legend_handles_labels()
        h2, l2 = ax2.get_legend_handles_labels()
        ax.legend(h1 + h2, l1 + l2, fontsize=8, loc="lower left")

    fig.suptitle("Exp 7 — the Sem$_1\\rightarrow$Sem$_2$ correction is largest at small sampling "
                 "budgets  (B = 5 gap is 5–6$\\times$ the B = 50 gap)", fontsize=12.5)
    fig.tight_layout(rect=[0, 0, 1, 0.955])
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(BASE, f"figure_budget_sweep.{ext}"), dpi=150,
                    bbox_inches="tight")
    print("slopes:", {b: round(np.polyfit(np.log([float(k) for k in sorted(ece[b])]),
                                          np.log([ece[b][B]["gap"][0] for B in sorted(ece[b])]), 1)[0], 3)
                      for b in BENCH})
    print("saved figure_budget_sweep.{png,pdf}")


if __name__ == "__main__":
    main()
