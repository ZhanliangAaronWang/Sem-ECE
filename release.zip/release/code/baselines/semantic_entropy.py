"""R4 semantic-entropy baseline — pure local analysis of the paper's n=50 samples.

Zero API calls: every quantity is derived from the existing clustering JSONL
(cluster_sizes / cluster_assignments) and grading JSONL (Y) of the paper's 15
model x benchmark cells.

Per question, from the n cluster labels:
    p_k    = counts_k / n
    SE     = -sum_k p_k ln p_k                     (plug-in / MLE entropy)
    SE_MM  = SE + (Khat - 1) / (2n)                (Miller-Madow bias correction)
    Khat   = number of observed semantic classes

Tracks
  A  label-free maps:  c = exp(-SE)  and  c = 1 - SE/ln(Khat)   (c=1 if Khat=1)
     x {SE, SE_MM}; report ECE.
  B  isotonic PCC: 10 random 50/50 question splits; fit centered-isotonic
     SE -> accuracy(zhat) on the calibration half, apply to the eval half;
     mean ECE +- sd. Sem2+isotonic reported as the reference row.
  C  AUROC of {-SE, c1, c2, Ver} for predicting correctness of zhat.
  D  SE1/SE2 decoupling: SE1 = exp(-H(pi_full)) attached to the full-pool zhat;
     SE2 = mean over the SAME R=10 half-splits Sem2 uses of exp(-H(pi_E)).
     (MM-corrected variants also reported: the two blocks differ in sample
     size, so the plug-in entropy bias -(K-1)/2n differs between them.)

The correctness label Y and the deployed answer zhat are IDENTICAL across all
confidence sources -- only the reported confidence changes.
"""
import os, json, argparse
import numpy as np
from collections import defaultdict
from sklearn.isotonic import IsotonicRegression
from sklearn.metrics import roc_auc_score

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)

CELLS = {
    "phase1": ("phase1/clustering/{p}_simpleqa_clustered.jsonl",
               "phase1/grading/{p}_simpleqa_graded.jsonl", "SimpleQA"),
    "phase2": ("phase2/clustering/{p}_simpleqa_clustered.jsonl",
               "phase2/grading/{p}_simpleqa_graded.jsonl", "HLE"),
    "phase4": ("phase4/clustering/{p}_popqa_clustered.jsonl",
               "phase4/grading/{p}_popqa_graded.jsonl", "PopQA"),
}
PROVIDERS = ["openai", "anthropic", "gemini", "xai", "mistral"]
R_SPLITS = 10
N_PCC_SPLITS = 10


# ── core quantities ─────────────────────────────────────────────────

def entropy_from_counts(counts):
    """Plug-in Shannon entropy (nats) of the empirical PMF, + Khat."""
    c = np.asarray([x for x in counts if x > 0], dtype=float)
    n = c.sum()
    p = c / n
    return float(-(p * np.log(p)).sum()), int(len(c)), int(n)


def sssc_and_se2(cluster_assignments, R=R_SPLITS, seed=0):
    """Sem2 confidence AND SE2, computed on the SAME R half-splits.

    Uses the identical RNG stream as the paper's compute_confidence.py so the
    splits are literally the ones Sem2 uses.
    """
    a = np.asarray(cluster_assignments)
    n = len(a)
    half = n // 2
    rng = np.random.default_rng(seed)
    maxlab = int(a.max()) + 1
    c2_vals, se2_vals, se2mm_vals = [], [], []
    for _ in range(R):
        perm = rng.permutation(n)
        S_idx, E_idx = perm[:half], perm[half:]
        z_S = int(np.argmax(np.bincount(a[S_idx], minlength=maxlab)))   # select on N
        E_lab = a[E_idx]
        c2_vals.append(float(np.mean(E_lab == z_S)))                    # evaluate on E
        cnts = np.bincount(E_lab, minlength=maxlab)
        H, Khat, m = entropy_from_counts(cnts)
        se2_vals.append(np.exp(-H))
        se2mm_vals.append(np.exp(-(H + (Khat - 1) / (2 * m))))
    return (float(np.mean(c2_vals)), float(np.mean(se2_vals)), float(np.mean(se2mm_vals)))


def ece_10bin(conf, y):
    conf, y = np.asarray(conf, float), np.asarray(y, float)
    if len(conf) == 0:
        return float("nan")
    idx = np.clip(np.digitize(conf, np.linspace(0, 1, 11)[1:-1]), 0, 9)
    e = 0.0
    for b in range(10):
        m = idx == b
        if m.any():
            e += m.mean() * abs(y[m].mean() - conf[m].mean())
    return float(e)


def safe_auroc(score, y):
    y = np.asarray(y)
    if len(np.unique(y)) < 2:
        return float("nan")
    return float(roc_auc_score(y, np.asarray(score, float)))


# ── load one cell ───────────────────────────────────────────────────

def load_cell(phase, cpat, gpat, prov):
    cpath = os.path.join(ROOT, cpat.format(p=prov))
    gpath = os.path.join(ROOT, gpat.format(p=prov))
    if not (os.path.exists(cpath) and os.path.exists(gpath)):
        return None
    grades = {}
    with open(gpath) as f:
        for line in f:
            r = json.loads(line)
            grades.setdefault(r["id"], r["Y"])
    rows = []
    with open(cpath) as f:
        for line in f:
            r = json.loads(line)
            y = grades.get(r["id"])
            if y is None:
                continue
            counts = r["cluster_sizes"]
            SE, Khat, n = entropy_from_counts(counts)
            SE_MM = SE + (Khat - 1) / (2 * n)
            c2, se2, se2mm = sssc_and_se2(r["cluster_assignments"])
            SE1, _, _ = SE, Khat, n
            ver = r.get("verbalized_mean")
            rows.append({
                "y": int(y),
                "SE": SE, "SE_MM": SE_MM, "Khat": Khat, "n": n,
                "c1": float(max(counts)) / n,
                "c2": c2,
                "ver": 1.0 if ver is None else float(ver),
                "se1_conf": float(np.exp(-SE)),
                "se1mm_conf": float(np.exp(-SE_MM)),
                "se2_conf": se2,
                "se2mm_conf": se2mm,
            })
    return rows


# ── tracks ──────────────────────────────────────────────────────────

def track_a(rows):
    """label-free maps x {SE, SE_MM} -> ECE"""
    y = [r["y"] for r in rows]
    out = {}
    for tag in ("SE", "SE_MM"):
        se = np.array([r[tag] for r in rows])
        Kh = np.array([r["Khat"] for r in rows], dtype=float)
        out[f"exp(-{tag})"] = ece_10bin(np.exp(-se), y)
        with np.errstate(divide="ignore", invalid="ignore"):
            lin = np.where(Kh > 1, 1.0 - se / np.log(np.maximum(Kh, 2)), 1.0)
        out[f"1-{tag}/lnK"] = ece_10bin(np.clip(lin, 0.0, 1.0), y)
    return out


def track_b(rows, seed=0):
    """isotonic PCC: 10 random 50/50 question splits."""
    y = np.array([r["y"] for r in rows], float)
    se = np.array([r["SE"] for r in rows], float)
    c2 = np.array([r["c2"] for r in rows], float)
    n = len(rows)
    rng = np.random.default_rng(seed)
    res = {"SE+iso": [], "Sem2+iso": []}
    for _ in range(N_PCC_SPLITS):
        perm = rng.permutation(n)
        cal, ev = perm[: n // 2], perm[n // 2:]
        if len(np.unique(y[cal])) < 2:
            continue
        # SE is inversely related to accuracy -> decreasing isotonic
        ir = IsotonicRegression(increasing=False, out_of_bounds="clip", y_min=0, y_max=1)
        ir.fit(se[cal], y[cal])
        res["SE+iso"].append(ece_10bin(ir.predict(se[ev]), y[ev]))
        ir2 = IsotonicRegression(increasing=True, out_of_bounds="clip", y_min=0, y_max=1)
        ir2.fit(c2[cal], y[cal])
        res["Sem2+iso"].append(ece_10bin(ir2.predict(c2[ev]), y[ev]))
    return {k: (float(np.mean(v)), float(np.std(v))) if v else (float("nan"), float("nan"))
            for k, v in res.items()}


def track_c(rows):
    y = [r["y"] for r in rows]
    return {
        "-SE": safe_auroc([-r["SE"] for r in rows], y),
        "c1": safe_auroc([r["c1"] for r in rows], y),
        "c2": safe_auroc([r["c2"] for r in rows], y),
        "Ver": safe_auroc([r["ver"] for r in rows], y),
    }


def track_d(rows):
    y = [r["y"] for r in rows]
    return {
        "SE1": ece_10bin([r["se1_conf"] for r in rows], y),
        "SE2": ece_10bin([r["se2_conf"] for r in rows], y),
        "SE1_MM": ece_10bin([r["se1mm_conf"] for r in rows], y),
        "SE2_MM": ece_10bin([r["se2mm_conf"] for r in rows], y),
        "mean_SE1": float(np.mean([r["se1_conf"] for r in rows])),
        "mean_SE2": float(np.mean([r["se2_conf"] for r in rows])),
        "acc": float(np.mean(y)),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(BASE, "RESULTS_semantic_entropy.md"))
    args = ap.parse_args()

    per_cell = {}
    pooled = defaultdict(list)
    for phase, (cpat, gpat, bench) in CELLS.items():
        for prov in PROVIDERS:
            rows = load_cell(phase, cpat, gpat, prov)
            if not rows:
                print(f"[{phase}/{prov}] missing, skip")
                continue
            per_cell[(bench, prov)] = rows
            pooled[bench] += rows
            print(f"[{bench}/{prov}] N={len(rows)}", flush=True)

    L = ["# R4 — Semantic-entropy baseline (local analysis of the paper's n=50 samples)\n",
         "All quantities derived from the existing clustering + grading files — **no new API calls**.",
         "Correctness label Y and deployed answer ẑ are identical across every confidence source;",
         "only the reported confidence differs. ECE = 10 equal-width bins.\n"]

    # ---- Track A
    L += ["## Track A — label-free entropy→confidence maps (ECE ↓)\n",
          "| bench | provider | N | exp(−SE) | 1−SE/lnK | exp(−SE_MM) | 1−SE_MM/lnK | Sem1-ECE | Sem2-ECE | Ver-ECE |",
          "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for (bench, prov), rows in per_cell.items():
        a = track_a(rows)
        y = [r["y"] for r in rows]
        L.append(f"| {bench} | {prov} | {len(rows)} | {a['exp(-SE)']:.4f} | {a['1-SE/lnK']:.4f} | "
                 f"{a['exp(-SE_MM)']:.4f} | {a['1-SE_MM/lnK']:.4f} | "
                 f"{ece_10bin([r['c1'] for r in rows], y):.4f} | "
                 f"{ece_10bin([r['c2'] for r in rows], y):.4f} | "
                 f"{ece_10bin([r['ver'] for r in rows], y):.4f} |")
    for bench, rows in pooled.items():
        a = track_a(rows)
        y = [r["y"] for r in rows]
        L.append(f"| **{bench}** | **pooled** | {len(rows)} | {a['exp(-SE)']:.4f} | {a['1-SE/lnK']:.4f} | "
                 f"{a['exp(-SE_MM)']:.4f} | {a['1-SE_MM/lnK']:.4f} | "
                 f"{ece_10bin([r['c1'] for r in rows], y):.4f} | "
                 f"{ece_10bin([r['c2'] for r in rows], y):.4f} | "
                 f"{ece_10bin([r['ver'] for r in rows], y):.4f} |")

    # ---- Track B
    L += ["\n## Track B — isotonic post-hoc calibration (10 random 50/50 question splits)\n",
          "Fitted on the calibration half, evaluated on the held-out half. mean ECE ± sd.\n",
          "| bench | provider | N | SE + isotonic | Sem2 + isotonic (ref) |",
          "|---|---|---:|---:|---:|"]
    for (bench, prov), rows in per_cell.items():
        b = track_b(rows)
        L.append(f"| {bench} | {prov} | {len(rows)} | {b['SE+iso'][0]:.4f} ± {b['SE+iso'][1]:.4f} | "
                 f"{b['Sem2+iso'][0]:.4f} ± {b['Sem2+iso'][1]:.4f} |")
    for bench, rows in pooled.items():
        b = track_b(rows)
        L.append(f"| **{bench}** | **pooled** | {len(rows)} | {b['SE+iso'][0]:.4f} ± {b['SE+iso'][1]:.4f} | "
                 f"{b['Sem2+iso'][0]:.4f} ± {b['Sem2+iso'][1]:.4f} |")

    # ---- Track C
    L += ["\n## Track C — AUROC for predicting correctness of ẑ (↑ better)\n",
          "| bench | provider | N | −SE | Sem1 (ĉ₁) | Sem2 (ĉ₂) | Ver |",
          "|---|---|---:|---:|---:|---:|---:|"]
    for (bench, prov), rows in per_cell.items():
        c = track_c(rows)
        L.append(f"| {bench} | {prov} | {len(rows)} | {c['-SE']:.4f} | {c['c1']:.4f} | {c['c2']:.4f} | {c['Ver']:.4f} |")
    for bench, rows in pooled.items():
        c = track_c(rows)
        L.append(f"| **{bench}** | **pooled** | {len(rows)} | {c['-SE']:.4f} | {c['c1']:.4f} | {c['c2']:.4f} | {c['Ver']:.4f} |")

    # ---- Track D
    L += ["\n## Track D — SE1 / SE2 decoupling (same R=10 splits Sem2 uses)\n",
          "SE1 = exp(−H(π̂_full)) on the full pool; SE2 = mean over splits of exp(−H(π̂_E)) on the held-out block.\n",
          "| bench | provider | N | acc | SE1-ECE | SE2-ECE | Δ(SE1−SE2) | SE1_MM | SE2_MM | Δ_MM | mean SE1 | mean SE2 |",
          "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for (bench, prov), rows in per_cell.items():
        d = track_d(rows)
        L.append(f"| {bench} | {prov} | {len(rows)} | {d['acc']:.3f} | {d['SE1']:.4f} | {d['SE2']:.4f} | "
                 f"{d['SE1']-d['SE2']:+.4f} | {d['SE1_MM']:.4f} | {d['SE2_MM']:.4f} | "
                 f"{d['SE1_MM']-d['SE2_MM']:+.4f} | {d['mean_SE1']:.3f} | {d['mean_SE2']:.3f} |")
    for bench, rows in pooled.items():
        d = track_d(rows)
        L.append(f"| **{bench}** | **pooled** | {len(rows)} | {d['acc']:.3f} | {d['SE1']:.4f} | {d['SE2']:.4f} | "
                 f"{d['SE1']-d['SE2']:+.4f} | {d['SE1_MM']:.4f} | {d['SE2_MM']:.4f} | "
                 f"{d['SE1_MM']-d['SE2_MM']:+.4f} | {d['mean_SE1']:.3f} | {d['mean_SE2']:.3f} |")

    L.append("\n*Isotonic fits use scikit-learn's PAVA with linear interpolation between fitted "
             "points (`out_of_bounds='clip'`), the interpolated variant of centered isotonic regression.*")

    with open(args.out, "w") as f:
        f.write("\n".join(L) + "\n")
    print("\nwrote", args.out)


if __name__ == "__main__":
    main()
