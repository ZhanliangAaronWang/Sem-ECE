"""Retry clustering for questions that exited Step-2 with parse / partition
failures (gpt-5.2 judge sometimes produces invalid partitions).

Scope: 9 cells = phase{1,2,4} × provider{openai,gemini,mistral}.
Strategy: identify (phase, provider) pairs where cells in extracted_jsonl are
missing from *_clustered.jsonl, build a single combined OpenAI batch with
seed=1 (was seed=0 originally) over just those qids, then merge results back
into each cell's clustered file. Downstream (grading + confidence + plots)
runs after.

This script handles only Step-2 retry. Use phase1/clustering/prep_*.py output
which already has the clustering batch row template per qid; we filter to
the missing qids and bump seed.

Outputs:
  cluster_retry/batch_input.jsonl       — combined batch input (custom_id includes phase+provider)
  cluster_retry/batch_state.json        — batch_id + chunk metadata
  cluster_retry/<ph>_<prov>_retry.jsonl — collected per-cell new clustered rows
"""
import os, json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RETRY_DIR = ROOT / "cluster_retry"
RETRY_DIR.mkdir(exist_ok=True)

# (phase, provider, ds_label_for_filename)
# Legacy quirk: phase2 (HLE) uses *_simpleqa_clustered.jsonl naming.
CELLS = [
    ("phase1", "openai",  "simpleqa"),
    ("phase1", "gemini",  "simpleqa"),
    ("phase1", "mistral", "simpleqa"),
    ("phase2", "openai",  "simpleqa"),
    ("phase2", "gemini",  "simpleqa"),
    ("phase2", "mistral", "simpleqa"),
    ("phase4", "openai",  "popqa"),
    ("phase4", "gemini",  "popqa"),
    ("phase4", "mistral", "popqa"),
]


def cell_paths(phase, prov, ds):
    return {
        "extracted":     ROOT / phase / "clustering" / f"{prov}_extracted.jsonl",
        "clustering_in": ROOT / phase / "clustering" / "batch_inputs" / f"{prov}_clustering.jsonl",
        "clustered":     ROOT / phase / "clustering" / f"{prov}_{ds}_clustered.jsonl",
    }


def load_qids(p):
    if not p.exists(): return set()
    return {json.loads(l)["id"] for l in open(p)}


def load_clustering_in_by_cid(p):
    """Return dict: custom_id -> full row from <prov>_clustering.jsonl"""
    if not p.exists(): return {}
    out = {}
    with open(p) as fh:
        for line in fh:
            r = json.loads(line)
            out[r["custom_id"]] = r
    return out


def main():
    print("=" * 80)
    print("Cluster retry — diagnose missing qids per cell")
    print("=" * 80)
    rows_to_retry = []
    per_cell_counts = []
    for phase, prov, ds in CELLS:
        paths = cell_paths(phase, prov, ds)
        ext = load_qids(paths["extracted"])
        clu = load_qids(paths["clustered"])
        missing = ext - clu
        per_cell_counts.append((phase, prov, ds, len(ext), len(clu), len(missing)))

        clu_by_cid = load_clustering_in_by_cid(paths["clustering_in"])
        # custom_id format from prep_*.py: f"{provider}__{qid}"
        for qid in sorted(missing):
            cid = f"{prov}__{qid}"
            template = clu_by_cid.get(cid)
            if template is None:
                # try the alt format
                template = clu_by_cid.get(qid)
                if template is None:
                    print(f"  WARN: no clustering input row for {phase}/{prov}/{qid}", flush=True)
                    continue
            row = json.loads(json.dumps(template))   # deep copy
            # Bump seed to give the judge a fresh shot
            row["body"]["seed"] = 1
            # Re-tag custom_id with phase + ds so we know how to route results
            row["custom_id"] = f"retry__{phase}__{prov}__{qid}"
            rows_to_retry.append(row)

    print(f"\n{'phase':<8}{'prov':<10}{'ds':<10}{'ext':>6}{'clu':>6}{'miss':>6}")
    for ph, pr, ds, ne, nc, nm in per_cell_counts:
        print(f"  {ph:<6}{pr:<10}{ds:<10}{ne:>6}{nc:>6}{nm:>6}")
    print(f"\nTotal retry rows: {len(rows_to_retry)}")

    out_path = RETRY_DIR / "batch_input.jsonl"
    with open(out_path, "w") as fh:
        for r in rows_to_retry:
            fh.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"Wrote -> {out_path}")
    print("\nNext: python3 cluster_retry.py --submit")


if __name__ == "__main__":
    if "--submit" in sys.argv:
        # ---- Submit single combined batch to OpenAI ----
        from dotenv import load_dotenv
        load_dotenv(ROOT / "phase1" / ".env", override=True)
        from openai import OpenAI
        c = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

        in_path = RETRY_DIR / "batch_input.jsonl"
        n_rows = sum(1 for _ in open(in_path))
        print(f"Uploading {n_rows} rows from {in_path}")
        fobj = c.files.create(file=open(in_path, "rb"), purpose="batch")
        b = c.batches.create(
            input_file_id=fobj.id,
            endpoint="/v1/chat/completions",
            completion_window="24h",
            metadata={"phase": "cluster_retry", "scope": "p1+p2+p4"},
        )
        print(f"batch_id: {b.id}  status: {b.status}")
        json.dump(
            {"batch_id": b.id, "input_file_id": fobj.id, "n_rows": n_rows},
            open(RETRY_DIR / "batch_state.json", "w"),
            indent=2,
        )
        print(f"State -> {RETRY_DIR / 'batch_state.json'}")
    else:
        main()
