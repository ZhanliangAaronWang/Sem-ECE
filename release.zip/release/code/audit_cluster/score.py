"""Score the cluster-level audit.

Reports, in plain terms:
  1. cluster purity — what share of clusters are internally coherent, by pool and benchmark
  2. impact on ĉ₁ — for flawed MODAL clusters, how much the confidence would move if the
     offending members were removed, and whether it crosses an ECE bin edge or flips ẑ
  3. what goes wrong — a breakdown of the failure notes
  4. case studies — the actual flawed clusters, printed in full
"""
import os, json, re, sys, argparse
from collections import defaultdict
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
sys.path.insert(0, os.path.join(ROOT, "audit"))
from score_audit import read_sheet, kappa                      # noqa: E402

CELLS = {"SimpleQA": "phase1/clustering/{p}_simpleqa_clustered.jsonl",
         "HLE": "phase2/clustering/{p}_simpleqa_clustered.jsonl",
         "PopQA": "phase4/clustering/{p}_popqa_clustered.jsonl"}


def parse_bad(s):
    return sorted({int(x) for x in re.findall(r"\d+", s or "")})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sheets", default=os.path.join(BASE, "sheets_checked"))
    ap.add_argument("--out", default=os.path.join(BASE, "RESULTS_cluster_audit.md"))
    ap.add_argument("--cases", type=int, default=8)
    args = ap.parse_args()

    M = json.load(open(os.path.join(BASE, "mapping", "clusters_mapping.json")))["clusters"]
    sheets = {}
    for who in ("A", "B"):
        for ext in ("csv", "xlsx"):
            p = os.path.join(args.sheets, f"clusters_{who}.{ext}")
            if os.path.exists(p):
                sheets[who] = {r["item_id"]: r for r in read_sheet(p) if r.get("item_id")}
                break
    if not sheets:
        print("no checked sheets found in", args.sheets); return

    merged = {}
    for who in ("B", "A"):                       # A wins on the overlap
        merged.update(sheets.get(who, {}))
    rows = []
    for iid, r in merged.items():
        m = M.get(iid)
        ok = (r.get("cluster_ok") or "").strip().upper()
        if not m or ok not in ("0", "1", "U"):
            continue
        rows.append({**m, "item_id": iid, "ok": ok,
                     "bad": parse_bad(r.get("bad_members", "")),
                     "note": (r.get("note") or "").strip()})
    print(f"usable rows: {len(rows)}")

    L = ["# Cluster-level audit of the clustering judge\n",
         "**What was done.** We sampled whole clusters produced by the paper's judge "
         "(`gpt-5.2`) and asked, for each one, a single question: *do all the answers in this "
         "cluster express the same answer?* If not, which members do not belong. This is a "
         "more direct check than pairwise adjudication and it produces concrete failure cases.\n",
         "**Who checked them.** `gpt-5.4` run through Codex, in two independent passes with an "
         "overlap block, reviewed and accepted by the authors. The checker saw only the "
         "question and the answers in the cluster — not the judge's own label, not the cluster's "
         "size rank, not which benchmark or model it came from.\n",
         "**What was sampled.** 300 clusters: 150 **modal** clusters (the cluster that defines "
         "ĉ₁ and the deployed answer) and 150 non-modal clusters, 10 of each per "
         "benchmark × provider, fixed seed. Singleton clusters — 57 % of all clusters — are "
         "excluded because a one-member cluster cannot be internally incoherent.\n"]

    # ---- 1 purity
    L += ["## 1. Cluster purity\n",
          "| pool | benchmark | n | coherent | flawed | undecidable | **purity** |",
          "|---|---|---:|---:|---:|---:|---:|"]
    for pool in ("modal", "non_modal"):
        for bench in ("SimpleQA", "HLE", "PopQA", "ALL"):
            sel = [r for r in rows if r["pool"] == pool
                   and (bench == "ALL" or r["bench"] == bench)]
            if not sel:
                continue
            ok = sum(1 for r in sel if r["ok"] == "1")
            bad = sum(1 for r in sel if r["ok"] == "0")
            u = sum(1 for r in sel if r["ok"] == "U")
            den = ok + bad
            L.append(f"| {pool} | {bench} | {len(sel)} | {ok} | {bad} | {u} | "
                     f"**{ok/den:.3f}**" if den else "| — |")
            L[-1] += " |"
    allr = [r for r in rows if r["ok"] in ("0", "1")]
    if allr:
        L.append(f"\nOverall: **{sum(1 for r in allr if r['ok']=='1')}/{len(allr)} = "
                 f"{np.mean([r['ok']=='1' for r in allr]):.1%}** of audited clusters are "
                 f"internally coherent.")

    # ---- 2 impact on c1
    L += ["\n## 2. Impact on the reported confidence\n",
          "For each flawed **modal** cluster we remove the members the checker flagged and "
          "recompute ĉ₁ = (modal cluster size)/n. This is the worst case for that cluster: it "
          "assumes every flagged member really is misplaced.\n"]
    src = {}
    want = {(r["bench"], r["provider"]) for r in rows}
    for bench, pat in CELLS.items():
        for prov in {p for b, p in want if b == bench}:
            path = os.path.join(ROOT, pat.format(p=prov))
            if os.path.exists(path):
                for line in open(path):
                    rr = json.loads(line)
                    src[(bench, prov, rr["id"])] = rr
    imp, flips, bins = [], 0, 0
    for r in rows:
        if r["pool"] != "modal" or r["ok"] != "0" or not r["bad"]:
            continue
        rr = src.get((r["bench"], r["provider"], r["qid"]))
        if not rr:
            continue
        sizes = list(rr["cluster_sizes"]); n = sum(sizes)
        k = r["cluster_idx"]
        removed = len([b for b in r["bad"] if 1 <= b <= r["cluster_size"]])
        c1_old = max(sizes) / n
        sizes[k] = max(sizes[k] - removed, 0)
        c1_new = max(sizes) / n
        imp.append(c1_old - c1_new)
        if int(np.argmax(sizes)) != k:
            flips += 1
        if min(int(c1_old * 10), 9) != min(int(c1_new * 10), 9):
            bins += 1
    if imp:
        a = np.array(imp)
        L += [f"- flawed modal clusters analysed: **{len(imp)}**",
              f"- mean drop in ĉ₁: **{a.mean():+.4f}**  (median {np.median(a):+.4f}, "
              f"max {a.max():+.4f})",
              f"- deployed answer ẑ would flip on **{flips}/{len(imp)}** of them",
              f"- ĉ₁ crosses an L=10 ECE bin edge on **{bins}/{len(imp)}** of them",
              f"\nAcross *all* {sum(1 for r in rows if r['pool']=='modal')} audited modal "
              f"clusters the average ĉ₁ movement is "
              f"**{a.sum()/max(sum(1 for r in rows if r['pool']=='modal'),1):+.4f}**."]
    else:
        L.append("- no flawed modal clusters found")

    # ---- 3 failure modes
    L += ["\n## 3. What goes wrong\n"]
    flawed = [r for r in rows if r["ok"] == "0"]
    if flawed:
        kinds = defaultdict(int)
        for r in flawed:
            t = r["note"].lower()
            if any(w in t for w in ("truncat", "fragment", "no answer", "reasoning")):
                kinds["truncated / no answer asserted"] += 1
            elif any(w in t for w in ("different", "distinct", "another", "not the same")):
                kinds["a genuinely different answer merged in"] += 1
            elif any(w in t for w in ("unclear", "vague", "hedge", "uncertain")):
                kinds["hedged / vague member"] += 1
            else:
                kinds["other"] += 1
        L += ["| failure mode | count |", "|---|---:|"]
        for k, v in sorted(kinds.items(), key=lambda x: -x[1]):
            L.append(f"| {k} | {v} |")
        sz = [r["cluster_size"] for r in flawed]
        allsz = [r["cluster_size"] for r in rows]
        L.append(f"\nFlawed clusters are larger than average "
                 f"(mean {np.mean(sz):.1f} members vs {np.mean(allsz):.1f} overall), and the "
                 f"checker flags a median of {np.median([len(r['bad']) for r in flawed]):.0f} "
                 f"member(s) per flawed cluster.")

    # ---- 4 case studies
    L += ["\n## 4. Case studies\n"]
    cases = sorted(flawed, key=lambda r: (r["pool"] != "modal", -r["cluster_size"]))[:args.cases]
    for i, r in enumerate(cases, 1):
        rr = src.get((r["bench"], r["provider"], r["qid"]))
        L += [f"\n### Case {i} — {r['bench']} / {r['provider']} ({r['pool']} cluster, "
              f"{r['cluster_size']} members)\n",
              f"**Question.** {r['question'][:300]}\n" if False else
              f"**Question.** {(rr['question'] if rr else '')[:300]}\n",
              f"**Gold answer.** {r.get('gold','')}\n",
              f"**Judge's label for this cluster.** `{r['judge_label']}`\n",
              "**Answers the judge put in this cluster:**\n"]
        if rr:
            mem = [i2 for i2, c in enumerate(rr["cluster_assignments"]) if c == r["cluster_idx"]]
            for n_, gi in enumerate(mem, start=1):
                mark = " ← **flagged**" if n_ in r["bad"] else ""
                txt = rr["answer_extracted"][gi].replace("\n", " ")
                L.append(f"- `[{n_}]` {txt[:200]}{mark}")
        L.append(f"\n**Checker's note.** {r['note']}")

    # ---- overlap consistency
    if len(sheets) == 2:
        ov = sorted(set(sheets["A"]) & set(sheets["B"]))
        a = [(sheets["A"][i].get("cluster_ok") or "").strip().upper() for i in ov]
        b = [(sheets["B"][i].get("cluster_ok") or "").strip().upper() for i in ov]
        both = [(x, y) for x, y in zip(a, b) if x in ("0", "1") and y in ("0", "1")]
        if both:
            L += ["\n## 5. Reproducibility of the check\n",
                  f"The two passes overlap on **{len(ov)}** clusters. On the {len(both)} where "
                  f"both gave a 0/1 verdict they agree on "
                  f"**{np.mean([x==y for x,y in both]):.1%}** "
                  f"(κ = {kappa([x for x,_ in both], [y for _,y in both]):.3f}). Both passes come "
                  "from the same model in separate sessions, so this measures reproducibility of "
                  "the checking procedure, not agreement between two people."]

    with open(args.out, "w") as f:
        f.write("\n".join(L) + "\n")
    print("wrote", args.out)


if __name__ == "__main__":
    main()
