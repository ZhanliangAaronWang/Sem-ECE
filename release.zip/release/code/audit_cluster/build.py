"""Cluster-level audit — is each cluster produced by the judge internally coherent?

Simpler and more directly interpretable than the pair-level audit: the unit is a whole
cluster, the question is "do all these answers say the same thing?", and any flaw comes
with the offending member indices, which turns straight into a case study.

Sampling (fixed seed 0, one cluster per question so no question is over-represented):
  150 MODAL clusters      — 10 per (benchmark × provider). These decide ĉ₁ and the
                            deployed answer, so their purity is what actually matters.
  150 NON-MODAL clusters  — 10 per (benchmark × provider), size ≥ 2
                            (57 % of all clusters are singletons and are trivially clean,
                             so they are excluded — a singleton cannot be incoherent).

Output: sheets/clusters_{A,B}.csv|xlsx and mapping/clusters_mapping.json.
"""
import os, json, csv, string, argparse
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)

CELLS = {"SimpleQA": "phase1/clustering/{p}_simpleqa_clustered.jsonl",
         "HLE": "phase2/clustering/{p}_simpleqa_clustered.jsonl",
         "PopQA": "phase4/clustering/{p}_popqa_clustered.jsonl"}
PROVS = ["openai", "anthropic", "gemini", "xai", "mistral"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-cell", type=int, default=10,
                    help="clusters of each kind per benchmark x provider")
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    rng = np.random.default_rng(args.seed)
    os.makedirs(os.path.join(BASE, "sheets"), exist_ok=True)
    os.makedirs(os.path.join(BASE, "mapping"), exist_ok=True)

    items = []
    for bench, pat in CELLS.items():
        for prov in PROVS:
            path = os.path.join(ROOT, pat.format(p=prov))
            if not os.path.exists(path):
                continue
            rows = [json.loads(l) for l in open(path)]
            # candidate (row, cluster_idx) pairs
            modal, other = [], []
            for i, r in enumerate(rows):
                sizes = r["cluster_sizes"]
                m = int(np.argmax(sizes))
                if sizes[m] >= 2:
                    modal.append((i, m))
                for k, s in enumerate(sizes):
                    if k != m and s >= 2:
                        other.append((i, k))
            for pool, cand in (("modal", modal), ("non_modal", other)):
                if not cand:
                    continue
                pick = rng.choice(len(cand), min(args.per_cell, len(cand)), replace=False)
                for j in pick:
                    ri, ck = cand[j]
                    r = rows[ri]
                    members = [i for i, c in enumerate(r["cluster_assignments"]) if c == ck]
                    items.append({
                        "bench": bench, "provider": prov, "qid": r["id"], "pool": pool,
                        "question": r["question"], "gold": r["gold_answer"],
                        "cluster_idx": ck, "judge_label": r["cluster_labels"][ck],
                        "members": members,
                        "answers": [r["answer_extracted"][i] for i in members],
                        "cluster_size": len(members), "n_clusters": r["n_clusters"],
                    })
            print(f"[{bench}/{prov}] modal cand {len(modal)}, non-modal cand {len(other)}")

    rng.shuffle(items)
    alphabet = np.array(list(string.ascii_uppercase + string.digits))
    used, rows_out, mapping = set(), [], {}
    for pos, it in enumerate(items, start=1):
        while True:
            iid = "".join(rng.choice(alphabet, 6))
            if iid not in used:
                used.add(iid); break
        # answers are presented 1..k with their own local numbering
        listing = "\n".join(f"[{n}] {a}" for n, a in enumerate(it["answers"], start=1))
        rows_out.append([iid, it["question"], it["cluster_size"], listing, "", "", ""])
        mapping[iid] = {k: it[k] for k in
                        ("bench", "provider", "qid", "pool", "cluster_idx", "judge_label",
                         "members", "cluster_size", "n_clusters", "gold")}
        mapping[iid]["position"] = pos

    hdr = ["item_id", "question", "n_answers", "answers_in_this_cluster",
           "cluster_ok", "bad_members", "note"]
    n = len(rows_out)
    split = [("A", 1, int(n * 0.68)), ("B", int(n * 0.32) + 1, n)]   # ~36 % overlap
    for who, lo, hi in split:
        sub = rows_out[lo - 1:hi]
        with open(os.path.join(BASE, "sheets", f"clusters_{who}.csv"), "w", newline="") as f:
            w = csv.writer(f); w.writerow(hdr); w.writerows(sub)
        write_xlsx(os.path.join(BASE, "sheets", f"clusters_{who}.xlsx"), hdr, sub)
        print(f"  clusters_{who}: items {lo}-{hi} ({len(sub)} rows)")

    json.dump({"clusters": mapping, "seed": args.seed, "per_cell": args.per_cell},
              open(os.path.join(BASE, "mapping", "clusters_mapping.json"), "w"), indent=1)
    print(f"\ntotal {n} clusters "
          f"({sum(1 for v in mapping.values() if v['pool']=='modal')} modal / "
          f"{sum(1 for v in mapping.values() if v['pool']=='non_modal')} non-modal)")


def write_xlsx(path, hdr, rows):
    import xlsxwriter
    wb = xlsxwriter.Workbook(path)
    fh = wb.add_format({"bold": True, "bg_color": "#DCE6F1", "border": 1, "text_wrap": True,
                        "valign": "top"})
    ft = wb.add_format({"text_wrap": True, "valign": "top", "border": 1})
    fi = wb.add_format({"bg_color": "#FFF2CC", "border": 1, "valign": "top"})
    ws0 = wb.add_worksheet("instructions")
    ws0.set_column(0, 0, 110)
    inst = [
        "TASK — is this cluster internally coherent?", "",
        "Each row shows one QUESTION and a group of answers that an automatic system placed",
        "in the SAME cluster, meaning it judged them to all express the same answer.",
        "Your job is to check whether that is true.", "",
        "cluster_ok:",
        "  1 = every answer in the group expresses the same underlying answer",
        "  0 = at least one answer does NOT belong with the others",
        "  U = genuinely undecidable", "",
        "bad_members:",
        "  If cluster_ok = 0, list the numbers in [brackets] of the answers that do not belong,",
        "  comma separated, e.g.  3, 7",
        "  Leave empty when cluster_ok = 1.", "",
        "note:",
        "  One short line saying what is wrong. Example: \"[3] is a different date\",",
        "  \"[7] is a truncated reasoning fragment, no answer stated\".", "",
        "Ignore surface differences: capitalisation, punctuation, articles, name order,",
        "trailing qualifiers, equivalent units (\"1.5 mM\" = \"0.0015 M\"), and paraphrase.",
        "Different specific answers do NOT belong together even if related",
        "(\"Paris\" vs \"France\", \"1869\" vs \"1865\").", "",
        "Some answers are truncated mid-sentence. Judge what the text actually asserts;",
        "if it asserts nothing, it does not belong with answers that do.", "",
        "You are not told what the automatic system's label was, or how confident it was.",
    ]
    for i, line in enumerate(inst):
        ws0.write(i, 0, line, wb.add_format({"text_wrap": True, "valign": "top",
                                             "bold": line.endswith(":")}))
    ws = wb.add_worksheet("clusters")
    ws.freeze_panes(1, 0)
    widths = {"question": 55, "answers_in_this_cluster": 70, "note": 30, "item_id": 11,
              "n_answers": 10, "cluster_ok": 11, "bad_members": 14}
    for c, h in enumerate(hdr):
        ws.write(0, c, h, fh); ws.set_column(c, c, widths.get(h, 12))
    for r, row in enumerate(rows, start=1):
        for c, v in enumerate(row):
            ws.write(r, c, v, fi if hdr[c] in ("cluster_ok", "bad_members", "note") else ft)
    ws.data_validation(1, hdr.index("cluster_ok"), len(rows), hdr.index("cluster_ok"),
                       {"validate": "list", "source": ["1", "0", "U"]})
    wb.close()


if __name__ == "__main__":
    main()
