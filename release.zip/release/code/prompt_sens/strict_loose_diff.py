"""Every question in the 600-question prompt-sensitivity subset where the STRICT
("when in doubt, SPLIT") and LOOSE ("when in doubt, MERGE") arms partition the answers
differently.

Cluster *labels* are arbitrary, so "assigned differently" is defined on the co-membership
relation: answer i is flagged when there exists some j such that i and j are in the same
class under one arm and in different classes under the other. That is label-invariant.

Outputs:
  RESULTS_strict_loose_diff.md   every differing question, in full
  review_sheet.md                a random 20-question sample for manual review
"""
import os, json, argparse, random
from collections import defaultdict
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
SRC = {"SimpleQA": "phase1/clustering/openai_simpleqa_clustered.jsonl",
       "HLE": "phase2/clustering/openai_simpleqa_clustered.jsonl",
       "PopQA": "phase4/clustering/openai_popqa_clustered.jsonl"}


def comembership(a):
    a = np.asarray(a)
    return a[:, None] == a[None, :]


def deployed_and_c1(assign, answers):
    """modal class -> (most common answer string in it, c1)."""
    a = np.asarray(assign)
    cnt = np.bincount(a)
    m = int(np.argmax(cnt))
    idx = [i for i in range(len(a)) if a[i] == m]
    best = max(set(answers[i] for i in idx),
               key=lambda s: sum(1 for i in idx if answers[i] == s))
    return best, cnt[m] / len(a)


def classes(assign, answers):
    """-> list of (sorted distinct answer strings, size), largest first."""
    g = defaultdict(list)
    for i, c in enumerate(assign):
        g[c].append(i)
    out = []
    for c, idx in g.items():
        strs = defaultdict(int)
        for i in idx:
            strs[answers[i]] += 1
        out.append((sorted(strs.items(), key=lambda kv: -kv[1]), len(idx), c))
    return sorted(out, key=lambda t: -t[1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample", type=int, default=20)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    part = {}
    for arm in ("loose", "strict"):
        for line in open(os.path.join(BASE, "clustering", f"{arm}.jsonl")):
            r = json.loads(line)
            part.setdefault((r["bench"], r["id"]), {})[arm] = r["cluster_assignments"]

    meta = {}
    for bench, p in SRC.items():
        for line in open(os.path.join(ROOT, p)):
            r = json.loads(line)
            k = (bench, r["id"])
            if k in part:
                meta[k] = {"q": r["question"], "gold": r.get("gold_answer"),
                           "ans": r["answer_extracted"]}

    diffs, n_ok = [], 0
    for k, d in sorted(part.items()):
        if "loose" not in d or "strict" not in d or k not in meta:
            continue
        L, S = d["loose"], d["strict"]
        answers = meta[k]["ans"]
        if not (len(L) == len(S) == len(answers)):
            continue
        n_ok += 1
        ML, MS = comembership(L), comembership(S)
        row_diff = (ML != MS).any(1)
        if not row_diff.any():
            continue
        depL, c1L = deployed_and_c1(L, answers)
        depS, c1S = deployed_and_c1(S, answers)
        # which distinct answer strings are involved
        moved = defaultdict(int)
        for i in np.nonzero(row_diff)[0]:
            moved[answers[i]] += 1
        diffs.append({
            "key": k, "q": meta[k]["q"], "gold": meta[k]["gold"], "ans": answers,
            "L": L, "S": S, "n": len(L),
            "n_moved": int(row_diff.sum()), "moved": dict(moved),
            "depL": depL, "depS": depS, "c1L": float(c1L), "c1S": float(c1S),
            "binL": min(int(c1L * 10), 9), "binS": min(int(c1S * 10), 9),
            "clsL": classes(L, answers), "clsS": classes(S, answers)})

    same_dep = sum(d["depL"] == d["depS"] for d in diffs)
    same_bin = sum(d["binL"] == d["binS"] for d in diffs)
    same_c1 = sum(d["c1L"] == d["c1S"] for d in diffs)

    def render(items, title, intro):
        out = [f"# {title}\n", intro, ""]
        for d in items:
            bench, qid = d["key"]
            out += [f"## `{bench}/{qid}`\n",
                    f"**Question.** {d['q']}\n",
                    f"**Gold answer.** {d['gold']}\n",
                    f"- answers whose class membership differs between arms: "
                    f"**{d['n_moved']} / {d['n']}**",
                    f"- deployed answer: `{d['depL']}` (loose) → `{d['depS']}` (strict) — "
                    f"{'**unchanged**' if d['depL']==d['depS'] else '**CHANGED**'}",
                    f"- ĉ₁: **{d['c1L']:.2f}** (loose) → **{d['c1S']:.2f}** (strict); "
                    f"ECE bin {d['binL']} → {d['binS']} "
                    f"{'(**unchanged**)' if d['binL']==d['binS'] else '(**CHANGED**)'}\n",
                    "**Answers whose assignment differs**\n",
                    "| answer | count |", "|---|---:|"]
            for s, c in sorted(d["moved"].items(), key=lambda kv: -kv[1]):
                out.append(f"| `{s}` | {c} |")
            out += ["", "**Partition under LOOSE (\"when in doubt, MERGE\")**\n",
                    "| class | size | answer strings |", "|---:|---:|---|"]
            for rank, (strs, size, _) in enumerate(d["clsL"]):
                cell = "; ".join(f"`{s}` ×{c}" for s, c in strs[:8])
                out.append(f"| {rank} | {size} | {cell} |")
            out += ["", "**Partition under STRICT (\"when in doubt, SPLIT\")**\n",
                    "| class | size | answer strings |", "|---:|---:|---|"]
            for rank, (strs, size, _) in enumerate(d["clsS"]):
                cell = "; ".join(f"`{s}` ×{c}" for s, c in strs[:8])
                out.append(f"| {rank} | {size} | {cell} |")
            out.append("")
        return out

    header = (f"Subset: **{n_ok} questions** with a valid partition under both arms "
              f"(200 each from SimpleQA, HLE, PopQA; generator = OpenAI gpt-5.4).\n\n"
              f"Questions where the two arms assign **any** answer differently: "
              f"**{len(diffs)} / {n_ok}** ({len(diffs)/max(n_ok,1):.1%}).\n\n"
              f"Of those {len(diffs)}:\n"
              f"- deployed answer unchanged: **{same_dep}** ({same_dep/max(len(diffs),1):.0%})\n"
              f"- ĉ₁ numerically unchanged: **{same_c1}**\n"
              f"- ĉ₁ stays in the same ECE bin: **{same_bin}** "
              f"({same_bin/max(len(diffs),1):.0%})\n\n"
              f"Relative to the whole subset: a bin change occurs on "
              f"{len(diffs)-same_bin}/{n_ok} = {(len(diffs)-same_bin)/max(n_ok,1):.1%} of "
              f"questions, a deployed-answer change on {len(diffs)-same_dep}/{n_ok} = "
              f"{(len(diffs)-same_dep)/max(n_ok,1):.1%}.\n\n"
              "Membership difference is computed on the co-membership relation, so it is "
              "invariant to cluster relabelling.")

    with open(os.path.join(BASE, "RESULTS_strict_loose_diff.md"), "w") as f:
        f.write("\n".join(render(
            diffs, "STRICT vs LOOSE — every question with a different partition",
            header)) + "\n")

    rng = random.Random(args.seed)
    sample = rng.sample(diffs, min(args.sample, len(diffs)))
    sample.sort(key=lambda d: d["key"])
    with open(os.path.join(BASE, "review_sheet.md"), "w") as f:
        f.write("\n".join(render(
            sample, "Review sheet — 20-question random sample",
            f"A random sample of **{len(sample)}** of the {len(diffs)} questions whose "
            f"partition differs between the STRICT and LOOSE clustering prompts "
            f"(seed {args.seed}). Full list: `RESULTS_strict_loose_diff.md`.\n\n"
            "For each question, judge whether the merge-leaning or the split-leaning "
            "partition is the better reading, or whether the case is genuinely "
            "underdetermined.")) + "\n")

    print(f"{n_ok} questions compared; {len(diffs)} differ")
    print(f"deployed answer unchanged {same_dep}, c1 identical {same_c1}, "
          f"same bin {same_bin}")
    print("wrote RESULTS_strict_loose_diff.md and review_sheet.md")


if __name__ == "__main__":
    main()
