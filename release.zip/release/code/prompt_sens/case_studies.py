"""Find concrete questions where the MERGE-leaning and SPLIT-leaning clustering prompts
produce different partitions, and show what that does (and does not) change.

The claim we want to illustrate: borderline answers move between clusters, but the
*deployed answer* and its *ECE bin* stay put. This looks for questions where the two arms
disagree on the partition, and reports the ones that make the pattern legible.
"""
import os, json, argparse
from collections import defaultdict
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
SRC = {"SimpleQA": "phase1/clustering/openai_simpleqa_clustered.jsonl",
       "HLE": "phase2/clustering/openai_simpleqa_clustered.jsonl",
       "PopQA": "phase4/clustering/openai_popqa_clustered.jsonl"}


def groups(assign, answers):
    g = defaultdict(list)
    for i, a in enumerate(assign):
        g[a].append(i)
    return sorted(g.values(), key=len, reverse=True)


def modal(assign):
    c = np.bincount(np.asarray(assign))
    return int(np.argmax(c)), int(c.max()), len(assign)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", nargs=2, default=["loose", "strict"],
                    help="merge-leaning arm, split-leaning arm")
    ap.add_argument("--top", type=int, default=25)
    ap.add_argument("--out", default=os.path.join(BASE, "RESULTS_case_studies.md"))
    args = ap.parse_args()
    A, B = args.arms

    part = {}
    for arm in (A, B):
        for line in open(os.path.join(BASE, "clustering", f"{arm}.jsonl")):
            r = json.loads(line)
            part.setdefault((r["bench"], r["id"]), {})[arm] = r["cluster_assignments"]

    ans = {}
    for bench, p in SRC.items():
        for line in open(os.path.join(ROOT, p)):
            r = json.loads(line)
            if (bench, r["id"]) in part:
                ans[(bench, r["id"])] = r["answer_extracted"]

    cands = []
    for key, d in part.items():
        if A not in d or B not in d or key not in ans:
            continue
        a, b = d[A], d[B]
        answers = ans[key]
        if len(a) != len(answers) or len(b) != len(answers):
            continue
        ma, ca, n = modal(a)
        mb, cb, _ = modal(b)
        dep_a = max(set(answers[i] for i in range(n) if a[i] == ma),
                    key=lambda s: sum(1 for i in range(n) if a[i] == ma and answers[i] == s))
        dep_b = max(set(answers[i] for i in range(n) if b[i] == mb),
                    key=lambda s: sum(1 for i in range(n) if b[i] == mb and answers[i] == s))
        c1a, c1b = ca / n, cb / n
        if c1a == c1b:
            continue                          # partition change didn't touch the modal class
        # distinct answer strings in the merge-arm modal class -> how legible the case is
        strings = sorted(set(answers[i] for i in range(n) if a[i] == ma))
        cands.append({"key": key, "n": n, "c1a": c1a, "c1b": c1b,
                      "bin_a": min(int(c1a * 10), 9), "bin_b": min(int(c1b * 10), 9),
                      "dep_a": dep_a, "dep_b": dep_b, "same_dep": dep_a == dep_b,
                      "nstr": len(strings), "strings": strings,
                      "grp_a": groups(a, answers), "grp_b": groups(b, answers),
                      "assign_a": a, "assign_b": b, "answers": answers})

    # most legible first: few distinct strings, same deployed answer, same bin
    cands.sort(key=lambda c: (not c["same_dep"], c["bin_a"] != c["bin_b"],
                              c["nstr"], -abs(c["c1a"] - c["c1b"])))

    L = ["# Case studies: MERGE-leaning vs SPLIT-leaning clustering prompt\n",
         f"Arms compared: **{A}** (\"when in doubt, MERGE\") vs **{B}** (\"when in doubt, "
         f"SPLIT\"), same generations, same reference judge, temperature 0.\n",
         f"Questions where the two arms give a different modal-class size: "
         f"**{len(cands)}**.\n"]

    same_dep = sum(c["same_dep"] for c in cands)
    same_bin = sum(c["bin_a"] == c["bin_b"] for c in cands)
    L += [f"- deployed answer **unchanged** in {same_dep}/{len(cands)} "
          f"({same_dep/max(len(cands),1):.1%}) of them",
          f"- ĉ₁ stays in the **same ECE bin** in {same_bin}/{len(cands)} "
          f"({same_bin/max(len(cands),1):.1%}) of them\n"]

    L.append("## Individual cases\n")
    for c in cands[:args.top]:
        bench, qid = c["key"]
        L += [f"### `{bench}/{qid}`  (n={c['n']})\n",
              f"- **{A}** (merge): modal class has {int(c['c1a']*c['n'])} of {c['n']} samples "
              f"→ ĉ₁ = **{c['c1a']:.2f}**, bin {c['bin_a']}",
              f"- **{B}** (split): modal class has {int(c['c1b']*c['n'])} of {c['n']} samples "
              f"→ ĉ₁ = **{c['c1b']:.2f}**, bin {c['bin_b']}",
              f"- deployed answer: {c['dep_a']!r} → {c['dep_b']!r} "
              f"{'(**unchanged**)' if c['same_dep'] else '(**CHANGED**)'}",
              f"- ECE bin: {'**unchanged**' if c['bin_a']==c['bin_b'] else '**CHANGED**'}\n",
              "Distinct answer strings in the merge-arm modal class:\n"]
        for s in c["strings"][:12]:
            k = sum(1 for i in range(c["n"]) if c["answers"][i] == s)
            grp_b = [gi for gi, g in enumerate(c["grp_b"])
                     if any(c["answers"][i] == s for i in g)]
            L.append(f"  - {s!r} ×{k}  → split-arm class(es) {grp_b}")
        L.append("")

    with open(args.out, "w") as f:
        f.write("\n".join(L) + "\n")
    print(f"{len(cands)} candidate questions; deployed answer preserved in {same_dep}, "
          f"bin preserved in {same_bin}")
    print("wrote", args.out)


if __name__ == "__main__":
    main()
