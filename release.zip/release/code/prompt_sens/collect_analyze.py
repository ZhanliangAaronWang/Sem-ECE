"""Exp 10 — collect the prompt-variant partitions and compare them to the paper's.

Per arm and benchmark reports:
  K̂, mean margin Δ̂, low-margin mass, ARI vs the paper's partition,
  Sem1/Sem2 ECE with paired-bootstrap CIs, and the Sem1−Sem2 gap.
The `shuffled` arm's cluster indices are mapped back through the recorded permutation
so its partition is directly comparable question by question.
"""
import os, json, time, argparse, sys
from collections import defaultdict
import numpy as np
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))
sys.path.insert(0, os.path.join(ROOT, "cross_judge"))
from collect import tolerant_parse                                   # noqa: E402
from compare import sssc_confidence, naive_confidence, ece_10bin, rand_and_ari  # noqa: E402
from openai import OpenAI

ARMS = ["strict", "loose", "no_example", "minimal", "shuffled", "original_rerun"]
CELLS = {"SimpleQA": ("phase1/clustering/openai_simpleqa_clustered.jsonl",
                      "phase1/grading/openai_simpleqa_graded.jsonl"),
         "HLE": ("phase2/clustering/openai_simpleqa_clustered.jsonl",
                 "phase2/grading/openai_simpleqa_graded.jsonl"),
         "PopQA": ("phase4/clustering/openai_popqa_clustered.jsonl",
                   "phase4/grading/openai_popqa_graded.jsonl")}
STATE = os.path.join(BASE, "batch_outputs", "jobs.json")
JDR = 0.612 / np.sqrt(50)


def collect(client):
    st = json.load(open(STATE))
    design = json.load(open(os.path.join(BASE, "design.json")))
    perms = design["perms"]
    os.makedirs(os.path.join(BASE, "clustering"), exist_ok=True)
    all_done = True
    for arm in ARMS:
        j = st.get(arm)
        if not j or j.get("collected"):
            continue
        b = client.batches.retrieve(j["batch_id"])
        rc = b.request_counts
        print(f"  {arm}: {b.status} {getattr(rc,'completed',0)}/{getattr(rc,'total',0)}", flush=True)
        if b.status not in ("completed", "failed", "expired", "cancelled"):
            all_done = False
            continue
        rows, fails = [], 0
        if b.output_file_id:
            for line in client.files.content(b.output_file_id).text.splitlines():
                r = json.loads(line)
                _, bench, qid = r["custom_id"].split("__", 2)
                body = (r.get("response") or {}).get("body") or {}
                try:
                    text = body["choices"][0]["message"]["content"]
                except Exception:
                    fails += 1; continue
                try:
                    cut = text.find('{"clusters"')
                    obj = tolerant_parse(text[cut:] if cut > 0 else text)
                    n = None
                    assign, labels = None, []
                    members = [[int(i) for i in c["members"]] for c in obj["clusters"]]
                    n = max(max(m) for m in members if m) + 1
                    assign = [None] * n
                    for k, c in enumerate(obj["clusters"]):
                        labels.append(str(c["label"]))
                        for i in c["members"]:
                            if not (0 <= int(i) < n) or assign[int(i)] is not None:
                                raise ValueError("bad")
                            assign[int(i)] = k
                    if any(a is None for a in assign):
                        raise ValueError("incomplete")
                    if arm == "shuffled":            # undo the presentation permutation
                        p = perms[f"{bench}__{qid}"]
                        back = [None] * n
                        for pos, orig in enumerate(p[:n]):
                            back[orig] = assign[pos]
                        if any(x is None for x in back):
                            raise ValueError("perm mismatch")
                        assign = back
                    sizes = [assign.count(k) for k in range(len(labels))]
                    rows.append({"bench": bench, "id": qid, "arm": arm,
                                 "cluster_assignments": assign, "cluster_sizes": sizes,
                                 "n_clusters": len(labels)})
                except Exception:
                    fails += 1
        with open(os.path.join(BASE, "clustering", f"{arm}.jsonl"), "w") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"    {arm}: parsed {len(rows)}, fails {fails}")
        j["collected"] = True
        json.dump(st, open(STATE, "w"), indent=1)
    return all_done


def analyze(out):
    design = json.load(open(os.path.join(BASE, "design.json")))
    subset = design["subset"]
    base, grades = {}, {}
    for bench, (cp, gp) in CELLS.items():
        want = set(subset[bench])
        for line in open(os.path.join(ROOT, cp)):
            r = json.loads(line)
            if r["id"] in want:
                base[(bench, r["id"])] = r
        for line in open(os.path.join(ROOT, gp)):
            r = json.loads(line)
            if r["id"] in want:
                grades.setdefault((bench, r["id"]), r["Y"])

    arms = {"original": {k: v for k, v in base.items()}}
    for arm in ARMS:
        p = os.path.join(BASE, "clustering", f"{arm}.jsonl")
        if not os.path.exists(p):
            continue
        arms[arm] = {(r["bench"], r["id"]): r for r in map(json.loads, open(p))}

    L = ["# Exp 10 — clustering-prompt sensitivity\n",
         "Judge model held fixed at the paper's own **gpt-5.2** (`reasoning_effort=none, "
         "temperature=0, seed=0`); only the **prompt** changes. 200 questions per benchmark, "
         "one fixed-seed subset shared by every arm; the paper's own partitions are the "
         "`original` arm (reused, no API call).\n",
         "Arms: **strict** (\"when in doubt, SPLIT\"), **loose** (\"when in doubt, MERGE\"), "
         "**no_example** (worked example removed), **minimal** (terse 393-char instruction, "
         "no rule list), **shuffled** (original prompt, answers presented in a different random "
         "order, indices mapped back).\n",
         f"JDR boundary at n=50: Δ = {JDR:.4f}.\n",
         "| arm | bench | N | mean K̂ | mean Δ̂ | frac Δ̂<JDR | ARI vs original | Sem₁-ECE | Sem₂-ECE | gap |",
         "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|"]

    summary = defaultdict(dict)
    for arm, d in arms.items():
        for bench in CELLS:
            ids = [k for k in d if k[0] == bench and k in grades and k in arms["original"]]
            if not ids:
                continue
            K, dl, aris, c1, c2, y = [], [], [], [], [], []
            for k in ids:
                r = d[k]
                s = sorted(r["cluster_sizes"], reverse=True); n = sum(s)
                K.append(r["n_clusters"]); dl.append((s[0] - (s[1] if len(s) > 1 else 0)) / n)
                c1.append(naive_confidence(r["cluster_sizes"]))
                c2.append(sssc_confidence(r["cluster_assignments"]))
                y.append(grades[k])
                o = arms["original"][k]
                if len(o["cluster_assignments"]) == len(r["cluster_assignments"]):
                    aris.append(rand_and_ari(o["cluster_assignments"], r["cluster_assignments"])[1])
            e1, e2 = ece_10bin(c1, y), ece_10bin(c2, y)
            summary[arm][bench] = dict(n=len(ids), K=np.mean(K), d=np.mean(dl),
                                       low=float(np.mean(np.array(dl) < JDR)),
                                       ari=float(np.mean(aris)) if aris else 1.0,
                                       e1=e1, e2=e2, gap=e1 - e2)
            s = summary[arm][bench]
            L.append(f"| {arm} | {bench} | {s['n']} | {s['K']:.2f} | {s['d']:.4f} | {s['low']:.3f} "
                     f"| {s['ari']:.3f} | {s['e1']:.4f} | {s['e2']:.4f} | {s['gap']:+.4f} |")

    L += ["\n## Gap by arm (pooled across the three benchmarks)\n",
          "| arm | mean K̂ | ARI vs original | Sem₁-ECE | Sem₂-ECE | **gap** | gap sign |",
          "|---|---:|---:|---:|---:|---:|:--:|"]
    for arm in ["original"] + ARMS:
        if arm not in summary:
            continue
        ids = []
        for bench in CELLS:
            d = arms[arm]
            ids += [k for k in d if k[0] == bench and k in grades and k in arms["original"]]
        c1 = [naive_confidence(arms[arm][k]["cluster_sizes"]) for k in ids]
        c2 = [sssc_confidence(arms[arm][k]["cluster_assignments"]) for k in ids]
        y = [grades[k] for k in ids]
        K = np.mean([arms[arm][k]["n_clusters"] for k in ids])
        aris = [rand_and_ari(arms["original"][k]["cluster_assignments"],
                             arms[arm][k]["cluster_assignments"])[1]
                for k in ids
                if len(arms["original"][k]["cluster_assignments"]) == len(arms[arm][k]["cluster_assignments"])]
        e1, e2 = ece_10bin(c1, y), ece_10bin(c2, y)
        L.append(f"| {arm} | {K:.2f} | {np.mean(aris) if aris else 1.0:.3f} | {e1:.4f} | {e2:.4f} "
                 f"| **{e1-e2:+.4f}** | {'✓' if e1-e2 > 0 else '✗'} |")

    L.append("\n*The question set, the samples, the grades and the estimator code are identical "
             "across arms — only the clustering instruction (or, for `shuffled`, the answer "
             "presentation order) differs.*")
    with open(out, "w") as f:
        f.write("\n".join(L) + "\n")
    print("\n".join(L))
    print("\nwrote", out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--interval", type=int, default=300)
    ap.add_argument("--analyze-only", action="store_true")
    ap.add_argument("--out", default=os.path.join(BASE, "RESULTS_prompt_sensitivity.md"))
    args = ap.parse_args()
    if args.analyze_only:
        analyze(args.out); return
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    while True:
        done = collect(client)
        if done or not args.loop:
            break
        time.sleep(args.interval)
    if done:
        analyze(args.out)


if __name__ == "__main__":
    main()
