"""Exp 10 — clustering-prompt sensitivity (R-comment: not just temperature).

The three cross-judge experiments (Exps 1/4/5) varied the judge MODEL but held the
clustering prompt byte-identical. This experiment holds the model fixed (the paper's
own gpt-5.2) and varies the PROMPT, which is what actually controls partition
granularity — and therefore K̂, the margin distribution, and the whole regime structure.

Arms (the paper's samples are reused; only the judge instruction changes):
  original    the paper's prompt                    -> reuse existing partitions, no API
  strict      bias toward MORE clusters             -> "when in doubt, split"
  loose       bias toward FEWER clusters            -> "when in doubt, merge"
  no_example  the worked example removed            -> tests few-shot dependence
  shuffled    original prompt, answers presented in a different random order
              (indices mapped back afterwards)      -> tests order / position bias
  minimal     terse instruction, no rule list       -> tests instruction verbosity

Subset: 200 questions per benchmark (SimpleQA / HLE / PopQA) drawn with a fixed seed
from the OpenAI cells, so all arms and all benchmarks are compared on one question set.
"""
import os, json, re, argparse
import numpy as np

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)

CELLS = {
    "SimpleQA": "phase1/clustering/openai_simpleqa_clustered.jsonl",
    "HLE": "phase2/clustering/openai_simpleqa_clustered.jsonl",
    "PopQA": "phase4/clustering/openai_popqa_clustered.jsonl",
}
N_PER_BENCH = 200
ORIG = open(os.path.join(ROOT, "cross_judge", "system_prompt.txt")).read()


def variants():
    """Return {arm: system_prompt}. `original` is kept for reference/reuse."""
    v = {"original": ORIG}

    # strict: same prompt + an explicit split-when-in-doubt instruction
    v["strict"] = ORIG.replace(
        "- Use as few clusters as faithfully captures the semantic distinctions. Do not over-fragment over trivial differences.",
        "- When in doubt, SPLIT: create a separate cluster rather than merging two answers you are not certain are identical in meaning. Prefer more clusters over fewer.")

    # loose: the opposite bias
    v["loose"] = ORIG.replace(
        "- Use as few clusters as faithfully captures the semantic distinctions. Do not over-fragment over trivial differences.",
        "- When in doubt, MERGE: group answers together whenever they plausibly refer to the same underlying answer. Prefer fewer clusters over more.")

    # no_example: strip the worked example block
    ne = re.sub(r"Example output:\n\{.*?\n\]\}\n", "", ORIG, flags=re.S)
    v["no_example"] = ne

    # minimal: terse instruction, no rule list, same output contract
    v["minimal"] = (
        "You are a semantic clustering assistant. You will receive a question and a list "
        "of model-generated answers, indexed 0 through N-1. Partition the answers into "
        "groups of answers that mean the same thing.\n\n"
        "Output ONLY a JSON object {\"clusters\": [{\"label\": <short string>, "
        "\"members\": [<indices>]}, ...]} in which every index 0..N-1 appears exactly once. "
        "No preamble, no code fences, no commentary.")

    # shuffled uses the ORIGINAL prompt; only the answer order changes
    v["shuffled"] = ORIG
    return v


def user_msg(q, answers):
    n = len(answers)
    return "\n".join([f"Question: {q}", "", f"Answers ({n} total, indexed 0 to {n-1}):"]
                     + [f"[{i}] {a}" for i, a in enumerate(answers)])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--n", type=int, default=N_PER_BENCH)
    args = ap.parse_args()
    os.makedirs(os.path.join(BASE, "batch_inputs"), exist_ok=True)
    V = variants()
    rng = np.random.default_rng(args.seed)

    subset = {}
    rows_by_id = {}
    for bench, path in CELLS.items():
        rows = [json.loads(l) for l in open(os.path.join(ROOT, path))]
        rows = [r for r in rows if len(r["answer_extracted"]) >= 40]
        idx = rng.permutation(len(rows))[:args.n]
        picked = [rows[i] for i in idx]
        subset[bench] = [r["id"] for r in picked]
        for r in picked:
            rows_by_id[(bench, r["id"])] = r
        print(f"{bench}: {len(picked)} questions")

    # per-question answer permutation for the shuffled arm (recorded so we can invert it)
    perms = {}
    for (bench, qid), r in rows_by_id.items():
        n = len(r["answer_extracted"])
        perms[f"{bench}__{qid}"] = [int(x) for x in rng.permutation(n)]

    json.dump({"subset": subset, "perms": perms,
               "prompts": {k: v for k, v in V.items()}},
              open(os.path.join(BASE, "design.json"), "w"), indent=1)

    for arm, sysp in V.items():
        if arm == "original":
            continue                      # reused from the paper, no API call
        path = os.path.join(BASE, "batch_inputs", f"{arm}.jsonl")
        n_rows = 0
        with open(path, "w") as f:
            for (bench, qid), r in rows_by_id.items():
                answers = r["answer_extracted"]
                if arm == "shuffled":
                    p = perms[f"{bench}__{qid}"]
                    answers = [answers[i] for i in p]
                f.write(json.dumps({
                    "custom_id": f"{arm}__{bench}__{qid}",
                    "method": "POST", "url": "/v1/chat/completions",
                    "body": {"model": "gpt-5.2",
                             "messages": [{"role": "system", "content": sysp},
                                          {"role": "user", "content": user_msg(r["question"], answers)}],
                             "reasoning_effort": "none", "temperature": 0.0,
                             "max_completion_tokens": 3000,
                             "response_format": {"type": "json_object"}, "seed": 0}},
                    ensure_ascii=False) + "\n")
                n_rows += 1
        print(f"[{arm}] {n_rows} rows -> {path}  (prompt {len(sysp)} chars)")


if __name__ == "__main__":
    main()
