"""Phase 3 (MATH-500 + AIME) Step 7 -- Collect grading batch results, parse, compute ECE.

Mirrors phase2/grading/collect_and_check.py.

Usage:
    python collect_and_check.py --providers openai xai mistral --watch
"""
import os, json, time, re, argparse, random
import numpy as np
import pandas as pd
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI

CLUSTER_DIR = os.path.join(ROOT, "phase4", "clustering")
GRADING_DIR = os.path.join(ROOT, "phase4", "grading")
CONF_DIR = os.path.join(ROOT, "phase4", "confidence")
BATCH_IDS_FILE = os.path.join(GRADING_DIR, "batch_ids.json")

TERMINAL = {"completed", "failed", "expired", "cancelled"}
client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])


def retrieve_with_retry(bid, max_tries=8):
    delay = 5
    for i in range(max_tries):
        try:
            return client.batches.retrieve(bid)
        except Exception:
            time.sleep(delay)
            delay = min(60, delay * 2)
    raise RuntimeError(f"retrieve {bid} failed after {max_tries} attempts")


def poll(batch_id, watch=False, interval=30):
    while True:
        b = retrieve_with_retry(batch_id)
        st = b.status
        rc = b.request_counts
        print(f"  [{time.strftime('%H:%M:%S')}] {st} done={rc.completed}/{rc.total} fail={rc.failed}", flush=True)
        if st in TERMINAL or not watch:
            return b
        time.sleep(interval)


def parse_grade(raw_text):
    if not raw_text:
        return "PARSE_ERROR", None
    txt = raw_text.strip()
    if txt.startswith("```"):
        txt = re.sub(r"^```(?:json)?\s*", "", txt)
        txt = re.sub(r"\s*```$", "", txt)
    try:
        obj = json.loads(txt)
        grade = obj.get("grade", "").upper()
        if grade in ("CORRECT", "INCORRECT", "NOT_ATTEMPTED"):
            return grade, raw_text
    except Exception:
        pass
    upper = raw_text.upper()
    for g in ("CORRECT", "INCORRECT", "NOT_ATTEMPTED"):
        if g in upper:
            return g, raw_text
    return "PARSE_ERROR", raw_text


# ---- ECE / ACE / Brier ----

def ece(confs, accs, n_bins=15):
    bin_edges = np.linspace(0, 1, n_bins + 1)
    ece_val = 0.0
    n = len(confs)
    bin_data = []
    for i in range(n_bins):
        lo, hi = bin_edges[i], bin_edges[i + 1]
        mask = (confs >= lo) & (confs < hi) if i < n_bins - 1 else (confs >= lo) & (confs <= hi)
        if mask.sum() == 0:
            bin_data.append({"lo": lo, "hi": hi, "n": 0, "mean_conf": None, "mean_acc": None, "gap": None})
            continue
        bin_confs = confs[mask]
        bin_accs = accs[mask]
        mean_c = bin_confs.mean()
        mean_a = bin_accs.mean()
        gap = abs(mean_c - mean_a)
        ece_val += (mask.sum() / n) * gap
        bin_data.append({"lo": lo, "hi": hi, "n": int(mask.sum()),
                         "mean_conf": float(mean_c), "mean_acc": float(mean_a),
                         "gap": float(gap)})
    return float(ece_val), bin_data


def ace(confs, accs, n_bins=15):
    n = len(confs)
    order = np.argsort(confs)
    sorted_c = confs[order]
    sorted_a = accs[order]
    bin_size = n // n_bins
    ace_val = 0.0
    for i in range(n_bins):
        lo = i * bin_size
        hi = (i + 1) * bin_size if i < n_bins - 1 else n
        bc = sorted_c[lo:hi]
        ba = sorted_a[lo:hi]
        gap = abs(bc.mean() - ba.mean())
        ace_val += (len(bc) / n) * gap
    return float(ace_val)


def brier(confs, accs):
    return float(np.mean((confs - accs) ** 2))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--providers", nargs="+", default=["openai", "mistral", "gemini"])
    ap.add_argument("--watch", action="store_true")
    ap.add_argument("--interval", type=int, default=30)
    ap.add_argument("--bins", type=int, default=15)
    args = ap.parse_args()

    with open(BATCH_IDS_FILE) as f:
        batch_ids = json.load(f)

    all_records = []
    total_in = total_out = 0

    for prov in args.providers:
        if prov not in batch_ids:
            print(f"[{prov}] SKIP -- no batch_id", flush=True)
            continue
        bid = batch_ids[prov]["batch_id"]
        print(f"[{prov}] batch_id: {bid}", flush=True)

        b = poll(bid, watch=args.watch, interval=args.interval)
        if b.status != "completed":
            print(f"[{prov}] NOT COMPLETED (status={b.status}). Skipping.", flush=True)
            continue

        print(f"  downloading output...", flush=True)
        resp = client.files.content(b.output_file_id)
        raw = (resp.read() if hasattr(resp, "read") else resp.content).decode()

        # Load clustering data for join
        clustered = {}
        cpath = os.path.join(CLUSTER_DIR, f"{prov}_popqa_clustered.jsonl")
        with open(cpath) as f:
            for line in f:
                r = json.loads(line)
                clustered[r["id"]] = r

        # Parse
        records = []
        in_tok = out_tok = 0
        for line in raw.strip().splitlines():
            jr = json.loads(line)
            cid = jr["custom_id"]
            qid = cid.replace(f"{prov}__", "")
            body = jr.get("response", {}).get("body", {})
            usage = body.get("usage", {})
            in_tok += usage.get("prompt_tokens", 0) or 0
            out_tok += usage.get("completion_tokens", 0) or 0

            choices = body.get("choices", [])
            raw_judge = choices[0]["message"]["content"] if choices else None
            grade, raw_text = parse_grade(raw_judge)
            Y = 1 if grade == "CORRECT" else (None if grade == "PARSE_ERROR" else 0)

            cr = clustered.get(qid, {})
            records.append({
                "id": qid,
                "model": prov,
                "question": cr.get("question", ""),
                "gold_answer": cr.get("gold_answer", ""),
                "modal_cluster_label": cr.get("modal_cluster_label", ""),
                "grade": grade,
                "Y": Y,
                "raw_judge_response": raw_text,
            })

        # Save graded file (keep "simpleqa" suffix to match phase2 convention)
        out_path = os.path.join(GRADING_DIR, f"{prov}_popqa_graded.jsonl")
        with open(out_path, "w") as f:
            for r in sorted(records, key=lambda x: x["id"]):
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"  wrote {len(records)} rows -> {out_path}", flush=True)

        # Sanity checks
        n = len(records)
        n_correct = sum(1 for r in records if r["grade"] == "CORRECT")
        n_incorrect = sum(1 for r in records if r["grade"] == "INCORRECT")
        n_na = sum(1 for r in records if r["grade"] == "NOT_ATTEMPTED")
        n_parse = sum(1 for r in records if r["grade"] == "PARSE_ERROR")
        acc = n_correct / n if n > 0 else 0

        print(f"\n=== Grading sanity checks ({prov}, Phase 3) ===", flush=True)
        print(f"  rows: {n}/{len(clustered)}", flush=True)
        print(f"  parse failures: {n_parse} ({n_parse*100/max(n,1):.2f}%)", flush=True)
        print(f"  CORRECT: {n_correct} ({n_correct*100/max(n,1):.1f}%)", flush=True)
        print(f"  INCORRECT: {n_incorrect} ({n_incorrect*100/max(n,1):.1f}%)", flush=True)
        print(f"  NOT_ATTEMPTED: {n_na} ({n_na*100/max(n,1):.1f}%)", flush=True)
        print(f"  accuracy (mean Y): {acc:.4f}", flush=True)

        # Random examples
        random.seed(0)
        sample = random.sample(records, min(10, len(records)))
        print(f"\n  10 random examples:", flush=True)
        for r in sample:
            print(f"    Q: {str(r['question'])[:80]}...", flush=True)
            print(f"    gold={str(r['gold_answer'])[:50]}  pred={str(r['modal_cluster_label'])[:50]}  grade={r['grade']}", flush=True)

        # Cost
        total_in += in_tok
        total_out += out_tok
        cost = in_tok * 1.25 / 2 / 1e6 + out_tok * 10.0 / 2 / 1e6
        print(f"\n  Cost: in={in_tok:,}  out={out_tok:,}  est=${cost:.2f}", flush=True)

        all_records.extend(records)

    # Save all grades
    if all_records:
        df = pd.DataFrame(all_records)
        pq_path = os.path.join(GRADING_DIR, "all_grades.parquet")
        df.to_parquet(pq_path, index=False)
        print(f"\nWrote {len(df)} rows -> {pq_path}", flush=True)


if __name__ == "__main__":
    main()
