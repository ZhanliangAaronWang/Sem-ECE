"""Phase 4 (PopQA) prep_anthropic — extract answers from anthropic_popqa_raw.jsonl
and build GPT-5.2 clustering batch input.

Anthropic Message Batches result format:
  { "custom_id": "{qid}__sample{NN}",
    "result": {"message": {"content": [{"type":"text","text":"..."}], ...}} }

Most Qs have full 50/50 (Anthropic batch is reliable when credit is available).
Use n=50 for clustering.
"""
import os, json, re, statistics
from collections import defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RAW = os.path.join(ROOT, "phase4", "batch_outputs", "anthropic_popqa_raw.jsonl")
GOLD = os.path.join(ROOT, "data", "phase4", "popqa_preprocessed.jsonl")
EXTRACTED = os.path.join(ROOT, "phase4", "clustering", "anthropic_extracted.jsonl")
BATCH_OUT = os.path.join(ROOT, "phase4", "clustering", "batch_inputs", "anthropic_clustering.jsonl")

JUDGE_MODEL = "gpt-5.2"
ANS_RE = re.compile(r"Answer:\s*(.+?)(?=\nConfidence|\Z)", re.DOTALL)
CONF_RE = re.compile(r"Confidence:\s*([0-9]+(?:\.[0-9]+)?)\s*%?")
NULL_ANS = {"see above", "as stated", "as mentioned", "as noted"}
N_KEEP = 50

SYSTEM_PROMPT = """You are a semantic clustering assistant for a research benchmark. You will receive a question and a list of model-generated answers, indexed 0 through N-1. Your job is to partition the answers into groups such that two answers are in the same group if and only if they express the same underlying answer to the question.

Rules:
- Cluster by SEMANTIC meaning, not surface form. "Leo Tolstoy", "Tolstoy", "Leo Tolstoy (1869)", and "the Russian novelist Leo Tolstoy" all belong to the same cluster.
- Surface variations to ignore: capitalization, punctuation, articles (a/the), trailing dates or qualifiers, formal vs informal name forms, units that express the same physical quantity ("1.5 mM" = "0.0015 M"), and explanatory parentheticals.
- Different specific answers belong to different clusters even if related: "Tolstoy" and "Dostoevsky" are different; "Paris" and "France" are different; "1869" and "1865" are different.
- Each answer index must appear in exactly one cluster. Every index 0 to N-1 must be assigned.
- Use as few clusters as faithfully captures the semantic distinctions. Do not over-fragment over trivial differences.

Output format: a single JSON object with one field, "clusters", whose value is an array of cluster objects. Each cluster object has two fields:
- "label": a short canonical string representing the cluster's answer (e.g., "Leo Tolstoy", "1869")
- "members": a sorted array of integer indices (0-indexed) of the answers in that cluster

Example output:
{"clusters": [
  {"label": "Leo Tolstoy", "members": [0, 1, 3, 5, 8, 12, 15, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46, 49]},
  {"label": "Fyodor Dostoevsky", "members": [2, 6, 11, 17, 24, 30, 38, 44]},
  {"label": "Anton Chekhov", "members": [4, 9, 14, 20, 27, 33, 41, 47]},
  {"label": "I don't know", "members": [7, 10, 13, 16, 18, 21, 23, 26, 29, 32, 35, 36, 39, 42, 45, 48]}
]}

Output ONLY the JSON object, with no preamble, no code fences, no commentary."""


def extract_answer(raw):
    if not raw:
        return "", "fallback_tail"
    m = ANS_RE.search(raw)
    if m:
        ans = m.group(1).strip()
        if ans and ans.lower() not in NULL_ANS:
            return ans, "answer_line"
    return raw[-200:].strip(), "fallback_tail"


def extract_conf(raw):
    if not raw:
        return None, "missing"
    m = CONF_RE.search(raw)
    if not m:
        return None, "missing"
    try:
        v = float(m.group(1)) / 100.0
    except ValueError:
        return None, "missing"
    return max(0.0, min(1.0, v)), "regex_match"


def extract_text(rec):
    msg = rec.get("result", {}).get("message")
    if msg is None:
        return None
    content = msg.get("content") or []
    parts = [c.get("text", "") for c in content if c.get("type") == "text"]
    return "\n".join(parts) if parts else None


def main():
    gold = {}
    with open(GOLD) as f:
        for line in f:
            d = json.loads(line)
            gold[d["qid"]] = d

    q_samples = defaultdict(dict)
    n_records = n_skipped_err = 0
    with open(RAW) as f:
        for line in f:
            n_records += 1
            r = json.loads(line)
            text = extract_text(r)
            if text is None:
                n_skipped_err += 1
                continue
            cid = r["custom_id"]
            qid, sample_key = cid.rsplit("__", 1)
            sample_idx = int(sample_key.replace("sample", ""))
            q_samples[qid][sample_idx] = text

    complete = {qid: s for qid, s in q_samples.items() if len(s) >= N_KEEP}
    print(f"Records read: {n_records}, skipped errors: {n_skipped_err}", flush=True)
    print(f"Questions with any data: {len(q_samples)}", flush=True)
    print(f"Complete (>={N_KEEP}): {len(complete)}", flush=True)

    fallback = missing_conf = 0
    all_conf = []
    extracted_rows = []
    batch_rows = []

    for qid in sorted(complete.keys()):
        samples = complete[qid]
        kept_idx = sorted(samples.keys())[:N_KEEP]
        results = [samples[i] for i in kept_idx]

        ans_list, ext_method, conf_list, conf_method = [], [], [], []
        for raw in results:
            a, em = extract_answer(raw)
            c, cm = extract_conf(raw)
            ans_list.append(a)
            ext_method.append(em)
            conf_list.append(c)
            conf_method.append(cm)
            if em == "fallback_tail":
                fallback += 1
            if cm == "missing":
                missing_conf += 1
            else:
                all_conf.append(c)

        # Missing verbalized confidence is imputed as 1.0 (model didn't bother to express uncertainty -> assume max conf).
        imputed_conf = [1.0 if c is None else c for c in conf_list]
        verb_mean = sum(imputed_conf) / len(imputed_conf) if imputed_conf else 1.0
        verb_n = sum(1 for c in conf_list if c is not None)

        gold_row = gold[qid]
        extracted_rows.append({
            "id": qid,
            "question": gold_row["question_final"],
            "gold_answer": gold_row["gold_answer"],
            "model": "anthropic",
            "n_samples": N_KEEP,
            "results": results,
            "answer_extracted": ans_list,
            "extraction_method": ext_method,
            "confidence_verbalized": conf_list,
            "confidence_extraction_method": conf_method,
            "verbalized_mean": verb_mean,
            "verbalized_n_extracted": verb_n,
        })

        ans_block = "\n".join(f"[{i}] {a}" for i, a in enumerate(ans_list))
        user_msg = f"Question: {gold_row['question_final']}\n\nAnswers ({N_KEEP} total, indexed 0 to {N_KEEP-1}):\n{ans_block}"
        batch_rows.append({
            "custom_id": f"anthropic__{qid}",
            "method": "POST",
            "url": "/v1/chat/completions",
            "body": {
                "model": JUDGE_MODEL,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_msg},
                ],
                "reasoning_effort": "none",
                "temperature": 0.0,
                "max_completion_tokens": 1500,
                "response_format": {"type": "json_object"},
                "seed": 0,
            },
        })

    os.makedirs(os.path.dirname(BATCH_OUT), exist_ok=True)
    with open(EXTRACTED, "w") as f:
        for r in extracted_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"Wrote {len(extracted_rows)} rows -> {EXTRACTED}", flush=True)

    with open(BATCH_OUT, "w") as f:
        for r in batch_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"Wrote {len(batch_rows)} rows -> {BATCH_OUT}", flush=True)

    total_samples = len(complete) * N_KEEP
    print(f"\n=== Step 1 stats (anthropic, P4 PopQA) ===", flush=True)
    print(f"  total samples: {total_samples}", flush=True)
    print(f"  fallback (answer): {fallback} ({fallback*100/total_samples:.2f}%)", flush=True)
    print(f"  missing (confidence): {missing_conf} ({missing_conf*100/total_samples:.2f}%)", flush=True)
    if all_conf:
        print(f"  mean verbalized conf:   {statistics.mean(all_conf):.3f}", flush=True)
        print(f"  median verbalized conf: {statistics.median(all_conf):.3f}", flush=True)


if __name__ == "__main__":
    main()
