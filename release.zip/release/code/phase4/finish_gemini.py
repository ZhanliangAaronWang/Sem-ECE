"""Finish Gemini P4: poll clustering -> collect -> grade -> collect grade -> update marker."""
import os, json, time, subprocess
from dotenv import load_dotenv
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)
from openai import OpenAI
client = OpenAI()
P4 = os.path.join(ROOT, "phase4")


def poll(bid, label):
    while True:
        b = client.batches.retrieve(bid)
        rc = b.request_counts
        print(f"[{time.strftime('%H:%M:%S')}] {label}: {b.status} {rc.completed}/{rc.total}", flush=True)
        if b.status in {"completed","failed","expired","cancelled"}: return b
        time.sleep(180)


def run(cmd):
    print(f"$ {cmd}", flush=True)
    r = subprocess.run(cmd, shell=True, cwd=ROOT)
    if r.returncode != 0: raise RuntimeError(cmd)


# 1. Wait for clustering
cs = json.load(open(os.path.join(P4, "clustering", "gemini_chunks.json")))
for c in cs["chunks"]:
    bb = poll(c["batch_id"], f"cluster_c{c['chunk']}")
    c["final_status"] = bb.status
    if bb.status == "completed":
        c["output_file_id"] = bb.output_file_id
        c["error_file_id"] = bb.error_file_id
with open(os.path.join(P4, "clustering", "gemini_chunks.json"), "w") as f:
    json.dump(cs, f, indent=2)

run("python phase4/clustering/collect_gemini.py")

# 2. Re-grade Gemini only
run("python phase4/grading/prep_and_submit.py --providers gemini --submit")
ids = json.load(open(os.path.join(P4, "grading", "batch_ids.json")))
poll(ids["gemini"]["batch_id"], "grade_gemini")
run("python phase4/grading/collect_and_check.py --providers gemini")

# 3. Touch marker
with open(os.path.join(P4, ".pipeline_done"), "w") as f:
    f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
print("P4 GEMINI FINISHED, marker refreshed")
