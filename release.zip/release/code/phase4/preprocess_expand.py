"""Phase 4 expansion — sample 1500 additional PopQA questions (no overlap with existing 500).

Keeps same stratification (s_pop quintile weights 0.30/0.25/0.20/0.15/0.10).
Uses SEED=1 to avoid reproducing the original sample order.
Output: data/phase4/popqa_preprocessed_expand.jsonl (1500 new questions).
"""
import json, os, random
from datasets import load_dataset

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXISTING = os.path.join(ROOT, "data", "phase4", "popqa_preprocessed.jsonl")
OUT = os.path.join(ROOT, "data", "phase4", "popqa_preprocessed_expand.jsonl")

N_EXPAND = 1500
SEED = 1

def main():
    # Load existing qids to exclude
    existing = set()
    with open(EXISTING) as f:
        for line in f:
            r = json.loads(line)
            existing.add(r["qid"])
    print(f"Existing: {len(existing)} qids to exclude")

    random.seed(SEED)
    ds = load_dataset("akariasai/PopQA", split="test")
    print(f"Loaded PopQA: {len(ds)} rows")

    rows = [r for r in ds if f"popqa_{r['id']}" not in existing]
    print(f"After excluding existing: {len(rows)} rows available")

    rows.sort(key=lambda r: r["s_pop"])
    n = len(rows)
    weights = [0.30, 0.25, 0.20, 0.15, 0.10]
    per_bin_n = [int(N_EXPAND * w) for w in weights]
    per_bin_n[0] += N_EXPAND - sum(per_bin_n)

    picked = []
    for bi, count in enumerate(per_bin_n):
        lo = int(bi * n / 5)
        hi = int((bi + 1) * n / 5)
        pool = rows[lo:hi]
        picked.extend(random.sample(pool, min(count, len(pool))))

    random.shuffle(picked)
    print(f"Selected {len(picked)} new questions: per-bin {per_bin_n}")

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        for r in picked:
            answers = json.loads(r["possible_answers"])
            row = {
                "qid": f"popqa_{r['id']}",
                "question_final": r["question"],
                "gold_answer": answers[0],
                "gold_answer_aliases": answers,
                "s_pop": r["s_pop"],
                "prop": r["prop"],
                "subj": r["subj"],
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(f"Wrote {len(picked)} -> {OUT}")


if __name__ == "__main__":
    main()
