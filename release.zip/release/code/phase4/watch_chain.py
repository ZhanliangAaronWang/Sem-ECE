"""Phase 4 PopQA unified pipeline watcher.

Chain:
  1. Poll 3 clustering batches (openai, mistral, gemini)
  2. Run collect_{provider}.py for each completed
  3. Submit grading batches (uses phase3/grading/prep_and_submit.py pattern)
  4. Poll grading batches
  5. Run collect_and_check + compute_confidence/ECE for phase4

Writes marker phase4/.pipeline_done when complete.
"""
import os, json, time, subprocess
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI
client = OpenAI()

P4 = os.path.join(ROOT, "phase4")
PROVIDERS = ["openai", "mistral", "gemini"]
POLL = 300
TERMINAL = {"completed", "failed", "expired", "cancelled"}
DONE_MARKER = os.path.join(P4, ".pipeline_done")


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def poll_until_done(batch_id, label):
    while True:
        b = client.batches.retrieve(batch_id)
        rc = b.request_counts
        log(f"  {label}: {b.status} {rc.completed}/{rc.total}")
        if b.status in TERMINAL:
            return b
        time.sleep(POLL)


def run(cmd):
    log(f"$ {cmd}")
    r = subprocess.run(cmd, shell=True, cwd=ROOT)
    if r.returncode != 0:
        raise RuntimeError(f"FAILED: {cmd}")


def main():
    # Step 1: poll clustering for each provider
    for prov in PROVIDERS:
        state = json.load(open(os.path.join(P4, "clustering", f"{prov}_chunks.json")))
        for c in state["chunks"]:
            b = poll_until_done(c["batch_id"], f"{prov}_cluster_c{c['chunk']}")
            c["final_status"] = b.status
            if b.status == "completed":
                c["output_file_id"] = b.output_file_id
                c["error_file_id"] = b.error_file_id
        with open(os.path.join(P4, "clustering", f"{prov}_chunks.json"), "w") as f:
            json.dump(state, f, indent=2)
        # Step 2: collect
        run(f"python phase4/clustering/collect_{prov}.py")

    # Step 3: submit grading
    run(f"python phase4/grading/prep_and_submit.py --providers {' '.join(PROVIDERS)} --submit")

    # Step 4: poll grading
    ids = json.load(open(os.path.join(P4, "grading", "batch_ids.json")))
    for prov in PROVIDERS:
        bid = ids.get(prov, {}).get("batch_id")
        if not bid: continue
        poll_until_done(bid, f"{prov}_grade")

    # Step 5: collect grading + ECE
    run(f"python phase4/grading/collect_and_check.py --providers {' '.join(PROVIDERS)}")

    with open(DONE_MARKER, "w") as f:
        f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
    log("P4 PIPELINE DONE")


if __name__ == "__main__":
    main()
