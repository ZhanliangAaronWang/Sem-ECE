"""Phase 4 PopQA xAI-only pipeline watcher.

Chain (xAI uses n=48 samples since seed=0 is rejected by xAI; sample00 always
errors, so we drop it and one more to keep n even for SSSC math):
  1. Poll xai clustering chunks (3 chunks: 800+800+400)
  2. Run collect_xai.py
  3. Submit grading batch (--providers xai)
  4. Poll grading batch
  5. Run collect_and_check.py --providers xai (computes confidence + ECE for xai
     and merges into existing all_confidence.parquet / calibration_metrics.csv)

Writes marker phase4/.pipeline_done_xai when complete.
"""
import os, json, time, subprocess
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI
client = OpenAI()

P4 = os.path.join(ROOT, "phase4")
POLL = 300
TERMINAL = {"completed", "failed", "expired", "cancelled"}
DONE_MARKER = os.path.join(P4, ".pipeline_done_xai")


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def poll_until_done(batch_id, label):
    while True:
        b = client.batches.retrieve(batch_id)
        rc = b.request_counts
        log(f"  {label}: {b.status} {rc.completed}/{rc.total}")
        if b.status in TERMINAL:
            return b
        time.sleep(POLL)


def run(cmd):
    log(f"$ {cmd}")
    r = subprocess.run(cmd, shell=True, cwd=ROOT)
    if r.returncode != 0:
        raise RuntimeError(f"FAILED: {cmd}")


def main():
    # Step 1: poll xai clustering chunks
    state_path = os.path.join(P4, "clustering", "xai_chunks.json")
    state = json.load(open(state_path))
    for c in state["chunks"]:
        b = poll_until_done(c["batch_id"], f"xai_cluster_c{c['chunk']}")
        c["final_status"] = b.status
        if b.status == "completed":
            c["output_file_id"] = b.output_file_id
            c["error_file_id"] = b.error_file_id
    with open(state_path, "w") as f:
        json.dump(state, f, indent=2)

    # Step 2: collect clustering
    run("python phase4/clustering/collect_xai.py")

    # Step 3: submit grading
    run("python phase4/grading/prep_and_submit.py --providers xai --submit")

    # Step 4: poll grading
    ids = json.load(open(os.path.join(P4, "grading", "batch_ids.json")))
    bid = ids.get("xai", {}).get("batch_id")
    if not bid:
        raise RuntimeError("no xai batch_id in grading/batch_ids.json")
    poll_until_done(bid, "xai_grade")

    # Step 5: collect grading
    run("python phase4/grading/collect_and_check.py --providers xai")

    # Step 6: compute confidence + ECE (re-runs all providers; cheap, local-only)
    run("python phase4/confidence/compute_confidence.py")
    run("python phase4/confidence/compute_ece.py")

    with open(DONE_MARKER, "w") as f:
        f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
    log("P4 xAI PIPELINE DONE")


if __name__ == "__main__":
    main()
