"""Phase 4 — PopQA preprocessing.

Selects a stratified sample of 500 questions biased toward LOW subject popularity
(s_pop quantile bins) so that we get more hard / low-margin questions, plus some
high-popularity easy questions for comparison. Output matches our standard schema.
"""
import json, os, random
from datasets import load_dataset

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "data", "phase4", "popqa_preprocessed.jsonl")

N_TOTAL = 500
SEED = 0

def main():
    random.seed(SEED)
    ds = load_dataset("akariasai/PopQA", split="test")
    print(f"Loaded PopQA: {len(ds)} rows")

    # Stratify by subject popularity quintiles to ensure varied difficulty
    rows = list(ds)
    rows.sort(key=lambda r: r["s_pop"])
    n = len(rows)
    # 5 quintiles, weighted toward lower popularity (more low-margin cases)
    weights = [0.30, 0.25, 0.20, 0.15, 0.10]  # low → high pop
    per_bin_n = [int(N_TOTAL * w) for w in weights]
    # Adjust for rounding
    per_bin_n[0] += N_TOTAL - sum(per_bin_n)

    picked = []
    for bi, count in enumerate(per_bin_n):
        lo = int(bi * n / 5)
        hi = int((bi + 1) * n / 5)
        pool = rows[lo:hi]
        picked.extend(random.sample(pool, min(count, len(pool))))

    random.shuffle(picked)
    print(f"Selected {len(picked)} questions across {len(per_bin_n)} popularity quintiles: {per_bin_n}")

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w") as f:
        for i, r in enumerate(picked):
            answers = json.loads(r["possible_answers"])
            row = {
                "qid": f"popqa_{r['id']}",
                "question_final": r["question"],
                "gold_answer": answers[0],
                "gold_answer_aliases": answers,
                "s_pop": r["s_pop"],
                "prop": r["prop"],
                "subj": r["subj"],
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(f"Wrote {len(picked)} -> {OUT}")


if __name__ == "__main__":
    main()
