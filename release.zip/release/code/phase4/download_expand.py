"""Phase 4 expansion — download generation outputs for OpenAI / Mistral / Gemini.

Reads phase4/batch_state_expand.json (all generation completed on the API side)
and writes:
  - phase4/batch_outputs/openai_popqa_expand_chunk{0-6}.jsonl  (raw OpenAI batch envelope, 1 line per request, n choices in body)
  - phase4/batch_outputs/mistral_popqa_expand_chunk0.jsonl       (raw Mistral batch envelope, 1 line per sample)
  - phase4/batch_outputs/gemini_popqa_expand.jsonl                (one record per InlinedResponse — qid, sample idx, text, usage)

Run with --provider openai|mistral|gemini to do one at a time (recommended; all 3 in parallel
hits the disk hard for ~80MB+ of writes plus 15 sequential gemini batch fetches).
"""
import os, json, sys, argparse, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from dotenv import load_dotenv
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

STATE = os.path.join(ROOT, "phase4", "batch_state_expand.json")
OUT_DIR = os.path.join(ROOT, "phase4", "batch_outputs")
os.makedirs(OUT_DIR, exist_ok=True)


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def download_openai(state):
    from openai import OpenAI
    c = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    chunks = state["openai"]["chunks"]
    log(f"OpenAI: {len(chunks)} chunks to download")
    total_bytes = 0
    for ch in chunks:
        ci = ch["chunk"]
        fid = ch["output_file_id"]
        out = os.path.join(OUT_DIR, f"openai_popqa_expand_chunk{ci}.jsonl")
        if os.path.exists(out) and os.path.getsize(out) > 0:
            log(f"  chunk{ci}: SKIP (exists, {os.path.getsize(out):,} B)")
            continue
        log(f"  chunk{ci}: fetching {fid}")
        fr = c.files.content(fid)
        data = fr.read() if hasattr(fr, "read") else fr.content
        with open(out, "wb") as f:
            f.write(data)
        total_bytes += len(data)
        log(f"  chunk{ci}: wrote {len(data):,} B, {len(data.splitlines())} lines -> {out}")
    log(f"OpenAI: {total_bytes:,} total bytes downloaded")


def download_mistral(state):
    from mistralai.client import Mistral
    c = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
    chunks = state["mistral"]["chunks"]
    log(f"Mistral: {len(chunks)} chunks to download")
    for ch in chunks:
        ci = ch["chunk"]
        bid = ch["batch_id"]
        out = os.path.join(OUT_DIR, f"mistral_popqa_expand_chunk{ci}.jsonl")
        if os.path.exists(out) and os.path.getsize(out) > 1_000_000:
            log(f"  chunk{ci}: SKIP (exists, {os.path.getsize(out):,} B)")
            continue
        # Look up output_file from current job state
        job = c.batch.jobs.get(job_id=bid)
        out_file_id = job.output_file
        log(f"  chunk{ci}: output_file={out_file_id}, fetching")
        # Mistral SDK: client.files.download(file_id=...) returns bytes
        resp = c.files.download(file_id=out_file_id)
        data = resp.read() if hasattr(resp, "read") else resp.content if hasattr(resp, "content") else bytes(resp)
        with open(out, "wb") as f:
            f.write(data)
        n_lines = sum(1 for _ in open(out))
        log(f"  chunk{ci}: wrote {len(data):,} B, {n_lines} lines -> {out}")
        # Persist output_file_id back to state for the record
        ch["output_file_id"] = out_file_id


def _serialize_part_text(resp):
    """Robustly extract text from a Gemini InlinedResponse or skip silently if missing."""
    try:
        cands = resp.response.candidates
        if not cands:
            return None
        parts = cands[0].content.parts
        texts = []
        for p in parts:
            t = getattr(p, "text", None)
            if t:
                texts.append(t)
        if not texts:
            return None
        return "".join(texts)
    except Exception as e:
        return None


def download_gemini(state):
    from google import genai
    c = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])
    batches = state["gemini"]["batches"]
    out = os.path.join(OUT_DIR, "gemini_popqa_expand.jsonl")
    if os.path.exists(out) and os.path.getsize(out) > 1_000_000:
        log(f"Gemini: SKIP (exists, {os.path.getsize(out):,} B)")
        return
    log(f"Gemini: {len(batches)} batches to walk through")
    n_total, n_text, n_blank, n_finish = 0, 0, 0, {}
    written = 0
    with open(out, "w") as f:
        for bi, b in enumerate(batches):
            log(f"  batch{bi}: fetching {b['name']}")
            job = c.batches.get(name=b["name"])
            inlined = getattr(job.dest, "inlined_responses", None) or []
            log(f"  batch{bi}: {len(inlined)} inlined responses")
            for ir in inlined:
                n_total += 1
                cid = (ir.metadata or {}).get("custom_id", "")
                resp = ir.response
                text = _serialize_part_text(ir)
                fr = None
                ut = pt = ct = None
                if resp is not None:
                    cands = getattr(resp, "candidates", []) or []
                    if cands:
                        fr_obj = getattr(cands[0], "finish_reason", None)
                        fr = fr_obj.name if hasattr(fr_obj, "name") else (str(fr_obj) if fr_obj is not None else None)
                    um = getattr(resp, "usage_metadata", None)
                    if um is not None:
                        pt = getattr(um, "prompt_token_count", None)
                        ct = getattr(um, "candidates_token_count", None)
                        ut = getattr(um, "total_token_count", None)
                if text:
                    n_text += 1
                else:
                    n_blank += 1
                if fr is not None:
                    n_finish[fr] = n_finish.get(fr, 0) + 1
                row = {"custom_id": cid, "text": text, "finish_reason": fr,
                        "prompt_tokens": pt, "completion_tokens": ct, "total_tokens": ut}
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
                written += 1
            log(f"  batch{bi}: cumulative written={written:,} text_ok={n_text:,} blank={n_blank:,}")
    log(f"Gemini: wrote {written:,} rows -> {out}")
    log(f"  text non-empty: {n_text:,}/{n_total:,}  blank: {n_blank:,}")
    log(f"  finish_reasons: {n_finish}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--provider", choices=["openai", "mistral", "gemini", "all"], default="all")
    args = ap.parse_args()

    state = json.load(open(STATE))
    if args.provider in ("openai", "all"):
        download_openai(state)
    if args.provider in ("mistral", "all"):
        download_mistral(state)
    if args.provider in ("gemini", "all"):
        download_gemini(state)

    # Persist any state updates (e.g., mistral output_file_id)
    json.dump(state, open(STATE, "w"), indent=2)
    log("=== download_expand.py done ===")


if __name__ == "__main__":
    main()
