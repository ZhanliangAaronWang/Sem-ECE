"""Phase 4 — PopQA generation batch inputs.

500 questions × 50 samples per provider. OpenAI / Mistral / Gemini only (xAI locked).
PopQA answers are short entities → MAX_TOKENS = 256 is plenty.
"""
import os, json

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
INPUT = os.path.join(CAL_BASE, "data", "phase4", "popqa_preprocessed.jsonl")
OUT_DIR = os.path.join(BASE, "batch_inputs")
os.makedirs(OUT_DIR, exist_ok=True)

SYSTEM_PROMPT = """You are answering questions for a research benchmark. Be concise and precise.

Your response MUST end with EXACTLY these two lines, with nothing after them:
Answer: <your final answer>
Confidence: <integer between 0 and 100>%

Keep <your final answer> as short as possible — ideally a single name, number, date, or short phrase. Do not put explanations or reasoning on the Answer line itself.

If you genuinely do not know, write:
Answer: I don't know
Confidence: 0%"""

N_SAMPLES = 50
MAX_TOKENS = 256  # PopQA answers are short entities

questions = [json.loads(l) for l in open(INPUT)]
print(f"Loaded {len(questions)} questions", flush=True)


def build_openai():
    """7 sub-batches per question via n-sampling (6×n=8 + 1×n=2 = 50)."""
    for ci in range(7):
        n = 8 if ci < 6 else 2
        rows = []
        for q in questions:
            rows.append({
                "custom_id": f"{q['qid']}__chunk{ci}",
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": "gpt-5.4",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": q["question_final"]},
                    ],
                    "max_completion_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "reasoning_effort": "none",
                    "n": n,
                    "seed": ci,
                },
            })
        path = os.path.join(OUT_DIR, f"openai_popqa_chunk{ci}.jsonl")
        with open(path, "w") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  openai: {len(questions)*7} rows -> 7 chunks", flush=True)


def build_gemini():
    rows = []
    for q in questions:
        for si in range(N_SAMPLES):
            rows.append({
                "custom_id": f"{q['qid']}__sample{si:02d}",
                "contents": q["question_final"],
                "config": {
                    "system_instruction": SYSTEM_PROMPT,
                    "max_output_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "thinking_config": {"thinking_budget": 0},
                    "seed": si,
                },
            })
    path = os.path.join(OUT_DIR, "gemini_popqa.jsonl")
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  gemini: {len(rows)} rows -> {path}", flush=True)


def build_mistral():
    rows = []
    for q in questions:
        for si in range(N_SAMPLES):
            rows.append({
                "custom_id": f"{q['qid']}__sample{si:02d}",
                "body": {
                    "model": "mistral-large-latest",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": q["question_final"]},
                    ],
                    "max_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "random_seed": si,
                },
            })
    path = os.path.join(OUT_DIR, "mistral_popqa.jsonl")
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  mistral: {len(rows)} rows -> {path}", flush=True)


build_openai()
build_gemini()
build_mistral()

nq = len(questions)
print(f"\n=== Cost Estimate (Phase 4 PopQA) ===")
print(f"  Questions: {nq}  Samples: {N_SAMPLES}")
for prov, in_price, out_price in [
    ("openai (gpt-5.4 batch)", 1.25, 10.0),
    ("gemini (flash batch)", 0.10, 0.40),
    ("mistral (batch)", 2.0, 6.0),
]:
    calls = nq * N_SAMPLES
    in_tok = 80 * calls  # short question
    out_tok = 60 * calls  # short answer + "Confidence: X%"
    cost = (in_tok * in_price * 0.5 + out_tok * out_price * 0.5) / 1e6
    print(f"  {prov:30s}: {calls:,} calls, ~${cost:.2f}")
