"""Phase 4 expansion — build batch inputs for 1500 NEW PopQA questions only.

Names outputs with `_expand_` marker so they don't clobber the original 500-Q batches.
After submission + collection, the prep scripts pick up both original + expand outputs.
"""
import os, json

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
INPUT = os.path.join(CAL_BASE, "data", "phase4", "popqa_preprocessed_expand.jsonl")
OUT_DIR = os.path.join(BASE, "batch_inputs")
os.makedirs(OUT_DIR, exist_ok=True)

SYSTEM_PROMPT = """You are answering questions for a research benchmark. Be concise and precise.

Your response MUST end with EXACTLY these two lines, with nothing after them:
Answer: <your final answer>
Confidence: <integer between 0 and 100>%

Keep <your final answer> as short as possible — ideally a single name, number, date, or short phrase. Do not put explanations or reasoning on the Answer line itself.

If you genuinely do not know, write:
Answer: I don't know
Confidence: 0%"""

N_SAMPLES = 50
MAX_TOKENS = 256

questions = [json.loads(l) for l in open(INPUT)]
print(f"Loaded {len(questions)} expansion questions", flush=True)


def build_openai():
    for ci in range(7):
        n = 8 if ci < 6 else 2
        rows = []
        for q in questions:
            rows.append({
                "custom_id": f"{q['qid']}__chunk{ci}",
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": "gpt-5.4",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": q["question_final"]},
                    ],
                    "max_completion_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "reasoning_effort": "none",
                    "n": n,
                    "seed": ci,
                },
            })
        path = os.path.join(OUT_DIR, f"openai_popqa_expand_chunk{ci}.jsonl")
        with open(path, "w") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  openai: {len(questions)*7} rows -> 7 expand chunks", flush=True)


def build_gemini():
    rows = []
    for q in questions:
        for si in range(N_SAMPLES):
            rows.append({
                "custom_id": f"{q['qid']}__sample{si:02d}",
                "contents": q["question_final"],
                "config": {
                    "system_instruction": SYSTEM_PROMPT,
                    "max_output_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "thinking_config": {"thinking_budget": 0},
                    "seed": si,
                },
            })
    path = os.path.join(OUT_DIR, "gemini_popqa_expand.jsonl")
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  gemini: {len(rows)} rows -> {path}", flush=True)


def build_mistral():
    rows = []
    for q in questions:
        for si in range(N_SAMPLES):
            rows.append({
                "custom_id": f"{q['qid']}__sample{si:02d}",
                "body": {
                    "model": "mistral-large-latest",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": q["question_final"]},
                    ],
                    "max_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "random_seed": si,
                },
            })
    path = os.path.join(OUT_DIR, "mistral_popqa_expand.jsonl")
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  mistral: {len(rows)} rows -> {path}", flush=True)


build_openai()
build_gemini()
build_mistral()
