"""Build xAI PopQA generation batch input — was previously skipped, adding now.

2000 questions × 50 samples = 100,000 rows.
max_tokens=16384 (no truncation; PopQA answers are typically short but allow buffer).
"""
import os, json

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
INPUT = os.path.join(CAL_BASE, "data", "phase4", "popqa_preprocessed.jsonl")
OUT = os.path.join(BASE, "batch_inputs", "xai_popqa.jsonl")
os.makedirs(os.path.dirname(OUT), exist_ok=True)

SYSTEM_PROMPT = """You are answering questions for a research benchmark. Be concise and precise.

Your response MUST end with EXACTLY these two lines, with nothing after them:
Answer: <your final answer>
Confidence: <integer between 0 and 100>%

Keep <your final answer> as short as possible — ideally a single name, number, date, or short phrase. Do not put explanations or reasoning on the Answer line itself.

If you genuinely do not know, write:
Answer: I don't know
Confidence: 0%"""

N_SAMPLES = 50
MAX_TOKENS = 16384

questions = [json.loads(l) for l in open(INPUT)]
print(f"Loaded {len(questions)} PopQA questions", flush=True)

n = 0
with open(OUT, "w") as f:
    for q in questions:
        for si in range(N_SAMPLES):
            row = {
                "custom_id": f"{q['qid']}__sample{si:02d}",
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": "grok-4.20-0309-non-reasoning",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": q["question_final"]},
                    ],
                    "max_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "seed": si,
                },
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            n += 1

print(f"Wrote {n} rows -> {OUT}", flush=True)
assert n == len(questions) * N_SAMPLES
