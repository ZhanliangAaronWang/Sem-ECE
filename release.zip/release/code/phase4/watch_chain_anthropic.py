"""Phase 4 PopQA Anthropic full chain.

Steps (single-shot SLURM job):
  1. submit_anthropic_popqa.py — submit + poll + download Anthropic batch
  2. prep_anthropic.py
  3. submit_anthropic_chunked.py (clustering)
  4. poll clustering chunks
  5. collect_anthropic.py
  6. prep_and_submit.py --providers anthropic --submit (grading)
  7. poll grading
  8. collect_and_check.py --providers anthropic
  9. compute_confidence.py + compute_ece.py (full 5-provider table)

Writes phase4/.pipeline_done_anthropic when complete.
"""
import os, json, time, subprocess
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI
client = OpenAI()

P4 = os.path.join(ROOT, "phase4")
POLL = 300
TERMINAL = {"completed", "failed", "expired", "cancelled"}
DONE_MARKER = os.path.join(P4, ".pipeline_done_anthropic")


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def run(cmd):
    log(f"$ {cmd}")
    r = subprocess.run(cmd, shell=True, cwd=ROOT)
    if r.returncode != 0:
        raise RuntimeError(f"FAILED: {cmd}")


def poll_until_done(batch_id, label):
    while True:
        b = client.batches.retrieve(batch_id)
        rc = b.request_counts
        log(f"  {label}: {b.status} {rc.completed}/{rc.total}")
        if b.status in TERMINAL:
            return b
        time.sleep(POLL)


def main():
    # Step 1: anthropic generation batch (script does its own polling+download)
    run("python phase4/submit_anthropic_popqa.py")

    # Step 2: prep
    run("python phase4/clustering/prep_anthropic.py")

    # Step 3: submit clustering
    run("python phase4/clustering/submit_anthropic_chunked.py")

    # Step 4: poll clustering chunks
    state_path = os.path.join(P4, "clustering", "anthropic_chunks.json")
    state = json.load(open(state_path))
    for c in state["chunks"]:
        b = poll_until_done(c["batch_id"], f"anthropic_cluster_c{c['chunk']}")
        c["final_status"] = b.status
        if b.status == "completed":
            c["output_file_id"] = b.output_file_id
            c["error_file_id"] = b.error_file_id
    with open(state_path, "w") as f:
        json.dump(state, f, indent=2)

    # Step 5: collect
    run("python phase4/clustering/collect_anthropic.py")

    # Step 6: submit grading
    run("python phase4/grading/prep_and_submit.py --providers anthropic --submit")

    # Step 7: poll grading
    ids = json.load(open(os.path.join(P4, "grading", "batch_ids.json")))
    bid = ids.get("anthropic", {}).get("batch_id")
    if not bid:
        raise RuntimeError("no anthropic batch_id in grading/batch_ids.json")
    poll_until_done(bid, "anthropic_grade")

    # Step 8: collect grading
    run("python phase4/grading/collect_and_check.py --providers anthropic")

    # Step 9: compute confidence + ECE for full set
    run("python phase4/confidence/compute_confidence.py")
    run("python phase4/confidence/compute_ece.py")

    with open(DONE_MARKER, "w") as f:
        f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
    log("P4 anthropic PIPELINE DONE")


if __name__ == "__main__":
    main()
