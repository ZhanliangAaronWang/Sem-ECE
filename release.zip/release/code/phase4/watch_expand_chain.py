"""P4 expansion watcher:
  - every 5 min: poll all batches (OpenAI / Mistral / Gemini)
  - every 30 min: retry submit_expand.py (idempotent — fills Gemini quota as it resets)
  - exits when all 3 providers done; writes .expand_batches_done marker
Downstream merge/cluster/grade/ECE is a separate manual step after this marker appears.
"""
import os, json, time, subprocess
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

P4 = os.path.join(ROOT, "phase4")
STATE = os.path.join(P4, "batch_state_expand.json")
MARKER = os.path.join(P4, ".expand_batches_done")

POLL_EVERY = 300
SUBMIT_RETRY_EVERY = 1800
N_GEMINI_EXPECTED = 15


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def try_submit_gemini():
    try:
        r = subprocess.run(
            "python phase4/submit_expand.py 2>&1 | tail -30",
            shell=True, cwd=ROOT, capture_output=True, text=True, timeout=600
        )
        if r.stdout:
            log(f"submit result tail: {r.stdout.strip()[-800:]}")
    except subprocess.TimeoutExpired:
        log("submit attempt timed out")


def all_gemini_submitted(state):
    return len(state.get("gemini", {}).get("batches", [])) >= N_GEMINI_EXPECTED


def poll_all(state):
    from openai import OpenAI
    from google import genai
    from mistralai.client import Mistral

    oa = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    gm = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])
    ms = Mistral(api_key=os.environ["MISTRAL_API_KEY"])

    TERM_OA = {"completed","failed","expired","cancelled"}
    TERM_GM = {"job_state_succeeded","job_state_failed","job_state_cancelled","job_state_expired",
               "succeeded","failed","cancelled","expired"}

    all_done = True
    lines = []

    for c in state.get("openai", {}).get("chunks", []):
        try:
            b = oa.batches.retrieve(c["batch_id"])
            rc = b.request_counts
            lines.append(f"  openai c{c['chunk']}: {b.status} {rc.completed}/{rc.total}")
            if b.status not in TERM_OA:
                all_done = False
            if b.status == "completed" and "output_file_id" not in c:
                c["output_file_id"] = b.output_file_id
                c["error_file_id"] = b.error_file_id
            c["final_status"] = b.status
        except Exception as e:
            lines.append(f"  openai c{c['chunk']}: ERR {str(e)[:80]}")
            all_done = False

    for c in state.get("mistral", {}).get("chunks", []):
        try:
            b = ms.batch.jobs.get(job_id=c["batch_id"])
            lines.append(f"  mistral c{c['chunk']}: {b.status} {b.completed_requests or 0}/{b.total_requests or 0}")
            if b.status.lower() not in TERM_OA:
                all_done = False
            c["final_status"] = b.status
        except Exception as e:
            lines.append(f"  mistral c{c['chunk']}: ERR {str(e)[:80]}")
            all_done = False

    if not all_gemini_submitted(state):
        all_done = False
        lines.append(f"  gemini: only {len(state.get('gemini',{}).get('batches',[]))}/{N_GEMINI_EXPECTED} submitted")
    for i, b in enumerate(state.get("gemini", {}).get("batches", [])):
        try:
            job = gm.batches.get(name=b["name"])
            status = job.state.name if hasattr(job.state, "name") else str(job.state)
            lines.append(f"  gemini b{i}: {status}")
            if status.lower() not in TERM_GM:
                all_done = False
            b["final_status"] = status
            if "succeeded" in status.lower() and hasattr(job, "dest") and job.dest is not None:
                b["dest"] = str(job.dest)
        except Exception as e:
            lines.append(f"  gemini b{i}: ERR {str(e)[:80]}")
            all_done = False

    return all_done, lines


def save_state(state):
    with open(STATE, "w") as f:
        json.dump(state, f, indent=2)


def main():
    log("=== P4 expansion watcher started ===")
    last_submit_try = 0

    while True:
        with open(STATE) as f:
            state = json.load(f)

        if not all_gemini_submitted(state) and (time.time() - last_submit_try) >= SUBMIT_RETRY_EVERY:
            log(f"Attempting gemini submit (have {len(state.get('gemini',{}).get('batches',[]))}/{N_GEMINI_EXPECTED})")
            try_submit_gemini()
            last_submit_try = time.time()
            with open(STATE) as f:
                state = json.load(f)

        all_done, lines = poll_all(state)
        log("status:")
        for l in lines:
            print(l, flush=True)
        save_state(state)

        if all_done:
            log("=== ALL BATCHES DONE ===")
            with open(MARKER, "w") as f:
                f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
            log(f"Marker written -> {MARKER}")
            break

        time.sleep(POLL_EVERY)


if __name__ == "__main__":
    main()
