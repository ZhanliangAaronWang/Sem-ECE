"""Build Phase 4 (PopQA) generation batch input for Anthropic claude-opus-4-6.

Targets the same 500-Q subset that openai/mistral/gemini ran on (loaded from
mistral_popqa.jsonl, which has the canonical 500 qids since mistral preserved
all 500 in its confidence file).

  - temperature 1.0, thinking off (param omitted)
  - system prompt identical to other providers
  - 50 samples per question
  - max_tokens = 16384 (PopQA answers are short; large cap is safety)

Output: phase4/batch_inputs/anthropic_popqa.jsonl (25,000 rows)
"""
import os, json

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
GOLD = os.path.join(CAL_BASE, "data", "phase4", "popqa_preprocessed.jsonl")
# qid universe: read from mistral_popqa.jsonl (the original 500 Q batch input)
QID_SOURCE = os.path.join(BASE, "batch_inputs", "mistral_popqa.jsonl")
OUT = os.path.join(BASE, "batch_inputs", "anthropic_popqa.jsonl")
os.makedirs(os.path.dirname(OUT), exist_ok=True)

SYSTEM_PROMPT = """You are answering questions for a research benchmark. Be concise and precise.

Your response MUST end with EXACTLY these two lines, with nothing after them:
Answer: <your final answer>
Confidence: <integer between 0 and 100>%

Keep <your final answer> as short as possible — ideally a single name, number, date, or short phrase. Do not put explanations or reasoning on the Answer line itself.

If you genuinely do not know, write:
Answer: I don't know
Confidence: 0%"""

N_SAMPLES = 50
MAX_TOKENS = 16384

# Get the 500-Q subset from mistral's batch input (canonical original PopQA set)
target_qids = set()
with open(QID_SOURCE) as f:
    for line in f:
        r = json.loads(line)
        cid = r.get("custom_id", "")
        qid = cid.rsplit("__sample", 1)[0]
        target_qids.add(qid)
print(f"Target qids from mistral source: {len(target_qids)}", flush=True)

# Load gold
gold = {}
with open(GOLD) as f:
    for line in f:
        d = json.loads(line)
        gold[d["qid"]] = d
print(f"Loaded {len(gold)} PopQA gold rows", flush=True)

# Filter to target subset
selected = [gold[q] for q in sorted(target_qids) if q in gold]
print(f"Selected {len(selected)} questions", flush=True)
assert len(selected) == len(target_qids), "qid mismatch with gold"

n = 0
with open(OUT, "w") as f:
    for q in selected:
        for si in range(N_SAMPLES):
            row = {
                "custom_id": f"{q['qid']}__sample{si:02d}",
                "params": {
                    "model": "claude-opus-4-6",
                    "max_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "system": SYSTEM_PROMPT,
                    "messages": [
                        {"role": "user", "content": q["question_final"]},
                    ],
                },
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            n += 1

print(f"Wrote {n} rows -> {OUT}", flush=True)
assert n == len(selected) * N_SAMPLES
