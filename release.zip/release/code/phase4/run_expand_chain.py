"""Chain runner for the PopQA expansion pipeline.

Runs end-to-end:
  1. Poll 9 clustering batches (3 providers × 3 chunks each) every 3 min until all complete.
  2. Run collect_*.py for each provider (writes *_popqa_clustered.jsonl with ~2000 rows).
  3. Submit grading batches (3 providers, ~2000 rows each).
  4. Poll 3 grading batches every 3 min until complete.
  5. Run collect_and_check.py for grading (writes *_popqa_graded.jsonl).
  6. Run compute_confidence.py for all 3 providers.
  7. Re-run experiment_n_sweep.py + experiment_bootstrap_ci.py + make_ece_figure.py.

All log lines stream to phase4/logs/expand_chain_master.log AND stdout.
"""
import os, json, time, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LOG = os.path.join(ROOT, "phase4", "logs", "expand_chain_master.log")
STATE_DIR = os.path.join(ROOT, "phase4", "clustering")

# Per-phase provider lists: openai already past cluster+grading-submit (manual fast-track),
# so it only needs to be polled at the grading stage and collected with everyone else.
ALL_PROVIDERS    = ["openai", "gemini", "mistral"]
CLUSTER_PROVIDERS = ["gemini", "mistral"]   # who still needs cluster wait + collect
GRADE_SUBMIT_PROVIDERS = ["gemini", "mistral"]   # who still needs grading submit

POLL_INTERVAL = 180   # 3 min
TERMINAL = {"completed", "failed", "expired", "cancelled"}


def log(m):
    line = f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}] {m}"
    print(line, flush=True)
    with open(LOG, "a") as f:
        f.write(line + "\n")


def run(cmd, cwd=ROOT):
    log(f"$ {cmd}  (cwd={cwd})")
    r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    log(f"  exit={r.returncode}")
    if r.stdout:
        log("  stdout (last 50 lines):")
        for line in r.stdout.splitlines()[-50:]:
            log(f"    {line}")
    if r.stderr.strip():
        log("  stderr (last 30 lines):")
        for line in r.stderr.splitlines()[-30:]:
            log(f"    {line}")
    if r.returncode != 0:
        raise RuntimeError(f"command failed: {cmd}")
    return r


# ---------------------------------------------------------------------------
def phase1_wait_clustering():
    log("=" * 80)
    log("PHASE 1: poll clustering batches")
    log("=" * 80)

    sys.path.insert(0, ROOT)
    from dotenv import load_dotenv
    load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)
    from openai import OpenAI
    c = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

    while True:
        all_done = True
        any_failed = False
        summary = []
        for prov in CLUSTER_PROVIDERS:
            state_path = os.path.join(STATE_DIR, f"{prov}_chunks.json")
            with open(state_path) as f:
                st = json.load(f)
            for ch in st["chunks"]:
                bid = ch["batch_id"]
                try:
                    b = c.batches.retrieve(bid)
                except Exception as e:
                    summary.append(f"  {prov} c{ch['chunk']}: ERR {str(e)[:80]}")
                    all_done = False
                    continue
                rc = b.request_counts
                summary.append(f"  {prov} c{ch['chunk']}: {b.status} {rc.completed}/{rc.total} fail={rc.failed}")
                if b.status not in TERMINAL:
                    all_done = False
                if b.status in ("failed", "expired", "cancelled"):
                    any_failed = True
                if b.status == "completed":
                    ch["final_status"] = b.status
                    ch["output_file_id"] = b.output_file_id
                    ch["error_file_id"] = b.error_file_id
            with open(state_path, "w") as f:
                json.dump(st, f, indent=2)

        log("status:")
        for s in summary:
            log(s)

        if any_failed:
            raise RuntimeError("one or more clustering batches failed/expired/cancelled — abort")
        if all_done:
            log("=== ALL CLUSTERING BATCHES COMPLETED ===")
            return
        time.sleep(POLL_INTERVAL)


def phase2_collect_clustering():
    log("=" * 80)
    log("PHASE 2: collect clustering outputs")
    log("=" * 80)
    for prov in CLUSTER_PROVIDERS:
        run(f"python3 collect_{prov}.py", cwd=os.path.join(ROOT, "phase4", "clustering"))


def phase3_submit_grading():
    log("=" * 80)
    log("PHASE 3: submit grading batches")
    log("=" * 80)
    if not GRADE_SUBMIT_PROVIDERS:
        log("  no providers to submit; skip")
        return
    run("python3 prep_and_submit.py --providers " + " ".join(GRADE_SUBMIT_PROVIDERS) + " --submit",
        cwd=os.path.join(ROOT, "phase4", "grading"))


def phase4_wait_grading():
    log("=" * 80)
    log("PHASE 4: poll grading batches")
    log("=" * 80)

    from dotenv import load_dotenv
    load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)
    from openai import OpenAI
    c = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

    bids_path = os.path.join(ROOT, "phase4", "grading", "batch_ids.json")
    with open(bids_path) as f:
        bids = json.load(f)

    while True:
        all_done = True
        any_failed = False
        summary = []
        for prov, info in bids.items():
            if prov not in ALL_PROVIDERS:
                continue
            try:
                b = c.batches.retrieve(info["batch_id"])
            except Exception as e:
                summary.append(f"  {prov}: ERR {str(e)[:80]}")
                all_done = False
                continue
            rc = b.request_counts
            summary.append(f"  {prov}: {b.status} {rc.completed}/{rc.total} fail={rc.failed}")
            if b.status not in TERMINAL:
                all_done = False
            if b.status in ("failed", "expired", "cancelled"):
                any_failed = True
        log("status:")
        for s in summary:
            log(s)
        if any_failed:
            raise RuntimeError("one or more grading batches failed/expired/cancelled — abort")
        if all_done:
            log("=== ALL GRADING BATCHES COMPLETED ===")
            return
        time.sleep(POLL_INTERVAL)


def phase5_collect_grading():
    log("=" * 80)
    log("PHASE 5: collect grading outputs")
    log("=" * 80)
    run("python3 collect_and_check.py --providers " + " ".join(ALL_PROVIDERS),
        cwd=os.path.join(ROOT, "phase4", "grading"))


def phase6_compute_confidence():
    log("=" * 80)
    log("PHASE 6: compute confidence")
    log("=" * 80)
    # compute_confidence.py is in phase4/confidence/, recompute for all providers (it's idempotent).
    run("python3 compute_confidence.py", cwd=os.path.join(ROOT, "phase4", "confidence"))


def phase7_replot():
    log("=" * 80)
    log("PHASE 7: re-run plots and bootstrap CIs")
    log("=" * 80)
    run("python3 experiment_n_sweep.py", cwd=ROOT)
    run("python3 experiment_bootstrap_ci.py", cwd=ROOT)
    run("python3 make_ece_figure.py", cwd=ROOT)


def main():
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    log("=" * 80)
    log(f"PopQA expand chain runner started ({time.strftime('%Y-%m-%dT%H:%M:%S')})")
    log("=" * 80)

    phase1_wait_clustering()
    phase2_collect_clustering()
    phase3_submit_grading()
    phase4_wait_grading()
    phase5_collect_grading()
    phase6_compute_confidence()
    phase7_replot()

    log("=" * 80)
    log("=== PIPELINE COMPLETE ===")
    log("=" * 80)


if __name__ == "__main__":
    main()
