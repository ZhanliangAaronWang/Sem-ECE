"""Poll anthropic n=100 generation batches -> {ds}_anthropic_raw.jsonl ({custom_id,text})."""
import os, json, time, argparse
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))
from anthropic import Anthropic

OUTD = os.path.join(BASE, "batch_outputs")


def text_of(rec):
    res = rec.get("result") or {}
    if res.get("type") != "succeeded":
        return None
    for b in (res.get("message") or {}).get("content", []):
        if b.get("type") == "text":
            return b.get("text")
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="+", default=["simpleqa", "hle", "popqa"])
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--interval", type=int, default=900)
    args = ap.parse_args()
    client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

    while True:
        all_done = True
        for ds in args.datasets:
            state_f = os.path.join(OUTD, f"{ds}_anthropic_jobs.json")
            if not os.path.exists(state_f):
                continue
            jobs = json.load(open(state_f))
            tag = "" if ds == "simpleqa" else f"{ds}_"
            out = os.path.join(OUTD, f"{tag}anthropic_raw.jsonl")
            for j in jobs:
                if j.get("collected"):
                    continue
                s = client.messages.batches.retrieve(j["batch_id"])
                c = s.request_counts
                print(f"  {ds} {j['batch_id'][:16]}…: {s.processing_status} ok={c.succeeded} proc={c.processing} err={c.errored}", flush=True)
                if s.processing_status != "ended":
                    all_done = False
                    continue
                n = 0
                with open(out, "a") as f:
                    for res in client.messages.batches.results(j["batch_id"]):
                        d = res.model_dump()
                        t = text_of(d)
                        if t:
                            f.write(json.dumps({"custom_id": d["custom_id"], "text": t}, ensure_ascii=False) + "\n")
                            n += 1
                j["collected"] = True
                with open(state_f, "w") as f:
                    json.dump(jobs, f, indent=1)
                print(f"    {ds}: wrote {n} samples", flush=True)
        if all_done or not args.loop:
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
