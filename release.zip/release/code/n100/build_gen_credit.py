"""Build n=100 extension generation inputs for anthropic + xai (credit-gated).

Reads questions AND old sample count from each existing clustered file, and
generates exactly (100 - old_n) new samples per question so every cell reaches
n=100. Sample indices run old_n..99. Prompts byte-identical to April; max_tokens
per dataset (256 simpleqa/popqa, 512 hle). Temp 1.0, no seed (both providers
draw independent stochastic samples).

Outputs:
  anthropic -> batch_inputs/{ds}_anthropic_n100.jsonl   (Anthropic {custom_id, params})
  xai       -> batch_inputs/{ds}_xai_n100.jsonl          (async {custom_id, body})
"""
import os, json, argparse

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
SYSTEM = json.loads(open(os.path.join(ROOT, "phase1", "batch_inputs",
                                      "openai_simpleqa.jsonl")).readline())["body"]["messages"][0]["content"]

DATASETS = {
    "simpleqa": dict(phase="phase1", clus="{p}_simpleqa_clustered.jsonl", max_tok=256),
    "hle":      dict(phase="phase2", clus="{p}_simpleqa_clustered.jsonl", max_tok=512),
    "popqa":    dict(phase="phase4", clus="{p}_popqa_clustered.jsonl",    max_tok=256),
}
MODELS = {"anthropic": "claude-opus-4-6", "xai": "grok-4.20-0309-non-reasoning"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="+", default=["simpleqa", "hle", "popqa"])
    ap.add_argument("--providers", nargs="+", default=["anthropic", "xai"])
    args = ap.parse_args()
    os.makedirs(os.path.join(BASE, "batch_inputs"), exist_ok=True)

    for ds in args.datasets:
        cfg = DATASETS[ds]; maxt = cfg["max_tok"]
        for prov in args.providers:
            src = os.path.join(ROOT, cfg["phase"], "clustering", cfg["clus"].format(p=prov))
            if not os.path.exists(src):
                print(f"[{ds}/{prov}] no clustered file, skip"); continue
            rows = [json.loads(l) for l in open(src)]
            old_n = rows[0]["n_samples"]
            new_idx = list(range(old_n, 100))  # e.g. 50..99, or 46..99 for hle anthropic
            path = os.path.join(BASE, "batch_inputs", f"{ds}_{prov}_n100.jsonl")
            n = 0
            with open(path, "w") as f:
                for r in rows:
                    q = r["question"]
                    for s in new_idx:
                        cid = f"{r['id']}__sample{s:02d}"
                        if prov == "anthropic":
                            obj = {"custom_id": cid, "params": {
                                "model": MODELS[prov], "max_tokens": maxt, "temperature": 1.0,
                                "system": SYSTEM,
                                "messages": [{"role": "user", "content": q}]}}
                        else:  # xai async format
                            obj = {"custom_id": cid, "body": {
                                "messages": [{"role": "system", "content": SYSTEM},
                                             {"role": "user", "content": q}],
                                "max_tokens": maxt, "temperature": 1.0, "top_p": 1.0}}
                        f.write(json.dumps(obj, ensure_ascii=False) + "\n")
                        n += 1
            print(f"[{ds}/{prov}] old_n={old_n} Q={len(rows)} new/Q={len(new_idx)} -> {n} rows")


if __name__ == "__main__":
    main()
