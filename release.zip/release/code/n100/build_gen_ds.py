"""Build +50-sample generation inputs for HLE (phase2) and PopQA (phase4).

Questions are read from the EXISTING clustered files so we regenerate exactly
the analyzed question set. Models / decode configs identical to the April runs
(system prompt byte-identical; only seeds are new). HLE uses max_tokens=512,
PopQA 256, matching the originals.

Outputs: batch_inputs/{ds}_{provider}_n100(.jsonl | _chunkNN.jsonl)
Providers default to the 3 credit-unblocked ones. xAI/Anthropic need credit.
"""
import os, json, argparse

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
SYSTEM = json.loads(open(os.path.join(ROOT, "phase1", "batch_inputs",
                                      "openai_simpleqa.jsonl")).readline())["body"]["messages"][0]["content"]

DATASETS = {
    "hle":   dict(phase="phase2", clus="{p}_simpleqa_clustered.jsonl", max_tok=512),
    "popqa": dict(phase="phase4", clus="{p}_popqa_clustered.jsonl",    max_tok=256),
}


def questions_from_clustered(phase, clus, prov):
    path = os.path.join(ROOT, phase, "clustering", clus.format(p=prov))
    if not os.path.exists(path):
        return None
    out = []
    with open(path) as f:
        for line in f:
            r = json.loads(line)
            out.append((r["id"], r["question"]))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="+", default=["hle", "popqa"])
    ap.add_argument("--providers", nargs="+", default=["openai", "gemini", "mistral"])
    args = ap.parse_args()
    os.makedirs(os.path.join(BASE, "batch_inputs"), exist_ok=True)

    for ds in args.datasets:
        cfg = DATASETS[ds]
        maxt = cfg["max_tok"]
        for prov in args.providers:
            qs = questions_from_clustered(cfg["phase"], cfg["clus"], prov)
            if qs is None:
                print(f"[{ds}/{prov}] no clustered file, skip"); continue

            if prov == "openai":
                path = os.path.join(BASE, "batch_inputs", f"{ds}_openai_n100.jsonl")
                n = 0
                with open(path, "w") as f:
                    for qid, q in qs:
                        for chunk_idx in range(7, 14):
                            n_val = 8 if chunk_idx < 13 else 2
                            f.write(json.dumps({
                                "custom_id": f"{qid}__chunk{chunk_idx}",
                                "method": "POST", "url": "/v1/chat/completions",
                                "body": {"model": "gpt-5.4",
                                         "messages": [{"role": "system", "content": SYSTEM},
                                                      {"role": "user", "content": q}],
                                         "max_completion_tokens": maxt, "temperature": 1.0,
                                         "top_p": 1.0, "reasoning_effort": "none",
                                         "n": n_val, "seed": chunk_idx}}, ensure_ascii=False) + "\n")
                            n += 1
                print(f"[{ds}/openai] {len(qs)} Q -> {n} rows")

            elif prov == "gemini":
                path = os.path.join(BASE, "batch_inputs", f"{ds}_gemini_n100.jsonl")
                n = 0
                with open(path, "w") as f:
                    for qid, q in qs:
                        for s in range(50, 100):
                            f.write(json.dumps({
                                "custom_id": f"{qid}__sample{s:02d}",
                                "contents": q,
                                "config": {"system_instruction": SYSTEM,
                                           "max_output_tokens": maxt, "temperature": 1.0,
                                           "top_p": 1.0,
                                           "thinking_config": {"thinking_budget": 0},
                                           "seed": s}}, ensure_ascii=False) + "\n")
                            n += 1
                print(f"[{ds}/gemini] {len(qs)} Q -> {n} rows")

            elif prov == "mistral":
                rows = []
                for qid, q in qs:
                    for s in range(50, 100):
                        rows.append({"custom_id": f"{qid}__sample{s:02d}",
                                     "body": {"messages": [{"role": "system", "content": SYSTEM},
                                                           {"role": "user", "content": q}],
                                              "max_tokens": maxt, "temperature": 1.0,
                                              "top_p": 1.0, "random_seed": s}})
                nch = 0
                for ci in range(0, len(rows), 20000):
                    p = os.path.join(BASE, "batch_inputs", f"{ds}_mistral_n100_chunk{ci//20000:02d}.jsonl")
                    with open(p, "w") as f:
                        for r in rows[ci:ci+20000]:
                            f.write(json.dumps(r, ensure_ascii=False) + "\n")
                    nch += 1
                print(f"[{ds}/mistral] {len(qs)} Q -> {len(rows)} rows in {nch} chunks")


if __name__ == "__main__":
    main()
