"""Submit n=100 extension generation batches for openai / gemini / mistral.

State per provider in batch_outputs/{provider}_jobs.json; idempotent.
Usage: python submit_all.py [--providers openai gemini mistral]
"""
import os, json, glob, time, argparse
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))

IN = os.path.join(BASE, "batch_inputs")
OUTD = os.path.join(BASE, "batch_outputs")


DS = "simpleqa"

def state_path(p):
    tag = "" if DS == "simpleqa" else f"{DS}_"
    return os.path.join(OUTD, f"{tag}{p}_jobs.json")


def load_state(p):
    if os.path.exists(state_path(p)):
        with open(state_path(p)) as f:
            return json.load(f)
    return {"jobs": []}


def save_state(p, s):
    with open(state_path(p), "w") as f:
        json.dump(s, f, indent=1)


def submit_openai():
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    s = load_state("openai")
    if s["jobs"]:
        print("openai: already submitted"); return
    path = os.path.join(IN, f"{DS}_openai_n100.jsonl")
    with open(path, "rb") as f:
        fobj = client.files.create(file=f, purpose="batch")
    batch = client.batches.create(input_file_id=fobj.id,
                                  endpoint="/v1/chat/completions",
                                  completion_window="24h")
    s["jobs"].append({"file_id": fobj.id, "batch_id": batch.id,
                      "submitted_at": time.strftime("%F %T")})
    save_state("openai", s)
    print(f"openai: batch {batch.id}")


def submit_gemini(chunk_rows=20000):
    from google import genai
    client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])
    s = load_state("gemini")
    done = set()
    for j in s["jobs"]:
        done.update(j["custom_ids"])
    rows = [json.loads(l) for l in open(os.path.join(IN, f"{DS}_gemini_n100.jsonl"))]
    rows = [r for r in rows if r["custom_id"] not in done]
    print(f"gemini: {len(rows)} rows to submit")
    for ci in range(0, len(rows), chunk_rows):
        chunk = rows[ci:ci+chunk_rows]
        inlined = [{"contents": r["contents"], "config": r["config"],
                    "metadata": {"custom_id": r["custom_id"]}} for r in chunk]
        job = client.batches.create(model="gemini-3-flash-preview", src=inlined,
                                    config={"display_name": f"n100_gen_{ci//chunk_rows}"})
        s["jobs"].append({"job_name": job.name, "n_rows": len(chunk),
                          "custom_ids": [r["custom_id"] for r in chunk],
                          "submitted_at": time.strftime("%F %T")})
        save_state("gemini", s)
        print(f"  gemini chunk {ci//chunk_rows}: {job.name} ({len(chunk)} rows)")


def submit_mistral():
    from mistralai.client import Mistral
    client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
    s = load_state("mistral")
    done = {j["chunk"] for j in s["jobs"]}
    for path in sorted(glob.glob(os.path.join(IN, f"{DS}_mistral_n100_chunk*.jsonl"))):
        name = os.path.basename(path)
        if name in done:
            print(f"  {name}: already submitted"); continue
        for attempt in range(3):
            try:
                with open(path, "rb") as f:
                    fobj = client.files.upload(file={"file_name": name, "content": f.read()},
                                               purpose="batch", timeout_ms=600_000)
                job = client.batch.jobs.create(model="mistral-large-latest",
                                               endpoint="/v1/chat/completions",
                                               input_files=[fobj.id], timeout_hours=24)
                s["jobs"].append({"chunk": name, "file_id": fobj.id, "job_id": job.id,
                                  "submitted_at": time.strftime("%F %T")})
                save_state("mistral", s)
                print(f"  {name}: job {job.id}")
                break
            except Exception as e:
                print(f"  {name}: attempt {attempt+1} failed — {str(e)[:120]}")
                time.sleep(30 * (attempt + 1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--providers", nargs="+", default=["openai", "gemini", "mistral"])
    ap.add_argument("--dataset", default="simpleqa")
    args = ap.parse_args()
    global DS
    DS = args.dataset
    os.makedirs(OUTD, exist_ok=True)
    for p in args.providers:
        print(f"── {args.dataset}/{p} ──")
        {"openai": submit_openai, "gemini": submit_gemini, "mistral": submit_mistral}[p]()


if __name__ == "__main__":
    main()
