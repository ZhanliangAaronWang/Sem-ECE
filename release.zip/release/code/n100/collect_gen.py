"""Poll the n=100 generation batches (openai/gemini/mistral), collect raw samples.

Writes batch_outputs/{provider}_raw.jsonl rows: {"custom_id", "text"} — one per
sample (openai rows are exploded from n-choice responses into per-sample rows,
sample index = chunk offset + choice index).

Usage: python collect_gen.py [--loop] [--interval 900]
"""
import os, json, time, argparse
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))

OUTD = os.path.join(BASE, "batch_outputs")
DS = "simpleqa"

def _tag():
    return "" if DS == "simpleqa" else f"{DS}_"

# chunk_idx -> (start_sample_index, n)  for openai chunks 7..13 → samples 50..99
OPENAI_CHUNK_BASE = {}
_s = 50
for ci in range(7, 14):
    n = 8 if ci < 13 else 2
    OPENAI_CHUNK_BASE[ci] = (_s, n)
    _s += n


def load_state(p):
    with open(os.path.join(OUTD, f"{_tag()}{p}_jobs.json")) as f:
        return json.load(f)


def save_state(p, s):
    with open(os.path.join(OUTD, f"{_tag()}{p}_jobs.json"), "w") as f:
        json.dump(s, f, indent=1)


def poll_openai():
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    s = load_state("openai")
    done = True
    for j in s["jobs"]:
        if j.get("collected"):
            continue
        b = client.batches.retrieve(j["batch_id"])
        print(f"  openai {j['batch_id']}: {b.status} "
              f"{getattr(b.request_counts,'completed',0)}/{getattr(b.request_counts,'total',0)}")
        if b.status not in ("completed", "failed", "expired", "cancelled"):
            done = False
            continue
        if b.output_file_id:
            content = client.files.content(b.output_file_id).text
            out = os.path.join(OUTD, f"{_tag()}openai_raw.jsonl")
            with open(out, "a") as f:
                for line in content.splitlines():
                    r = json.loads(line)
                    cid = r["custom_id"]  # {qid}__chunk{ci}
                    qid, chunk = cid.rsplit("__chunk", 1)
                    base, _ = OPENAI_CHUNK_BASE[int(chunk)]
                    body = (r.get("response") or {}).get("body") or {}
                    for k, ch in enumerate(body.get("choices", [])):
                        f.write(json.dumps({
                            "custom_id": f"{qid}__sample{base+k}",
                            "text": ch["message"]["content"]}, ensure_ascii=False) + "\n")
        if b.error_file_id:
            print(f"    NOTE error_file {b.error_file_id}")
        j["collected"] = True
        save_state("openai", s)
    return done


def poll_gemini():
    from google import genai
    client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])
    s = load_state("gemini")
    done = True
    for j in s["jobs"]:
        if j.get("collected"):
            continue
        job = client.batches.get(name=j["job_name"])
        state = str(job.state).split(".")[-1]
        print(f"  gemini {j['job_name'].split('/')[-1][:12]}…: {state}")
        if state not in ("JOB_STATE_SUCCEEDED", "JOB_STATE_FAILED", "JOB_STATE_CANCELLED",
                         "JOB_STATE_EXPIRED"):
            done = False
            continue
        if state == "JOB_STATE_SUCCEEDED":
            dest = getattr(job, "dest", None)
            inlined = getattr(dest, "inlined_responses", None) if dest else None
            out = os.path.join(OUTD, f"{_tag()}gemini_raw.jsonl")
            n_ok = 0
            with open(out, "a") as f:
                for ro in inlined or []:
                    md = getattr(ro, "metadata", None) or {}
                    cid = md.get("custom_id", "")
                    resp = getattr(ro, "response", None)
                    text = None
                    if resp is not None:
                        try:
                            text = resp.text
                        except Exception:
                            text = None
                    if cid and text:
                        f.write(json.dumps({"custom_id": cid, "text": text},
                                           ensure_ascii=False) + "\n")
                        n_ok += 1
            print(f"    wrote {n_ok} samples")
        j["collected"] = True
        save_state("gemini", s)
    return done


def poll_mistral():
    from mistralai.client import Mistral
    client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
    s = load_state("mistral")
    done = True
    for j in s["jobs"]:
        if j.get("collected"):
            continue
        job = client.batch.jobs.get(job_id=j["job_id"])
        status = str(job.status).split(".")[-1].upper()
        comp = getattr(job, "completed_requests", 0) or 0
        tot = getattr(job, "total_requests", 0) or 0
        print(f"  mistral {j['chunk']}: {status} {comp}/{tot}")
        if status not in ("SUCCESS", "FAILED", "CANCELLED", "TIMEOUT_EXCEEDED"):
            done = False
            continue
        ofid = getattr(job, "output_file", None)
        if ofid:
            content = client.files.download(file_id=ofid)
            data = content.read() if hasattr(content, "read") else content
            if isinstance(data, bytes):
                data = data.decode()
            out = os.path.join(OUTD, f"{_tag()}mistral_raw.jsonl")
            n_ok = 0
            with open(out, "a") as f:
                for line in data.splitlines():
                    try:
                        r = json.loads(line)
                        text = r["response"]["body"]["choices"][0]["message"]["content"]
                        f.write(json.dumps({"custom_id": r["custom_id"], "text": text},
                                           ensure_ascii=False) + "\n")
                        n_ok += 1
                    except Exception:
                        pass
            print(f"    wrote {n_ok} samples")
        j["collected"] = True
        save_state("mistral", s)
    return done


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--interval", type=int, default=900)
    ap.add_argument("--dataset", default="simpleqa")
    args = ap.parse_args()
    global DS
    DS = args.dataset
    while True:
        d1 = poll_openai(); d2 = poll_gemini(); d3 = poll_mistral()
        if (d1 and d2 and d3) or not args.loop:
            print("ALL TERMINAL" if (d1 and d2 and d3) else "still running")
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
