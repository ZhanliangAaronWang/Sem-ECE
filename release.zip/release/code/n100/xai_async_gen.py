"""Async xAI n=100 generation (grok-4.20-0309-non-reasoning), per dataset.

Reads batch_inputs/{ds}_xai_n100.jsonl ({custom_id, body}); writes
batch_outputs/{ds}_xai_raw.jsonl ({custom_id, text}). Resumes from existing
output. xAI has no batch API for this model, so we use the real-time endpoint
with bounded concurrency.
"""
import os, json, time, asyncio, argparse
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))
from openai import AsyncOpenAI

client = AsyncOpenAI(api_key=os.environ["XAI_API_KEY"], base_url="https://api.x.ai/v1")
MODEL = "grok-4.20-0309-non-reasoning"
MAX_CONCURRENT = 50
RATE_LIMIT_RPM = 480
DELAY = 60.0 / RATE_LIMIT_RPM


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True)
    args = ap.parse_args()
    ds = args.dataset
    IN = os.path.join(BASE, "batch_inputs", f"{ds}_xai_n100.jsonl")
    tag = "" if ds == "simpleqa" else f"{ds}_"
    OUT = os.path.join(BASE, "batch_outputs", f"{tag}xai_raw.jsonl")

    rows = [json.loads(l) for l in open(IN)]
    done = set()
    if os.path.exists(OUT):
        for l in open(OUT):
            try:
                done.add(json.loads(l)["custom_id"])
            except Exception:
                pass
    remaining = [r for r in rows if r["custom_id"] not in done]
    print(f"[{ds}] {len(rows)} total, {len(done)} done, {len(remaining)} remaining", flush=True)
    if not remaining:
        print("all done"); return

    sem = asyncio.Semaphore(MAX_CONCURRENT)
    rate_lock = asyncio.Lock()
    last = [0.0]
    buf = []
    counter = [0]

    async def one(row):
        body = row["body"]
        async with sem:
            async with rate_lock:
                w = DELAY - (time.monotonic() - last[0])
                if w > 0:
                    await asyncio.sleep(w)
                last[0] = time.monotonic()
            for attempt in range(5):
                try:
                    resp = await client.chat.completions.create(
                        model=MODEL, messages=body["messages"],
                        max_tokens=body.get("max_tokens", 256),
                        temperature=body.get("temperature", 1.0),
                        top_p=body.get("top_p", 1.0))
                    buf.append({"custom_id": row["custom_id"], "text": resp.choices[0].message.content})
                    counter[0] += 1
                    if counter[0] % 1000 == 0:
                        print(f"[{ds}] {counter[0]}/{len(remaining)}", flush=True)
                    return
                except Exception as e:
                    es = str(e)
                    if "429" in es or "rate" in es.lower():
                        await asyncio.sleep(2 ** attempt * 5)
                    elif "500" in es or "503" in es:
                        await asyncio.sleep(2 ** attempt * 2)
                    else:
                        buf.append({"custom_id": row["custom_id"], "text": "", "error": es[:150]})
                        return

    async def flusher():
        while True:
            await asyncio.sleep(10)
            if buf:
                with open(OUT, "a") as f:
                    while buf:
                        f.write(json.dumps(buf.pop(0), ensure_ascii=False) + "\n")

    async def run():
        ft = asyncio.create_task(flusher())
        await asyncio.gather(*[one(r) for r in remaining])
        await asyncio.sleep(1)
        ft.cancel()
        if buf:
            with open(OUT, "a") as f:
                while buf:
                    f.write(json.dumps(buf.pop(0), ensure_ascii=False) + "\n")

    asyncio.run(run())
    print(f"[{ds}] done, {counter[0]} new", flush=True)


if __name__ == "__main__":
    main()
