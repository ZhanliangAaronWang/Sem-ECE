"""Exp 3 figure: 3-panel n-sweep convergence (Sem1 & Sem2 vs n) + gap log-log slope.

Reads the per-dataset RESULTS_convergence_{ds}.md tables (n, Sem1, Sem2, gap).
Panel per dataset; top row = ECE curves converging; annotation of provider set.
Also fits log-log slope of the gap vs n (expect ~ -0.5, Theorem 5.6 rate).
"""
import os, re
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.dirname(os.path.abspath(__file__))
DS = [("simpleqa", "SimpleQA", "openai/gemini/mistral/xai (4)"),
      ("hle", "HLE", "all 5 providers"),
      ("popqa", "PopQA", "all 5 providers")]


def parse(ds):
    n, s1, s2 = [], [], []
    for line in open(os.path.join(BASE, f"RESULTS_convergence_{ds}.md")):
        m = re.match(r"\|\s*(\d+)\s*\|\s*([0-9.]+)\s*\|\s*([0-9.]+)\s*\|\s*([+\-][0-9.]+)", line)
        if m:
            n.append(int(m.group(1))); s1.append(float(m.group(2))); s2.append(float(m.group(3)))
    return np.array(n), np.array(s1), np.array(s2)


fig, axes = plt.subplots(2, 3, figsize=(13, 7), gridspec_kw={"height_ratios": [2, 1]})
slopes = {}
for j, (ds, label, provstr) in enumerate(DS):
    n, s1, s2 = parse(ds)
    ax = axes[0, j]
    ax.plot(n, s1, "o-", color="#d1495b", label="Sem$_1$-ECE", lw=2, ms=5)
    ax.plot(n, s2, "s-", color="#2e86ab", label="Sem$_2$-ECE", lw=2, ms=5)
    ax.set_title(f"{label}\n({provstr})", fontsize=11)
    ax.set_xlabel("n (samples per question)")
    if j == 0:
        ax.set_ylabel("pooled ECE")
    ax.legend(fontsize=9); ax.grid(alpha=0.3)

    # bottom: gap log-log with slope fit
    gap = s1 - s2
    axg = axes[1, j]
    axg.loglog(n, gap, "o-", color="#3c1642", lw=2, ms=4)
    lg = np.polyfit(np.log(n), np.log(gap), 1)
    slopes[ds] = lg[0]
    axg.loglog(n, np.exp(lg[1]) * n ** lg[0], "--", color="gray",
               label=f"slope={lg[0]:.2f}")
    ref = gap[0] * (n / n[0]) ** -0.5
    axg.loglog(n, ref, ":", color="#c0c0c0", label="$-1/2$ ref")
    axg.set_xlabel("n"); axg.legend(fontsize=8); axg.grid(alpha=0.3, which="both")
    if j == 0:
        axg.set_ylabel("Sem$_1$-Sem$_2$ gap")

fig.suptitle("Exp 3: Sem$_1$-ECE and Sem$_2$-ECE converge to a common limit as n: 50 → 100 "
             "(gap shrinks at the $1/\\sqrt{n}$ rate)", fontsize=12)
fig.tight_layout(rect=[0, 0, 1, 0.96])
for ext in ("png", "pdf"):
    fig.savefig(os.path.join(BASE, f"figure_convergence_n100.{ext}"), dpi=150, bbox_inches="tight")
print("slopes (gap vs n, log-log):", {k: round(v, 3) for k, v in slopes.items()})
print("saved figure_convergence_n100.{png,pdf}")
