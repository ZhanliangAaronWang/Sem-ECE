"""Exp 3 pilot — build +50-sample generation inputs for SimpleQA (n: 50→100).

Providers: openai, gemini, mistral. Identical models & decode configs to the
April runs; only the seeds are new so the 50 fresh samples are disjoint:
  - openai : gpt-5.4, chunks 7..13 (6×n=8 + 1×n=2), seed=chunk_idx
  - gemini : gemini-3-flash-preview, per-sample rows, seed 50..99, thinking 0
  - mistral: mistral-large-latest, per-sample rows, random_seed 50..99

System prompt / temperature / top_p / max tokens are read to match the
original batch inputs verbatim.
"""
import os, json

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
DATA = os.path.join(ROOT, "phase1", "data", "simpleqa_full.jsonl")
OUT = os.path.join(BASE, "batch_inputs")

SYSTEM = json.loads(open(os.path.join(ROOT, "phase1", "batch_inputs", "openai_simpleqa.jsonl")).readline())["body"]["messages"][0]["content"]


def main():
    os.makedirs(OUT, exist_ok=True)
    questions = [json.loads(l) for l in open(DATA)]
    print(f"{len(questions)} questions, system prompt {len(SYSTEM)} chars")

    # ── OpenAI: chunks 7..13, seeds 7..13 ──
    path = os.path.join(OUT, "openai_simpleqa_n100.jsonl")
    n = 0
    with open(path, "w") as f:
        for q in questions:
            for chunk_idx in range(7, 14):
                n_val = 8 if chunk_idx < 13 else 2
                f.write(json.dumps({
                    "custom_id": f"{q['id']}__chunk{chunk_idx}",
                    "method": "POST",
                    "url": "/v1/chat/completions",
                    "body": {
                        "model": "gpt-5.4",
                        "messages": [{"role": "system", "content": SYSTEM},
                                     {"role": "user", "content": q["question"]}],
                        "max_completion_tokens": 256,
                        "temperature": 1.0, "top_p": 1.0,
                        "reasoning_effort": "none",
                        "n": n_val, "seed": chunk_idx,
                    },
                }, ensure_ascii=False) + "\n")
                n += 1
    print(f"openai: {n} rows -> {path}")

    # ── Gemini: per-sample rows, seeds 50..99 ──
    path = os.path.join(OUT, "gemini_simpleqa_n100.jsonl")
    n = 0
    with open(path, "w") as f:
        for q in questions:
            for s in range(50, 100):
                f.write(json.dumps({
                    "custom_id": f"{q['id']}__sample{s:02d}",
                    "contents": q["question"],
                    "config": {
                        "system_instruction": SYSTEM,
                        "max_output_tokens": 256,
                        "temperature": 1.0, "top_p": 1.0,
                        "thinking_config": {"thinking_budget": 0},
                        "seed": s,
                    },
                }, ensure_ascii=False) + "\n")
                n += 1
    print(f"gemini: {n} rows -> {path}")

    # ── Mistral: per-sample rows, random_seed 50..99, chunked 20k ──
    rows = []
    for q in questions:
        for s in range(50, 100):
            rows.append({
                "custom_id": f"{q['id']}__sample{s:02d}",
                "body": {
                    "messages": [{"role": "system", "content": SYSTEM},
                                 {"role": "user", "content": q["question"]}],
                    "max_tokens": 256, "temperature": 1.0, "top_p": 1.0,
                    "random_seed": s,
                },
            })
    for ci in range(0, len(rows), 20000):
        path = os.path.join(OUT, f"mistral_simpleqa_n100_chunk{ci//20000:02d}.jsonl")
        with open(path, "w") as f:
            for r in rows[ci:ci+20000]:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"mistral: {len(rows)} rows in {(len(rows)+19999)//20000} chunks")


if __name__ == "__main__":
    main()
