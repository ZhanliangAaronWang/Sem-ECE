"""Merge old 50 + new 50 samples → n=100; build GPT-5.2 clustering batch inputs.

- Answer/confidence extraction follows the original phase1 spec verbatim
  (Answer regex → fallback last-200-chars; Confidence regex → [0,1]).
- Sample order in the merged 100: indices 0-49 = original samples (from the
  phase1 clustered file), 50-99 = new samples. This lets the post-clustering
  drift check compare the two halves directly.
- Clustering prompt: identical system message; user template with N=100.

Usage: python merge_and_build_cluster_inputs.py [--providers gemini ...]
"""
import os, json, re, argparse

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)

DATASETS = {
    "simpleqa": dict(phase="phase1", clus="{p}_simpleqa_clustered.jsonl"),
    "hle":      dict(phase="phase2", clus="{p}_simpleqa_clustered.jsonl"),
    "popqa":    dict(phase="phase4", clus="{p}_popqa_clustered.jsonl"),
}
ANS_RE = re.compile(r"Answer:\s*(.+?)(?=\nConfidence|\Z)", re.DOTALL)
CONF_RE = re.compile(r"Confidence:\s*([0-9]+(?:\.[0-9]+)?)\s*%?")
BAD_ANS = {"see above", "as stated", "as mentioned", "as noted"}

SYSTEM = open(os.path.join(ROOT, "cross_judge", "system_prompt.txt")).read()


def extract(text):
    m = ANS_RE.search(text)
    ans, method = None, "fallback_tail"
    if m:
        cand = m.group(1).strip()
        if cand and cand.lower() not in BAD_ANS:
            ans, method = cand, "answer_line"
    if ans is None:
        ans = text[-200:].strip()
    cm = CONF_RE.search(text)
    conf = None
    if cm:
        conf = max(0.0, min(1.0, float(cm.group(1)) / 100.0))
    return ans, method, conf


def user_message(question, answers):
    n = len(answers)
    lines = [f"Question: {question}", "", f"Answers ({n} total, indexed 0 to {n-1}):"]
    lines += [f"[{i}] {a}" for i, a in enumerate(answers)]
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--providers", nargs="+", default=["openai", "gemini", "mistral"])
    ap.add_argument("--dataset", default="simpleqa")
    args = ap.parse_args()
    ds = args.dataset
    dc = DATASETS[ds]
    tag = "" if ds == "simpleqa" else f"{ds}_"

    os.makedirs(os.path.join(BASE, "generation"), exist_ok=True)
    os.makedirs(os.path.join(BASE, "cluster_inputs"), exist_ok=True)

    for prov in args.providers:
        raw_path = os.path.join(BASE, "batch_outputs", f"{tag}{prov}_raw.jsonl")
        old_path = os.path.join(ROOT, dc["phase"], "clustering", dc["clus"].format(p=prov))
        if not os.path.exists(raw_path):
            print(f"[{prov}] raw not ready, skip"); continue

        new = {}  # qid -> {sample_idx: text}
        with open(raw_path) as f:
            for line in f:
                r = json.loads(line)
                qid, s = r["custom_id"].rsplit("__sample", 1)
                new.setdefault(qid, {})[int(s)] = r["text"]

        n_ok = n_short = 0
        merged_path = os.path.join(BASE, "generation", f"{tag}{prov}_merged100.jsonl")
        cluster_path = os.path.join(BASE, "cluster_inputs", f"{tag}{prov}_clustering100.jsonl")
        with open(old_path) as fin, open(merged_path, "w") as fm, open(cluster_path, "w") as fc:
            for line in fin:
                old = json.loads(line)
                qid = old["id"]
                samples = new.get(qid, {})
                old_n = len(old["answer_extracted"])
                need = 100 - old_n
                if len(samples) < need:
                    n_short += 1
                    continue
                texts = [samples[k] for k in sorted(samples)][:need]
                answers, methods, confs = [], [], []
                for t in texts:
                    a, m, c = extract(t)
                    answers.append(a); methods.append(m); confs.append(c)
                all_results = old["results"] + texts
                all_answers = old["answer_extracted"] + answers
                all_confs = old["confidence_verbalized"] + confs
                fm.write(json.dumps({
                    "id": qid, "question": old["question"], "gold_answer": old["gold_answer"],
                    "model": prov, "n_samples": len(all_answers),
                    "results": all_results, "answer_extracted": all_answers,
                    "confidence_verbalized": all_confs,
                    "extraction_method": old["extraction_method"] + methods,
                    "old_n": len(old["answer_extracted"]),
                }, ensure_ascii=False) + "\n")
                fc.write(json.dumps({
                    "custom_id": f"{prov}__{qid}",
                    "method": "POST", "url": "/v1/chat/completions",
                    "body": {
                        "model": "gpt-5.2",
                        "messages": [{"role": "system", "content": SYSTEM},
                                     {"role": "user", "content": user_message(old["question"], all_answers)}],
                        "reasoning_effort": "none",
                        "temperature": 0.0,
                        "max_completion_tokens": 3000,
                        "response_format": {"type": "json_object"},
                        "seed": 0,
                    },
                }, ensure_ascii=False) + "\n")
                n_ok += 1
        print(f"[{prov}] merged {n_ok} questions (short/missing new samples: {n_short}) "
              f"-> {merged_path} + cluster input")


if __name__ == "__main__":
    main()
