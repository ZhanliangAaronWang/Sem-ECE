"""Poll n=100 clustering batches (gpt-5.2), parse into clustered100 jsonl.

Output: clustering/{provider}_simpleqa_clustered100.jsonl with canonical
partition schema over 100 samples (indices 0-49 = original, 50-99 = new).
"""
import os, json, time, argparse, sys
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))
sys.path.insert(0, os.path.join(ROOT, "cross_judge"))
from collect import tolerant_parse  # bracket-tolerant

from openai import OpenAI

DS = "simpleqa"
def _tag(): return "" if DS == "simpleqa" else f"{DS}_"
def _state(): return os.path.join(BASE, "batch_outputs",
    "cluster_jobs.json" if DS == "simpleqa" else f"cluster_jobs_{DS}.json")
def _raw(): return os.path.join(BASE, "batch_outputs", f"{_tag()}cluster_raw.jsonl")
CLUSTER_DIR = os.path.join(BASE, "clustering")
GEN_DIR = os.path.join(BASE, "generation")


def merged_lookup(prov):
    """qid -> merged record (for question text, confidences, n)."""
    d = {}
    with open(os.path.join(GEN_DIR, f"{_tag()}{prov}_merged100.jsonl")) as f:
        for line in f:
            r = json.loads(line)
            d[r["id"]] = r
    return d


def parse_provider(prov, texts):
    """texts: {qid: judge_text}. Returns list of clustered rows."""
    merged = merged_lookup(prov)
    rows, fails = [], 0
    for qid, text in texts.items():
        m = merged.get(qid)
        if not m:
            continue
        n = m["n_samples"]
        try:
            obj = tolerant_parse(text)
            clusters = obj["clusters"]
            assign = [None] * n
            labels = []
            for k, c in enumerate(clusters):
                labels.append(str(c["label"]))
                for i in c["members"]:
                    if not (0 <= int(i) < n) or assign[int(i)] is not None:
                        raise ValueError("bad")
                    assign[int(i)] = k
            if any(a is None for a in assign):
                raise ValueError("incomplete")
            sizes = [assign.count(k) for k in range(len(labels))]
            modal = max(range(len(sizes)), key=lambda k: sizes[k])
            vv = [c for c in m["confidence_verbalized"] if c is not None]
            rows.append({
                "id": qid, "question": m["question"], "gold_answer": m["gold_answer"],
                "model": prov, "n_samples": n, "old_n": m["old_n"],
                "n_clusters": len(labels), "cluster_labels": labels,
                "cluster_assignments": assign, "cluster_sizes": sizes,
                "modal_cluster": modal, "modal_cluster_label": labels[modal],
                "verbalized_mean": (sum(vv) / len(vv)) if vv else 1.0,
                "verbalized_n_extracted": len(vv),
            })
        except Exception:
            fails += 1
    return rows, fails


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--loop", action="store_true")
    ap.add_argument("--interval", type=int, default=600)
    ap.add_argument("--dataset", default="simpleqa")
    args = ap.parse_args()
    global DS
    DS = args.dataset

    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    os.makedirs(CLUSTER_DIR, exist_ok=True)
    while True:
        with open(_state()) as f:
            state = json.load(f)
        all_done = True
        for prov, j in state.items():
            if j.get("collected"):
                continue
            b = client.batches.retrieve(j["batch_id"])
            print(f"  {prov}: {b.status} "
                  f"{getattr(b.request_counts,'completed',0)}/{getattr(b.request_counts,'total',0)}")
            if b.status not in ("completed", "failed", "expired", "cancelled"):
                all_done = False
                continue
            texts = {}
            if b.output_file_id:
                content = client.files.content(b.output_file_id).text
                with open(_raw(), "a") as f:
                    f.write(content if content.endswith("\n") else content + "\n")
                for line in content.splitlines():
                    r = json.loads(line)
                    cid = r["custom_id"]  # {prov}__{qid}
                    _, qid = cid.split("__", 1)
                    body = (r.get("response") or {}).get("body") or {}
                    try:
                        texts[qid] = body["choices"][0]["message"]["content"]
                    except Exception:
                        pass
            rows, fails = parse_provider(prov, texts)
            out = os.path.join(CLUSTER_DIR, f"{_tag()}{prov}_clustered100.jsonl")
            with open(out, "w") as f:
                for r in sorted(rows, key=lambda x: x["id"]):
                    f.write(json.dumps(r, ensure_ascii=False) + "\n")
            print(f"    {prov}: parsed {len(rows)}, fails {fails} -> {out}")
            j["collected"] = True
            with open(_state(), "w") as f:
                json.dump(state, f, indent=1)
        if all_done or not args.loop:
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
