"""Auto-advance the n=100 pipeline as generation completes, per dataset.

Loop: for each dataset, for each provider whose generation is fully collected
(all jobs marked collected in the state file), run merge → submit gpt-5.2
clustering. Then poll+parse clustering. When all providers' clustered100 files
exist for a dataset, run the convergence analysis. All steps idempotent.

Usage: python orchestrate.py [--once] [--interval 900] [--providers ...]
"""
import os, json, glob, time, argparse, subprocess

BASE = os.path.dirname(os.path.abspath(__file__))
OUTD = os.path.join(BASE, "batch_outputs")
DATASETS = ["simpleqa", "hle", "popqa"]
PY = "python"


def tag(ds):
    return "" if ds == "simpleqa" else f"{ds}_"


def gen_complete(ds, prov):
    """True if the generation state file exists and every job is collected."""
    p = os.path.join(OUTD, f"{tag(ds)}{prov}_jobs.json")
    if not os.path.exists(p):
        return False
    s = json.load(open(p))
    jobs = s.get("jobs", [])
    return bool(jobs) and all(j.get("collected") for j in jobs)


def run(cmd):
    print("  $ " + " ".join(cmd), flush=True)
    subprocess.run(cmd, cwd=BASE, check=False)


def advance_once(providers):
    for ds in DATASETS:
        t = tag(ds)
        ready = [p for p in providers if gen_complete(ds, p)]
        if not ready:
            continue
        # 1. merge (only providers whose merged file is missing or stale-by-absence)
        to_merge = [p for p in ready
                    if not os.path.exists(os.path.join(BASE, "generation", f"{t}{p}_merged100.jsonl"))]
        if to_merge:
            print(f"[{ds}] merge {to_merge}", flush=True)
            run([PY, "merge_and_build_cluster_inputs.py", "--dataset", ds, "--providers", *to_merge])
        # 2. submit clustering for providers with a cluster input not yet submitted
        state_f = os.path.join(OUTD, "cluster_jobs.json" if ds == "simpleqa" else f"cluster_jobs_{ds}.json")
        submitted = set(json.load(open(state_f)).keys()) if os.path.exists(state_f) else set()
        to_submit = [p for p in ready
                     if os.path.exists(os.path.join(BASE, "cluster_inputs", f"{t}{p}_clustering100.jsonl"))
                     and p not in submitted]
        if to_submit:
            print(f"[{ds}] submit clustering {to_submit}", flush=True)
            run([PY, "submit_cluster.py", "--dataset", ds, "--providers", *to_submit])
        # 3. poll + parse clustering (one pass)
        if os.path.exists(state_f):
            run([PY, "collect_cluster.py", "--dataset", ds])
        # 4. analyze if all ready providers now have clustered100
        have = [p for p in ready
                if os.path.exists(os.path.join(BASE, "clustering", f"{t}{p}_clustered100.jsonl"))]
        if have:
            run([PY, "analyze_convergence.py", "--dataset", ds, "--providers", *have])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--interval", type=int, default=900)
    ap.add_argument("--providers", nargs="+", default=["openai", "gemini", "mistral"])
    args = ap.parse_args()
    while True:
        print(f"=== advance pass {time.strftime('%F %T')} ===", flush=True)
        advance_once(args.providers)
        if args.once:
            break
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
