"""Submit anthropic n=100 generation via Message Batches (all datasets).

Reads batch_inputs/{ds}_anthropic_n100.jsonl (already in {custom_id, params}
form). Chunks by 100k. State: batch_outputs/{ds}_anthropic_jobs.json.
"""
import os, json, time, argparse
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))

from anthropic import Anthropic

CHUNK = 100_000


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--datasets", nargs="+", default=["simpleqa", "hle", "popqa"])
    args = ap.parse_args()
    client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    os.makedirs(os.path.join(BASE, "batch_outputs"), exist_ok=True)

    for ds in args.datasets:
        state_f = os.path.join(BASE, "batch_outputs", f"{ds}_anthropic_jobs.json")
        if os.path.exists(state_f):
            print(f"{ds}: already submitted"); continue
        path = os.path.join(BASE, "batch_inputs", f"{ds}_anthropic_n100.jsonl")
        reqs = [json.loads(l) for l in open(path)]
        print(f"{ds}: {len(reqs)} requests")
        jobs = []
        for i in range(0, len(reqs), CHUNK):
            chunk = reqs[i:i + CHUNK]
            batch = client.messages.batches.create(requests=chunk)
            jobs.append({"batch_id": batch.id, "n": len(chunk),
                         "submitted_at": time.strftime("%F %T")})
            with open(state_f, "w") as f:
                json.dump(jobs, f, indent=1)
            print(f"  sub-batch {i//CHUNK}: {batch.id} ({len(chunk)})")


if __name__ == "__main__":
    main()
