"""Finish the last n=100 cell: SimpleQA × Anthropic.

Chain: poll the generation batches -> collect -> merge 50+50 -> submit gpt-5.2
clustering -> poll/parse -> re-run the 5-provider convergence analysis for all three
benchmarks. Idempotent; safe to re-run.
"""
import os, json, time, subprocess, sys
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))
from anthropic import Anthropic
from openai import OpenAI

GEN_STATE = os.path.join(BASE, "batch_outputs", "simpleqa_anthropic_jobs.json")
RAW = os.path.join(BASE, "batch_outputs", "anthropic_raw.jsonl")
CLUS_STATE = os.path.join(BASE, "batch_outputs", "cluster_jobs.json")
PY = sys.executable


def log(m):
    print(f"[{time.strftime('%F %T')}] {m}", flush=True)


def text_of(rec):
    res = rec.get("result") or {}
    if res.get("type") != "succeeded":
        return None
    for b in (res.get("message") or {}).get("content", []):
        if b.get("type") == "text":
            return b.get("text")
    return None


def step_generation(ac):
    """poll + collect until every recorded generation batch is done."""
    while True:
        jobs = json.load(open(GEN_STATE))
        pending = False
        for j in jobs:
            if j.get("collected"):
                continue
            s = ac.messages.batches.retrieve(j["batch_id"])
            rc = s.request_counts
            log(f"gen {j['batch_id'][:18]}: {s.processing_status} ok={rc.succeeded} "
                f"proc={rc.processing} err={rc.errored}")
            if s.processing_status != "ended":
                pending = True
                continue
            n = 0
            with open(RAW, "a") as f:
                for res in ac.messages.batches.results(j["batch_id"]):
                    d = res.model_dump()
                    t = text_of(d)
                    if t:
                        f.write(json.dumps({"custom_id": d["custom_id"], "text": t},
                                           ensure_ascii=False) + "\n")
                        n += 1
            log(f"  collected {n} samples")
            j["collected"] = True
            json.dump(jobs, open(GEN_STATE, "w"), indent=1)
        if not pending:
            return
        time.sleep(600)


def run(cmd):
    log("$ " + " ".join(cmd))
    subprocess.run(cmd, cwd=BASE, check=False)


def main():
    ac = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    oc = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

    log("=== step 1: generation ===")
    step_generation(ac)
    total = sum(1 for _ in open(RAW))
    log(f"anthropic simpleqa raw total: {total}")

    log("=== step 2: merge 50+50 ===")
    run([PY, "merge_and_build_cluster_inputs.py", "--dataset", "simpleqa",
         "--providers", "anthropic"])

    log("=== step 3: submit gpt-5.2 clustering ===")
    run([PY, "submit_cluster.py", "--dataset", "simpleqa", "--providers", "anthropic"])

    log("=== step 4: poll + parse clustering ===")
    while True:
        st = json.load(open(CLUS_STATE))
        j = st.get("anthropic")
        if not j:
            log("no anthropic clustering job recorded; aborting"); return
        if j.get("collected"):
            break
        b = oc.batches.retrieve(j["batch_id"])
        rc = b.request_counts
        log(f"cluster anthropic: {b.status} {getattr(rc,'completed',0)}/{getattr(rc,'total',0)}")
        if b.status in ("completed", "failed", "expired", "cancelled"):
            run([PY, "collect_cluster.py", "--dataset", "simpleqa"])
            break
        time.sleep(300)

    # the collector writes clustering/anthropic_clustered100.jsonl; the analyzer wants
    # the {p}_simpleqa_clustered100.jsonl naming
    src = os.path.join(BASE, "clustering", "anthropic_clustered100.jsonl")
    dst = os.path.join(BASE, "clustering", "anthropic_simpleqa_clustered100.jsonl")
    if os.path.exists(src):
        import shutil
        shutil.copy(src, dst)
        log(f"copied -> {os.path.basename(dst)} ({sum(1 for _ in open(dst))} rows)")

    log("=== step 5: 5-provider convergence, all benchmarks ===")
    for ds in ("simpleqa", "hle", "popqa"):
        run([PY, "analyze_convergence.py", "--dataset", ds,
             "--providers", "openai", "gemini", "mistral", "xai", "anthropic"])
    run([PY, "figure_convergence.py"])
    log("=== DONE ===")


if __name__ == "__main__":
    main()
