"""Submit n=100 clustering batches (gpt-5.2), one per provider, dataset-aware.

Usage: python submit_cluster.py --dataset hle --providers openai gemini mistral
State: batch_outputs/cluster_jobs[_{ds}].json  (keyed by provider).
"""
import os, json, time, argparse
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
load_dotenv(os.path.join(ROOT, "phase1", ".env"))

from openai import OpenAI


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--providers", nargs="+", required=True)
    ap.add_argument("--dataset", default="simpleqa")
    args = ap.parse_args()
    ds = args.dataset
    tag = "" if ds == "simpleqa" else f"{ds}_"
    STATE = os.path.join(BASE, "batch_outputs",
                         "cluster_jobs.json" if ds == "simpleqa" else f"cluster_jobs_{ds}.json")

    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    state = {}
    if os.path.exists(STATE):
        with open(STATE) as f:
            state = json.load(f)

    for prov in args.providers:
        if prov in state:
            print(f"{prov}: already submitted ({state[prov]['batch_id']})"); continue
        path = os.path.join(BASE, "cluster_inputs", f"{tag}{prov}_clustering100.jsonl")
        if not os.path.exists(path):
            print(f"{prov}: cluster input missing ({path}), run merge first"); continue
        with open(path, "rb") as f:
            fobj = client.files.create(file=f, purpose="batch")
        batch = client.batches.create(input_file_id=fobj.id,
                                      endpoint="/v1/chat/completions",
                                      completion_window="24h")
        state[prov] = {"file_id": fobj.id, "batch_id": batch.id,
                       "submitted_at": time.strftime("%F %T")}
        with open(STATE, "w") as f:
            json.dump(state, f, indent=1)
        print(f"{ds}/{prov}: batch {batch.id}")


if __name__ == "__main__":
    main()
