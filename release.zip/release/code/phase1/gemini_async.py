"""Async parallel Gemini requests for SimpleQA generation.

Bypasses the batch API (which is quota-limited) and uses direct
async generateContent calls with concurrency control.

Designed to run as a Slurm CPU job.
"""
import os, json, time, asyncio, sys
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from google import genai
from google.genai import types

client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])

INPUT_FILE = os.path.join(BASE, "batch_inputs", "gemini_simpleqa.jsonl")
OUTPUT_FILE = os.path.join(BASE, "batch_outputs", "gemini_raw.jsonl")
PROGRESS_FILE = os.path.join(BASE, "batch_outputs", "gemini_progress.json")
os.makedirs(os.path.join(BASE, "batch_outputs"), exist_ok=True)

MODEL = "gemini-3-flash-preview"
MAX_CONCURRENT = 50   # concurrent requests (stay under RPM limit)
RATE_LIMIT_RPM = 1500  # stay well under the 2000 RPM paid tier limit
DELAY = 60.0 / RATE_LIMIT_RPM  # seconds between request starts

# Load all requests
print("Loading requests...", flush=True)
all_rows = []
with open(INPUT_FILE) as f:
    for line in f:
        all_rows.append(json.loads(line))
print(f"  {len(all_rows)} total requests", flush=True)

# Load progress (resume support)
completed = set()
if os.path.exists(OUTPUT_FILE):
    with open(OUTPUT_FILE) as f:
        for line in f:
            try:
                r = json.loads(line)
                completed.add(r.get("custom_id"))
            except:
                pass
print(f"  {len(completed)} already completed (resuming)", flush=True)

remaining = [r for r in all_rows if r["custom_id"] not in completed]
print(f"  {len(remaining)} remaining", flush=True)

if not remaining:
    print("All done!", flush=True)
    sys.exit(0)

# Semaphore for concurrency control
sem = asyncio.Semaphore(MAX_CONCURRENT)
rate_limiter = asyncio.Lock()
last_request_time = [0.0]

results_buffer = []
FLUSH_EVERY = 100
errors = {"count": 0, "last": ""}
done_count = [len(completed)]
total = len(all_rows)
start_time = time.time()


async def process_one(row):
    cfg = row["config"]
    custom_id = row["custom_id"]

    async with sem:
        # Rate limiting
        async with rate_limiter:
            now = time.monotonic()
            wait = DELAY - (now - last_request_time[0])
            if wait > 0:
                await asyncio.sleep(wait)
            last_request_time[0] = time.monotonic()

        # Retry with exponential backoff
        for attempt in range(5):
            try:
                resp = await client.aio.models.generate_content(
                    model=MODEL,
                    contents=row["contents"],
                    config=types.GenerateContentConfig(
                        system_instruction=cfg["system_instruction"],
                        max_output_tokens=cfg["max_output_tokens"],
                        temperature=cfg["temperature"],
                        top_p=cfg["top_p"],
                        thinking_config=types.ThinkingConfig(
                            thinking_budget=cfg["thinking_config"]["thinking_budget"]
                        ),
                        seed=cfg.get("seed"),
                    ),
                )

                um = resp.usage_metadata
                result = {
                    "custom_id": custom_id,
                    "text": resp.text,
                    "prompt_tokens": getattr(um, "prompt_token_count", None),
                    "completion_tokens": getattr(um, "candidates_token_count", None),
                    "status": "success",
                }
                results_buffer.append(result)
                done_count[0] += 1

                # Periodic progress
                if done_count[0] % 500 == 0:
                    elapsed = time.time() - start_time
                    rpm = done_count[0] / (elapsed / 60) if elapsed > 0 else 0
                    eta_min = (total - done_count[0]) / rpm if rpm > 0 else 0
                    print(f"  {done_count[0]}/{total} done ({rpm:.0f} RPM, ETA {eta_min:.0f} min)", flush=True)

                return
            except Exception as e:
                err_str = str(e)
                if "429" in err_str or "RESOURCE_EXHAUSTED" in err_str:
                    wait_time = 2 ** attempt * 5
                    await asyncio.sleep(wait_time)
                elif "500" in err_str or "503" in err_str:
                    await asyncio.sleep(2 ** attempt * 2)
                else:
                    errors["count"] += 1
                    errors["last"] = err_str[:200]
                    result = {
                        "custom_id": custom_id,
                        "text": None,
                        "error": err_str[:500],
                        "status": "error",
                    }
                    results_buffer.append(result)
                    done_count[0] += 1
                    return

        # All retries failed
        errors["count"] += 1
        result = {
            "custom_id": custom_id,
            "text": None,
            "error": f"All 5 retries failed: {errors['last'][:200]}",
            "status": "error",
        }
        results_buffer.append(result)
        done_count[0] += 1


async def flush_results():
    """Periodically flush results buffer to disk."""
    while True:
        await asyncio.sleep(10)
        if results_buffer:
            with open(OUTPUT_FILE, "a") as f:
                while results_buffer:
                    r = results_buffer.pop(0)
                    f.write(json.dumps(r, ensure_ascii=False) + "\n")


async def main():
    print(f"Starting async processing: {len(remaining)} requests, "
          f"concurrency={MAX_CONCURRENT}, rate={RATE_LIMIT_RPM} RPM", flush=True)

    # Start flusher
    flusher = asyncio.create_task(flush_results())

    # Process all remaining requests
    tasks = [process_one(row) for row in remaining]
    await asyncio.gather(*tasks)

    # Final flush
    flusher.cancel()
    with open(OUTPUT_FILE, "a") as f:
        while results_buffer:
            r = results_buffer.pop(0)
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    elapsed = time.time() - start_time
    print(f"\nDone! {done_count[0]}/{total} completed in {elapsed/60:.1f} min", flush=True)
    print(f"  Errors: {errors['count']}", flush=True)
    if errors["last"]:
        print(f"  Last error: {errors['last'][:200]}", flush=True)

    # Save progress summary
    with open(PROGRESS_FILE, "w") as f:
        json.dump({
            "total": total,
            "completed": done_count[0],
            "errors": errors["count"],
            "elapsed_min": elapsed / 60,
            "rpm": done_count[0] / (elapsed / 60) if elapsed > 60 else None,
        }, f, indent=2)


asyncio.run(main())
