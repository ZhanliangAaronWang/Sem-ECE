"""Merge all gemini_raw_w*.jsonl worker files into the master gemini_raw.jsonl.

Deduplicates by custom_id (last-write-wins) and reports any rows still missing
from the original input set.
"""
import os, json, glob

BASE = os.path.dirname(os.path.abspath(__file__))
INPUT_FILE = os.path.join(BASE, "batch_inputs", "gemini_simpleqa.jsonl")
OUT_DIR = os.path.join(BASE, "batch_outputs")
MASTER = os.path.join(OUT_DIR, "gemini_raw.jsonl")
WORKER_GLOB = os.path.join(OUT_DIR, "gemini_raw_w*.jsonl")


def load_rows(path):
    rows = {}
    if not os.path.exists(path):
        return rows
    with open(path) as f:
        for line in f:
            try:
                r = json.loads(line)
                cid = r.get("custom_id")
                if cid:
                    rows[cid] = r
            except Exception:
                pass
    return rows


def main():
    print(f"Master: {MASTER}", flush=True)
    merged = load_rows(MASTER)
    print(f"  loaded {len(merged)} rows from master", flush=True)

    for wf in sorted(glob.glob(WORKER_GLOB)):
        wrows = load_rows(wf)
        before = len(merged)
        merged.update(wrows)
        print(f"  {os.path.basename(wf)}: {len(wrows)} rows, +{len(merged) - before} new", flush=True)

    expected = set()
    with open(INPUT_FILE) as f:
        for line in f:
            d = json.loads(line)
            expected.add(d["custom_id"])
    have = set(merged.keys())
    missing = expected - have
    extra = have - expected
    print(f"\nMerged total: {len(merged)}, expected {len(expected)}, missing {len(missing)}, extra {len(extra)}", flush=True)
    n_err = sum(1 for r in merged.values() if r.get("status") == "error")
    print(f"  errors in merged set: {n_err}", flush=True)

    out_path = os.path.join(OUT_DIR, "gemini_raw.jsonl")
    with open(out_path, "w") as f:
        for cid in sorted(merged.keys()):
            f.write(json.dumps(merged[cid], ensure_ascii=False) + "\n")
    print(f"\nWrote {len(merged)} rows to {out_path}", flush=True)

    if missing:
        miss_path = os.path.join(OUT_DIR, "gemini_missing.txt")
        with open(miss_path, "w") as f:
            for cid in sorted(missing):
                f.write(cid + "\n")
        print(f"  ({len(missing)} missing custom_ids -> {miss_path})", flush=True)


if __name__ == "__main__":
    main()
