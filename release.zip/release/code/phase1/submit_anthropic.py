"""Submit Anthropic Message Batch and poll until complete."""
import os, json, time
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from anthropic import Anthropic
from anthropic.types.message_create_params import MessageCreateParamsNonStreaming
from anthropic.types.messages import BatchCreateParams

client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

INPUT_FILE = os.path.join(BASE, "batch_inputs", "anthropic_simpleqa.jsonl")
BATCH_IDS = os.path.join(BASE, "batch_ids.json")
OUTPUT_FILE = os.path.join(BASE, "batch_outputs", "anthropic_raw.jsonl")

os.makedirs(os.path.join(BASE, "batch_outputs"), exist_ok=True)

if os.path.exists(BATCH_IDS):
    with open(BATCH_IDS) as f:
        batch_ids = json.load(f)
else:
    batch_ids = {}

if "anthropic" in batch_ids and batch_ids["anthropic"].get("batch_id"):
    batch_id = batch_ids["anthropic"]["batch_id"]
    print(f"Resuming existing batch: {batch_id}")
else:
    # Load requests from JSONL
    print("Loading batch input file...")
    requests = []
    with open(INPUT_FILE) as f:
        for line in f:
            row = json.loads(line)
            requests.append(row)
    print(f"  {len(requests)} requests loaded")

    # Anthropic Message Batches API accepts up to 100k requests per batch.
    # We have 216,300 → need 3 batches.
    CHUNK_SIZE = 100_000
    chunks = [requests[i : i + CHUNK_SIZE] for i in range(0, len(requests), CHUNK_SIZE)]
    print(f"  Splitting into {len(chunks)} sub-batches ({[len(c) for c in chunks]})")

    sub_batch_ids = []
    for idx, chunk in enumerate(chunks):
        print(f"  Submitting sub-batch {idx} ({len(chunk)} requests)...")
        batch = client.messages.batches.create(requests=chunk)
        sub_batch_ids.append(batch.id)
        print(f"    batch_id: {batch.id}")

    batch_ids["anthropic"] = {
        "batch_id": sub_batch_ids if len(sub_batch_ids) > 1 else sub_batch_ids[0],
        "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "n_rows": len(requests),
        "n_sub_batches": len(sub_batch_ids),
    }
    with open(BATCH_IDS, "w") as f:
        json.dump(batch_ids, f, indent=2)

    batch_id = batch_ids["anthropic"]["batch_id"]

# Poll all sub-batches
ids = batch_id if isinstance(batch_id, list) else [batch_id]
print(f"Polling {len(ids)} sub-batch(es)...")

while True:
    all_done = True
    for bid in ids:
        status = client.messages.batches.retrieve(bid)
        counts = status.request_counts
        print(f"  anthropic [{bid[:12]}...]: {status.processing_status} — "
              f"succeeded={counts.succeeded} processing={counts.processing} "
              f"errored={counts.errored} canceled={counts.canceled}")
        if status.processing_status not in ("ended",):
            all_done = False
    if all_done:
        break
    time.sleep(300)

# Download results for all sub-batches
print("Downloading results...")
with open(OUTPUT_FILE, "w") as out:
    total = 0
    for bid in ids:
        for result in client.messages.batches.results(bid):
            out.write(json.dumps(result.model_dump(), default=str) + "\n")
            total += 1
print(f"  Wrote {total} results to {OUTPUT_FILE}")

batch_ids["anthropic"]["status"] = "completed"
batch_ids["anthropic"]["completed_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
with open(BATCH_IDS, "w") as f:
    json.dump(batch_ids, f, indent=2)

print("Anthropic batch done.")
