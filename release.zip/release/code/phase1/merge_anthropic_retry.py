"""Merge retry results into anthropic_raw.jsonl, replacing the errored
entries from the original 2026-04-10 run with successful retry entries.

Backup the original to anthropic_raw.jsonl.bak_partial67pct before overwriting.
"""
import json, os, shutil
from collections import Counter

BASE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(BASE, "batch_outputs", "anthropic_raw.jsonl")
RETRY = os.path.join(BASE, "batch_outputs", "anthropic_raw_retry.jsonl")
BAK = RAW + ".bak_partial67pct"

if not os.path.exists(BAK):
    print(f"[backup] {RAW} -> {BAK}")
    shutil.copy2(RAW, BAK)
else:
    print(f"[backup] already exists, skipping: {BAK}")

# Load retry into a dict by custom_id
retry_by_cid = {}
with open(RETRY) as f:
    for line in f:
        r = json.loads(line)
        retry_by_cid[r["custom_id"]] = r
print(f"[retry] {len(retry_by_cid)} retry rows loaded")

# Stream original raw, swap errored for retry
out_path = RAW + ".tmp"
n_total = n_swapped = n_kept_ok = n_unmatched_err = 0
with open(BAK) as fi, open(out_path, "w") as fo:
    for line in fi:
        r = json.loads(line)
        n_total += 1
        cid = r["custom_id"]
        msg = r.get("result", {}).get("message")
        if msg is None:
            # was errored — try replace
            new = retry_by_cid.get(cid)
            if new is not None:
                fo.write(json.dumps(new, default=str) + "\n")
                n_swapped += 1
            else:
                fo.write(line)
                n_unmatched_err += 1
        else:
            fo.write(line)
            n_kept_ok += 1

print(f"[merge] total={n_total}, kept_ok={n_kept_ok}, swapped={n_swapped}, unmatched_err={n_unmatched_err}")
assert n_unmatched_err == 0, "Some errored rows had no retry — investigate before promoting."

# Promote
os.replace(out_path, RAW)
print(f"[promote] new merged file written to {RAW}")

# Final validation
ok = err = 0
models = Counter()
stops = Counter()
out_lens = []
for line in open(RAW):
    r = json.loads(line)
    m = r.get("result", {}).get("message")
    if m is None:
        err += 1
        continue
    ok += 1
    models[m["model"]] += 1
    stops[m["stop_reason"]] += 1
    out_lens.append(m["usage"]["output_tokens"])

print(f"[final] ok={ok}, err={err}")
print(f"  models: {dict(models)}")
print(f"  stops: {dict(stops)}")
import statistics
print(f"  output_tokens: mean={statistics.mean(out_lens):.1f}, "
      f"median={statistics.median(out_lens):.1f}, max={max(out_lens)}, "
      f"frac_at_max(256)={sum(1 for x in out_lens if x>=256)/len(out_lens)*100:.2f}%")
