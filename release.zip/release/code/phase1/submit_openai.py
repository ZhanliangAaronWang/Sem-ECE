"""Submit OpenAI batch in sequential sub-batches.

org limit: 900K enqueued tokens for gpt-5.4.
~137 input tokens per row → max ~6500 rows per sub-batch.
With n=8, output tokens also count → be conservative with ~4000 rows per batch.
Submit one sub-batch, wait for completion, submit next.
"""
import os, json, time, sys, math
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from openai import OpenAI
client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

INPUT_FILE = os.path.join(BASE, "batch_inputs", "openai_simpleqa.jsonl")
OUTPUT_DIR = os.path.join(BASE, "batch_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Provider-specific batch_ids file to avoid race conditions
BATCH_STATE = os.path.join(BASE, "batch_state_openai.json")

ROWS_PER_BATCH = 4000  # conservative to stay under 900K enqueued token limit

# Load all input rows
all_lines = open(INPUT_FILE).readlines()
n_batches = math.ceil(len(all_lines) / ROWS_PER_BATCH)
print(f"Total rows: {len(all_lines)}, splitting into {n_batches} sequential sub-batches of ~{ROWS_PER_BATCH}")

# Load state
if os.path.exists(BATCH_STATE):
    with open(BATCH_STATE) as f:
        state = json.load(f)
else:
    state = {"completed_batches": [], "next_offset": 0}

offset = state["next_offset"]
completed_output_files = []

while offset < len(all_lines):
    chunk = all_lines[offset:offset + ROWS_PER_BATCH]
    batch_idx = offset // ROWS_PER_BATCH
    print(f"\n--- Sub-batch {batch_idx} (rows {offset}-{offset+len(chunk)-1}) ---")

    # Write temp chunk file
    tmp = f"/tmp/openai_chunk_{batch_idx}.jsonl"
    with open(tmp, "w") as f:
        f.writelines(chunk)

    # Upload
    print("  Uploading...")
    with open(tmp, "rb") as f:
        file_obj = client.files.create(file=f, purpose="batch")
    print(f"  file_id: {file_obj.id}")

    # Create batch
    print("  Creating batch...")
    batch = client.batches.create(
        input_file_id=file_obj.id,
        endpoint="/v1/chat/completions",
        completion_window="24h",
    )
    print(f"  batch_id: {batch.id}")

    # Poll until done
    while True:
        s = client.batches.retrieve(batch.id)
        rc = s.request_counts
        completed = rc.completed if rc else 0
        failed = rc.failed if rc else 0
        total = rc.total if rc else 0
        print(f"  {s.status}: {completed}/{total} done, {failed} failed", flush=True)

        if s.status in ("completed", "failed", "expired", "cancelled"):
            break
        time.sleep(120)  # 2 min polls for sequential batches

    # Download output
    if s.status == "completed" and s.output_file_id:
        out_path = os.path.join(OUTPUT_DIR, f"openai_raw_{batch_idx}.jsonl")
        content = client.files.content(s.output_file_id)
        with open(out_path, "wb") as f:
            f.write(content.read())
        completed_output_files.append(out_path)
        print(f"  Downloaded to {out_path}")
    elif s.status == "failed":
        print(f"  FAILED: {s.errors}")
        # Save state and exit so user can diagnose
        state["next_offset"] = offset
        state["error"] = str(s.errors)
        with open(BATCH_STATE, "w") as f:
            json.dump(state, f, indent=2)
        sys.exit(1)

    # Update state
    offset += len(chunk)
    state["next_offset"] = offset
    state["completed_batches"].append({
        "batch_id": batch.id,
        "rows": len(chunk),
        "output_file": completed_output_files[-1] if completed_output_files else None,
    })
    with open(BATCH_STATE, "w") as f:
        json.dump(state, f, indent=2)

# Merge all output chunks
print("\nMerging output files...")
merged = os.path.join(OUTPUT_DIR, "openai_raw.jsonl")
with open(merged, "w") as out:
    total = 0
    for p in completed_output_files:
        for line in open(p):
            out.write(line)
            total += 1
print(f"Wrote {total} lines to {merged}")

# Update main batch_ids.json
try:
    with open(os.path.join(BASE, "batch_ids.json")) as f:
        batch_ids = json.load(f)
except:
    batch_ids = {}
batch_ids["openai"] = {
    "batch_id": [b["batch_id"] for b in state["completed_batches"]],
    "submitted_at": state["completed_batches"][0]["batch_id"] if state["completed_batches"] else None,
    "n_rows": len(all_lines),
    "n_sub_batches": len(state["completed_batches"]),
    "status": "completed",
    "completed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
}
with open(os.path.join(BASE, "batch_ids.json"), "w") as f:
    json.dump(batch_ids, f, indent=2)

print("OpenAI batch done.")
