"""Submit Mistral batch job(s) from split files and poll until complete."""
import os, json, time, glob
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from mistralai.client import Mistral

client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])

CHUNK_FILES = sorted(glob.glob(os.path.join(BASE, "batch_inputs", "mistral_simpleqa_chunk*.jsonl")))
BATCH_STATE = os.path.join(BASE, "batch_state_mistral.json")
OUTPUT_DIR = os.path.join(BASE, "batch_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

print(f"Found {len(CHUNK_FILES)} chunk files", flush=True)

# Load state
if os.path.exists(BATCH_STATE):
    with open(BATCH_STATE) as f:
        state = json.load(f)
else:
    state = {"jobs": []}

# Submit chunks not yet submitted
submitted_chunks = {j["chunk_idx"] for j in state["jobs"]}

for chunk_file in CHUNK_FILES:
    idx = int(chunk_file.split("chunk")[1].split(".")[0])
    if idx in submitted_chunks:
        print(f"  Chunk {idx}: already submitted", flush=True)
        continue

    print(f"  Chunk {idx}: uploading {chunk_file}...", flush=True)
    retries = 0
    while retries < 3:
        try:
            with open(chunk_file, "rb") as f:
                file_obj = client.files.upload(
                    file={"file_name": f"mistral_chunk{idx}.jsonl", "content": f.read()},
                    purpose="batch",
                    timeout_ms=300_000,
                )
            print(f"    file_id: {file_obj.id}", flush=True)
            break
        except Exception as e:
            retries += 1
            print(f"    Upload failed (retry {retries}/3): {str(e)[:200]}", flush=True)
            time.sleep(30 * retries)
    else:
        print(f"    GIVING UP on chunk {idx}", flush=True)
        continue

    print(f"    Creating batch job...", flush=True)
    job = client.batch.jobs.create(
        model="mistral-large-latest",
        endpoint="/v1/chat/completions",
        input_files=[file_obj.id],
        timeout_hours=24,
    )
    print(f"    job_id: {job.id}", flush=True)

    state["jobs"].append({"chunk_idx": idx, "job_id": job.id, "file_id": file_obj.id})
    with open(BATCH_STATE, "w") as f:
        json.dump(state, f, indent=2)

# Poll all jobs
job_ids = [j["job_id"] for j in state["jobs"]]
print(f"\nPolling {len(job_ids)} job(s)...", flush=True)

while True:
    all_done = True
    for j in state["jobs"]:
        job = client.batch.jobs.get(job_id=j["job_id"])
        status = job.status
        completed = getattr(job, "completed_requests", 0) or 0
        failed = getattr(job, "failed_requests", 0) or 0
        total = getattr(job, "total_requests", 0) or 0
        print(f"  chunk{j['chunk_idx']}: {status} {completed}/{total} done, {failed} failed", flush=True)
        j["status"] = status
        if status not in ("SUCCESS", "FAILED", "TIMEOUT_EXCEEDED", "CANCELLED", "COMPLETED"):
            all_done = False
    with open(BATCH_STATE, "w") as f:
        json.dump(state, f, indent=2)
    if all_done:
        break
    time.sleep(300)

# Download outputs
print("\nDownloading results...", flush=True)
output_file = os.path.join(OUTPUT_DIR, "mistral_raw.jsonl")
with open(output_file, "w") as out:
    total = 0
    for j in state["jobs"]:
        job = client.batch.jobs.get(job_id=j["job_id"])
        ofid = getattr(job, "output_file", None)
        if ofid:
            content = client.files.download(file_id=ofid)
            data = content if isinstance(content, bytes) else content.read() if hasattr(content, 'read') else content.encode()
            for line in data.decode().strip().split("\n"):
                out.write(line + "\n")
                total += 1
print(f"  Wrote {total} lines to {output_file}", flush=True)
print("Mistral batch done.")
