"""Async parallel xAI requests for SimpleQA generation.

Uses grok-4.20-0309-non-reasoning via real-time API (not batch — batch
doesn't support this model). OpenAI-compatible endpoint at api.x.ai/v1.

Designed to run as a Slurm CPU job.
"""
import os, json, time, asyncio, sys
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from openai import AsyncOpenAI

client = AsyncOpenAI(
    api_key=os.environ["XAI_API_KEY"],
    base_url="https://api.x.ai/v1",
)

INPUT_FILE = os.path.join(BASE, "batch_inputs", "xai_simpleqa.jsonl")
OUTPUT_FILE = os.path.join(BASE, "batch_outputs", "xai_raw.jsonl")
PROGRESS_FILE = os.path.join(BASE, "batch_outputs", "xai_progress.json")
os.makedirs(os.path.join(BASE, "batch_outputs"), exist_ok=True)

MODEL = "grok-4.20-0309-non-reasoning"
MAX_CONCURRENT = 50
RATE_LIMIT_RPM = 500  # conservative for xAI
DELAY = 60.0 / RATE_LIMIT_RPM

SYSTEM = json.loads(open(INPUT_FILE).readline())["body"]["messages"][0]["content"]

# Load all requests
print("Loading requests...", flush=True)
all_rows = []
with open(INPUT_FILE) as f:
    for line in f:
        row = json.loads(line)
        all_rows.append(row)
print(f"  {len(all_rows)} total requests", flush=True)

# Load progress (resume support)
completed = set()
if os.path.exists(OUTPUT_FILE):
    with open(OUTPUT_FILE) as f:
        for line in f:
            try:
                r = json.loads(line)
                completed.add(r.get("custom_id"))
            except:
                pass
print(f"  {len(completed)} already completed (resuming)", flush=True)

remaining = [r for r in all_rows if r["custom_id"] not in completed]
print(f"  {len(remaining)} remaining", flush=True)

if not remaining:
    print("All done!", flush=True)
    sys.exit(0)

sem = asyncio.Semaphore(MAX_CONCURRENT)
rate_limiter = asyncio.Lock()
last_request_time = [0.0]

results_buffer = []
errors = {"count": 0, "last": ""}
done_count = [len(completed)]
total = len(all_rows)
start_time = time.time()


async def process_one(row):
    custom_id = row["custom_id"]
    body = row["body"]
    messages = body["messages"]

    async with sem:
        async with rate_limiter:
            now = time.monotonic()
            wait = DELAY - (now - last_request_time[0])
            if wait > 0:
                await asyncio.sleep(wait)
            last_request_time[0] = time.monotonic()

        for attempt in range(5):
            try:
                resp = await client.chat.completions.create(
                    model=MODEL,
                    messages=messages,
                    max_tokens=body.get("max_tokens", 256),
                    temperature=body.get("temperature", 1.0),
                    top_p=body.get("top_p", 1.0),
                )
                result = {
                    "custom_id": custom_id,
                    "text": resp.choices[0].message.content,
                    "prompt_tokens": resp.usage.prompt_tokens,
                    "completion_tokens": resp.usage.completion_tokens,
                    "status": "success",
                }
                results_buffer.append(result)
                done_count[0] += 1

                if done_count[0] % 500 == 0:
                    elapsed = time.time() - start_time
                    rpm = (done_count[0] - len(completed)) / (elapsed / 60) if elapsed > 0 else 0
                    eta_min = (total - done_count[0]) / rpm if rpm > 0 else 0
                    print(f"  {done_count[0]}/{total} done ({rpm:.0f} RPM, ETA {eta_min:.0f} min)", flush=True)
                return

            except Exception as e:
                err_str = str(e)
                if "429" in err_str or "rate" in err_str.lower():
                    await asyncio.sleep(2 ** attempt * 5)
                elif "500" in err_str or "503" in err_str:
                    await asyncio.sleep(2 ** attempt * 2)
                else:
                    errors["count"] += 1
                    errors["last"] = err_str[:200]
                    result = {
                        "custom_id": custom_id,
                        "text": None,
                        "error": err_str[:500],
                        "status": "error",
                    }
                    results_buffer.append(result)
                    done_count[0] += 1
                    return

        errors["count"] += 1
        result = {
            "custom_id": custom_id,
            "text": None,
            "error": f"All 5 retries failed",
            "status": "error",
        }
        results_buffer.append(result)
        done_count[0] += 1


async def flush_results():
    while True:
        await asyncio.sleep(10)
        if results_buffer:
            with open(OUTPUT_FILE, "a") as f:
                while results_buffer:
                    r = results_buffer.pop(0)
                    f.write(json.dumps(r, ensure_ascii=False) + "\n")


async def main():
    print(f"Starting async: {len(remaining)} requests, model={MODEL}, "
          f"concurrency={MAX_CONCURRENT}, rate={RATE_LIMIT_RPM} RPM", flush=True)

    flusher = asyncio.create_task(flush_results())
    tasks = [process_one(row) for row in remaining]
    await asyncio.gather(*tasks)

    flusher.cancel()
    with open(OUTPUT_FILE, "a") as f:
        while results_buffer:
            r = results_buffer.pop(0)
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    elapsed = time.time() - start_time
    print(f"\nDone! {done_count[0]}/{total} completed in {elapsed/60:.1f} min", flush=True)
    print(f"  Errors: {errors['count']}", flush=True)

    with open(PROGRESS_FILE, "w") as f:
        json.dump({
            "total": total, "completed": done_count[0],
            "errors": errors["count"], "elapsed_min": elapsed / 60,
        }, f, indent=2)


asyncio.run(main())
