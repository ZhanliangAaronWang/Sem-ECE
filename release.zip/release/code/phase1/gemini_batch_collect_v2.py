"""Collect completed Gemini batch results and append to gemini_raw.jsonl.

Reads batch jobs from gemini_batch_jobs.json (or directly by name),
extracts inlined_responses, and appends new success rows.
"""
import os, json, time
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"), override=True)

from google import genai

MASTER_OUT = os.path.join(BASE, "batch_outputs", "gemini_raw.jsonl")
JOBS_FILE = os.path.join(BASE, "batch_outputs", "gemini_batch_jobs.json")

client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])


def already_success_ids():
    done = set()
    if not os.path.exists(MASTER_OUT):
        return done
    with open(MASTER_OUT) as f:
        for line in f:
            try:
                r = json.loads(line)
                if r.get("status") == "success" and r.get("custom_id"):
                    done.add(r["custom_id"])
            except Exception:
                pass
    return done


def collect_job(job_name):
    job = client.batches.get(name=job_name)
    state = str(job.state).split(".")[-1]
    print(f"  {job_name}: state={state}", flush=True)

    if state != "JOB_STATE_SUCCEEDED":
        return [], state

    dest = getattr(job, "dest", None)
    inlined = None
    if dest:
        inlined = getattr(dest, "inlined_responses", None)
    if not inlined:
        inlined = getattr(job, "inlined_responses", None)
    if not inlined:
        print(f"    no inlined_responses found", flush=True)
        return [], state

    rows = []
    for resp_obj in inlined:
        md = getattr(resp_obj, "metadata", None) or {}
        cid = md.get("custom_id", "")
        response = getattr(resp_obj, "response", None)
        err = getattr(resp_obj, "error", None)

        if err and not response:
            rows.append({"custom_id": cid, "text": None, "error": str(err)[:500], "status": "error"})
            continue

        if not response:
            rows.append({"custom_id": cid, "text": None, "error": "no response", "status": "error"})
            continue

        try:
            text = response.text
        except Exception as e:
            rows.append({"custom_id": cid, "text": None, "error": f"text: {e}", "status": "error"})
            continue

        um = getattr(response, "usage_metadata", None)
        rows.append({
            "custom_id": cid,
            "text": text,
            "prompt_tokens": getattr(um, "prompt_token_count", None) if um else None,
            "completion_tokens": getattr(um, "candidates_token_count", None) if um else None,
            "status": "success",
        })

    print(f"    extracted {len(rows)} rows ({sum(1 for r in rows if r['status']=='success')} success)", flush=True)
    return rows, state


def main():
    already = already_success_ids()
    print(f"Existing success rows: {len(already)}", flush=True)

    # Collect from jobs file
    if not os.path.exists(JOBS_FILE):
        print(f"No {JOBS_FILE}", flush=True)
        return

    with open(JOBS_FILE) as f:
        jobs = json.load(f)

    new_rows = []
    for j in jobs:
        if j.get("collected"):
            continue
        rows, state = collect_job(j["name"])
        if state == "JOB_STATE_SUCCEEDED":
            # Filter out already-done
            fresh = [r for r in rows if r["custom_id"] not in already]
            new_rows.extend(fresh)
            j["collected"] = True
            j["collected_at"] = time.time()
            j["n_collected"] = len(rows)
            j["n_fresh"] = len(fresh)
            print(f"    fresh (not already in master): {len(fresh)}", flush=True)

    if new_rows:
        with open(MASTER_OUT, "a") as f:
            for r in new_rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"\nAppended {len(new_rows)} new rows -> {MASTER_OUT}", flush=True)

    # Save updated jobs
    with open(JOBS_FILE, "w") as f:
        json.dump(jobs, f, indent=2)

    # Report totals
    total_success = len(already) + sum(1 for r in new_rows if r["status"] == "success")
    total_error = sum(1 for r in new_rows if r["status"] == "error")
    print(f"\nTotal success in master: {total_success}")
    print(f"New errors: {total_error}")
    print(f"Target: 216300")
    print(f"Remaining: {216300 - total_success}")


if __name__ == "__main__":
    main()
