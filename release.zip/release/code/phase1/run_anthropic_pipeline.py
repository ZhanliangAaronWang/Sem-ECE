"""Sequential downstream pipeline for SimpleQA Anthropic (claude-opus-4-6).
Runs every step that turns the merged anthropic_raw.jsonl into final ECE.

Stages (each prints `STAGE: <name>` so a monitor can track progress):
  merge          — fold anthropic_raw_retry into anthropic_raw
  prep           — extract answers, build clustering batch input
  cluster_submit — chunk clustering, submit, poll until done
  cluster_collect — parse clustering outputs -> anthropic_simpleqa_clustered.jsonl
  grade_submit   — submit GPT-5.2 grading batch (single batch, n=4326)
  grade_collect  — poll grading, parse -> anthropic_simpleqa_graded.jsonl
  confidence     — compute SCOPE-1 / SCOPE-2 / verbalized for anthropic
  ece            — compute ECE for anthropic alongside the other 4 providers

Idempotent: re-running picks up after the last completed stage when possible
(merge/prep/collect rebuild from inputs; cluster/grade submit resume from
state files).
"""
import os, sys, time, subprocess

BASE = os.path.dirname(os.path.abspath(__file__))
PYTHON = sys.executable

def run(label, args, cwd=None):
    print(f"\n{'='*60}\nSTAGE: {label}\n{'='*60}", flush=True)
    print(f"  cmd: {' '.join(args)}", flush=True)
    print(f"  cwd: {cwd or BASE}", flush=True)
    t0 = time.time()
    rc = subprocess.run(args, cwd=cwd or BASE).returncode
    dt = time.time() - t0
    print(f"  rc={rc}, elapsed={dt:.1f}s", flush=True)
    if rc != 0:
        print(f"STAGE_FAIL: {label}", flush=True)
        sys.exit(rc)
    print(f"STAGE_OK: {label}", flush=True)


def main():
    # 0. merge retry results (idempotent; backs up original on first run)
    run("merge",
        [PYTHON, "phase1/merge_anthropic_retry.py"],
        cwd=os.path.dirname(BASE))

    # 1. prep — extract answers / build clustering input
    run("prep",
        [PYTHON, "clustering/prep_anthropic.py"],
        cwd=BASE)

    # 2. cluster_submit — chunked GPT-5.2 clustering batches
    run("cluster_submit",
        [PYTHON, "clustering/submit_anthropic_chunked.py"],
        cwd=BASE)

    # 3. cluster_collect
    run("cluster_collect",
        [PYTHON, "clustering/collect_provider.py", "anthropic"],
        cwd=BASE)

    # 4. grade_submit
    run("grade_submit",
        [PYTHON, "grading/prep_and_submit.py", "--providers", "anthropic", "--submit"],
        cwd=BASE)

    # 5. grade_collect (watch mode polls until terminal)
    run("grade_collect",
        [PYTHON, "grading/collect_and_check.py",
         "--providers", "anthropic", "--watch", "--interval", "30"],
        cwd=BASE)

    # 6. confidence (anthropic only — preserves other providers' files)
    run("confidence",
        [PYTHON, "confidence/compute_confidence.py", "--providers", "anthropic"],
        cwd=BASE)

    # 7. ECE — recompute across all 5 providers so the comparison table is fresh
    run("ece",
        [PYTHON, "confidence/compute_ece.py",
         "--providers", "openai", "anthropic", "xai", "mistral", "gemini"],
        cwd=BASE)

    print("\nPIPELINE_DONE: SimpleQA Anthropic full downstream complete.", flush=True)


if __name__ == "__main__":
    main()
