"""Step 4 (OpenAI only): upload openai_clustering.jsonl and start the batch.

Saves batch metadata to phase1/clustering/batch_ids.json (merging with existing).
"""
import os, json, time
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(BASE, ".env"), override=True)

from openai import OpenAI

BATCH_INPUT = os.path.join(BASE, "clustering", "batch_inputs", "openai_clustering.jsonl")
BATCH_IDS = os.path.join(BASE, "clustering", "batch_ids.json")

client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

print(f"Uploading {BATCH_INPUT}...", flush=True)
with open(BATCH_INPUT, "rb") as f:
    fobj = client.files.create(file=f, purpose="batch")
print(f"  file_id: {fobj.id}", flush=True)

print("Creating batch...", flush=True)
batch = client.batches.create(
    input_file_id=fobj.id,
    endpoint="/v1/chat/completions",
    completion_window="24h",
    metadata={"phase": "phase1_clustering", "provider": "openai"},
)
print(f"  batch_id: {batch.id}", flush=True)
print(f"  status:   {batch.status}", flush=True)

# Count rows
n_rows = 0
with open(BATCH_INPUT) as f:
    for _ in f:
        n_rows += 1

# Merge with existing batch_ids.json
ids = {}
if os.path.exists(BATCH_IDS):
    with open(BATCH_IDS) as f:
        ids = json.load(f)
ids["openai"] = {
    "batch_id": batch.id,
    "input_file_id": fobj.id,
    "n_rows": n_rows,
    "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    "status_at_submit": batch.status,
}
with open(BATCH_IDS, "w") as f:
    json.dump(ids, f, indent=2)
print(f"Saved -> {BATCH_IDS}", flush=True)
