"""Submit OpenAI clustering as multiple smaller batches, sequentially.

The previous all-at-once submission failed with token_limit_exceeded
(900,000 enqueued-token limit for gpt-5.2). We split openai_clustering.jsonl
into ROWS_PER_CHUNK rows per batch and submit them one at a time, waiting
for each to complete (or fail) before moving to the next.

State is tracked in phase1/clustering/openai_chunks.json so re-runs resume
from the next un-submitted chunk.
"""
import os, json, time, math, sys
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(BASE, ".env"), override=True)

from openai import OpenAI

INPUT = os.path.join(BASE, "clustering", "batch_inputs", "openai_clustering.jsonl")
CHUNK_DIR = os.path.join(BASE, "clustering", "batch_inputs", "openai_chunks")
STATE = os.path.join(BASE, "clustering", "openai_chunks.json")

ROWS_PER_CHUNK = 800   # ~600k input tokens per chunk, well under 900k cap
POLL_INTERVAL = 30     # seconds between polls
TERMINAL = {"completed", "failed", "expired", "cancelled"}

os.makedirs(CHUNK_DIR, exist_ok=True)
client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])


def split_input():
    with open(INPUT) as f:
        all_rows = f.readlines()
    n_chunks = math.ceil(len(all_rows) / ROWS_PER_CHUNK)
    paths = []
    for i in range(n_chunks):
        chunk = all_rows[i * ROWS_PER_CHUNK : (i + 1) * ROWS_PER_CHUNK]
        p = os.path.join(CHUNK_DIR, f"openai_clustering_chunk{i}.jsonl")
        with open(p, "w") as f:
            f.writelines(chunk)
        paths.append((i, p, len(chunk)))
    return paths


def load_state():
    if os.path.exists(STATE):
        with open(STATE) as f:
            return json.load(f)
    return {"chunks": []}


def save_state(s):
    with open(STATE, "w") as f:
        json.dump(s, f, indent=2)


def call_with_retry(label, fn, max_tries=8):
    delay = 5
    for i in range(max_tries):
        try:
            return fn()
        except Exception as e:
            msg = str(e)[:200]
            print(f"    {label} attempt {i+1} failed: {msg}", flush=True)
            time.sleep(delay)
            delay = min(60, delay * 2)
    raise RuntimeError(f"{label} failed after {max_tries} attempts")


def submit_chunk(idx, path, n_rows):
    print(f"\n[chunk {idx}] uploading {os.path.basename(path)} ({n_rows} rows)...", flush=True)
    def _upload():
        with open(path, "rb") as f:
            return client.files.create(file=f, purpose="batch")
    fobj = call_with_retry("upload", _upload)
    print(f"  file_id: {fobj.id}", flush=True)
    def _create():
        return client.batches.create(
            input_file_id=fobj.id,
            endpoint="/v1/chat/completions",
            completion_window="24h",
            metadata={"phase": "phase1_clustering", "provider": "openai", "chunk": str(idx)},
        )
    batch = call_with_retry("batch.create", _create)
    print(f"  batch_id: {batch.id}  status: {batch.status}", flush=True)
    return {
        "chunk": idx,
        "path": path,
        "n_rows": n_rows,
        "file_id": fobj.id,
        "batch_id": batch.id,
        "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "final_status": None,
        "output_file_id": None,
        "error_file_id": None,
    }


def retrieve_with_retry(bid, max_tries=8):
    delay = 5
    for i in range(max_tries):
        try:
            return client.batches.retrieve(bid)
        except Exception as e:
            msg = str(e)[:200]
            print(f"    retrieve attempt {i+1} failed: {msg}", flush=True)
            time.sleep(delay)
            delay = min(60, delay * 2)
    raise RuntimeError(f"retrieve {bid} failed after {max_tries} attempts")


def wait_chunk(entry):
    bid = entry["batch_id"]
    while True:
        b = retrieve_with_retry(bid)
        st = b.status if isinstance(b.status, str) else str(b.status)
        rc = b.request_counts
        print(f"  [{time.strftime('%H:%M:%S')}] {bid}: status={st}  done={rc.completed}/{rc.total}  fail={rc.failed}", flush=True)
        if st in TERMINAL:
            entry["final_status"] = st
            entry["output_file_id"] = b.output_file_id
            entry["error_file_id"] = b.error_file_id
            if st != "completed":
                entry["errors"] = str(b.errors)[:500] if b.errors else None
            return st
        time.sleep(POLL_INTERVAL)


def main():
    chunks = split_input()
    print(f"Split into {len(chunks)} chunks of <= {ROWS_PER_CHUNK} rows", flush=True)

    state = load_state()
    done_indices = {c["chunk"] for c in state["chunks"] if c.get("final_status") == "completed"}
    print(f"Already-completed chunks: {sorted(done_indices) or 'none'}", flush=True)

    for idx, path, n_rows in chunks:
        if idx in done_indices:
            continue
        # If chunk has been submitted but not finished, just resume polling.
        existing = next((c for c in state["chunks"] if c["chunk"] == idx and c.get("batch_id") and c.get("final_status") != "completed"), None)
        if existing:
            print(f"\n[chunk {idx}] resuming poll on existing batch {existing['batch_id']}", flush=True)
            entry = existing
        else:
            entry = submit_chunk(idx, path, n_rows)
            state["chunks"].append(entry)
            save_state(state)

        st = wait_chunk(entry)
        save_state(state)
        if st != "completed":
            print(f"\n[chunk {idx}] FAILED with status={st}. Aborting.", flush=True)
            print(f"  errors: {entry.get('errors')}", flush=True)
            sys.exit(2)

    print(f"\nAll {len(chunks)} chunks completed.", flush=True)


if __name__ == "__main__":
    main()
