"""Collect clustering batch results for any provider, parse into clustered.jsonl.

Usage:
    python collect_provider.py gemini
    python collect_provider.py xai
"""
import os, sys, json, re, random, statistics
import pandas as pd
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(BASE, ".env"), override=True)

from openai import OpenAI

CLUSTER_DIR = os.path.dirname(os.path.abspath(__file__))
BATCH_IDS_FILE = os.path.join(CLUSTER_DIR, "batch_ids.json")

client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
OLD_KEY = "<REDACTED_OPENAI_KEY>"
old_client = OpenAI(api_key=OLD_KEY)


def download_output(file_id):
    for cl in [client, old_client]:
        try:
            resp = cl.files.content(file_id)
            return (resp.read() if hasattr(resp, "read") else resp.content).decode()
        except Exception:
            continue
    raise RuntimeError(f"cannot download {file_id}")


def parse_cluster_json(raw_text):
    if raw_text is None:
        return None, "empty"
    txt = raw_text.strip()
    if txt.startswith("```"):
        txt = re.sub(r"^```(?:json)?\s*", "", txt)
        txt = re.sub(r"\s*```$", "", txt)
    try:
        obj = json.loads(txt)
    except Exception as e:
        return None, f"json: {e}"
    if "clusters" not in obj:
        return None, "no clusters key"
    return obj["clusters"], None


def build_assignments(clusters, n=50):
    assignments = [-1] * n
    labels = []
    for ci, c in enumerate(clusters):
        label = c.get("label", "")
        members = c.get("members", [])
        labels.append(str(label))
        for m in members:
            if not isinstance(m, int) or not (0 <= m < n):
                raise ValueError(f"bad member {m}")
            if assignments[m] != -1:
                raise ValueError(f"index {m} dup")
            assignments[m] = ci
    if any(a == -1 for a in assignments):
        missing = [i for i in range(n) if assignments[i] == -1]
        raise ValueError(f"unassigned: {missing[:5]}")
    sizes = [assignments.count(k) for k in range(len(labels))]
    return assignments, labels, sizes


def main():
    provider = sys.argv[1]
    extracted_path = os.path.join(CLUSTER_DIR, f"{provider}_extracted.jsonl")
    clustered_path = os.path.join(CLUSTER_DIR, f"{provider}_simpleqa_clustered.jsonl")

    # Load extracted rows
    extracted = {}
    with open(extracted_path) as f:
        for line in f:
            r = json.loads(line)
            extracted[r["id"]] = r
    print(f"Loaded {len(extracted)} extracted rows for {provider}", flush=True)

    # Get batch IDs
    with open(BATCH_IDS_FILE) as f:
        ids = json.load(f)

    # Download all outputs
    all_lines = []
    prov_info = ids.get(provider, {})
    if "chunks" in prov_info:
        # Multi-chunk (xAI)
        for ch in prov_info["chunks"]:
            bid = ch["batch_id"]
            b = client.batches.retrieve(bid)
            if b.status != "completed":
                print(f"  chunk {ch['chunk']}: {b.status} — SKIP", flush=True)
                continue
            raw = download_output(b.output_file_id)
            lines = raw.strip().splitlines()
            all_lines.extend(lines)
            print(f"  chunk {ch['chunk']}: {len(lines)} lines", flush=True)
    else:
        # Single batch
        bid = prov_info["batch_id"]
        b = client.batches.retrieve(bid)
        if b.status != "completed":
            print(f"  batch {bid}: {b.status} — ABORT", flush=True)
            return
        raw = download_output(b.output_file_id)
        all_lines = raw.strip().splitlines()
        print(f"  single batch: {len(all_lines)} lines", flush=True)

    # Parse
    out_rows = []
    parse_failures = []
    k_counts = []
    in_tok_total = out_tok_total = 0

    for line in all_lines:
        jr = json.loads(line)
        cid = jr.get("custom_id", "")
        qid = cid.replace(f"{provider}__", "")
        ext = extracted.get(qid)
        if ext is None:
            parse_failures.append((qid, "no extracted row"))
            continue

        body = jr.get("response", {}).get("body", {})
        usage = body.get("usage", {})
        in_tok_total += usage.get("prompt_tokens", 0) or 0
        out_tok_total += usage.get("completion_tokens", 0) or 0

        choices = body.get("choices", [])
        raw_judge = choices[0]["message"]["content"] if choices else None
        clusters, err = parse_cluster_json(raw_judge)
        if err:
            parse_failures.append((qid, err))
            continue
        try:
            assignments, labels, sizes = build_assignments(clusters, n=50)
        except Exception as e:
            parse_failures.append((qid, str(e)))
            continue

        modal = sizes.index(max(sizes))
        out_row = dict(ext)
        out_row.update({
            "n_clusters": len(labels),
            "cluster_labels": labels,
            "cluster_assignments": assignments,
            "cluster_sizes": sizes,
            "modal_cluster": modal,
            "modal_cluster_label": labels[modal],
            "raw_judge_response": raw_judge,
        })
        out_rows.append(out_row)
        k_counts.append(len(labels))

    with open(clustered_path, "w") as f:
        for r in sorted(out_rows, key=lambda x: x["id"]):
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    n_total = len(extracted)
    n_have = len(out_rows)
    n_fail = len(parse_failures)
    print(f"\n=== {provider} clustering results ===", flush=True)
    print(f"  rows: {n_have}/{n_total}", flush=True)
    print(f"  parse failures: {n_fail} ({n_fail*100/n_total:.2f}%)", flush=True)
    if k_counts:
        print(f"  K mean={statistics.mean(k_counts):.2f} median={statistics.median(k_counts)}", flush=True)
    print(f"  tokens: in={in_tok_total:,} out={out_tok_total:,}", flush=True)
    print(f"  wrote -> {clustered_path}", flush=True)

    if parse_failures:
        print(f"\n  first 5 failures:", flush=True)
        for qid, msg in parse_failures[:5]:
            print(f"    {qid}: {msg}", flush=True)


if __name__ == "__main__":
    main()
