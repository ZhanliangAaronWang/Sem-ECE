"""Step 0: verify gpt-5.2 access with reasoning DISABLED.

Sends ONE non-batch request and asserts reasoning_tokens == 0.
"""
import os, sys, json
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(BASE, ".env"), override=True)

from openai import OpenAI

client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

# Try the most current GPT-5 family disabling syntax. Newer SDKs use
# reasoning_effort="minimal" / "none". We'll attempt a couple variants.
attempts = [
    {"reasoning_effort": "minimal"},
    {"reasoning_effort": "none"},
    {},  # last resort: no reasoning param
]

resp = None
last_err = None
which = None
for kw in attempts:
    try:
        resp = client.chat.completions.create(
            model="gpt-5.2",
            messages=[{"role": "user", "content": "Reply with the single word: ok"}],
            max_completion_tokens=20,
            **kw,
        )
        which = kw
        break
    except Exception as e:
        last_err = str(e)
        print(f"  attempt {kw} failed: {last_err[:200]}", flush=True)

if resp is None:
    print(f"\nALL ATTEMPTS FAILED. Last error: {last_err}", flush=True)
    sys.exit(1)

print(f"\nSuccess with kwargs={which}", flush=True)
print(f"model: {resp.model}", flush=True)
print(f"reply text: {resp.choices[0].message.content!r}", flush=True)

usage = resp.usage
print(f"\nusage: prompt_tokens={usage.prompt_tokens} completion_tokens={usage.completion_tokens} total={usage.total_tokens}", flush=True)

reasoning_tokens = None
ctd = getattr(usage, "completion_tokens_details", None)
if ctd is not None:
    reasoning_tokens = getattr(ctd, "reasoning_tokens", None)
print(f"reasoning_tokens: {reasoning_tokens}", flush=True)

ok_text = "ok" in (resp.choices[0].message.content or "").lower()
ok_reason = (reasoning_tokens == 0)

print(f"\n[gate1] reply contains 'ok': {ok_text}", flush=True)
print(f"[gate2] reasoning_tokens == 0: {ok_reason}", flush=True)

if ok_text and ok_reason:
    print("\nGATE PASSED — proceed with clustering.", flush=True)
    sys.exit(0)
else:
    print("\nGATE FAILED.", flush=True)
    sys.exit(2)
