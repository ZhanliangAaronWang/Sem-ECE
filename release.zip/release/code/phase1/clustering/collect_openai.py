"""Steps 5+6+7 (OpenAI only): poll the clustering batch, parse output, run sanity checks.

Reads batch_id from phase1/clustering/batch_ids.json.
Polls until terminal state, downloads output file, joins with openai_extracted.jsonl,
parses cluster JSON per row, validates partitions, and writes the unified clustered file.

Outputs:
  phase1/clustering/openai_simpleqa_clustered.jsonl
  phase1/clustering_cost_report.md  (appended/created)

CLI:
  --watch       Loop polling every --interval sec until terminal
  --interval N  Poll interval (default 120)
  --no-wait     Just check current state once and exit if not terminal (used after manual completion)
"""
import os, sys, json, time, argparse, random, re, statistics
from collections import Counter
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(BASE, ".env"), override=True)

from openai import OpenAI

EXTRACTED = os.path.join(BASE, "clustering", "openai_extracted.jsonl")
CHUNKS_FILE = os.path.join(BASE, "clustering", "openai_chunks.json")
CLUSTERED = os.path.join(BASE, "clustering", "openai_simpleqa_clustered.jsonl")
COST_REPORT = os.path.join(BASE, "clustering_cost_report.md")

OLD_KEY = "<REDACTED_OPENAI_KEY>"
client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
old_client = OpenAI(api_key=OLD_KEY)


def load_extracted():
    rows = {}
    with open(EXTRACTED) as f:
        for line in f:
            r = json.loads(line)
            rows[r["id"]] = r
    return rows


def parse_cluster_json(raw_text):
    """Return (clusters_list_or_None, error_str_or_None). Forgiving to fenced JSON."""
    if raw_text is None:
        return None, "empty response"
    txt = raw_text.strip()
    if txt.startswith("```"):
        txt = re.sub(r"^```(?:json)?\s*", "", txt)
        txt = re.sub(r"\s*```$", "", txt)
    try:
        obj = json.loads(txt)
    except Exception as e:
        return None, f"json parse: {e}"
    if not isinstance(obj, dict) or "clusters" not in obj:
        return None, "missing 'clusters' key"
    clusters = obj["clusters"]
    if not isinstance(clusters, list):
        return None, "'clusters' not list"
    return clusters, None


def build_assignments(clusters, n=50):
    """Return (assignments_list, labels, sizes) or raise on partition error."""
    assignments = [-1] * n
    labels = []
    for ci, c in enumerate(clusters):
        if not isinstance(c, dict):
            raise ValueError(f"cluster {ci} not a dict")
        label = c.get("label", "")
        members = c.get("members", [])
        if not isinstance(members, list):
            raise ValueError(f"cluster {ci} members not a list")
        labels.append(str(label))
        for m in members:
            if not isinstance(m, int) or not (0 <= m < n):
                raise ValueError(f"cluster {ci} bad member {m}")
            if assignments[m] != -1:
                raise ValueError(f"index {m} appears twice (clusters {assignments[m]} and {ci})")
            assignments[m] = ci
    if any(a == -1 for a in assignments):
        missing = [i for i, a in enumerate(assignments) if a == -1]
        raise ValueError(f"unassigned indices: {missing[:5]}...")
    sizes = [assignments.count(k) for k in range(len(labels))]
    return assignments, labels, sizes


def state_str(s):
    return s if isinstance(s, str) else str(s)


def poll(batch_id, watch=False, interval=120):
    while True:
        b = client.batches.retrieve(batch_id)
        status = state_str(b.status)
        rc = b.request_counts
        print(f"  [{time.strftime('%H:%M:%S')}] status={status} | total={rc.total} done={rc.completed} fail={rc.failed}", flush=True)
        if status in TERMINAL or not watch:
            return b
        time.sleep(interval)


def main():
    ap = argparse.ArgumentParser()
    args = ap.parse_args()

    with open(CHUNKS_FILE) as f:
        chunks = json.load(f)["chunks"]
    print(f"Loading {len(chunks)} chunks", flush=True)

    # Download / load all chunk outputs into one merged text
    all_lines = []
    for c in chunks:
        ci = c["chunk"]
        local = c.get("local_output")
        if local and os.path.exists(os.path.join(BASE, local)):
            path = os.path.join(BASE, local)
            print(f"  chunk {ci}: reading local file {path}", flush=True)
            with open(path) as f:
                all_lines.extend(f.read().strip().splitlines())
        else:
            fid = c["output_file_id"]
            print(f"  chunk {ci}: downloading {fid}", flush=True)
            try:
                file_resp = client.files.content(fid)
                raw = (file_resp.read() if hasattr(file_resp, "read") else file_resp.content).decode()
                all_lines.extend(raw.strip().splitlines())
            except Exception:
                # Try old key
                file_resp = old_client.files.content(fid)
                raw = (file_resp.read() if hasattr(file_resp, "read") else file_resp.content).decode()
                all_lines.extend(raw.strip().splitlines())
    print(f"  total raw lines: {len(all_lines)}", flush=True)
    raw_text = "\n".join(all_lines)

    # Parse each line
    extracted = load_extracted()
    out_rows = []
    parse_failures = []
    k_counts = []
    singleton = 0
    coverage_ok = 0
    coverage_bad = []
    modal_mass = []
    in_tokens_total = 0
    out_tokens_total = 0

    seen_ids = set()
    for line in raw_text.splitlines():
        if not line.strip():
            continue
        try:
            jr = json.loads(line)
        except Exception as e:
            parse_failures.append((None, f"line json: {e}"))
            continue
        cid = jr.get("custom_id", "")
        qid = cid.replace("openai__", "")
        seen_ids.add(qid)
        ext = extracted.get(qid)
        if ext is None:
            parse_failures.append((qid, "no extracted row"))
            continue

        body = jr.get("response", {}).get("body", {})
        usage = body.get("usage", {})
        in_tokens_total += usage.get("prompt_tokens", 0) or 0
        out_tokens_total += usage.get("completion_tokens", 0) or 0

        choices = body.get("choices", [])
        raw_judge = choices[0]["message"]["content"] if choices else None

        clusters, err = parse_cluster_json(raw_judge)
        if err:
            parse_failures.append((qid, err))
            continue
        try:
            assignments, labels, sizes = build_assignments(clusters, n=50)
        except Exception as e:
            parse_failures.append((qid, f"partition: {e}"))
            continue

        modal = sizes.index(max(sizes))
        out_row = dict(ext)
        out_row.update({
            "n_clusters": len(labels),
            "cluster_labels": labels,
            "cluster_assignments": assignments,
            "cluster_sizes": sizes,
            "modal_cluster": modal,
            "modal_cluster_label": labels[modal],
            "raw_judge_response": raw_judge,
        })
        out_rows.append(out_row)
        k_counts.append(len(labels))
        if len(labels) == 1:
            singleton += 1
        if sum(sizes) == 50:
            coverage_ok += 1
        else:
            coverage_bad.append(qid)
        modal_mass.append(max(sizes) / 50.0)

    # Write clustered file
    with open(CLUSTERED, "w") as f:
        for r in sorted(out_rows, key=lambda x: x["id"]):
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"\nWrote {len(out_rows)} rows -> {CLUSTERED}", flush=True)

    # Sanity checks
    n_total = len(extracted)
    n_have = len(out_rows)
    n_fail = len(parse_failures)
    fail_rate = n_fail / n_total
    missing_ids = sorted(set(extracted.keys()) - seen_ids)

    print("\n=== Sanity checks (OpenAI) ===", flush=True)
    print(f"  rows: {n_have}/{n_total}  missing={len(missing_ids)}", flush=True)
    print(f"  parse failures: {n_fail} ({fail_rate*100:.2f}%)", flush=True)
    if k_counts:
        print(f"  K mean={statistics.mean(k_counts):.2f}  median={statistics.median(k_counts)}", flush=True)
        buckets = {"K=1":0,"K=2":0,"K=3":0,"K=4":0,"K=5":0,"K=6-10":0,"K=11-20":0,"K>20":0}
        for k in k_counts:
            if k==1: buckets["K=1"]+=1
            elif k==2: buckets["K=2"]+=1
            elif k==3: buckets["K=3"]+=1
            elif k==4: buckets["K=4"]+=1
            elif k==5: buckets["K=5"]+=1
            elif k<=10: buckets["K=6-10"]+=1
            elif k<=20: buckets["K=11-20"]+=1
            else: buckets["K>20"]+=1
        print(f"  K hist: {buckets}", flush=True)
    print(f"  singleton (K=1): {singleton} ({singleton*100/max(1,n_have):.1f}%)", flush=True)
    print(f"  coverage ok: {coverage_ok}/{n_have}  bad={len(coverage_bad)}", flush=True)
    if modal_mass:
        mm_buckets = [0]*5
        for v in modal_mass:
            i = min(4, int(v*5))
            mm_buckets[i]+=1
        print(f"  modal mass hist [0-0.2,0.2-0.4,0.4-0.6,0.6-0.8,0.8-1.0]: {mm_buckets}", flush=True)

    # extraction method recap (from extracted)
    em_counter = Counter()
    cm_counter = Counter()
    vmean_vals = []
    for r in extracted.values():
        em_counter.update(r["extraction_method"])
        cm_counter.update(r["confidence_extraction_method"])
        if r["verbalized_mean"] is not None:
            vmean_vals.append(r["verbalized_mean"])
    print(f"  extraction method: {dict(em_counter)}", flush=True)
    print(f"  confidence extraction: {dict(cm_counter)}", flush=True)
    if vmean_vals:
        print(f"  per-question verbalized_mean: mean={statistics.mean(vmean_vals):.3f} median={statistics.median(vmean_vals):.3f}", flush=True)
        vbuckets = [0]*5
        for v in vmean_vals:
            i = min(4, int(v*5))
            vbuckets[i]+=1
        print(f"  verbalized_mean hist: {vbuckets}", flush=True)

    # 5 random examples
    if out_rows:
        print("\n=== 5 random clustering examples (OpenAI) ===", flush=True)
        random.seed(0)
        sample = random.sample(out_rows, min(5, len(out_rows)))
        for r in sample:
            print(f"\n--- {r['id']} ---", flush=True)
            print(f"  Q: {r['question']}", flush=True)
            print(f"  gold: {r['gold_answer']}", flush=True)
            print(f"  K={r['n_clusters']} sizes={r['cluster_sizes']}", flush=True)
            for k, lbl in enumerate(r["cluster_labels"]):
                members = [i for i, a in enumerate(r["cluster_assignments"]) if a == k]
                print(f"    [{k}] {lbl}  members={members[:10]}{'...' if len(members)>10 else ''}", flush=True)

    # Cost report
    in_price = 1.25 / 2 / 1e6
    out_price = 10.0 / 2 / 1e6
    cost = in_tokens_total * in_price + out_tokens_total * out_price
    md = ["# Phase 1 Clustering Cost Report\n",
          "## OpenAI",
          f"- input tokens: {in_tokens_total:,}",
          f"- output tokens: {out_tokens_total:,}",
          f"- batch price (est): \\${in_price*1e6:.4f}/1M in, \\${out_price*1e6:.4f}/1M out",
          f"- est cost: ${cost:.2f}",
          ""]
    with open(COST_REPORT, "w") as f:
        f.write("\n".join(md))
    print(f"\nCost report -> {COST_REPORT}", flush=True)
    print(f"  in={in_tokens_total:,}  out={out_tokens_total:,}  est=${cost:.2f}", flush=True)

    # Print failure samples
    if parse_failures:
        print(f"\nFirst 5 parse failures:", flush=True)
        for qid, msg in parse_failures[:5]:
            print(f"  {qid}: {msg}", flush=True)

    # Final verdict
    ok = (fail_rate <= 0.02 and len(coverage_bad) == 0 and not missing_ids
          and (k_counts and 1.5 <= statistics.mean(k_counts) <= 10))
    if ok:
        print("\n[OpenAI] PASS — clustering ready.", flush=True)
    else:
        print("\n[OpenAI] FAIL — see metrics above.", flush=True)


if __name__ == "__main__":
    main()
