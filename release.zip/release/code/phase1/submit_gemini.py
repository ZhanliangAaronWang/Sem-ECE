"""Submit Gemini batch job(s) and poll until complete.

Uses smaller sub-batches (5000 inline requests each) to stay within quota.
"""
import os, json, time
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from google import genai
from google.genai import types

client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])

INPUT_FILE = os.path.join(BASE, "batch_inputs", "gemini_simpleqa.jsonl")
BATCH_IDS = os.path.join(BASE, "batch_ids.json")
OUTPUT_FILE = os.path.join(BASE, "batch_outputs", "gemini_raw.jsonl")

os.makedirs(os.path.join(BASE, "batch_outputs"), exist_ok=True)

if os.path.exists(BATCH_IDS):
    with open(BATCH_IDS) as f:
        batch_ids = json.load(f)
else:
    batch_ids = {}

MODEL = "gemini-3-flash-preview"
CHUNK_SIZE = 500  # small chunks to stay within API quota limits

if "gemini" in batch_ids and batch_ids["gemini"].get("batch_id"):
    sub_ids = batch_ids["gemini"]["batch_id"]
    if isinstance(sub_ids, str):
        sub_ids = [sub_ids]
    print(f"Resuming {len(sub_ids)} existing sub-batch(es)")
else:
    # Load all rows
    print("Loading batch input file...")
    all_rows = []
    with open(INPUT_FILE) as f:
        for line in f:
            all_rows.append(json.loads(line))
    print(f"  {len(all_rows)} requests loaded")

    # Split into chunks
    chunks = [all_rows[i:i + CHUNK_SIZE] for i in range(0, len(all_rows), CHUNK_SIZE)]
    print(f"  Splitting into {len(chunks)} sub-batches of ~{CHUNK_SIZE} each")

    sub_ids = []
    for idx, chunk in enumerate(chunks):
        print(f"  Submitting sub-batch {idx}/{len(chunks)-1} ({len(chunk)} requests)...")
        inlined = []
        for row in chunk:
            cfg = row["config"]
            inlined.append(types.InlinedRequest(
                contents=row["contents"],
                config=types.GenerateContentConfig(
                    system_instruction=cfg["system_instruction"],
                    max_output_tokens=cfg["max_output_tokens"],
                    temperature=cfg["temperature"],
                    top_p=cfg["top_p"],
                    thinking_config=types.ThinkingConfig(
                        thinking_budget=cfg["thinking_config"]["thinking_budget"]
                    ),
                    seed=cfg.get("seed"),
                ),
                metadata={"custom_id": row["custom_id"]},
            ))

        retries = 0
        while retries < 5:
            try:
                batch_job = client.batches.create(model=MODEL, src=inlined)
                sub_ids.append(batch_job.name)
                print(f"    batch_name: {batch_job.name} state: {batch_job.state}")
                # Brief delay between submissions to avoid burst rate limits
                time.sleep(2)
                break
            except Exception as e:
                if "429" in str(e) or "RESOURCE_EXHAUSTED" in str(e):
                    retries += 1
                    wait = 60 * retries
                    print(f"    Rate limited, waiting {wait}s (retry {retries}/5)...", flush=True)
                    time.sleep(wait)
                else:
                    raise

        # Save progress after each sub-batch
        batch_ids["gemini"] = {
            "batch_id": sub_ids.copy(),
            "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "n_rows": len(all_rows),
            "n_sub_batches": len(sub_ids),
        }
        with open(BATCH_IDS, "w") as f:
            json.dump(batch_ids, f, indent=2)

# Poll
print(f"\nPolling {len(sub_ids)} sub-batch(es)...")
while True:
    all_done = True
    succeeded = 0
    failed = 0
    pending = 0
    for name in sub_ids:
        try:
            job = client.batches.get(name=name)
            state_str = str(job.state)
            if "SUCCEEDED" in state_str:
                succeeded += 1
            elif "FAILED" in state_str or "CANCELLED" in state_str:
                failed += 1
            else:
                pending += 1
                all_done = False
        except Exception as e:
            print(f"    Error polling {name[-20:]}: {e}")
            all_done = False
    print(f"  gemini: succeeded={succeeded} failed={failed} pending={pending}/{len(sub_ids)}")
    if all_done:
        break
    time.sleep(300)

# Collect results
print("Collecting results...")
with open(OUTPUT_FILE, "w") as out:
    total = 0
    for name in sub_ids:
        try:
            job = client.batches.get(name=name)
            # Check for inline results or destination
            if hasattr(job, "dest") and job.dest:
                # File-based results
                out.write(json.dumps({"job_name": name, "dest": str(job.dest)}, default=str) + "\n")
                total += 1
            # Try to iterate results if available
            if hasattr(job, "responses") and job.responses:
                for r in job.responses:
                    out.write(json.dumps(r, default=str) + "\n")
                    total += 1
        except Exception as e:
            print(f"  Error collecting {name[-20:]}: {e}")
print(f"  Wrote {total} results to {OUTPUT_FILE}")

batch_ids["gemini"]["status"] = "completed"
batch_ids["gemini"]["completed_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
with open(BATCH_IDS, "w") as f:
    json.dump(batch_ids, f, indent=2)

print("Gemini batch done.")
