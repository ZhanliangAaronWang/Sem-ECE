"""Step 1: verify each of the 5 provider model names and that reasoning is OFF.

Sends "What is 2+2? Answer with just the number." to each provider with
max output 10 tokens. Prints full response + reasoning-token check.
"""
import os, sys, traceback, json
from dotenv import load_dotenv

load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

PROMPT = "What is 2+2? Answer with just the number."
MAX_TOK = 10

results = {}

# --- OpenAI: gpt-5.4 ---
def test_openai():
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    # gpt-5.4 exposes reasoning_effort values: none|low|medium|high|xhigh
    # (API-reported when 'minimal' was rejected). 'none' disables reasoning.
    resp = client.chat.completions.create(
        model="gpt-5.4",
        messages=[{"role": "user", "content": PROMPT}],
        max_completion_tokens=10,
        reasoning_effort="none",
    )
    text = resp.choices[0].message.content
    usage = resp.usage
    rtoks = getattr(
        getattr(usage, "completion_tokens_details", None),
        "reasoning_tokens",
        None,
    )
    return {
        "model": "gpt-5.4",
        "text": text,
        "reasoning_tokens": rtoks,
        "completion_tokens": usage.completion_tokens,
        "prompt_tokens": usage.prompt_tokens,
    }

# --- Anthropic: claude-opus-4-6 ---
def test_anthropic():
    from anthropic import Anthropic
    client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    resp = client.messages.create(
        model="claude-opus-4-6",
        max_tokens=10,
        messages=[{"role": "user", "content": PROMPT}],
    )
    blocks = resp.content
    text_blocks = [b.text for b in blocks if getattr(b, "type", None) == "text"]
    has_thinking = any(getattr(b, "type", None) == "thinking" for b in blocks)
    return {
        "model": "claude-opus-4-6",
        "text": "".join(text_blocks),
        "has_thinking_block": has_thinking,
        "block_types": [getattr(b, "type", None) for b in blocks],
        "input_tokens": resp.usage.input_tokens,
        "output_tokens": resp.usage.output_tokens,
    }

# --- Google: gemini-3-pro ---
def test_gemini():
    from google import genai
    from google.genai import types
    client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])
    resp = client.models.generate_content(
        model="gemini-3-flash-preview",
        contents=PROMPT,
        config=types.GenerateContentConfig(
            max_output_tokens=10,
            thinking_config=types.ThinkingConfig(thinking_budget=0),
        ),
    )
    um = resp.usage_metadata
    return {
        "model": "gemini-3-flash-preview",
        "text": resp.text,
        "prompt_token_count": getattr(um, "prompt_token_count", None),
        "candidates_token_count": getattr(um, "candidates_token_count", None),
        "thoughts_token_count": getattr(um, "thoughts_token_count", None),
    }

# --- xAI: grok-4.20-0309-non-reasoning ---
def test_xai():
    from openai import OpenAI
    client = OpenAI(
        api_key=os.environ["XAI_API_KEY"],
        base_url="https://api.x.ai/v1",
    )
    resp = client.chat.completions.create(
        model="grok-4.20-0309-non-reasoning",
        messages=[{"role": "user", "content": PROMPT}],
        max_tokens=10,
    )
    return {
        "model": "grok-4.20-0309-non-reasoning",
        "text": resp.choices[0].message.content,
        "prompt_tokens": resp.usage.prompt_tokens,
        "completion_tokens": resp.usage.completion_tokens,
    }

# --- Mistral: mistral-large-latest ---
def test_mistral():
    from mistralai.client import Mistral
    client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
    resp = client.chat.complete(
        model="mistral-large-latest",
        messages=[{"role": "user", "content": PROMPT}],
        max_tokens=10,
    )
    return {
        "model": "mistral-large-latest",
        "text": resp.choices[0].message.content,
        "prompt_tokens": resp.usage.prompt_tokens,
        "completion_tokens": resp.usage.completion_tokens,
    }

tests = [
    ("openai", test_openai),
    ("anthropic", test_anthropic),
    ("gemini", test_gemini),
    ("xai", test_xai),
    ("mistral", test_mistral),
]

for name, fn in tests:
    print(f"\n{'=' * 60}\n{name}\n{'=' * 60}")
    try:
        out = fn()
        results[name] = {"ok": True, "data": out}
        for k, v in out.items():
            print(f"  {k}: {v!r}")
    except Exception as e:
        results[name] = {"ok": False, "error": f"{type(e).__name__}: {e}"}
        print(f"  FAILED: {type(e).__name__}: {e}")
        tb = traceback.format_exc().splitlines()[-3:]
        for line in tb:
            print(f"    {line}")

print("\n" + "=" * 60 + "\nSUMMARY\n" + "=" * 60)
for name, r in results.items():
    status = "OK" if r["ok"] else "FAIL"
    print(f"  {name:10s} {status}")

# Write machine-readable summary
out_path = os.path.join(os.path.dirname(__file__), "step1_results.json")
with open(out_path, "w") as f:
    json.dump(results, f, indent=2, default=str)
print(f"\nWrote {out_path}")

# Exit nonzero if any failed
if not all(r["ok"] for r in results.values()):
    sys.exit(1)
