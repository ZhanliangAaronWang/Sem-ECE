"""Monitor all 5 provider jobs and send email when all are done.

Polls every 5 minutes. Checks:
- OpenAI: batch_state_openai.json (sequential sub-batches)
- Anthropic: API poll (3 sub-batches)
- Gemini: batch_outputs/gemini_progress.json (async Slurm job)
- xAI: batch_outputs/xai_progress.json (async Slurm job)
- Mistral: batch_state_mistral.json (batch API)

Sends a summary email to the user when all 5 are done (or if any failed).
"""
import os, json, time, subprocess, sys
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

EMAIL = "anonymous@example.invalid"
POLL_INTERVAL = 300  # 5 minutes


def check_openai():
    path = os.path.join(BASE, "batch_state_openai.json")
    if not os.path.exists(path):
        return "pending", "no state file"
    with open(path) as f:
        d = json.load(f)
    offset = d.get("next_offset", 0)
    total = 30282
    n_batches = len(d.get("completed_batches", []))
    if d.get("error"):
        return "failed", f"error at offset {offset}: {d['error'][:100]}"
    # Check if merged output exists
    merged = os.path.join(BASE, "batch_outputs", "openai_raw.jsonl")
    if os.path.exists(merged):
        lines = sum(1 for _ in open(merged))
        return "done", f"{lines} output lines, {n_batches} sub-batches"
    if offset >= total:
        return "done", f"all {n_batches} sub-batches complete, awaiting merge"
    return "running", f"{offset}/{total} rows ({offset*100/total:.0f}%), {n_batches} sub-batches done"


def check_anthropic():
    try:
        from anthropic import Anthropic
        ac = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        total_succ = 0
        total_proc = 0
        total_err = 0
        statuses = []
        for bid in ["msgbatch_01Agyaufke6SkRU6qVjRTA4Z",
                     "msgbatch_018ZQb6PtULmRf4QuHHezyEi",
                     "msgbatch_01EZy59PBWK2YRa2BLY9eGzk"]:
            s = ac.messages.batches.retrieve(bid)
            c = s.request_counts
            total_succ += c.succeeded
            total_proc += c.processing
            total_err += c.errored
            statuses.append(s.processing_status)
        total = total_succ + total_proc + total_err
        if all(s == "ended" for s in statuses):
            return "done", f"{total_succ}/{total} succeeded, {total_err} errors"
        if total_err > 0 and total_proc == 0:
            return "failed", f"{total_err} errors out of {total}"
        return "running", f"{total_succ}/{total} succeeded, {total_proc} processing"
    except Exception as e:
        return "error", str(e)[:100]


def check_async_job(name):
    progress_path = os.path.join(BASE, "batch_outputs", f"{name}_progress.json")
    output_path = os.path.join(BASE, "batch_outputs", f"{name}_raw.jsonl")
    if os.path.exists(progress_path):
        with open(progress_path) as f:
            d = json.load(f)
        completed = d.get("completed", 0)
        total = d.get("total", 216300)
        errors = d.get("errors", 0)
        if completed >= total:
            return "done", f"{completed}/{total} done, {errors} errors, {d.get('elapsed_min',0):.0f} min"
        return "running", f"{completed}/{total} ({completed*100/total:.0f}%)"
    if os.path.exists(output_path):
        lines = sum(1 for _ in open(output_path))
        return "running", f"{lines}/216300 lines written ({lines*100/216300:.0f}%)"
    return "pending", "no output yet"


def check_mistral():
    path = os.path.join(BASE, "batch_state_mistral.json")
    if not os.path.exists(path):
        return "pending", "no state file"
    with open(path) as f:
        d = json.load(f)
    try:
        from mistralai.client import Mistral
        mc = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
        total_done = 0
        total_failed = 0
        total_req = 0
        all_terminal = True
        for j in d.get("jobs", []):
            job = mc.batch.jobs.get(job_id=j["job_id"])
            done = getattr(job, "completed_requests", 0) or 0
            failed = getattr(job, "failed_requests", 0) or 0
            tot = getattr(job, "total_requests", 0) or 0
            total_done += done
            total_failed += failed
            total_req += tot
            if job.status not in ("SUCCESS", "FAILED", "TIMEOUT_EXCEEDED", "CANCELLED", "COMPLETED"):
                all_terminal = False
        if all_terminal and total_req > 0:
            return "done", f"{total_done}/{total_req} done, {total_failed} failed"
        if total_req > 0:
            return "running", f"{total_done}/{total_req} ({total_done*100/total_req:.0f}% done)"
        return "running", "processing"
    except Exception as e:
        return "error", str(e)[:100]


def send_email(subject, body):
    try:
        proc = subprocess.run(
            ["mail", "-s", subject, EMAIL],
            input=body.encode(),
            timeout=30,
        )
        return proc.returncode == 0
    except Exception as e:
        print(f"Email failed: {e}", flush=True)
        return False


TERMINAL = ("done", "failed")


def main():
    print(f"Monitoring all 5 providers. Polling every {POLL_INTERVAL}s.", flush=True)
    print(f"Will email {EMAIL} when all done.\n", flush=True)
    failure_emailed = set()

    while True:
        results = {}
        results["openai"] = check_openai()
        results["anthropic"] = check_anthropic()
        results["gemini"] = check_async_job("gemini")
        results["xai"] = check_async_job("xai")
        results["mistral"] = check_mistral()

        print(f"[{time.strftime('%H:%M:%S')}]", flush=True)
        all_terminal = True
        new_failures = []
        for name, (status, detail) in results.items():
            print(f"  {name:<12s} {status:<10s} {detail}", flush=True)
            if status not in TERMINAL:
                all_terminal = False
            if status in ("failed", "error") and name not in failure_emailed:
                new_failures.append(name)

        if new_failures:
            subject = f"Phase 1 — failure: {', '.join(new_failures)}"
            body = "New failure(s) detected.\n\n"
            for name, (status, detail) in results.items():
                body += f"  {name}: {status} — {detail}\n"
            body += f"\nCheck logs at: {BASE}/logs/\n"
            send_email(subject, body)
            for name in new_failures:
                failure_emailed.add(name)
            print(f"\nFailure email sent ({', '.join(new_failures)}).", flush=True)

        if all_terminal:
            subject = "Phase 1 SimpleQA Generation COMPLETE"
            body = "All 5 providers reached a terminal state.\n\n"
            for name, (status, detail) in results.items():
                body += f"  {name}: {status} — {detail}\n"
            body += f"\nCheck results at: {BASE}/batch_outputs/\n"
            send_email(subject, body)
            print(f"\nAll terminal! Email sent to {EMAIL}", flush=True)
            break

        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    main()
