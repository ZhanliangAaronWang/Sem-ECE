"""SimpleQA Gemini backfill chain.

Runs end-to-end:
  Phase A. Every 30 min, retry gemini_batch_submit.py to push more chunks
           (Gemini batch quota resets gradually; each retry submits whatever fits).
  Phase B. Every 5 min, poll all tracked batch jobs in
           phase1/batch_outputs/gemini_batch_jobs.json.
  Phase C. When every job reaches a terminal state (SUCCEEDED / FAILED / CANCELLED /
           EXPIRED), run gemini_batch_collect_v2.py to merge new rows into
           phase1/batch_outputs/gemini_raw.jsonl.
  Phase D. Run prep_gemini.py (rebuilds gemini_extracted + clustering batch input).
  Phase E. Wipe stale gemini_chunks.json (so submit_openai_chunked.py rechunks)
           and submit a fresh clustering batch via submit_openai_chunked.py.
           [phase1 has only an openai-chunked submitter; same script is reused for
            other providers' clustering since the *judge* model is OpenAI gpt-5.2.]
  Phase F. Poll clustering batches every 3 min; when done, run collect.
  Phase G. Submit grading via prep_and_submit.py --providers gemini --submit.
  Phase H. Poll grading every 3 min; when done, run collect_and_check.py.
  Phase I. Recompute confidence + ECE.
  Phase J. Re-run all top-level figures (n-sweep, bootstrap CI, ECE figures).

Logs to phase1/logs/simpleqa_gemini_chain_master.log AND stdout.
"""
import os, json, time, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P1   = os.path.join(ROOT, "phase1")
LOG  = os.path.join(P1, "logs", "simpleqa_gemini_chain_master.log")

GEMINI_JOBS_FILE = os.path.join(P1, "batch_outputs", "gemini_batch_jobs.json")
TARGET_TOTAL_SAMPLES = 216300         # 4326 Q × 50 samples
GEMINI_TERMINAL = {
    "JOB_STATE_SUCCEEDED", "JOB_STATE_FAILED",
    "JOB_STATE_CANCELLED", "JOB_STATE_EXPIRED",
    "succeeded", "failed", "cancelled", "expired",
}
OPENAI_TERMINAL = {"completed", "failed", "expired", "cancelled"}

GEMINI_SUBMIT_RETRY_S = 600    # 10 min (was 30 — accelerate quota-refresh detection)
GEMINI_POLL_S         = 180    # 3  min
OPENAI_POLL_S         = 180    # 3  min


def log(m):
    line = f"[{time.strftime('%Y-%m-%dT%H:%M:%S')}] {m}"
    print(line, flush=True)
    with open(LOG, "a") as f:
        f.write(line + "\n")


def run(cmd, cwd=ROOT, ok_nonzero=False):
    log(f"$ {cmd}  (cwd={cwd})")
    r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    log(f"  exit={r.returncode}")
    for line in r.stdout.splitlines()[-50:]:
        log(f"    {line}")
    if r.stderr.strip():
        for line in r.stderr.splitlines()[-20:]:
            log(f"    [stderr] {line}")
    if r.returncode != 0 and not ok_nonzero:
        raise RuntimeError(f"command failed: {cmd}")
    return r


# -----------------------------------------------------------------------
# Phase A + B: gemini submit-retry + poll
# -----------------------------------------------------------------------
def gemini_batch_state():
    """(all_terminal, all_succeeded, summary_lines)"""
    sys.path.insert(0, ROOT)
    from dotenv import load_dotenv
    load_dotenv(os.path.join(P1, ".env"), override=True)
    from google import genai
    c = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])

    if not os.path.exists(GEMINI_JOBS_FILE):
        return False, False, ["  no jobs file yet"]
    with open(GEMINI_JOBS_FILE) as f:
        jobs = json.load(f)
    all_term, all_ok, lines = True, True, []
    for j in jobs:
        try:
            job = c.batches.get(name=j["name"])
            state = str(job.state).split(".")[-1]
        except Exception as e:
            state = f"ERR:{str(e)[:60]}"
            all_term, all_ok = False, False
        lines.append(f"  {j['name'][-30:]}: {state}")
        if state not in GEMINI_TERMINAL:
            all_term, all_ok = False, False
        elif "SUCCEED" not in state.upper():
            all_ok = False
    return all_term, all_ok, lines


def gemini_currently_have_samples():
    """Count unique success custom_ids across master + sync-worker files.
    Sync workers (gemini_worker.py) write to gemini_raw_w<idx>.jsonl in parallel
    with the batch chain — counting both gives a true coverage measure even
    before merge_gemini.py folds workers into master."""
    import glob
    paths = [os.path.join(P1, "batch_outputs", "gemini_raw.jsonl")]
    paths += sorted(glob.glob(os.path.join(P1, "batch_outputs", "gemini_raw_w*.jsonl")))
    seen = set()
    for p in paths:
        if not os.path.exists(p):
            continue
        with open(p) as fh:
            for line in fh:
                try:
                    r = json.loads(line)
                    if r.get("status") == "success" and r.get("custom_id"):
                        seen.add(r["custom_id"])
                except Exception:
                    pass
    return len(seen)


def phase_a_b_submit_and_wait():
    log("=" * 80)
    log("PHASE A+B: keep submitting Gemini chunks (retry on quota) + poll until coverage hits target")
    log("=" * 80)
    last_submit = 0.0
    coverage_floor = int(TARGET_TOTAL_SAMPLES * 0.95)
    submit_quiet = False  # set True once gemini_batch_submit.py reports "Nothing to do."
    while True:
        # try a submission round whenever the quota cool-off may have elapsed
        if (time.time() - last_submit) >= GEMINI_SUBMIT_RETRY_S:
            log("attempting gemini_batch_submit.py (will skip already-submitted)")
            r = run("python3 gemini_batch_submit.py 2>&1 | tail -50",
                    cwd=P1, ok_nonzero=True)
            if "Nothing to do" in (r.stdout or "") or \
               "All remaining rows already covered by existing batch jobs" in (r.stdout or ""):
                submit_quiet = True
                log("submit reports nothing to do — every custom_id is now done or in-flight.")
            last_submit = time.time()

        all_term, all_ok, lines = gemini_batch_state()
        have = gemini_currently_have_samples()
        log("status:")
        for l in lines:
            log(l)
        log(f"  master gemini_raw success rows: {have:,}/{TARGET_TOTAL_SAMPLES:,}  "
            f"(submit_quiet={submit_quiet})")

        # Exit conditions:
        #   - submit script reports nothing left to push AND all in-flight terminal
        #   - OR coverage already past the 95% floor AND all in-flight terminal
        if all_term and (submit_quiet or have >= coverage_floor):
            if not all_ok:
                log("WARNING: some Gemini batches reached non-success terminal state. Continuing — partial recovery still useful.")
            log("=== GEMINI BACKFILL DONE ===")
            return
        time.sleep(GEMINI_POLL_S)


def phase_c_collect_gemini():
    log("=" * 80)
    log("PHASE C: collect Gemini batch outputs + merge sync-worker files into master")
    log("=" * 80)
    run("python3 gemini_batch_collect_v2.py", cwd=P1)
    # merge_gemini.py folds gemini_raw_w*.jsonl (sync workers) into the master file
    # so prep_gemini sees the union.
    run("python3 merge_gemini.py", cwd=P1, ok_nonzero=True)
    have = gemini_currently_have_samples()
    log(f"after collect+merge: master+workers cover {have:,} samples ({have/TARGET_TOTAL_SAMPLES*100:.1f}%)")


def phase_d_prep_gemini():
    log("=" * 80)
    log("PHASE D: prep_gemini.py — re-extract complete-50 questions, build clustering batch")
    log("=" * 80)
    run("python3 prep_gemini.py", cwd=os.path.join(P1, "clustering"))


def _wipe_old_state():
    """phase1 has gemini-clustering state mixed into openai_chunks.json (legacy);
    we only want to wipe Gemini-specific state. Look for gemini_chunks.json."""
    for fn in ("gemini_chunks.json",):
        p = os.path.join(P1, "clustering", fn)
        if os.path.exists(p):
            bak = p + ".bak_pre_backfill"
            os.rename(p, bak)
            log(f"  archived stale state: {fn} -> {os.path.basename(bak)}")


def phase_ef_clustering():
    log("=" * 80)
    log("PHASE E+F: submit gemini clustering (sequential, blocks until each chunk completes)")
    log("=" * 80)
    _wipe_old_state()
    run("python3 submit_gemini_chunked.py",
        cwd=os.path.join(P1, "clustering"))


def phase_g_collect_clustering():
    log("=" * 80)
    log("PHASE G: collect gemini clustering outputs")
    log("=" * 80)
    # phase1 collect_provider.py is the unified collector
    run("python3 collect_provider.py gemini",
        cwd=os.path.join(P1, "clustering"))


def phase_h_grading():
    log("=" * 80)
    log("PHASE H: submit gemini grading + poll + collect")
    log("=" * 80)
    run("python3 prep_and_submit.py --providers gemini --submit",
        cwd=os.path.join(P1, "grading"))

    # poll
    bids_path = os.path.join(P1, "grading", "batch_ids.json")
    from openai import OpenAI
    c = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    while True:
        with open(bids_path) as fh:
            bids = json.load(fh)
        info = bids.get("gemini")
        if info is None:
            raise RuntimeError("gemini grading batch not found in batch_ids.json")
        try:
            b = c.batches.retrieve(info["batch_id"])
        except Exception as e:
            log(f"  gemini grade poll ERR {str(e)[:80]}")
            time.sleep(OPENAI_POLL_S)
            continue
        rc = b.request_counts
        log(f"  gemini grade: {b.status} {rc.completed}/{rc.total} fail={rc.failed}")
        if b.status in OPENAI_TERMINAL:
            break
        time.sleep(OPENAI_POLL_S)

    run("python3 collect_and_check.py --providers gemini",
        cwd=os.path.join(P1, "grading"))


def phase_i_confidence():
    log("=" * 80)
    log("PHASE I: compute confidence + ECE")
    log("=" * 80)
    run("python3 compute_confidence.py", cwd=os.path.join(P1, "confidence"))
    run("python3 compute_ece.py",        cwd=os.path.join(P1, "confidence"))


def phase_j_replot():
    log("=" * 80)
    log("PHASE J: re-render top-level figures + bootstrap CI")
    log("=" * 80)
    run("python3 experiment_n_sweep.py",       cwd=ROOT)
    run("python3 experiment_bootstrap_ci.py",  cwd=ROOT)
    run("python3 make_ece_figure.py",          cwd=ROOT)


def main():
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    log("=" * 80)
    log(f"SimpleQA-Gemini backfill chain started ({time.strftime('%Y-%m-%dT%H:%M:%S')})")
    log("=" * 80)

    phase_a_b_submit_and_wait()
    phase_c_collect_gemini()
    phase_d_prep_gemini()
    phase_ef_clustering()
    phase_g_collect_clustering()
    phase_h_grading()
    phase_i_confidence()
    phase_j_replot()

    log("=" * 80)
    log("=== SIMPLEQA GEMINI BACKFILL PIPELINE COMPLETE ===")
    log("=" * 80)


if __name__ == "__main__":
    main()
