"""Retry the 112 OpenAI rows that sub-batch 7 silently dropped.

Diffs openai_simpleqa.jsonl against the union of all openai_raw_*.jsonl files
to find missing custom_ids, then calls the real-time chat completions API
(reusing each row's original body verbatim) and appends results to
openai_raw.jsonl in the same batch-output format.
"""
import os, json, asyncio
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from openai import AsyncOpenAI

INPUT_FILE = os.path.join(BASE, "batch_inputs", "openai_simpleqa.jsonl")
OUTPUT_DIR = os.path.join(BASE, "batch_outputs")
MERGED = os.path.join(OUTPUT_DIR, "openai_raw.jsonl")
CONCURRENCY = 10

client = AsyncOpenAI(api_key=os.environ["OPENAI_API_KEY"])


def find_missing():
    got = set()
    for i in range(8):
        p = os.path.join(OUTPUT_DIR, f"openai_raw_{i}.jsonl")
        with open(p) as f:
            for line in f:
                got.add(json.loads(line)["custom_id"])
    missing = []
    with open(INPUT_FILE) as f:
        for line in f:
            d = json.loads(line)
            if d["custom_id"] not in got:
                missing.append(d)
    return missing


async def call_one(row, sem):
    async with sem:
        body = row["body"]
        try:
            resp = await client.chat.completions.create(**body)
            return {
                "id": f"retry_{row['custom_id']}",
                "custom_id": row["custom_id"],
                "response": {
                    "status_code": 200,
                    "request_id": resp.id,
                    "body": resp.model_dump(),
                },
                "error": None,
            }
        except Exception as e:
            return {
                "id": f"retry_{row['custom_id']}",
                "custom_id": row["custom_id"],
                "response": None,
                "error": {"message": str(e)[:500]},
            }


async def main():
    missing = find_missing()
    print(f"{len(missing)} missing rows", flush=True)
    if not missing:
        return
    sem = asyncio.Semaphore(CONCURRENCY)
    tasks = [call_one(r, sem) for r in missing]
    results = []
    done = 0
    for coro in asyncio.as_completed(tasks):
        r = await coro
        results.append(r)
        done += 1
        if done % 10 == 0 or done == len(missing):
            print(f"  {done}/{len(missing)}", flush=True)
    n_err = sum(1 for r in results if r["error"])
    print(f"Done. {len(results) - n_err} ok, {n_err} errors.", flush=True)
    with open(MERGED, "a") as f:
        for r in results:
            f.write(json.dumps(r) + "\n")
    print(f"Appended to {MERGED}", flush=True)


if __name__ == "__main__":
    asyncio.run(main())
