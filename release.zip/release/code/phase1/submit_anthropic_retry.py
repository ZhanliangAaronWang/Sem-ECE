"""Submit retry batch for the 72,060 SimpleQA samples that errored with
credit_balance_too_low on the original 2026-04-10 run. Idempotent — if
batch already submitted, resumes polling.

Inputs:
  batch_inputs/anthropic_simpleqa_retry.jsonl

Outputs:
  batch_outputs/anthropic_raw_retry.jsonl
  batch_ids_retry.json   (state)

Constraints (locked):
  model = claude-opus-4-6
  no thinking / reasoning enabled
  max_tokens = 256, temperature = 1.0  (params come from the original input
  rows verbatim, so they always match the 67% already in anthropic_raw.jsonl)
"""
import os, json, time, sys
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from anthropic import Anthropic

client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

INPUT_FILE = os.path.join(BASE, "batch_inputs", "anthropic_simpleqa_retry.jsonl")
STATE_FILE = os.path.join(BASE, "batch_ids_retry.json")
OUTPUT_FILE = os.path.join(BASE, "batch_outputs", "anthropic_raw_retry.jsonl")

os.makedirs(os.path.dirname(OUTPUT_FILE), exist_ok=True)

state = {}
if os.path.exists(STATE_FILE):
    with open(STATE_FILE) as f:
        state = json.load(f)

if state.get("batch_id"):
    batch_id = state["batch_id"]
    print(f"[resume] existing batch: {batch_id}", flush=True)
else:
    print("[load] reading retry input...", flush=True)
    requests = []
    with open(INPUT_FILE) as f:
        for line in f:
            requests.append(json.loads(line))
    print(f"  {len(requests)} requests", flush=True)
    if len(requests) > 100_000:
        print("  ERROR: retry exceeds 100K limit; would need chunking. Aborting.")
        sys.exit(1)

    # Sanity check: every request must be opus-4-6 with no thinking
    for r in requests:
        p = r["params"]
        assert p["model"] == "claude-opus-4-6", f"bad model in {r['custom_id']}"
        assert "thinking" not in p, f"thinking enabled in {r['custom_id']}"

    print("[submit] creating batch...", flush=True)
    batch = client.messages.batches.create(requests=requests)
    batch_id = batch.id
    state = {
        "batch_id": batch_id,
        "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "n_rows": len(requests),
    }
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)
    print(f"  batch_id: {batch_id}", flush=True)

# Poll
print("[poll] every 5 min until ended...", flush=True)
while True:
    s = client.messages.batches.retrieve(batch_id)
    c = s.request_counts
    print(f"  {time.strftime('%H:%M:%S')} status={s.processing_status} "
          f"succeeded={c.succeeded} processing={c.processing} "
          f"errored={c.errored} canceled={c.canceled} expired={c.expired}",
          flush=True)
    if s.processing_status == "ended":
        break
    time.sleep(300)

# Download
print("[download] writing results...", flush=True)
with open(OUTPUT_FILE, "w") as out:
    n = 0
    for result in client.messages.batches.results(batch_id):
        out.write(json.dumps(result.model_dump(), default=str) + "\n")
        n += 1
print(f"  wrote {n} results to {OUTPUT_FILE}", flush=True)

# Validate
ok = err = 0
for line in open(OUTPUT_FILE):
    r = json.loads(line)
    if r.get("result", {}).get("message"):
        ok += 1
    else:
        err += 1
print(f"[validate] ok={ok}, err={err}", flush=True)

state["status"] = "completed"
state["completed_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
state["ok"] = ok
state["err"] = err
with open(STATE_FILE, "w") as f:
    json.dump(state, f, indent=2)

print("[done] retry batch complete.", flush=True)
