"""Poll all jobs in gemini_batch_jobs.json and append results to gemini_raw.jsonl.

Run repeatedly (or in a loop) — only newly-finished jobs add new rows.
For each finished job:
  - Pull inlined_responses (or destination file if used) and write each as a row
    {custom_id, text, prompt_tokens, completion_tokens, status} matching the existing schema.
  - Mark the job as 'collected' in the jobs file so we don't double-write.
"""
import os, json, time, argparse
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from google import genai

MASTER_OUT = os.path.join(BASE, "batch_outputs", "gemini_raw.jsonl")
JOBS_FILE = os.path.join(BASE, "batch_outputs", "gemini_batch_jobs.json")

TERMINAL = {"JOB_STATE_SUCCEEDED", "JOB_STATE_FAILED", "JOB_STATE_CANCELLED",
            "JOB_STATE_EXPIRED", "JOB_STATE_PARTIALLY_SUCCEEDED"}


def state_str(s):
    return str(s).split(".")[-1]


def already_success_ids():
    done = set()
    if not os.path.exists(MASTER_OUT):
        return done
    with open(MASTER_OUT) as f:
        for line in f:
            try:
                r = json.loads(line)
                if r.get("status") == "success" and r.get("custom_id"):
                    done.add(r["custom_id"])
            except Exception:
                pass
    return done


def extract_row(resp_obj, fallback_cid):
    """Pull (custom_id, text, prompt_tok, completion_tok, status, error) from one inlined response."""
    cid = fallback_cid
    md = getattr(resp_obj, "metadata", None)
    if md and isinstance(md, dict):
        cid = md.get("custom_id", cid)

    err = getattr(resp_obj, "error", None)
    response = getattr(resp_obj, "response", None)

    if err is not None and response is None:
        return {"custom_id": cid, "text": None, "error": str(err)[:500], "status": "error"}

    if response is None:
        return {"custom_id": cid, "text": None, "error": "no response object", "status": "error"}

    try:
        text = response.text
    except Exception as e:
        text = None
        return {"custom_id": cid, "text": None, "error": f"text extract: {e}", "status": "error"}

    um = getattr(response, "usage_metadata", None)
    return {
        "custom_id": cid,
        "text": text,
        "prompt_tokens": getattr(um, "prompt_token_count", None) if um else None,
        "completion_tokens": getattr(um, "candidates_token_count", None) if um else None,
        "status": "success",
    }


def collect_job(client, job_entry, already_done):
    name = job_entry["name"]
    job = client.batches.get(name=name)
    state = state_str(job.state)
    print(f"  {name}: state={state}", flush=True)
    if state not in TERMINAL:
        return 0, state

    new_rows = []
    expected_cids = job_entry.get("custom_ids", [])

    inlined = getattr(job, "inlined_responses", None) or getattr(getattr(job, "dest", None), "inlined_responses", None)
    if inlined:
        for i, resp in enumerate(inlined):
            fallback = expected_cids[i] if i < len(expected_cids) else None
            row = extract_row(resp, fallback)
            cid = row.get("custom_id")
            if cid and cid in already_done and row.get("status") == "success":
                continue
            new_rows.append(row)
    else:
        # Possibly file-based; report and skip
        print(f"    no inlined_responses on job; dest={getattr(job,'dest',None)}", flush=True)

    if new_rows:
        with open(MASTER_OUT, "a") as f:
            for r in new_rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"    appended {len(new_rows)} rows", flush=True)

    return len(new_rows), state


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--watch", action="store_true", help="Loop, polling every --interval sec until all jobs terminal")
    ap.add_argument("--interval", type=int, default=120)
    args = ap.parse_args()

    client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])

    if not os.path.exists(JOBS_FILE):
        print(f"No {JOBS_FILE} — nothing to collect.", flush=True)
        return

    while True:
        with open(JOBS_FILE) as f:
            jobs = json.load(f)

        already = already_success_ids()
        any_pending = False
        total_appended = 0
        for j in jobs:
            if j.get("collected"):
                continue
            n, state = collect_job(client, j, already)
            total_appended += n
            if state in TERMINAL:
                j["collected"] = True
                j["final_state"] = state
                j["collected_at"] = time.time()
            else:
                any_pending = True
            with open(JOBS_FILE, "w") as f:
                json.dump(jobs, f, indent=2)

        print(f"\nThis pass: +{total_appended} rows. Pending jobs: {any_pending}", flush=True)
        if not args.watch or not any_pending:
            break
        print(f"Sleeping {args.interval}s...", flush=True)
        time.sleep(args.interval)


if __name__ == "__main__":
    main()
