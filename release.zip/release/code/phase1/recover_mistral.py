"""Recover Mistral results.

1. Download partial outputs from all 5 batch jobs (1 SUCCESS + 4 CANCELLED).
2. Merge into mistral_raw.jsonl.
3. Diff against input chunks to find missing custom_ids (~357 expected:
   ~277 server-side `Internal error` + 80 stuck-tail rows).
4. Retry the missing rows via real-time chat completions API.
5. Append retry results to mistral_raw.jsonl.
"""
import os, json, glob, time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from mistralai.client import Mistral

client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])

OUTPUT_DIR = os.path.join(BASE, "batch_outputs")
MERGED = os.path.join(OUTPUT_DIR, "mistral_raw.jsonl")
STATE_FILE = os.path.join(BASE, "batch_state_mistral.json")
INPUT_GLOB = os.path.join(BASE, "batch_inputs", "mistral_simpleqa_chunk*.jsonl")
MODEL = "mistral-large-latest"
CONCURRENCY = 8


def download_all():
    with open(STATE_FILE) as f:
        state = json.load(f)
    total = 0
    with open(MERGED, "w") as out:
        for j in state["jobs"]:
            job = client.batch.jobs.get(job_id=j["job_id"])
            ofid = getattr(job, "output_file", None)
            if not ofid:
                print(f"  chunk{j['chunk_idx']}: no output_file (status={job.status})", flush=True)
                continue
            print(f"  chunk{j['chunk_idx']}: downloading {ofid}...", flush=True)
            content = client.files.download(file_id=ofid)
            data = content if isinstance(content, bytes) else content.read() if hasattr(content, "read") else content.encode()
            n = 0
            for line in data.decode().strip().split("\n"):
                if not line:
                    continue
                out.write(line + "\n")
                n += 1
                total += 1
            print(f"    wrote {n} lines", flush=True)
    print(f"Total written: {total}", flush=True)
    return total


def find_missing():
    got = set()
    with open(MERGED) as f:
        for line in f:
            d = json.loads(line)
            cid = d.get("custom_id")
            if cid:
                got.add(cid)
    expected = {}
    for fp in sorted(glob.glob(INPUT_GLOB)):
        with open(fp) as f:
            for line in f:
                d = json.loads(line)
                expected[d["custom_id"]] = d
    missing = [expected[cid] for cid in expected if cid not in got]
    print(f"Expected {len(expected)}, got {len(got)}, missing {len(missing)}", flush=True)
    return missing


def call_one(row):
    body = row["body"]
    cid = row["custom_id"]
    try:
        resp = client.chat.complete(
            model=MODEL,
            messages=body["messages"],
            max_tokens=body.get("max_tokens", 256),
            temperature=body.get("temperature", 1.0),
            top_p=body.get("top_p", 1.0),
            random_seed=body.get("random_seed", 0),
        )
        return {
            "id": f"retry_{cid}",
            "custom_id": cid,
            "response": {
                "status_code": 200,
                "body": resp.model_dump(),
            },
            "error": None,
        }
    except Exception as e:
        return {
            "id": f"retry_{cid}",
            "custom_id": cid,
            "response": None,
            "error": {"message": str(e)[:500]},
        }


def retry_missing(missing):
    if not missing:
        return
    print(f"Retrying {len(missing)} rows with concurrency={CONCURRENCY}...", flush=True)
    results = []
    done = 0
    with ThreadPoolExecutor(max_workers=CONCURRENCY) as ex:
        futs = [ex.submit(call_one, r) for r in missing]
        for fut in as_completed(futs):
            results.append(fut.result())
            done += 1
            if done % 25 == 0 or done == len(missing):
                print(f"  {done}/{len(missing)}", flush=True)
    n_err = sum(1 for r in results if r["error"])
    print(f"Retry done. {len(results) - n_err} ok, {n_err} errors.", flush=True)
    with open(MERGED, "a") as f:
        for r in results:
            f.write(json.dumps(r) + "\n")
    print(f"Appended to {MERGED}", flush=True)


if __name__ == "__main__":
    print("Step 1: download partial outputs", flush=True)
    download_all()
    print("\nStep 2: find missing custom_ids", flush=True)
    missing = find_missing()
    print("\nStep 3: retry via real-time API", flush=True)
    retry_missing(missing)
    print("\nDone.", flush=True)
