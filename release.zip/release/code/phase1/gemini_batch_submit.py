"""Submit remaining Gemini SimpleQA rows via the Gemini Batch API.

- Skips custom_ids that already have status=='success' in batch_outputs/gemini_raw.jsonl.
- Splits remaining rows into chunks (default 20k each) and submits each as one batch job.
- Persists job metadata to batch_outputs/gemini_batch_jobs.json so the collector can poll later.
"""
import os, json, math, time, argparse
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from google import genai
from google.genai import types

INPUT_FILE = os.path.join(BASE, "batch_inputs", "gemini_simpleqa.jsonl")
MASTER_OUT = os.path.join(BASE, "batch_outputs", "gemini_raw.jsonl")
JOBS_FILE = os.path.join(BASE, "batch_outputs", "gemini_batch_jobs.json")
MODEL = "gemini-3-flash-preview"
DEFAULT_CHUNK = 20000


def load_done():
    done = set()
    if not os.path.exists(MASTER_OUT):
        return done
    with open(MASTER_OUT) as f:
        for line in f:
            try:
                r = json.loads(line)
                if r.get("status") == "success" and r.get("custom_id"):
                    done.add(r["custom_id"])
            except Exception:
                pass
    return done


def to_inlined(row):
    cfg = row["config"]
    return {
        "contents": row["contents"],
        "config": {
            "system_instruction": cfg["system_instruction"],
            "max_output_tokens": cfg["max_output_tokens"],
            "temperature": cfg["temperature"],
            "top_p": cfg["top_p"],
            "thinking_config": {"thinking_budget": cfg["thinking_config"]["thinking_budget"]},
            "seed": cfg.get("seed"),
        },
        "metadata": {"custom_id": row["custom_id"]},
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--chunk-size", type=int, default=DEFAULT_CHUNK)
    ap.add_argument("--max-chunks", type=int, default=None,
                    help="Submit only the first N chunks (for staged rollout)")
    args = ap.parse_args()

    client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])

    print(f"Loading input from {INPUT_FILE}...", flush=True)
    rows = []
    with open(INPUT_FILE) as f:
        for line in f:
            rows.append(json.loads(line))
    print(f"  total input: {len(rows)}", flush=True)

    done = load_done()
    print(f"  already-success custom_ids: {len(done)}", flush=True)

    remaining = [r for r in rows if r["custom_id"] not in done]
    print(f"  remaining to submit: {len(remaining)}", flush=True)
    if not remaining:
        print("Nothing to do.", flush=True)
        return

    # Already-submitted jobs: avoid resubmitting the same custom_ids
    if os.path.exists(JOBS_FILE):
        with open(JOBS_FILE) as f:
            existing = json.load(f)
        already_in_jobs = set()
        for j in existing:
            already_in_jobs.update(j.get("custom_ids", []))
        before = len(remaining)
        remaining = [r for r in remaining if r["custom_id"] not in already_in_jobs]
        print(f"  filtered out {before - len(remaining)} already in pending batch jobs", flush=True)
        jobs = existing
    else:
        jobs = []

    if not remaining:
        print("All remaining rows already covered by existing batch jobs. Run gemini_batch_collect.py.", flush=True)
        return

    n_chunks = math.ceil(len(remaining) / args.chunk_size)
    if args.max_chunks:
        n_chunks = min(n_chunks, args.max_chunks)
    print(f"\nSplitting into {n_chunks} chunk(s) of up to {args.chunk_size} rows each", flush=True)

    for ci in range(n_chunks):
        chunk = remaining[ci * args.chunk_size : (ci + 1) * args.chunk_size]
        if not chunk:
            break
        cids = [r["custom_id"] for r in chunk]
        inlined = [to_inlined(r) for r in chunk]
        display = f"gemini_simpleqa_chunk_{int(time.time())}_{ci}"
        print(f"\n[chunk {ci+1}/{n_chunks}] {len(chunk)} rows -> submitting as {display}", flush=True)
        try:
            job = client.batches.create(
                model=MODEL,
                src=inlined,
                config=types.CreateBatchJobConfig(display_name=display),
            )
        except Exception as e:
            print(f"  SUBMIT FAILED: {e}", flush=True)
            print(f"  Stopping. Re-run after the issue is resolved (already-submitted chunks are saved).", flush=True)
            break
        print(f"  job: {job.name}  state: {job.state}", flush=True)
        jobs.append({
            "name": job.name,
            "display_name": display,
            "submitted_at": time.time(),
            "n_rows": len(chunk),
            "custom_ids": cids,
        })
        with open(JOBS_FILE, "w") as f:
            json.dump(jobs, f, indent=2)

    print(f"\n{len(jobs)} total job(s) tracked in {JOBS_FILE}", flush=True)
    print("Run gemini_batch_collect.py to poll and download results.", flush=True)


if __name__ == "__main__":
    main()
