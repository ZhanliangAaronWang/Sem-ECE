"""Build a retry batch input containing ONLY the custom_ids whose original
batch result was an error (credit_balance_too_low etc.).

Inputs:
  batch_inputs/anthropic_simpleqa.jsonl   — original 216,300 requests
  batch_outputs/anthropic_raw.jsonl       — original outputs (mix of msg + errored)

Outputs:
  batch_inputs/anthropic_simpleqa_retry.jsonl  — only the failed custom_ids
  batch_outputs/anthropic_failed_ids.json      — list of custom_ids needing retry
"""
import json, os
from collections import Counter

BASE = os.path.dirname(os.path.abspath(__file__))
RAW = os.path.join(BASE, "batch_outputs", "anthropic_raw.jsonl")
SRC = os.path.join(BASE, "batch_inputs", "anthropic_simpleqa.jsonl")
OUT = os.path.join(BASE, "batch_inputs", "anthropic_simpleqa_retry.jsonl")
IDS = os.path.join(BASE, "batch_outputs", "anthropic_failed_ids.json")

failed = set()
err_types = Counter()
with open(RAW) as f:
    for line in f:
        r = json.loads(line)
        msg = r.get("result", {}).get("message")
        if msg is None:
            failed.add(r["custom_id"])
            err = r.get("result", {}).get("error", {}).get("error", {})
            err_types[err.get("type", "?")] += 1

print(f"failed custom_ids: {len(failed)}")
print(f"error types: {err_types}")

n_in = 0
n_out = 0
with open(SRC) as fi, open(OUT, "w") as fo:
    for line in fi:
        n_in += 1
        row = json.loads(line)
        if row["custom_id"] in failed:
            # sanity: never enable extended thinking on retry
            assert "thinking" not in row.get("params", {}), \
                f"retry must not enable thinking: {row['custom_id']}"
            assert row["params"]["model"] == "claude-opus-4-6", \
                f"retry must keep model=claude-opus-4-6: {row['custom_id']}"
            fo.write(json.dumps(row) + "\n")
            n_out += 1

with open(IDS, "w") as f:
    json.dump(sorted(failed), f)

assert n_out == len(failed), f"mismatch: wrote {n_out}, expected {len(failed)}"
print(f"read {n_in} from src, wrote {n_out} to {OUT}")
print(f"failed ids saved to {IDS}")
