"""Build batch input JSONL files for all 5 providers.

Reads phase1/data/simpleqa_full.jsonl and writes per-provider batch input files
to phase1/batch_inputs/.
"""
import json, os, sys

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "data", "simpleqa_full.jsonl")
OUT = os.path.join(BASE, "batch_inputs")
os.makedirs(OUT, exist_ok=True)

SYSTEM = """You are answering questions for a research benchmark. Be concise and precise.

Your response MUST end with EXACTLY these two lines, with nothing after them:
Answer: <your final answer>
Confidence: <integer between 0 and 100>%

Keep <your final answer> as short as possible — ideally a single name, number, date, or short phrase. Do not put explanations or reasoning on the Answer line itself.

If you genuinely do not know, write:
Answer: I don't know
Confidence: 0%"""

N_SAMPLES = 50

# Load questions
questions = []
with open(DATA) as f:
    for line in f:
        questions.append(json.loads(line))
print(f"Loaded {len(questions)} questions")

# ---------------------------------------------------------------------------
# OpenAI: 7 rows per question (6×n=8 + 1×n=2), native n
# ---------------------------------------------------------------------------
path = os.path.join(OUT, "openai_simpleqa.jsonl")
count = 0
with open(path, "w") as f:
    for q in questions:
        for chunk_idx in range(7):
            n_val = 8 if chunk_idx < 6 else 2
            row = {
                "custom_id": f"{q['id']}__chunk{chunk_idx}",
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": "gpt-5.4",
                    "messages": [
                        {"role": "system", "content": SYSTEM},
                        {"role": "user", "content": q["question"]},
                    ],
                    "max_completion_tokens": 256,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "reasoning_effort": "none",
                    "n": n_val,
                    "seed": chunk_idx,  # distinct seed per chunk for distinct samples
                },
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            count += 1
print(f"OpenAI:    {count:>8,d} rows → {path}")

# ---------------------------------------------------------------------------
# Anthropic: 50 rows per question (replicate), Message Batches format
# ---------------------------------------------------------------------------
path = os.path.join(OUT, "anthropic_simpleqa.jsonl")
count = 0
with open(path, "w") as f:
    for q in questions:
        for s in range(N_SAMPLES):
            row = {
                "custom_id": f"{q['id']}__sample{s:02d}",
                "params": {
                    "model": "claude-opus-4-6",
                    "max_tokens": 256,
                    "temperature": 1.0,
                    # top_p omitted: claude-opus-4-6 rejects temperature+top_p together
                    "system": SYSTEM,
                    "messages": [
                        {"role": "user", "content": q["question"]},
                    ],
                },
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            count += 1
print(f"Anthropic: {count:>8,d} rows → {path}")

# ---------------------------------------------------------------------------
# Gemini: 50 rows per question (replicate), will be submitted via
# client.batches.create(src=list[InlinedRequest]) or file upload
# Store as JSONL with metadata.custom_id for tracking
# ---------------------------------------------------------------------------
path = os.path.join(OUT, "gemini_simpleqa.jsonl")
count = 0
with open(path, "w") as f:
    for q in questions:
        for s in range(N_SAMPLES):
            row = {
                "custom_id": f"{q['id']}__sample{s:02d}",
                "contents": q["question"],
                "config": {
                    "system_instruction": SYSTEM,
                    "max_output_tokens": 256,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "thinking_config": {"thinking_budget": 0},
                    "seed": s,
                },
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            count += 1
print(f"Gemini:    {count:>8,d} rows → {path}")

# ---------------------------------------------------------------------------
# xAI: 50 rows per question (replicate), OpenAI-compatible batch format
# ---------------------------------------------------------------------------
path = os.path.join(OUT, "xai_simpleqa.jsonl")
count = 0
with open(path, "w") as f:
    for q in questions:
        for s in range(N_SAMPLES):
            row = {
                "custom_id": f"{q['id']}__sample{s:02d}",
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": "grok-4.20-0309-non-reasoning",
                    "messages": [
                        {"role": "system", "content": SYSTEM},
                        {"role": "user", "content": q["question"]},
                    ],
                    "max_tokens": 256,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "seed": s + 1,  # xAI requires seed > 0
                },
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            count += 1
print(f"xAI:       {count:>8,d} rows → {path}")

# ---------------------------------------------------------------------------
# Mistral: 50 rows per question (replicate), Mistral batch format
# (custom_id + body only; model specified at batch job level)
# ---------------------------------------------------------------------------
path = os.path.join(OUT, "mistral_simpleqa.jsonl")
count = 0
with open(path, "w") as f:
    for q in questions:
        for s in range(N_SAMPLES):
            row = {
                "custom_id": f"{q['id']}__sample{s:02d}",
                "body": {
                    "messages": [
                        {"role": "system", "content": SYSTEM},
                        {"role": "user", "content": q["question"]},
                    ],
                    "max_tokens": 256,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "random_seed": s,
                },
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            count += 1
print(f"Mistral:   {count:>8,d} rows → {path}")

# Summary
print("\n--- File sizes ---")
for name in ["openai", "anthropic", "gemini", "xai", "mistral"]:
    p = os.path.join(OUT, f"{name}_simpleqa.jsonl")
    sz = os.path.getsize(p)
    print(f"  {name:<12s} {sz / 1e6:>8.1f} MB")
