"""Tiny test: submit 5 inlined requests via Gemini Batch API and poll until done."""
import os, json, time
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from google import genai
from google.genai import types

INPUT_FILE = os.path.join(BASE, "batch_inputs", "gemini_simpleqa.jsonl")
MODEL = "gemini-3-flash-preview"

client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])

rows = []
with open(INPUT_FILE) as f:
    for line in f:
        rows.append(json.loads(line))
        if len(rows) >= 5:
            break

print(f"Loaded {len(rows)} test rows", flush=True)

inlined = []
for r in rows:
    cfg = r["config"]
    inlined.append({
        "contents": r["contents"],
        "config": {
            "system_instruction": cfg["system_instruction"],
            "max_output_tokens": cfg["max_output_tokens"],
            "temperature": cfg["temperature"],
            "top_p": cfg["top_p"],
            "thinking_config": {"thinking_budget": cfg["thinking_config"]["thinking_budget"]},
            "seed": cfg.get("seed"),
        },
        "metadata": {"custom_id": r["custom_id"]},
    })

print(f"Submitting batch with {len(inlined)} requests, model={MODEL}...", flush=True)
try:
    job = client.batches.create(
        model=MODEL,
        src=inlined,
        config=types.CreateBatchJobConfig(display_name="gemini_test_5"),
    )
    print(f"  job name: {job.name}", flush=True)
    print(f"  initial state: {job.state}", flush=True)
except Exception as e:
    print(f"SUBMIT FAILED: {e}", flush=True)
    raise

# Poll
TERMINAL = {"JOB_STATE_SUCCEEDED", "JOB_STATE_FAILED", "JOB_STATE_CANCELLED",
            "JOB_STATE_EXPIRED", "JOB_STATE_PARTIALLY_SUCCEEDED"}
start = time.time()
while True:
    job = client.batches.get(name=job.name)
    state = str(job.state).split(".")[-1] if not isinstance(job.state, str) else job.state
    elapsed = time.time() - start
    print(f"  [{elapsed:.0f}s] state={state}", flush=True)
    if state in TERMINAL or any(t in str(job.state) for t in TERMINAL):
        break
    if elapsed > 1800:
        print("TIMEOUT after 30 min", flush=True)
        break
    time.sleep(15)

print(f"\nFinal job: {job}", flush=True)

# Try to extract results
if hasattr(job, "dest") and job.dest is not None:
    print(f"\ndest: {job.dest}", flush=True)
if hasattr(job, "inlined_responses"):
    print(f"\ninlined_responses count: {len(job.inlined_responses) if job.inlined_responses else 0}", flush=True)
    if job.inlined_responses:
        for i, resp in enumerate(job.inlined_responses[:3]):
            print(f"  [{i}] {resp}", flush=True)
