"""Phase 1 Step 3b — Collect grading batch results, parse, sanity check.

Usage:
    python collect_and_check.py --providers openai
    python collect_and_check.py --providers openai --watch   # poll until done
"""
import os, json, time, re, argparse, random
import pandas as pd
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(BASE, ".env"), override=True)

from openai import OpenAI

CLUSTER_DIR = os.path.join(BASE, "clustering")
GRADING_DIR = os.path.dirname(os.path.abspath(__file__))
BATCH_IDS_FILE = os.path.join(GRADING_DIR, "batch_ids.json")
COST_REPORT = os.path.join(BASE, "grading_cost_report.md")

TERMINAL = {"completed", "failed", "expired", "cancelled"}

client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

# Also keep old key for fallback
OLD_KEY = "<REDACTED_OPENAI_KEY>"
old_client = OpenAI(api_key=OLD_KEY)


def retrieve_with_retry(bid, max_tries=8):
    delay = 5
    for i in range(max_tries):
        try:
            return client.batches.retrieve(bid)
        except Exception:
            try:
                return old_client.batches.retrieve(bid)
            except Exception:
                pass
            time.sleep(delay)
            delay = min(60, delay * 2)
    raise RuntimeError(f"retrieve {bid} failed after {max_tries} attempts")


def poll(batch_id, watch=False, interval=30):
    while True:
        b = retrieve_with_retry(batch_id)
        st = b.status
        rc = b.request_counts
        print(f"  [{time.strftime('%H:%M:%S')}] {st} done={rc.completed}/{rc.total} fail={rc.failed}", flush=True)
        if st in TERMINAL or not watch:
            return b
        time.sleep(interval)


def parse_grade(raw_text):
    if not raw_text:
        return "PARSE_ERROR", None
    txt = raw_text.strip()
    if txt.startswith("```"):
        txt = re.sub(r"^```(?:json)?\s*", "", txt)
        txt = re.sub(r"\s*```$", "", txt)
    try:
        obj = json.loads(txt)
        grade = obj.get("grade", "").upper()
        if grade in ("CORRECT", "INCORRECT", "NOT_ATTEMPTED"):
            return grade, raw_text
    except Exception:
        pass
    # Fallback: look for keyword
    upper = raw_text.upper()
    for g in ("CORRECT", "INCORRECT", "NOT_ATTEMPTED"):
        if g in upper:
            return g, raw_text
    return "PARSE_ERROR", raw_text


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--providers", nargs="+", default=["openai"])
    ap.add_argument("--watch", action="store_true")
    ap.add_argument("--interval", type=int, default=30)
    args = ap.parse_args()

    with open(BATCH_IDS_FILE) as f:
        batch_ids = json.load(f)

    all_records = []
    cost_lines = ["# Phase 1 Grading Cost Report\n"]
    total_in = total_out = 0

    for prov in args.providers:
        if prov not in batch_ids:
            print(f"[{prov}] SKIP — no batch_id", flush=True)
            continue
        bid = batch_ids[prov]["batch_id"]
        print(f"[{prov}] batch_id: {bid}", flush=True)

        b = poll(bid, watch=args.watch, interval=args.interval)
        if b.status != "completed":
            print(f"[{prov}] NOT COMPLETED (status={b.status}). Skipping.", flush=True)
            continue

        # Download
        print(f"  downloading output...", flush=True)
        try:
            resp = client.files.content(b.output_file_id)
        except Exception:
            resp = old_client.files.content(b.output_file_id)
        raw = (resp.read() if hasattr(resp, "read") else resp.content).decode()

        # Load clustering data for join
        clustered = {}
        cpath = os.path.join(CLUSTER_DIR, f"{prov}_simpleqa_clustered.jsonl")
        with open(cpath) as f:
            for line in f:
                r = json.loads(line)
                clustered[r["id"]] = r

        # Parse
        records = []
        in_tok = out_tok = 0
        for line in raw.strip().splitlines():
            jr = json.loads(line)
            cid = jr["custom_id"]
            qid = cid.replace(f"{prov}__", "")
            body = jr.get("response", {}).get("body", {})
            usage = body.get("usage", {})
            in_tok += usage.get("prompt_tokens", 0) or 0
            out_tok += usage.get("completion_tokens", 0) or 0

            choices = body.get("choices", [])
            raw_judge = choices[0]["message"]["content"] if choices else None
            grade, raw_text = parse_grade(raw_judge)
            Y = 1 if grade == "CORRECT" else (None if grade == "PARSE_ERROR" else 0)

            cr = clustered.get(qid, {})
            records.append({
                "id": qid,
                "model": prov,
                "question": cr.get("question", ""),
                "gold_answer": cr.get("gold_answer", ""),
                "modal_cluster_label": cr.get("modal_cluster_label", ""),
                "grade": grade,
                "Y": Y,
                "raw_judge_response": raw_text,
            })

        # Save
        out_path = os.path.join(GRADING_DIR, f"{prov}_simpleqa_graded.jsonl")
        with open(out_path, "w") as f:
            for r in sorted(records, key=lambda x: x["id"]):
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"  wrote {len(records)} rows -> {out_path}", flush=True)

        # Sanity checks
        n = len(records)
        n_correct = sum(1 for r in records if r["grade"] == "CORRECT")
        n_incorrect = sum(1 for r in records if r["grade"] == "INCORRECT")
        n_na = sum(1 for r in records if r["grade"] == "NOT_ATTEMPTED")
        n_parse = sum(1 for r in records if r["grade"] == "PARSE_ERROR")
        acc = n_correct / n if n > 0 else 0

        expected = len(clustered)
        missing = expected - n

        print(f"\n=== Sanity checks ({prov}) ===", flush=True)
        print(f"  rows: {n}/{expected}  missing={missing}", flush=True)
        print(f"  parse failures: {n_parse} ({n_parse*100/n:.2f}%)", flush=True)
        print(f"  CORRECT: {n_correct} ({n_correct*100/n:.1f}%)", flush=True)
        print(f"  INCORRECT: {n_incorrect} ({n_incorrect*100/n:.1f}%)", flush=True)
        print(f"  NOT_ATTEMPTED: {n_na} ({n_na*100/n:.1f}%)", flush=True)
        print(f"  accuracy (mean Y): {acc:.4f}", flush=True)

        if acc < 0.20 or acc > 0.80:
            print(f"  WARNING: accuracy {acc:.4f} outside expected [0.20, 0.80]", flush=True)
        if n_parse / n > 0.01:
            print(f"  WARNING: parse failure rate > 1%", flush=True)

        # Random examples
        random.seed(0)
        sample = random.sample(records, min(10, len(records)))
        print(f"\n  10 random examples:", flush=True)
        for r in sample:
            print(f"    Q: {r['question'][:80]}...", flush=True)
            print(f"    gold={r['gold_answer']}  pred={r['modal_cluster_label']}  grade={r['grade']}", flush=True)

        # Cost
        in_price = 1.25 / 2 / 1e6
        out_price = 10.0 / 2 / 1e6
        cost = in_tok * in_price + out_tok * out_price
        total_in += in_tok
        total_out += out_tok
        cost_lines.append(f"## {prov}")
        cost_lines.append(f"- input tokens: {in_tok:,}")
        cost_lines.append(f"- output tokens: {out_tok:,}")
        cost_lines.append(f"- est cost: ${cost:.2f}\n")

        all_records.extend(records)

    # Unified table
    if all_records:
        df = pd.DataFrame(all_records)
        pq_path = os.path.join(GRADING_DIR, "all_grades.parquet")
        df.to_parquet(pq_path, index=False)
        print(f"\nWrote {len(df)} rows -> {pq_path}", flush=True)

    # Cost report
    total_cost = total_in * 1.25 / 2 / 1e6 + total_out * 10.0 / 2 / 1e6
    cost_lines.append(f"## Total\n- in={total_in:,}  out={total_out:,}  cost=${total_cost:.2f}\n")
    with open(COST_REPORT, "w") as f:
        f.write("\n".join(cost_lines))
    print(f"Cost report -> {COST_REPORT}", flush=True)


if __name__ == "__main__":
    main()
