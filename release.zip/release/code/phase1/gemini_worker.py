"""Parallel-worker variant of gemini_async.py.

Reads SLURM_ARRAY_TASK_ID and SLURM_ARRAY_TASK_COUNT (or --worker / --num-workers
args) and processes only the slice of rows where
    int(custom_id_hash) % num_workers == worker_idx

Each worker writes to its own output file: gemini_raw_w<idx>.jsonl
A final merge step combines all worker files into gemini_raw.jsonl.

For resume: each worker reads its own output file plus the master
gemini_raw.jsonl to skip already-completed custom_ids.
"""
import os, json, time, asyncio, sys, hashlib, argparse
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from google import genai
from google.genai import types

INPUT_FILE = os.path.join(BASE, "batch_inputs", "gemini_simpleqa.jsonl")
MASTER_OUTPUT = os.path.join(BASE, "batch_outputs", "gemini_raw.jsonl")
OUTPUT_DIR = os.path.join(BASE, "batch_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

MODEL = "gemini-3-flash-preview"
MAX_CONCURRENT = 5
RATE_LIMIT_RPM = 100
DELAY = 60.0 / RATE_LIMIT_RPM


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--worker", type=int, default=None)
    p.add_argument("--num-workers", type=int, default=None)
    a = p.parse_args()
    if a.worker is None:
        a.worker = int(os.environ.get("SLURM_ARRAY_TASK_ID", 0))
    if a.num_workers is None:
        a.num_workers = int(os.environ.get("SLURM_ARRAY_TASK_COUNT", 1))
    return a


def slice_for(custom_id, num_workers):
    h = int(hashlib.md5(custom_id.encode()).hexdigest(), 16)
    return h % num_workers


def load_completed(*paths):
    """Return custom_ids that have a SUCCESSFUL row. Errors are retried."""
    done = set()
    for p in paths:
        if not os.path.exists(p):
            continue
        with open(p) as f:
            for line in f:
                try:
                    r = json.loads(line)
                    cid = r.get("custom_id")
                    if cid and r.get("status") == "success":
                        done.add(cid)
                except Exception:
                    pass
    return done


async def main():
    args = parse_args()
    worker_idx = args.worker
    num_workers = args.num_workers
    output_file = os.path.join(OUTPUT_DIR, f"gemini_raw_w{worker_idx}.jsonl")
    print(f"=== Worker {worker_idx}/{num_workers} ===", flush=True)
    print(f"Output: {output_file}", flush=True)

    client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])

    print("Loading input...", flush=True)
    all_rows = []
    with open(INPUT_FILE) as f:
        for line in f:
            all_rows.append(json.loads(line))
    print(f"  {len(all_rows)} total input rows", flush=True)

    completed = load_completed(MASTER_OUTPUT, output_file)
    print(f"  {len(completed)} already-completed rows seen across master + own file", flush=True)

    my_slice = [r for r in all_rows if slice_for(r["custom_id"], num_workers) == worker_idx]
    remaining = [r for r in my_slice if r["custom_id"] not in completed]
    print(f"  My slice: {len(my_slice)}, remaining after dedup: {len(remaining)}", flush=True)

    if not remaining:
        print("Nothing to do.", flush=True)
        return

    sem = asyncio.Semaphore(MAX_CONCURRENT)
    rate_limiter = asyncio.Lock()
    last_request_time = [0.0]
    results_buffer = []
    errors = {"count": 0, "last": ""}
    done_count = [0]
    start = time.time()

    async def process_one(row):
        cfg = row["config"]
        cid = row["custom_id"]
        async with sem:
            async with rate_limiter:
                now = time.monotonic()
                wait = DELAY - (now - last_request_time[0])
                if wait > 0:
                    await asyncio.sleep(wait)
                last_request_time[0] = time.monotonic()

            last_err = ""
            MAX_RETRIES = 20
            for attempt in range(MAX_RETRIES):
                try:
                    resp = await client.aio.models.generate_content(
                        model=MODEL,
                        contents=row["contents"],
                        config=types.GenerateContentConfig(
                            system_instruction=cfg["system_instruction"],
                            max_output_tokens=cfg["max_output_tokens"],
                            temperature=cfg["temperature"],
                            top_p=cfg["top_p"],
                            thinking_config=types.ThinkingConfig(
                                thinking_budget=cfg["thinking_config"]["thinking_budget"]
                            ),
                            seed=cfg.get("seed"),
                        ),
                    )
                    um = resp.usage_metadata
                    results_buffer.append({
                        "custom_id": cid,
                        "text": resp.text,
                        "prompt_tokens": getattr(um, "prompt_token_count", None),
                        "completion_tokens": getattr(um, "candidates_token_count", None),
                        "status": "success",
                    })
                    done_count[0] += 1
                    if done_count[0] % 250 == 0:
                        elapsed = time.time() - start
                        rpm = done_count[0] / (elapsed / 60) if elapsed > 0 else 0
                        eta = (len(remaining) - done_count[0]) / rpm if rpm > 0 else 0
                        print(f"  w{worker_idx}: {done_count[0]}/{len(remaining)} ({rpm:.0f} RPM, ETA {eta:.0f} min, errs={errors['count']})", flush=True)
                    return
                except Exception as e:
                    last_err = str(e)
                    if "429" in last_err or "RESOURCE_EXHAUSTED" in last_err:
                        # capped exponential backoff: 5,10,20,40,60,60,60,60,60,60
                        await asyncio.sleep(min(60, 2 ** attempt * 5))
                    elif "500" in last_err or "503" in last_err or "UNAVAILABLE" in last_err:
                        await asyncio.sleep(min(30, 2 ** attempt * 2))
                    else:
                        # non-retryable
                        errors["count"] += 1
                        errors["last"] = last_err[:200]
                        results_buffer.append({
                            "custom_id": cid,
                            "text": None,
                            "error": last_err[:500],
                            "status": "error",
                        })
                        done_count[0] += 1
                        return
            errors["count"] += 1
            errors["last"] = last_err[:200]
            results_buffer.append({
                "custom_id": cid,
                "text": None,
                "error": f"retry_exhausted({MAX_RETRIES}): {last_err[:400]}",
                "status": "error",
            })
            done_count[0] += 1

    async def flusher():
        while True:
            await asyncio.sleep(10)
            if results_buffer:
                with open(output_file, "a") as f:
                    while results_buffer:
                        r = results_buffer.pop(0)
                        f.write(json.dumps(r, ensure_ascii=False) + "\n")

    print(f"Starting: {len(remaining)} requests, concurrency={MAX_CONCURRENT}, target={RATE_LIMIT_RPM} RPM", flush=True)
    flush_task = asyncio.create_task(flusher())
    await asyncio.gather(*[process_one(r) for r in remaining])
    flush_task.cancel()
    with open(output_file, "a") as f:
        while results_buffer:
            r = results_buffer.pop(0)
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

    elapsed = time.time() - start
    print(f"\nWorker {worker_idx} done. {done_count[0]}/{len(remaining)} in {elapsed/60:.1f} min, errors={errors['count']}", flush=True)


if __name__ == "__main__":
    asyncio.run(main())
