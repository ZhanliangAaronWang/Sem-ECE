"""Submit xAI batch and poll until complete.

xAI's batch API is OpenAI-compatible for file upload but requires a `name` field
in batch creation that the OpenAI SDK doesn't send. Uses raw HTTP for batch creation.
Also: max 50,000 requests per file → split into sub-batches.
"""
import os, json, time
from dotenv import load_dotenv
import httpx

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE, ".env"))

from openai import OpenAI

API_KEY = os.environ["XAI_API_KEY"]
client = OpenAI(api_key=API_KEY, base_url="https://api.x.ai/v1")
HEADERS = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}

INPUT_FILE = os.path.join(BASE, "batch_inputs", "xai_simpleqa.jsonl")
BATCH_IDS = os.path.join(BASE, "batch_ids.json")
OUTPUT_DIR = os.path.join(BASE, "batch_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

CHUNK_SIZE = 50_000

if os.path.exists(BATCH_IDS):
    with open(BATCH_IDS) as f:
        batch_ids = json.load(f)
else:
    batch_ids = {}

if "xai" in batch_ids and batch_ids["xai"].get("batch_id"):
    sub_ids = batch_ids["xai"]["batch_id"]
    if isinstance(sub_ids, str):
        sub_ids = [sub_ids]
    print(f"Resuming {len(sub_ids)} existing sub-batch(es)")
else:
    # Split input file into chunks
    lines = open(INPUT_FILE).readlines()
    chunks = [lines[i:i + CHUNK_SIZE] for i in range(0, len(lines), CHUNK_SIZE)]
    print(f"Splitting {len(lines)} rows into {len(chunks)} sub-batches ({[len(c) for c in chunks]})")

    sub_ids = []
    for idx, chunk in enumerate(chunks):
        # Write temp chunk file
        tmp = f"/tmp/xai_chunk_{idx}.jsonl"
        with open(tmp, "w") as f:
            f.writelines(chunk)

        # Upload
        print(f"  Sub-batch {idx}: uploading {len(chunk)} rows...")
        with open(tmp, "rb") as f:
            file_obj = client.files.create(file=f, purpose="batch")
        print(f"    file_id: {file_obj.id}")

        # Create batch via raw HTTP (xAI requires `name` field)
        resp = httpx.post(
            "https://api.x.ai/v1/batches",
            headers=HEADERS,
            json={
                "input_file_id": file_obj.id,
                "endpoint": "/v1/chat/completions",
                "completion_window": "24h",
                "name": f"simpleqa_xai_chunk{idx}",
            },
            timeout=60,
        )
        resp.raise_for_status()
        data = resp.json()
        batch_id = data["batch_id"]
        sub_ids.append(batch_id)
        print(f"    batch_id: {batch_id}")

    batch_ids["xai"] = {
        "batch_id": sub_ids,
        "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "n_rows": len(lines),
        "n_sub_batches": len(sub_ids),
    }
    with open(BATCH_IDS, "w") as f:
        json.dump(batch_ids, f, indent=2)

# Poll
print(f"Polling {len(sub_ids)} sub-batch(es)...")
while True:
    all_done = True
    for bid in sub_ids:
        resp = httpx.get(f"https://api.x.ai/v1/batches/{bid}", headers=HEADERS, timeout=30)
        data = resp.json()
        state = data.get("state", {})
        total = state.get("num_requests", "?")
        success = state.get("num_success", 0)
        error = state.get("num_error", 0)
        pending = state.get("num_pending", 0)
        print(f"  xai [{bid[:12]}...]: success={success} error={error} pending={pending} total={total}")
        if pending > 0 or (success + error < total if isinstance(total, int) else True):
            all_done = False
    if all_done:
        break
    time.sleep(300)

# Download outputs
print("Downloading results...")
output_file = os.path.join(OUTPUT_DIR, "xai_raw.jsonl")
with open(output_file, "w") as out:
    total = 0
    for bid in sub_ids:
        resp = httpx.get(f"https://api.x.ai/v1/batches/{bid}", headers=HEADERS, timeout=30)
        data = resp.json()
        output_fid = data.get("output_file_id")
        if output_fid:
            content = client.files.content(output_fid)
            for line in content.text.strip().split("\n"):
                out.write(line + "\n")
                total += 1
print(f"  Wrote {total} lines to {output_file}")

batch_ids["xai"]["status"] = "completed"
batch_ids["xai"]["completed_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
with open(BATCH_IDS, "w") as f:
    json.dump(batch_ids, f, indent=2)

print("xAI batch done.")
