"""figure1a.py — Predicted gap E[ĉ_1] − E[ĉ_2] vs sample size n.

Under the local scaling
    pi_{q,1} = 1/2 + λ/sqrt(n),     pi_{q,2} = 1/2 − λ/sqrt(n),
the closed-form gap is

    E[ĉ_1] − E[ĉ_2]  =  g_A(λ) / sqrt(n)  +  o(1/sqrt(n)),

with
    g_A(λ) = phi(2λ) − 2λ Phi(−2λ) + 2λ Phi(−sqrt(2) λ).

The band over λ ∈ [0, 0.5] has
    upper edge (λ = 0  ): g_A(0)  / sqrt(n)   (tied case, max gap)
    lower edge (λ = 0.5): g_A(0.5)/ sqrt(n)   (boundary, min gap)

Outputs:
    figure1a.pdf  — editable vector
    figure1a.png  — 200 dpi raster
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import rcParams
from scipy.stats import norm


# Editable text in PDF / EPS
rcParams["pdf.fonttype"]    = 42
rcParams["ps.fonttype"]     = 42
rcParams["font.family"]     = "sans-serif"
rcParams["font.sans-serif"] = ["Helvetica", "Arial", "DejaVu Sans"]
rcParams["mathtext.fontset"] = "cm"


phi = norm.pdf
Phi = norm.cdf


def g_A(lam):
    return phi(2*lam) - 2*lam*Phi(-2*lam) + 2*lam*Phi(-np.sqrt(2)*lam)


def main():
    # ---- Critical numeric check (must run before saving) ----------------
    g_up_50 = g_A(0.0) / np.sqrt(50)
    g_lo_50 = g_A(0.5) / np.sqrt(50)
    print(f"g_A(0)   = {g_A(0.0):.4f}")
    print(f"g_A(0.5) = {g_A(0.5):.4f}")
    print(f"At n=50: gap_upper = {g_up_50:.4f}  (expected ≈ 0.0564)")
    print(f"At n=50: gap_lower = {g_lo_50:.4f}  (expected ≈ 0.0457)")
    assert abs(g_up_50 - 0.0564) < 5e-4, f"upper {g_up_50:.4f} ≠ 0.0564"
    assert abs(g_lo_50 - 0.0457) < 5e-4, f"lower {g_lo_50:.4f} ≠ 0.0457"

    # ---- Curves ---------------------------------------------------------
    n_grid    = np.linspace(10, 100, 400)
    gap_upper = g_A(0.0) / np.sqrt(n_grid)
    gap_lower = g_A(0.5) / np.sqrt(n_grid)

    sem1_color = "#E07A5F"
    accent     = sem1_color

    fig, ax = plt.subplots(figsize=(6.0, 4.0), dpi=150)

    # Reference: zero baseline (gap = 0 → the two estimators agree)
    ax.axhline(0, color="#888888", linestyle="--", linewidth=1.0, zorder=1)

    # Shaded band over λ ∈ [0, 0.5]
    ax.fill_between(n_grid, gap_lower, gap_upper,
                    color=sem1_color, alpha=0.20, linewidth=0, zorder=2)

    # Upper edge (tied case, λ=0): solid bold line
    ax.plot(n_grid, gap_upper, color=sem1_color, linewidth=2.2, zorder=3,
            label=r"$\mathbb{E}[\hat c_1] - \mathbb{E}[\hat c_2]$, "
                  r"$\lambda \in [0, 0.5]$")

    # ---- Annotate the band range at n = 50 ------------------------------
    n_mark = 50
    ax.annotate("", xy=(n_mark, g_up_50), xytext=(n_mark, g_lo_50),
                arrowprops=dict(arrowstyle="<->", color=accent,
                                linewidth=1.6, shrinkA=0, shrinkB=0),
                zorder=5)
    # Label tucked below the band in clean white space, with a thin
    # leader line to the arrow's midpoint.  Accent colour = ocean blue
    # contrasting against the warm-orange band.
    label_x, label_y = 56, 0.024
    ax.annotate(
        f"$[{g_lo_50:.3f},\\,{g_up_50:.3f}]$\nat $n = 50$",
        xy=(n_mark, g_lo_50),
        xytext=(label_x, label_y),
        fontsize=10, color=accent,
        ha="left", va="center", zorder=5, linespacing=1.2,
        arrowprops=dict(arrowstyle="-", color=accent, lw=0.7,
                        shrinkA=0, shrinkB=4),
    )

    # ---- Axes -----------------------------------------------------------
    ax.set_xlabel(r"sample size $n$", fontsize=11)
    ax.set_ylabel(r"$\mathbb{E}[\hat c_1] - \mathbb{E}[\hat c_2]$",
                  fontsize=11)
    ax.set_xlim(10, 102)
    ax.set_ylim(0, 0.10)
    ax.set_xticks([10, 20, 30, 40, 50, 60, 70, 80, 90, 100])
    ax.tick_params(labelsize=9.5)
    ax.grid(True, linestyle=":", linewidth=0.5, alpha=0.45)
    ax.legend(loc="upper right", fontsize=10, framealpha=0.95,
              edgecolor="#cccccc")
    ax.text(-0.10, 1.03, "(a)", transform=ax.transAxes,
            fontsize=14, fontweight="bold", va="bottom")

    plt.tight_layout()
    plt.savefig("figure1a.pdf", bbox_inches="tight")
    plt.savefig("figure1a.png", dpi=200, bbox_inches="tight")
    plt.close(fig)
    print("saved figure1a.pdf, figure1a.png")


if __name__ == "__main__":
    main()
