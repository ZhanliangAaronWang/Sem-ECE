"""Phase 2 (HLE) — Collect Anthropic clustering batch results, parse, validate.

Reads chunk state from phase2/clustering/anthropic_chunks.json.
Downloads output files, parses cluster JSON, validates partitions.
Writes phase2/clustering/anthropic_simpleqa_clustered.jsonl.

Note: file is named `_simpleqa_clustered.jsonl` to match phase2 naming
convention (legacy from when phase2 reused phase1 names); content is HLE.
"""
import os, json, re, random, statistics
from collections import Counter
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI

EXTRACTED = os.path.join(ROOT, "phase2", "clustering", "anthropic_extracted.jsonl")
CHUNKS_FILE = os.path.join(ROOT, "phase2", "clustering", "anthropic_chunks.json")
CLUSTERED = os.path.join(ROOT, "phase2", "clustering", "anthropic_simpleqa_clustered.jsonl")

N = 46
client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])


def load_extracted():
    rows = {}
    with open(EXTRACTED) as f:
        for line in f:
            r = json.loads(line)
            rows[r["id"]] = r
    return rows


def parse_cluster_json(raw_text):
    if raw_text is None:
        return None, "empty response"
    txt = raw_text.strip()
    if txt.startswith("```"):
        txt = re.sub(r"^```(?:json)?\s*", "", txt)
        txt = re.sub(r"\s*```$", "", txt)
    try:
        obj = json.loads(txt)
    except Exception as e:
        return None, f"json parse: {e}"
    if not isinstance(obj, dict) or "clusters" not in obj:
        return None, "missing 'clusters' key"
    clusters = obj["clusters"]
    if not isinstance(clusters, list):
        return None, "'clusters' not list"
    return clusters, None


def build_assignments(clusters, n=N):
    assignments = [-1] * n
    labels = []
    for ci, c in enumerate(clusters):
        if not isinstance(c, dict):
            raise ValueError(f"cluster {ci} not a dict")
        label = c.get("label", "")
        members = c.get("members", [])
        if not isinstance(members, list):
            raise ValueError(f"cluster {ci} members not a list")
        labels.append(str(label))
        for m in members:
            if not isinstance(m, int) or not (0 <= m < n):
                raise ValueError(f"cluster {ci} bad member {m}")
            if assignments[m] != -1:
                raise ValueError(f"index {m} appears twice (clusters {assignments[m]} and {ci})")
            assignments[m] = ci
    if any(a == -1 for a in assignments):
        missing = [i for i, a in enumerate(assignments) if a == -1]
        raise ValueError(f"unassigned indices: {missing[:5]}...")
    sizes = [assignments.count(k) for k in range(len(labels))]
    return assignments, labels, sizes


def main():
    with open(CHUNKS_FILE) as f:
        chunks = json.load(f)["chunks"]
    print(f"Loading {len(chunks)} chunks", flush=True)

    all_lines = []
    for c in chunks:
        ci = c["chunk"]
        fid = c["output_file_id"]
        if fid is None:
            raise RuntimeError(f"chunk {ci} has no output_file_id; batch not completed")
        print(f"  chunk {ci}: downloading {fid}", flush=True)
        file_resp = client.files.content(fid)
        raw = (file_resp.read() if hasattr(file_resp, "read") else file_resp.content).decode()
        all_lines.extend(raw.strip().splitlines())
    print(f"  total raw lines: {len(all_lines)}", flush=True)

    extracted = load_extracted()
    out_rows = []
    parse_failures = []
    k_counts = []
    singleton = 0
    coverage_ok = 0
    coverage_bad = []
    modal_mass = []

    for line in all_lines:
        if not line.strip():
            continue
        try:
            jr = json.loads(line)
        except Exception as e:
            parse_failures.append((None, f"line json: {e}"))
            continue
        cid = jr.get("custom_id", "")
        qid = cid.replace("anthropic__", "")
        ext = extracted.get(qid)
        if ext is None:
            parse_failures.append((qid, "no extracted row"))
            continue

        body = jr.get("response", {}).get("body", {})
        choices = body.get("choices", [])
        raw_judge = choices[0]["message"]["content"] if choices else None

        clusters, err = parse_cluster_json(raw_judge)
        if err:
            parse_failures.append((qid, err))
            continue
        try:
            assignments, labels, sizes = build_assignments(clusters, n=N)
        except Exception as e:
            parse_failures.append((qid, f"partition: {e}"))
            continue

        modal = sizes.index(max(sizes))
        out_row = dict(ext)
        out_row.update({
            "n_clusters": len(labels),
            "cluster_labels": labels,
            "cluster_assignments": assignments,
            "cluster_sizes": sizes,
            "modal_cluster": modal,
            "modal_cluster_label": labels[modal],
            "raw_judge_response": raw_judge,
        })
        out_rows.append(out_row)
        k_counts.append(len(labels))
        if len(labels) == 1:
            singleton += 1
        if sum(sizes) == N:
            coverage_ok += 1
        else:
            coverage_bad.append(qid)
        modal_mass.append(max(sizes) / float(N))

    with open(CLUSTERED, "w") as f:
        for r in sorted(out_rows, key=lambda x: x["id"]):
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"\nWrote {len(out_rows)} rows -> {CLUSTERED}", flush=True)

    n_total = len(extracted)
    n_have = len(out_rows)
    n_fail = len(parse_failures)
    fail_rate = n_fail / n_total if n_total > 0 else 0

    print("\n=== Sanity checks (anthropic, P2 HLE) ===", flush=True)
    print(f"  rows: {n_have}/{n_total}", flush=True)
    print(f"  parse failures: {n_fail} ({fail_rate*100:.2f}%)", flush=True)
    if k_counts:
        print(f"  K mean={statistics.mean(k_counts):.2f}  median={statistics.median(k_counts)}", flush=True)
    print(f"  singleton (K=1): {singleton} ({singleton*100/max(1,n_have):.1f}%)", flush=True)
    print(f"  coverage ok: {coverage_ok}/{n_have}", flush=True)
    if parse_failures:
        print("First 5 parse failures:", flush=True)
        for qid, msg in parse_failures[:5]:
            print(f"  {qid}: {msg}", flush=True)


if __name__ == "__main__":
    main()
