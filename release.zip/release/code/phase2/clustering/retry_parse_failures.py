"""Retry Anthropic clustering parse failures with seed=99.

Reads:
  phase2/clustering/anthropic_extracted.jsonl       (all 1504 Q's prep'd)
  phase2/clustering/anthropic_simpleqa_clustered.jsonl  (Q's that successfully clustered)

Identifies Q's missing from clustered (= parse failures), re-submits an OpenAI
batch with seed=99 (different from first pass's seed=42), polls, parses results,
APPENDS valid rows to the clustered file.

State: phase2/clustering/anthropic_retry_chunks.json
"""
import os, json, re, time, statistics
from collections import Counter
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI

EXTRACTED = os.path.join(ROOT, "phase2", "clustering", "anthropic_extracted.jsonl")
CLUSTERED = os.path.join(ROOT, "phase2", "clustering", "anthropic_simpleqa_clustered.jsonl")
RETRY_INPUT = os.path.join(ROOT, "phase2", "clustering", "batch_inputs", "anthropic_clustering_retry.jsonl")
STATE = os.path.join(ROOT, "phase2", "clustering", "anthropic_retry_chunks.json")

JUDGE_MODEL = "gpt-5.2"
N_KEEP = 46
RETRY_SEED = 99
TERMINAL = {"completed", "failed", "expired", "cancelled"}

SYSTEM_PROMPT = """You are a semantic clustering assistant for a research benchmark. You will receive a question and a list of model-generated answers, indexed 0 through N-1. Your job is to partition the answers into groups such that two answers are in the same group if and only if they express the same underlying answer to the question.

Rules:
- Cluster by SEMANTIC meaning, not surface form. "Leo Tolstoy", "Tolstoy", "Leo Tolstoy (1869)", and "the Russian novelist Leo Tolstoy" all belong to the same cluster.
- Surface variations to ignore: capitalization, punctuation, articles (a/the), trailing dates or qualifiers, formal vs informal name forms, units that express the same physical quantity ("1.5 mM" = "0.0015 M"), and explanatory parentheticals.
- Different specific answers belong to different clusters even if related: "Tolstoy" and "Dostoevsky" are different; "Paris" and "France" are different; "1869" and "1865" are different.
- Each answer index must appear in exactly one cluster. Every index 0 to N-1 must be assigned.
- Use as few clusters as faithfully captures the semantic distinctions. Do not over-fragment over trivial differences.

Output format: a single JSON object with one field, "clusters", whose value is an array of cluster objects. Each cluster object has two fields:
- "label": a short canonical string representing the cluster's answer (e.g., "Leo Tolstoy", "1869")
- "members": a sorted array of integer indices (0-indexed) of the answers in that cluster

Example output:
{"clusters": [
  {"label": "Leo Tolstoy", "members": [0, 1, 3, 5, 8, 12, 15, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46]},
  {"label": "Fyodor Dostoevsky", "members": [2, 6, 11, 17, 24, 30, 38, 44]},
  {"label": "I don't know", "members": [4, 7, 9, 10, 13, 14, 16, 18, 20, 21, 23, 26, 27, 29, 32, 33, 35, 36, 39, 41, 42, 45]}
]}

Output ONLY the JSON object, with no preamble, no code fences, no commentary."""


def parse_cluster_json(raw_text):
    if raw_text is None:
        return None, "empty response"
    txt = raw_text.strip()
    if txt.startswith("```"):
        txt = re.sub(r"^```(?:json)?\s*", "", txt)
        txt = re.sub(r"\s*```$", "", txt)
    try:
        obj = json.loads(txt)
    except Exception as e:
        return None, f"json parse: {e}"
    if not isinstance(obj, dict) or "clusters" not in obj:
        return None, "missing 'clusters' key"
    clusters = obj["clusters"]
    if not isinstance(clusters, list):
        return None, "'clusters' not list"
    return clusters, None


def build_assignments(clusters, n=N_KEEP):
    assignments = [-1] * n
    labels = []
    for ci, c in enumerate(clusters):
        if not isinstance(c, dict):
            raise ValueError(f"cluster {ci} not a dict")
        label = c.get("label", "")
        members = c.get("members", [])
        if not isinstance(members, list):
            raise ValueError(f"cluster {ci} members not a list")
        labels.append(str(label))
        for m in members:
            if not isinstance(m, int) or not (0 <= m < n):
                raise ValueError(f"cluster {ci} bad member {m}")
            if assignments[m] != -1:
                raise ValueError(f"index {m} appears twice (clusters {assignments[m]} and {ci})")
            assignments[m] = ci
    if any(a == -1 for a in assignments):
        missing = [i for i, a in enumerate(assignments) if a == -1]
        raise ValueError(f"unassigned indices: {missing[:5]}...")
    sizes = [assignments.count(k) for k in range(len(labels))]
    return assignments, labels, sizes


def main():
    print(f"[load] {EXTRACTED}", flush=True)
    extracted = {}
    with open(EXTRACTED) as f:
        for line in f:
            r = json.loads(line)
            extracted[r["id"]] = r
    print(f"  extracted: {len(extracted)} Qs", flush=True)

    print(f"[load] {CLUSTERED}", flush=True)
    clustered_qids = set()
    with open(CLUSTERED) as f:
        for line in f:
            r = json.loads(line)
            clustered_qids.add(r["id"])
    print(f"  already clustered: {len(clustered_qids)} Qs", flush=True)

    failed_qids = sorted(set(extracted.keys()) - clustered_qids)
    print(f"  parse failures to retry: {len(failed_qids)} Qs", flush=True)

    if not failed_qids:
        print("Nothing to retry. Done.", flush=True)
        return

    # Build retry batch input
    os.makedirs(os.path.dirname(RETRY_INPUT), exist_ok=True)
    with open(RETRY_INPUT, "w") as f:
        for qid in failed_qids:
            ext = extracted[qid]
            ans_list = ext["answer_extracted"]
            n = len(ans_list)
            ans_block = "\n".join(f"[{i}] {a}" for i, a in enumerate(ans_list))
            user_msg = f"Question: {ext['question']}\n\nAnswers ({n} total, indexed 0 to {n-1}):\n{ans_block}"
            row = {
                "custom_id": f"anthropic__{qid}",
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": JUDGE_MODEL,
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": user_msg},
                    ],
                    "reasoning_effort": "none",
                    "temperature": 0.0,
                    "max_completion_tokens": 3000,
                    "response_format": {"type": "json_object"},
                    "seed": RETRY_SEED,
                },
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    print(f"  wrote {len(failed_qids)} retry rows -> {RETRY_INPUT}", flush=True)

    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

    # Load or create state
    state = {}
    if os.path.exists(STATE):
        with open(STATE) as f:
            state = json.load(f)

    if not state.get("batch_id"):
        # Submit batch
        print("[submit] uploading retry batch...", flush=True)
        with open(RETRY_INPUT, "rb") as fh:
            fobj = client.files.create(file=fh, purpose="batch")
        b = client.batches.create(
            input_file_id=fobj.id,
            endpoint="/v1/chat/completions",
            completion_window="24h",
            metadata={"phase": "phase2_clustering", "provider": "anthropic", "retry": "1"},
        )
        state = {
            "batch_id": b.id,
            "input_file_id": fobj.id,
            "n_rows": len(failed_qids),
            "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "final_status": None,
            "output_file_id": None,
            "error_file_id": None,
        }
        with open(STATE, "w") as f:
            json.dump(state, f, indent=2)
        print(f"  batch_id: {b.id}", flush=True)
    else:
        print(f"[resume] batch_id: {state['batch_id']}", flush=True)

    # Poll
    print("[poll] every 5 min until terminal...", flush=True)
    while True:
        b = client.batches.retrieve(state["batch_id"])
        rc = b.request_counts
        print(f"  {time.strftime('%H:%M:%S')} {b.id[:18]}.. status={b.status} {rc.completed}/{rc.total}", flush=True)
        if b.status in TERMINAL:
            state["final_status"] = b.status
            state["output_file_id"] = b.output_file_id
            state["error_file_id"] = b.error_file_id
            with open(STATE, "w") as f:
                json.dump(state, f, indent=2)
            break
        time.sleep(300)

    if state["final_status"] != "completed" or not state.get("output_file_id"):
        print(f"  retry batch did not complete; status={state['final_status']}. Keeping clustered as-is.", flush=True)
        return

    # Download and parse retry results
    print("[download] retry results...", flush=True)
    fid = state["output_file_id"]
    file_resp = client.files.content(fid)
    raw = (file_resp.read() if hasattr(file_resp, "read") else file_resp.content).decode()
    lines = raw.strip().splitlines()
    print(f"  {len(lines)} response lines", flush=True)

    new_rows = []
    still_failing = []
    for line in lines:
        if not line.strip():
            continue
        jr = json.loads(line)
        cid = jr.get("custom_id", "")
        qid = cid.replace("anthropic__", "")
        ext = extracted.get(qid)
        if ext is None:
            still_failing.append((qid, "no extracted row"))
            continue
        body = jr.get("response", {}).get("body", {})
        choices = body.get("choices", [])
        raw_judge = choices[0]["message"]["content"] if choices else None
        clusters, err = parse_cluster_json(raw_judge)
        if err:
            still_failing.append((qid, err))
            continue
        try:
            assignments, labels, sizes = build_assignments(clusters, n=N_KEEP)
        except Exception as e:
            still_failing.append((qid, f"partition: {e}"))
            continue

        modal = sizes.index(max(sizes))
        out_row = dict(ext)
        out_row.update({
            "n_clusters": len(labels),
            "cluster_labels": labels,
            "cluster_assignments": assignments,
            "cluster_sizes": sizes,
            "modal_cluster": modal,
            "modal_cluster_label": labels[modal],
            "raw_judge_response": raw_judge,
        })
        new_rows.append(out_row)

    # Append to clustered file (sorted by id afterwards)
    with open(CLUSTERED) as f:
        existing = [json.loads(l) for l in f if l.strip()]

    merged = existing + new_rows
    merged.sort(key=lambda x: x["id"])
    with open(CLUSTERED, "w") as f:
        for r in merged:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"\n=== Retry results ===", flush=True)
    print(f"  retried: {len(failed_qids)}", flush=True)
    print(f"  fixed: {len(new_rows)}", flush=True)
    print(f"  still failing: {len(still_failing)}", flush=True)
    print(f"  total clustered now: {len(merged)}", flush=True)
    if still_failing:
        print("  Remaining parse failures (first 5):", flush=True)
        for qid, msg in still_failing[:5]:
            print(f"    {qid}: {msg}", flush=True)


if __name__ == "__main__":
    main()
