"""Phase 2 (HLE) Step 4 — Collect xAI clustering batch results, parse, validate.

Reads chunk state from phase2/clustering/xai_chunks.json.
Downloads output files, parses cluster JSON, validates partitions.
Writes phase2/clustering/xai_simpleqa_clustered.jsonl.
"""
import os, json, re, random, statistics
from collections import Counter
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI

EXTRACTED = os.path.join(ROOT, "phase2", "clustering", "xai_extracted.jsonl")
CHUNKS_FILE = os.path.join(ROOT, "phase2", "clustering", "xai_chunks.json")
CLUSTERED = os.path.join(ROOT, "phase2", "clustering", "xai_simpleqa_clustered.jsonl")

client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])


def load_extracted():
    rows = {}
    with open(EXTRACTED) as f:
        for line in f:
            r = json.loads(line)
            rows[r["id"]] = r
    return rows


def parse_cluster_json(raw_text):
    if raw_text is None:
        return None, "empty response"
    txt = raw_text.strip()
    if txt.startswith("```"):
        txt = re.sub(r"^```(?:json)?\s*", "", txt)
        txt = re.sub(r"\s*```$", "", txt)
    try:
        obj = json.loads(txt)
    except Exception as e:
        return None, f"json parse: {e}"
    if not isinstance(obj, dict) or "clusters" not in obj:
        return None, "missing 'clusters' key"
    clusters = obj["clusters"]
    if not isinstance(clusters, list):
        return None, "'clusters' not list"
    return clusters, None


def build_assignments(clusters, n=48):
    assignments = [-1] * n
    labels = []
    for ci, c in enumerate(clusters):
        if not isinstance(c, dict):
            raise ValueError(f"cluster {ci} not a dict")
        label = c.get("label", "")
        members = c.get("members", [])
        if not isinstance(members, list):
            raise ValueError(f"cluster {ci} members not a list")
        labels.append(str(label))
        for m in members:
            if not isinstance(m, int) or not (0 <= m < n):
                raise ValueError(f"cluster {ci} bad member {m}")
            if assignments[m] != -1:
                raise ValueError(f"index {m} appears twice (clusters {assignments[m]} and {ci})")
            assignments[m] = ci
    if any(a == -1 for a in assignments):
        missing = [i for i, a in enumerate(assignments) if a == -1]
        raise ValueError(f"unassigned indices: {missing[:5]}...")
    sizes = [assignments.count(k) for k in range(len(labels))]
    return assignments, labels, sizes


def main():
    with open(CHUNKS_FILE) as f:
        chunks = json.load(f)["chunks"]
    print(f"Loading {len(chunks)} chunks", flush=True)

    # Download all chunk outputs
    all_lines = []
    for c in chunks:
        ci = c["chunk"]
        fid = c["output_file_id"]
        print(f"  chunk {ci}: downloading {fid}", flush=True)
        file_resp = client.files.content(fid)
        raw = (file_resp.read() if hasattr(file_resp, "read") else file_resp.content).decode()
        all_lines.extend(raw.strip().splitlines())
    print(f"  total raw lines: {len(all_lines)}", flush=True)

    extracted = load_extracted()
    out_rows = []
    parse_failures = []
    k_counts = []
    singleton = 0
    coverage_ok = 0
    coverage_bad = []
    modal_mass = []
    in_tokens_total = 0
    out_tokens_total = 0

    seen_ids = set()
    for line in all_lines:
        if not line.strip():
            continue
        try:
            jr = json.loads(line)
        except Exception as e:
            parse_failures.append((None, f"line json: {e}"))
            continue
        cid = jr.get("custom_id", "")
        qid = cid.replace("xai__", "")
        seen_ids.add(qid)
        ext = extracted.get(qid)
        if ext is None:
            parse_failures.append((qid, "no extracted row"))
            continue

        body = jr.get("response", {}).get("body", {})
        usage = body.get("usage", {})
        in_tokens_total += usage.get("prompt_tokens", 0) or 0
        out_tokens_total += usage.get("completion_tokens", 0) or 0

        choices = body.get("choices", [])
        raw_judge = choices[0]["message"]["content"] if choices else None

        clusters, err = parse_cluster_json(raw_judge)
        if err:
            parse_failures.append((qid, err))
            continue
        try:
            assignments, labels, sizes = build_assignments(clusters, n=48)
        except Exception as e:
            parse_failures.append((qid, f"partition: {e}"))
            continue

        modal = sizes.index(max(sizes))
        out_row = dict(ext)
        out_row.update({
            "n_clusters": len(labels),
            "cluster_labels": labels,
            "cluster_assignments": assignments,
            "cluster_sizes": sizes,
            "modal_cluster": modal,
            "modal_cluster_label": labels[modal],
            "raw_judge_response": raw_judge,
        })
        out_rows.append(out_row)
        k_counts.append(len(labels))
        if len(labels) == 1:
            singleton += 1
        if sum(sizes) == 48:
            coverage_ok += 1
        else:
            coverage_bad.append(qid)
        modal_mass.append(max(sizes) / 48.0)

    # Write clustered file
    with open(CLUSTERED, "w") as f:
        for r in sorted(out_rows, key=lambda x: x["id"]):
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"\nWrote {len(out_rows)} rows -> {CLUSTERED}", flush=True)

    # Sanity checks
    n_total = len(extracted)
    n_have = len(out_rows)
    n_fail = len(parse_failures)
    fail_rate = n_fail / n_total if n_total > 0 else 0
    missing_ids = sorted(set(extracted.keys()) - seen_ids)

    print("\n=== Sanity checks (xAI, Phase 2 HLE) ===", flush=True)
    print(f"  rows: {n_have}/{n_total}  missing={len(missing_ids)}", flush=True)
    print(f"  parse failures: {n_fail} ({fail_rate*100:.2f}%)", flush=True)
    if k_counts:
        print(f"  K mean={statistics.mean(k_counts):.2f}  median={statistics.median(k_counts)}", flush=True)
        buckets = {"K=1":0,"K=2":0,"K=3":0,"K=4":0,"K=5":0,"K=6-10":0,"K=11-20":0,"K>20":0}
        for k in k_counts:
            if k==1: buckets["K=1"]+=1
            elif k==2: buckets["K=2"]+=1
            elif k==3: buckets["K=3"]+=1
            elif k==4: buckets["K=4"]+=1
            elif k==5: buckets["K=5"]+=1
            elif k<=10: buckets["K=6-10"]+=1
            elif k<=20: buckets["K=11-20"]+=1
            else: buckets["K>20"]+=1
        print(f"  K hist: {buckets}", flush=True)
    print(f"  singleton (K=1): {singleton} ({singleton*100/max(1,n_have):.1f}%)", flush=True)
    print(f"  coverage ok: {coverage_ok}/{n_have}  bad={len(coverage_bad)}", flush=True)
    if modal_mass:
        mm_buckets = [0]*5
        for v in modal_mass:
            i = min(4, int(v*5))
            mm_buckets[i]+=1
        print(f"  modal mass hist [0-0.2,0.2-0.4,0.4-0.6,0.6-0.8,0.8-1.0]: {mm_buckets}", flush=True)

    # Extraction method recap
    em_counter = Counter()
    cm_counter = Counter()
    vmean_vals = []
    for r in extracted.values():
        em_counter.update(r["extraction_method"])
        cm_counter.update(r["confidence_extraction_method"])
        if r["verbalized_mean"] is not None:
            vmean_vals.append(r["verbalized_mean"])
    print(f"  extraction method: {dict(em_counter)}", flush=True)
    print(f"  confidence extraction: {dict(cm_counter)}", flush=True)
    if vmean_vals:
        print(f"  per-question verbalized_mean: mean={statistics.mean(vmean_vals):.3f} median={statistics.median(vmean_vals):.3f}", flush=True)

    # 5 random examples
    if out_rows:
        print("\n=== 5 random clustering examples (xAI HLE) ===", flush=True)
        random.seed(0)
        sample = random.sample(out_rows, min(5, len(out_rows)))
        for r in sample:
            print(f"\n--- {r['id']} ---", flush=True)
            print(f"  Q: {r['question'][:120]}...", flush=True)
            print(f"  gold: {r['gold_answer']}", flush=True)
            print(f"  K={r['n_clusters']} sizes={r['cluster_sizes']}", flush=True)
            for k, lbl in enumerate(r["cluster_labels"]):
                members = [i for i, a in enumerate(r["cluster_assignments"]) if a == k]
                print(f"    [{k}] {lbl}  members={members[:10]}{'...' if len(members)>10 else ''}", flush=True)

    # Cost
    in_price = 1.25 / 2 / 1e6
    out_price = 10.0 / 2 / 1e6
    cost = in_tokens_total * in_price + out_tokens_total * out_price
    print(f"\n=== Cost ===", flush=True)
    print(f"  in={in_tokens_total:,}  out={out_tokens_total:,}  est=${cost:.2f}", flush=True)

    # Print failure samples
    if parse_failures:
        print(f"\nFirst 5 parse failures:", flush=True)
        for qid, msg in parse_failures[:5]:
            print(f"  {qid}: {msg}", flush=True)

    # Final verdict
    ok = (fail_rate <= 0.02 and len(coverage_bad) == 0 and not missing_ids
          and (k_counts and 1.5 <= statistics.mean(k_counts) <= 30))
    if ok:
        print("\n[xAI HLE] PASS -- clustering ready.", flush=True)
    else:
        print("\n[xAI HLE] FAIL -- see metrics above.", flush=True)


if __name__ == "__main__":
    main()
