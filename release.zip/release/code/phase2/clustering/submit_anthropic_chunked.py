"""Phase 2 (HLE) — Submit Anthropic clustering batch via OpenAI batch API, chunked.

Splits anthropic_clustering.jsonl into 800-row chunks and submits all in parallel.
State tracked in phase2/clustering/anthropic_chunks.json for resume support.
"""
import os, json, time, math
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI

INPUT = os.path.join(ROOT, "phase2", "clustering", "batch_inputs", "anthropic_clustering.jsonl")
CHUNK_DIR = os.path.join(ROOT, "phase2", "clustering", "batch_inputs", "anthropic_chunks")
STATE = os.path.join(ROOT, "phase2", "clustering", "anthropic_chunks.json")

ROWS_PER_CHUNK = 800
TERMINAL = {"completed", "failed", "expired", "cancelled"}

os.makedirs(CHUNK_DIR, exist_ok=True)
client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])


def split_input():
    with open(INPUT) as f:
        all_rows = f.readlines()
    n_chunks = math.ceil(len(all_rows) / ROWS_PER_CHUNK)
    paths = []
    for i in range(n_chunks):
        chunk = all_rows[i * ROWS_PER_CHUNK : (i + 1) * ROWS_PER_CHUNK]
        p = os.path.join(CHUNK_DIR, f"anthropic_clustering_chunk{i}.jsonl")
        with open(p, "w") as f:
            f.writelines(chunk)
        paths.append((i, p, len(chunk)))
    return paths


def load_state():
    if os.path.exists(STATE):
        with open(STATE) as f:
            return json.load(f)
    return {"chunks": []}


def save_state(s):
    with open(STATE, "w") as f:
        json.dump(s, f, indent=2)


def call_with_retry(label, fn, max_tries=8):
    delay = 5
    for i in range(max_tries):
        try:
            return fn()
        except Exception as e:
            msg = str(e)[:200]
            print(f"    {label} attempt {i+1} failed: {msg}", flush=True)
            time.sleep(delay)
            delay = min(60, delay * 2)
    raise RuntimeError(f"{label} failed after {max_tries} attempts")


def submit_chunk(idx, path, n_rows):
    print(f"\n[chunk {idx}] uploading {os.path.basename(path)} ({n_rows} rows)...", flush=True)
    def _upload():
        with open(path, "rb") as f:
            return client.files.create(file=f, purpose="batch")
    fobj = call_with_retry("upload", _upload)
    print(f"  file_id: {fobj.id}", flush=True)
    def _create():
        return client.batches.create(
            input_file_id=fobj.id,
            endpoint="/v1/chat/completions",
            completion_window="24h",
            metadata={"phase": "phase2_clustering", "provider": "anthropic", "chunk": str(idx)},
        )
    batch = call_with_retry("batch.create", _create)
    print(f"  batch_id: {batch.id}  status: {batch.status}", flush=True)
    return {
        "chunk": idx,
        "path": path,
        "n_rows": n_rows,
        "file_id": fobj.id,
        "batch_id": batch.id,
        "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "final_status": None,
        "output_file_id": None,
        "error_file_id": None,
    }


def main():
    chunks = split_input()
    print(f"Split into {len(chunks)} chunks of <= {ROWS_PER_CHUNK} rows", flush=True)

    state = load_state()
    done_indices = {c["chunk"] for c in state["chunks"] if c.get("final_status") == "completed"}
    print(f"Already-completed chunks: {sorted(done_indices) or 'none'}", flush=True)

    for idx, path, n_rows in chunks:
        if idx in done_indices:
            continue
        existing = next((c for c in state["chunks"]
                         if c["chunk"] == idx and c.get("batch_id")
                         and c.get("final_status") != "completed"), None)
        if existing:
            print(f"\n[chunk {idx}] already submitted (batch_id={existing['batch_id']})", flush=True)
            continue
        entry = submit_chunk(idx, path, n_rows)
        state["chunks"].append(entry)
        save_state(state)

    print(f"\nAll {len(chunks)} chunks submitted. Poll later with batch IDs in {STATE}.", flush=True)


if __name__ == "__main__":
    main()
