"""Phase 2 (HLE) Step 1 — Extract answers from xAI batch outputs and build clustering batch.

Inputs:
  phase2/batch_outputs/xai_raw_w{0-15}.jsonl + xai_raw_retry2.jsonl  (flat format)
  data/phase2/hle_preprocessed.jsonl                                  (gold data)

Outputs:
  phase2/clustering/xai_extracted.jsonl
  phase2/clustering/batch_inputs/xai_clustering.jsonl
"""
import os, json, re, statistics, glob
from collections import defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
BATCH_DIR = os.path.join(ROOT, "phase2", "batch_outputs")
GOLD_FILE = os.path.join(ROOT, "data", "phase2", "hle_preprocessed.jsonl")
EXTRACTED = os.path.join(ROOT, "phase2", "clustering", "xai_extracted.jsonl")
BATCH_OUT = os.path.join(ROOT, "phase2", "clustering", "batch_inputs", "xai_clustering.jsonl")

JUDGE_MODEL = "gpt-5.2"
ANS_RE = re.compile(r"Answer:\s*(.+?)(?=\nConfidence|\Z)", re.DOTALL)
CONF_RE = re.compile(r"Confidence:\s*([0-9]+(?:\.[0-9]+)?)\s*%?")
NULL_ANS = {"see above", "as stated", "as mentioned", "as noted"}

SYSTEM_PROMPT = """You are a semantic clustering assistant for a research benchmark. You will receive a question and a list of model-generated answers, indexed 0 through N-1. Your job is to partition the answers into groups such that two answers are in the same group if and only if they express the same underlying answer to the question.

Rules:
- Cluster by SEMANTIC meaning, not surface form. "Leo Tolstoy", "Tolstoy", "Leo Tolstoy (1869)", and "the Russian novelist Leo Tolstoy" all belong to the same cluster.
- Surface variations to ignore: capitalization, punctuation, articles (a/the), trailing dates or qualifiers, formal vs informal name forms, units that express the same physical quantity ("1.5 mM" = "0.0015 M"), and explanatory parentheticals.
- Different specific answers belong to different clusters even if related: "Tolstoy" and "Dostoevsky" are different; "Paris" and "France" are different; "1869" and "1865" are different.
- Each answer index must appear in exactly one cluster. Every index 0 to N-1 must be assigned.
- Use as few clusters as faithfully captures the semantic distinctions. Do not over-fragment over trivial differences.

Output format: a single JSON object with one field, "clusters", whose value is an array of cluster objects. Each cluster object has two fields:
- "label": a short canonical string representing the cluster's answer (e.g., "Leo Tolstoy", "1869")
- "members": a sorted array of integer indices (0-indexed) of the answers in that cluster

Example output:
{"clusters": [
  {"label": "Leo Tolstoy", "members": [0, 1, 3, 5, 8, 12, 15, 19, 22, 25, 28, 31, 34, 37, 40, 43, 46, 49]},
  {"label": "Fyodor Dostoevsky", "members": [2, 6, 11, 17, 24, 30, 38, 44]},
  {"label": "Anton Chekhov", "members": [4, 9, 14, 20, 27, 33, 41, 47]},
  {"label": "I don't know", "members": [7, 10, 13, 16, 18, 21, 23, 26, 29, 32, 35, 36, 39, 42, 45, 48]}
]}

Output ONLY the JSON object, with no preamble, no code fences, no commentary."""


def extract_answer(raw):
    if not raw:
        return "", "fallback_tail"
    m = ANS_RE.search(raw)
    if m:
        ans = m.group(1).strip()
        if ans and ans.lower() not in NULL_ANS:
            return ans, "answer_line"
    return raw[-200:].strip(), "fallback_tail"


def extract_conf(raw):
    if not raw:
        return None, "missing"
    m = CONF_RE.search(raw)
    if not m:
        return None, "missing"
    try:
        v = float(m.group(1)) / 100.0
    except ValueError:
        return None, "missing"
    return max(0.0, min(1.0, v)), "regex_match"


def main():
    # 1) Load gold data
    gold = {}
    with open(GOLD_FILE) as f:
        for l in f:
            d = json.loads(l)
            gold[d["qid"]] = d

    # 2) Gather raw generations grouped by qid from ALL xai files (incl. retry3).
    # Many samples are truncated (no Confidence:) but still have a usable Answer
    # line — those count as valid for clustering. Out of 107.9K samples,
    # ~50% have Confidence and ~13% have Answer-only; combined ~63%.
    # We accept Qs with >=N_KEEP=48 valid samples and use the first 48 sorted
    # by sample_idx to keep n even for SSSC math.
    N_KEEP = 48
    q_samples = defaultdict(dict)  # qid -> {sample_idx: best_text_so_far}
    # Priority: prefer text with "Confidence:" over Answer-only over plain success
    def _quality(t):
        if not t: return 0
        if "Confidence:" in t: return 3
        if "Answer:" in t: return 2
        return 1
    raw_files = sorted(glob.glob(os.path.join(BATCH_DIR, "xai_raw_w*.jsonl")))
    raw_files.append(os.path.join(BATCH_DIR, "xai_raw_retry2.jsonl"))
    raw_files.extend(sorted(glob.glob(os.path.join(BATCH_DIR, "xai_raw_retry3_w*.jsonl"))))
    total_lines = 0
    success_lines = 0
    for path in raw_files:
        if not os.path.exists(path):
            continue
        with open(path) as f:
            for line in f:
                total_lines += 1
                r = json.loads(line)
                if r.get("status") != "success":
                    continue
                success_lines += 1
                cid = r["custom_id"]  # "{qid}__sample{NN}"
                parts = cid.rsplit("__", 1)
                qid = parts[0]
                sample_key = parts[1] if len(parts) > 1 else "0"
                sample_idx = int(sample_key.replace("sample", ""))
                new_text = r.get("text", "") or ""
                cur = q_samples[qid].get(sample_idx)
                if cur is None or _quality(new_text) > _quality(cur):
                    q_samples[qid][sample_idx] = new_text

    print(f"Read {total_lines} total lines, {success_lines} success", flush=True)

    # Filter to questions with at least N_KEEP successful samples
    complete = {qid: samples for qid, samples in q_samples.items() if len(samples) >= N_KEEP}
    print(f"Total questions with data: {len(q_samples)}", flush=True)
    print(f"Complete (>={N_KEEP}/50): {len(complete)}", flush=True)

    # Ensure output dirs exist
    os.makedirs(os.path.dirname(EXTRACTED), exist_ok=True)
    os.makedirs(os.path.dirname(BATCH_OUT), exist_ok=True)

    fallback_count = 0
    missing_conf_count = 0
    all_conf = []
    extracted_rows = []
    batch_rows = []

    for qid in sorted(complete.keys()):
        samples = complete[qid]
        kept_idx = sorted(samples.keys())[:N_KEEP]
        results = [samples[i] for i in kept_idx]

        ans_list, ext_method, conf_list, conf_method = [], [], [], []
        for raw in results:
            a, em = extract_answer(raw)
            c, cm = extract_conf(raw)
            ans_list.append(a)
            ext_method.append(em)
            conf_list.append(c)
            conf_method.append(cm)
            if em == "fallback_tail":
                fallback_count += 1
            if cm == "missing":
                missing_conf_count += 1
            else:
                all_conf.append(c)

        # Missing verbalized confidence is imputed as 1.0 (model didn't bother to express uncertainty -> assume max conf).
        imputed_conf = [1.0 if c is None else c for c in conf_list]
        verb_mean = sum(imputed_conf) / len(imputed_conf) if imputed_conf else 1.0
        verb_n = sum(1 for c in conf_list if c is not None)

        gold_row = gold[qid]
        extracted_rows.append({
            "id": qid,
            "question": gold_row["question_final"],
            "gold_answer": gold_row["gold_answer"],
            "model": "xai",
            "n_samples": N_KEEP,
            "results": results,
            "answer_extracted": ans_list,
            "extraction_method": ext_method,
            "confidence_verbalized": conf_list,
            "confidence_extraction_method": conf_method,
            "verbalized_mean": verb_mean,
            "verbalized_n_extracted": verb_n,
        })

        # Build clustering batch row
        ans_block = "\n".join(f"[{i}] {a}" for i, a in enumerate(ans_list))
        user_msg = f"Question: {gold_row['question_final']}\n\nAnswers ({N_KEEP} total, indexed 0 to {N_KEEP-1}):\n{ans_block}"

        batch_rows.append({
            "custom_id": f"xai__{qid}",
            "method": "POST",
            "url": "/v1/chat/completions",
            "body": {
                "model": JUDGE_MODEL,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_msg},
                ],
                "reasoning_effort": "none",
                "temperature": 0.0,
                "max_completion_tokens": 1500,
                "response_format": {"type": "json_object"},
                "seed": 0,
            },
        })

    # Write extracted
    with open(EXTRACTED, "w") as f:
        for r in extracted_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"Wrote {len(extracted_rows)} rows to {EXTRACTED}", flush=True)

    # Write batch input
    with open(BATCH_OUT, "w") as f:
        for r in batch_rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"Wrote {len(batch_rows)} rows to {BATCH_OUT}", flush=True)

    # Stats
    total_samples = len(complete) * N_KEEP
    print(f"\n=== Step 1 stats (xAI, Phase 2 HLE) ===", flush=True)
    print(f"  total samples: {total_samples}", flush=True)
    print(f"  fallback (answer): {fallback_count} ({fallback_count*100/total_samples:.2f}%)", flush=True)
    print(f"  missing (confidence): {missing_conf_count} ({missing_conf_count*100/total_samples:.2f}%)", flush=True)
    if all_conf:
        print(f"  mean verbalized conf:   {statistics.mean(all_conf):.3f}", flush=True)
        print(f"  median verbalized conf: {statistics.median(all_conf):.3f}", flush=True)

    if fallback_count / total_samples > 0.05:
        print("  WARN: answer fallback rate > 5%", flush=True)
    if missing_conf_count / total_samples > 0.10:
        print("  WARN: confidence missing rate > 10%", flush=True)

    # Cost estimate
    n_calls = len(batch_rows)
    in_tok = 2500 * n_calls
    out_tok = 500 * n_calls
    in_price = 1.25 / 2 / 1e6
    out_price = 10.0 / 2 / 1e6
    cost = in_tok * in_price + out_tok * out_price
    print(f"\n=== Cost estimate (xAI clustering, batch) ===", flush=True)
    print(f"  calls: {n_calls}  est cost: ${cost:.2f}", flush=True)


if __name__ == "__main__":
    main()
