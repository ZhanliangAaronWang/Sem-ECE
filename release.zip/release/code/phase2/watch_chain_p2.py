"""Phase 2 (HLE) watcher: anthropic + xai downstream pipeline.

Chain:
  1. Poll anthropic clustering chunks (anthropic_chunks.json)
  2. Poll xai clustering chunks (xai_chunks.json)
  3. Run collect_anthropic.py and collect_xai.py
  4. Submit grading for anthropic + xai
  5. Poll grading
  6. Run collect_and_check.py --providers xai anthropic
  7. Run compute_confidence + compute_ece for the full set of 5 providers

Writes marker phase2/.pipeline_done_p2 when complete. Existing openai/gemini/
mistral data is left untouched (they have valid old confidence/ECE files);
this run merges anthropic + xai (the latter regenerated from retry3 + n=48)
into the same calibration_metrics.csv.
"""
import os, json, time, subprocess
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI
client = OpenAI()

P2 = os.path.join(ROOT, "phase2")
POLL = 300
TERMINAL = {"completed", "failed", "expired", "cancelled"}
DONE_MARKER = os.path.join(P2, ".pipeline_done_p2")
PROVIDERS = ["anthropic", "xai"]


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def poll_until_done(batch_id, label):
    while True:
        b = client.batches.retrieve(batch_id)
        rc = b.request_counts
        log(f"  {label}: {b.status} {rc.completed}/{rc.total}")
        if b.status in TERMINAL:
            return b
        time.sleep(POLL)


def run(cmd):
    log(f"$ {cmd}")
    r = subprocess.run(cmd, shell=True, cwd=ROOT)
    if r.returncode != 0:
        raise RuntimeError(f"FAILED: {cmd}")


def main():
    # Step 1+2: poll clustering
    for prov in PROVIDERS:
        state_path = os.path.join(P2, "clustering", f"{prov}_chunks.json")
        state = json.load(open(state_path))
        for c in state["chunks"]:
            b = poll_until_done(c["batch_id"], f"{prov}_cluster_c{c['chunk']}")
            c["final_status"] = b.status
            if b.status == "completed":
                c["output_file_id"] = b.output_file_id
                c["error_file_id"] = b.error_file_id
        with open(state_path, "w") as f:
            json.dump(state, f, indent=2)

    # Step 3: collect clustering
    for prov in PROVIDERS:
        run(f"python phase2/clustering/collect_{prov}.py")

    # Step 4: submit grading
    run("python phase2/grading/prep_and_submit.py --providers " + " ".join(PROVIDERS) + " --submit")

    # Step 5: poll grading
    ids = json.load(open(os.path.join(P2, "grading", "batch_ids.json")))
    for prov in PROVIDERS:
        bid = ids.get(prov, {}).get("batch_id")
        if not bid:
            log(f"WARN: no batch_id for {prov} in grading/batch_ids.json")
            continue
        poll_until_done(bid, f"{prov}_grade")

    # Step 6: collect grading
    run("python phase2/grading/collect_and_check.py --providers " + " ".join(PROVIDERS))

    # Step 7: confidence + ECE for all 5 providers (re-runs everything; cheap)
    run("python phase2/confidence/compute_confidence.py")
    run("python phase2/confidence/compute_ece.py")

    with open(DONE_MARKER, "w") as f:
        f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
    log("P2 PIPELINE DONE (anthropic + xai)")


if __name__ == "__main__":
    main()
