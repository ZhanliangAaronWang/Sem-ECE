"""Build Phase 2 (HLE) generation batch input files for 4 providers.

Reads: data/phase2/hle_preprocessed.jsonl
Writes: phase2/batch_inputs/{provider}_hle.jsonl

Providers: openai, gemini, xai, mistral (skip anthropic)
Samples: 50 per question (same as Phase 1)
max_output_tokens: 512 (up from 256 for longer HLE answers)
"""
import os, json

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
INPUT = os.path.join(CAL_BASE, "data", "phase2", "hle_preprocessed.jsonl")
OUT_DIR = os.path.join(BASE, "batch_inputs")
os.makedirs(OUT_DIR, exist_ok=True)

SYSTEM_PROMPT = """You are answering questions for a research benchmark. Be concise and precise.

Your response MUST end with EXACTLY these two lines, with nothing after them:
Answer: <your final answer>
Confidence: <integer between 0 and 100>%

Keep <your final answer> as short as possible — ideally a single name, number, date, or short phrase. Do not put explanations or reasoning on the Answer line itself.

If you genuinely do not know, write:
Answer: I don't know
Confidence: 0%"""

N_SAMPLES = 50
MAX_TOKENS = 512

# Load questions
questions = []
with open(INPUT) as f:
    for line in f:
        questions.append(json.loads(line))
print(f"Loaded {len(questions)} HLE questions", flush=True)


def build_openai():
    """OpenAI: 7 sub-batches per question (6×n=8 + 1×n=2 = 50)."""
    chunks = []
    for ci in range(7):
        n = 8 if ci < 6 else 2
        rows = []
        for q in questions:
            rows.append({
                "custom_id": f"{q['qid']}__chunk{ci}",
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": "gpt-5.4",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": q["question_final"]},
                    ],
                    "max_completion_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "reasoning_effort": "none",
                    "n": n,
                    "seed": ci,
                },
            })
        chunks.append(rows)

    # Write as separate files for separate batch submissions
    for ci, rows in enumerate(chunks):
        path = os.path.join(OUT_DIR, f"openai_hle_chunk{ci}.jsonl")
        with open(path, "w") as f:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    # Also write combined
    path = os.path.join(OUT_DIR, "openai_hle.jsonl")
    with open(path, "w") as f:
        for chunk in chunks:
            for r in chunk:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    total = sum(len(c) for c in chunks)
    print(f"  openai: {total} rows ({len(chunks)} chunks) -> {OUT_DIR}/openai_hle*.jsonl", flush=True)


def build_gemini():
    """Gemini: 1 row per sample (50 rows per question)."""
    rows = []
    for q in questions:
        for si in range(N_SAMPLES):
            rows.append({
                "custom_id": f"{q['qid']}__sample{si:02d}",
                "contents": q["question_final"],
                "config": {
                    "system_instruction": SYSTEM_PROMPT,
                    "max_output_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "thinking_config": {"thinking_budget": 0},
                    "seed": si,
                },
            })
    path = os.path.join(OUT_DIR, "gemini_hle.jsonl")
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  gemini: {len(rows)} rows -> {path}", flush=True)


def build_xai():
    """xAI: 1 row per sample, OpenAI-compatible format for async runner."""
    rows = []
    for q in questions:
        for si in range(N_SAMPLES):
            rows.append({
                "custom_id": f"{q['qid']}__sample{si:02d}",
                "method": "POST",
                "url": "/v1/chat/completions",
                "body": {
                    "model": "grok-4.20-0309-non-reasoning",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": q["question_final"]},
                    ],
                    "max_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "seed": si,
                },
            })
    path = os.path.join(OUT_DIR, "xai_hle.jsonl")
    with open(path, "w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  xai: {len(rows)} rows -> {path}", flush=True)


def build_mistral():
    """Mistral: 1 row per sample, Mistral batch format."""
    rows = []
    for q in questions:
        for si in range(N_SAMPLES):
            rows.append({
                "custom_id": f"{q['qid']}__sample{si:02d}",
                "body": {
                    "model": "mistral-large-latest",
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": q["question_final"]},
                    ],
                    "max_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "top_p": 1.0,
                    "random_seed": si,
                },
            })
    # Split into chunks of ~43260 for Mistral batch API limit
    chunk_size = 43260
    for ci in range(0, len(rows), chunk_size):
        chunk = rows[ci:ci + chunk_size]
        path = os.path.join(OUT_DIR, f"mistral_hle_chunk{ci // chunk_size}.jsonl")
        with open(path, "w") as f:
            for r in chunk:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")
    path_all = os.path.join(OUT_DIR, "mistral_hle.jsonl")
    with open(path_all, "w") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"  mistral: {len(rows)} rows -> {OUT_DIR}/mistral_hle*.jsonl", flush=True)


build_openai()
build_gemini()
build_xai()
build_mistral()

# Cost estimate
nq = len(questions)
print(f"\n=== Cost Estimate (HLE Phase 2) ===")
print(f"  Questions: {nq}")
print(f"  Samples per question: {N_SAMPLES}")
# Rough: ~400 input tokens + ~100 output tokens per call
for prov, model, in_price, out_price, note in [
    ("openai", "gpt-5.4", 1.25, 10.0, "batch 50% off"),
    ("gemini", "gemini-3-flash", 0.10, 0.40, "batch ~50% off estimate"),
    ("xai", "grok-4.20", 2.0, 10.0, "realtime (no batch)"),
    ("mistral", "mistral-large", 2.0, 6.0, "batch ~33% off"),
]:
    calls = nq * N_SAMPLES
    in_tok = 400 * calls
    out_tok = 100 * calls
    # Apply batch discount where applicable
    discount = 0.5 if "batch" in note else 1.0
    cost = (in_tok * in_price * discount + out_tok * out_price * discount) / 1e6
    print(f"  {prov:10s} ({model}): {calls:,} calls, ~${cost:.2f} {note}")
