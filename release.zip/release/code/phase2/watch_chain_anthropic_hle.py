"""Phase 2 HLE Anthropic retry full chain.

Steps (single SLURM job):
  1. build_anthropic_hle_retry.py  (build retry input from original errors)
  2. submit_anthropic_hle_retry.py (submit + poll + download retry batch)
  3. merge_anthropic_hle_retry.py  (merge retry into anthropic_hle_raw.jsonl)
  4. clustering/prep_anthropic.py  (extract + build clustering batch input)
  5. clustering/submit_anthropic_chunked.py
  6. poll clustering chunks
  7. clustering/collect_anthropic.py
  8. grading/prep_and_submit.py --providers anthropic --submit
  9. poll grading
 10. grading/collect_and_check.py --providers anthropic
 11. confidence/compute_confidence.py + compute_ece.py (5-provider HLE table)

Writes phase2/.pipeline_done_anthropic_hle when complete.
"""
import os, json, time, subprocess
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI
client = OpenAI()

P2 = os.path.join(ROOT, "phase2")
POLL = 300
TERMINAL = {"completed", "failed", "expired", "cancelled"}
DONE_MARKER = os.path.join(P2, ".pipeline_done_anthropic_hle")


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def run(cmd):
    log(f"$ {cmd}")
    r = subprocess.run(cmd, shell=True, cwd=ROOT)
    if r.returncode != 0:
        raise RuntimeError(f"FAILED: {cmd}")


def poll_until_done(batch_id, label):
    while True:
        b = client.batches.retrieve(batch_id)
        rc = b.request_counts
        log(f"  {label}: {b.status} {rc.completed}/{rc.total}")
        if b.status in TERMINAL:
            return b
        time.sleep(POLL)


def main():
    # Step 1: build retry batch input
    run("python phase2/build_anthropic_hle_retry.py")

    # Step 2: submit + poll + download retry (script does its own polling)
    run("python phase2/submit_anthropic_hle_retry.py")

    # Step 3: merge retry into main raw file
    run("python phase2/merge_anthropic_hle_retry.py")

    # Step 3b: reset stale clustering state (old run was on 696 Q, now ~2156 Q)
    old_chunks = os.path.join(P2, "clustering", "anthropic_chunks.json")
    if os.path.exists(old_chunks):
        bak = old_chunks + ".bak_pre_retry"
        if not os.path.exists(bak):
            log(f"  backing up old clustering state -> {bak}")
            os.rename(old_chunks, bak)
        else:
            log(f"  removing stale clustering state (backup already exists)")
            os.remove(old_chunks)

    # Step 4: prep clustering
    run("python phase2/clustering/prep_anthropic.py")

    # Step 5: submit clustering chunks
    run("python phase2/clustering/submit_anthropic_chunked.py")

    # Step 6: poll clustering chunks
    state_path = os.path.join(P2, "clustering", "anthropic_chunks.json")
    state = json.load(open(state_path))
    for c in state["chunks"]:
        if c.get("final_status") == "completed" and c.get("output_file_id"):
            log(f"  anthropic_cluster_c{c['chunk']}: already completed")
            continue
        b = poll_until_done(c["batch_id"], f"anthropic_cluster_c{c['chunk']}")
        c["final_status"] = b.status
        if b.status == "completed":
            c["output_file_id"] = b.output_file_id
            c["error_file_id"] = b.error_file_id
    with open(state_path, "w") as f:
        json.dump(state, f, indent=2)

    # Step 7: collect clustering
    run("python phase2/clustering/collect_anthropic.py")

    # Step 8: submit grading
    run("python phase2/grading/prep_and_submit.py --providers anthropic --submit")

    # Step 9: poll grading
    ids = json.load(open(os.path.join(P2, "grading", "batch_ids.json")))
    bid = ids.get("anthropic", {}).get("batch_id")
    if not bid:
        raise RuntimeError("no anthropic batch_id in grading/batch_ids.json")
    poll_until_done(bid, "anthropic_grade")

    # Step 10: collect grading
    run("python phase2/grading/collect_and_check.py --providers anthropic")

    # Step 11: compute confidence + ECE for HLE 5-provider
    run("python phase2/confidence/compute_confidence.py")
    run("python phase2/confidence/compute_ece.py")

    with open(DONE_MARKER, "w") as f:
        f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
    log("P2 anthropic HLE PIPELINE DONE")


if __name__ == "__main__":
    main()
