"""Phase 2 HLE Anthropic fix-up chain.

After watch_chain_anthropic_hle.py finished with n=1400, this chain:
  - lowers N_KEEP to 46 (already edited in prep/collect)
  - bumps max_completion_tokens to 3000 + seed=42 (already edited in prep)
  - re-runs prep + clustering + collect (fresh state)
  - retries any remaining parse failures with seed=99
  - re-runs grading + ECE for the larger anthropic set

Steps:
  1. Backup old clustering state + clustered output
  2. Re-run clustering/prep_anthropic.py    (N=46, seed=42, max_tok=3000)
  3. Re-submit clustering chunks
  4. Poll clustering
  5. collect_anthropic.py                   (n=46)
  6. retry_parse_failures.py                (seed=99 for any remainder)
  7. grading/prep_and_submit.py --providers anthropic --submit
  8. Poll grading
  9. grading/collect_and_check.py --providers anthropic
 10. confidence/compute_confidence.py + compute_ece.py

Writes phase2/.pipeline_done_anthropic_fix when complete.
"""
import os, json, time, shutil, subprocess
from dotenv import load_dotenv

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)

from openai import OpenAI
client = OpenAI()

P2 = os.path.join(ROOT, "phase2")
POLL = 300
TERMINAL = {"completed", "failed", "expired", "cancelled"}
DONE_MARKER = os.path.join(P2, ".pipeline_done_anthropic_fix")


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def run(cmd):
    log(f"$ {cmd}")
    r = subprocess.run(cmd, shell=True, cwd=ROOT)
    if r.returncode != 0:
        raise RuntimeError(f"FAILED: {cmd}")


def poll_until_done(batch_id, label):
    while True:
        b = client.batches.retrieve(batch_id)
        rc = b.request_counts
        log(f"  {label}: {b.status} {rc.completed}/{rc.total}")
        if b.status in TERMINAL:
            return b
        time.sleep(POLL)


def backup_or_remove(path, suffix=".bak_pre_fix"):
    if not os.path.exists(path):
        return
    bak = path + suffix
    if os.path.exists(bak):
        log(f"  backup exists, removing {path}")
        os.remove(path)
    else:
        log(f"  {path} -> {bak}")
        shutil.move(path, bak)


def main():
    # Step 1: Backup existing clustering state and outputs
    backup_or_remove(os.path.join(P2, "clustering", "anthropic_chunks.json"))
    backup_or_remove(os.path.join(P2, "clustering", "anthropic_simpleqa_clustered.jsonl"))
    backup_or_remove(os.path.join(P2, "clustering", "anthropic_extracted.jsonl"))
    backup_or_remove(os.path.join(P2, "clustering", "anthropic_retry_chunks.json"))

    # Step 2: re-prep (N=46, seed=42, max_tok=3000)
    run("python phase2/clustering/prep_anthropic.py")

    # Step 3: submit clustering chunks
    run("python phase2/clustering/submit_anthropic_chunked.py")

    # Step 4: poll clustering chunks
    state_path = os.path.join(P2, "clustering", "anthropic_chunks.json")
    state = json.load(open(state_path))
    for c in state["chunks"]:
        if c.get("final_status") == "completed" and c.get("output_file_id"):
            log(f"  anthropic_cluster_c{c['chunk']}: already completed")
            continue
        b = poll_until_done(c["batch_id"], f"anthropic_cluster_c{c['chunk']}")
        c["final_status"] = b.status
        if b.status == "completed":
            c["output_file_id"] = b.output_file_id
            c["error_file_id"] = b.error_file_id
    with open(state_path, "w") as f:
        json.dump(state, f, indent=2)

    # Step 5: collect (first pass, seed=42)
    run("python phase2/clustering/collect_anthropic.py")

    # Step 6: retry remaining parse failures with seed=99
    run("python phase2/clustering/retry_parse_failures.py")

    # Step 7: submit grading
    run("python phase2/grading/prep_and_submit.py --providers anthropic --submit")

    # Step 8: poll grading
    ids = json.load(open(os.path.join(P2, "grading", "batch_ids.json")))
    bid = ids.get("anthropic", {}).get("batch_id")
    if not bid:
        raise RuntimeError("no anthropic batch_id in grading/batch_ids.json")
    poll_until_done(bid, "anthropic_grade")

    # Step 9: collect grading
    run("python phase2/grading/collect_and_check.py --providers anthropic")

    # Step 10: compute confidence + ECE for HLE 5-provider
    run("python phase2/confidence/compute_confidence.py")
    run("python phase2/confidence/compute_ece.py")

    with open(DONE_MARKER, "w") as f:
        f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
    log("P2 anthropic FIX PIPELINE DONE")


if __name__ == "__main__":
    main()
