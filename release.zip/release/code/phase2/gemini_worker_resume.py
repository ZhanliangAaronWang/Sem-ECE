"""Async Gemini resume worker for HLE Phase 2 generation.

Resume-only-errors mode:
  1. Reads existing output file `batch_outputs/gemini_raw_w{N}.jsonl`
  2. Any custom_id in this worker's slice that does NOT have status=="success"
     in that file — either missing entirely or present with text=None / error —
     is retried.
  3. Successful retries are APPENDED to `batch_outputs/gemini_raw_w{N}_retry.jsonl`
     (siblings to the original file; original is never modified).
  4. Already-successful rows are skipped (no API call).

Schema of output rows is identical to the main worker so downstream
aggregation can simply concatenate `*_w{N}.jsonl` + `*_w{N}_retry.jsonl`
and pick the latest status==success row for each custom_id.
"""
import os, json, time, asyncio, hashlib, argparse
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
load_dotenv(os.path.join(CAL_BASE, "phase1", ".env"), override=True)

from google import genai
from google.genai import types

INPUT_FILE = os.path.join(BASE, "batch_inputs", "gemini_hle.jsonl")
OUTPUT_DIR = os.path.join(BASE, "batch_outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

MODEL = "gemini-3-flash-preview"
MAX_CONCURRENT = 50
RATE_LIMIT_RPM = 1500
DELAY = 60.0 / RATE_LIMIT_RPM


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--worker", type=int, default=None)
    p.add_argument("--num-workers", type=int, default=None)
    a = p.parse_args()
    if a.worker is None:
        a.worker = int(os.environ.get("SLURM_ARRAY_TASK_ID", 0))
    if a.num_workers is None:
        a.num_workers = int(os.environ.get("SLURM_ARRAY_TASK_COUNT", 1))
    return a


def slice_for(custom_id, num_workers):
    h = int(hashlib.md5(custom_id.encode()).hexdigest(), 16)
    return h % num_workers


def load_successful(*paths):
    """Return set of custom_ids that have at least one status==success row."""
    done = set()
    for p in paths:
        if not os.path.exists(p):
            continue
        with open(p) as f:
            for line in f:
                try:
                    r = json.loads(line)
                    if r.get("custom_id") and r.get("status") == "success":
                        done.add(r["custom_id"])
                except Exception:
                    pass
    return done


async def main():
    args = parse_args()
    worker_idx = args.worker
    num_workers = args.num_workers
    original_file = os.path.join(OUTPUT_DIR, f"gemini_raw_w{worker_idx}.jsonl")
    retry_file = os.path.join(OUTPUT_DIR, f"gemini_raw_w{worker_idx}_retry.jsonl")
    print(f"=== Resume Worker {worker_idx}/{num_workers} ===", flush=True)
    print(f"  original: {original_file}", flush=True)
    print(f"  retry out: {retry_file}", flush=True)

    client = genai.Client(api_key=os.environ["GOOGLE_API_KEY"])

    all_rows = []
    with open(INPUT_FILE) as f:
        for line in f:
            all_rows.append(json.loads(line))
    print(f"  {len(all_rows)} total input rows", flush=True)

    # Consider both the original partial file AND any prior retry file as
    # sources of already-successful custom_ids (idempotent re-runs).
    successful = load_successful(original_file, retry_file)
    my_slice = [r for r in all_rows if slice_for(r["custom_id"], num_workers) == worker_idx]
    remaining = [r for r in my_slice if r["custom_id"] not in successful]
    print(f"  My slice: {len(my_slice)}, already-success: {len(my_slice) - len(remaining)}, "
          f"to-retry: {len(remaining)}", flush=True)

    if not remaining:
        print("Nothing to do.", flush=True)
        return

    sem = asyncio.Semaphore(MAX_CONCURRENT)
    rate_limiter = asyncio.Lock()
    last_request_time = [0.0]
    results_buffer = []
    errors = {"count": 0}
    done_count = [0]
    start = time.time()

    async def process_one(row):
        cfg = row["config"]
        cid = row["custom_id"]
        async with sem:
            async with rate_limiter:
                now = time.monotonic()
                wait = DELAY - (now - last_request_time[0])
                if wait > 0:
                    await asyncio.sleep(wait)
                last_request_time[0] = time.monotonic()

            last_err = ""
            for attempt in range(10):
                try:
                    resp = await client.aio.models.generate_content(
                        model=MODEL,
                        contents=row["contents"],
                        config=types.GenerateContentConfig(
                            system_instruction=cfg["system_instruction"],
                            max_output_tokens=cfg["max_output_tokens"],
                            temperature=cfg["temperature"],
                            top_p=cfg["top_p"],
                            thinking_config=types.ThinkingConfig(
                                thinking_budget=cfg["thinking_config"]["thinking_budget"]
                            ),
                            seed=cfg.get("seed"),
                        ),
                    )
                    um = resp.usage_metadata
                    results_buffer.append({
                        "custom_id": cid, "text": resp.text,
                        "prompt_tokens": getattr(um, "prompt_token_count", None),
                        "completion_tokens": getattr(um, "candidates_token_count", None),
                        "status": "success",
                    })
                    done_count[0] += 1
                    if done_count[0] % 250 == 0:
                        elapsed = time.time() - start
                        rpm = done_count[0] / (elapsed / 60) if elapsed > 0 else 0
                        print(f"  w{worker_idx}: {done_count[0]}/{len(remaining)} ({rpm:.0f} RPM)", flush=True)
                    return
                except Exception as e:
                    last_err = str(e)
                    if "429" in last_err or "RESOURCE_EXHAUSTED" in last_err:
                        await asyncio.sleep(min(60, 2 ** attempt * 5))
                    elif "500" in last_err or "503" in last_err:
                        await asyncio.sleep(min(30, 2 ** attempt * 2))
                    else:
                        errors["count"] += 1
                        results_buffer.append({
                            "custom_id": cid, "text": None,
                            "error": last_err[:500], "status": "error",
                        })
                        done_count[0] += 1
                        return
            errors["count"] += 1
            results_buffer.append({
                "custom_id": cid, "text": None,
                "error": f"retry_exhausted: {last_err[:400]}", "status": "error",
            })
            done_count[0] += 1

    async def flusher():
        while True:
            await asyncio.sleep(10)
            if results_buffer:
                with open(retry_file, "a") as f:
                    while results_buffer:
                        f.write(json.dumps(results_buffer.pop(0), ensure_ascii=False) + "\n")

    flush_task = asyncio.create_task(flusher())
    await asyncio.gather(*[process_one(r) for r in remaining])
    flush_task.cancel()
    with open(retry_file, "a") as f:
        while results_buffer:
            f.write(json.dumps(results_buffer.pop(0), ensure_ascii=False) + "\n")

    elapsed = time.time() - start
    print(f"\nResume worker {worker_idx} done. {done_count[0]}/{len(remaining)} in {elapsed/60:.1f} min "
          f"(errors={errors['count']})", flush=True)


if __name__ == "__main__":
    asyncio.run(main())
