"""Monitor all Phase 2 HLE generation batches and send email when all complete.

Polls every 5 minutes. Sends email via SMTP when all providers reach terminal state.
"""
import os, json, time, smtplib
from email.mime.text import MIMEText
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
load_dotenv(os.path.join(CAL_BASE, "phase1", ".env"), override=True)

STATE_FILE = os.path.join(BASE, "batch_state.json")
POLL_INTERVAL = 300  # 5 minutes


def check_openai(state):
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])
    chunks = state.get("openai", {}).get("chunks", [])
    total = done = failed = 0
    for c in chunks:
        try:
            b = client.batches.retrieve(c["batch_id"])
            rc = b.request_counts
            total += rc.total
            done += rc.completed
            failed += rc.failed
            c["last_status"] = b.status
            c["completed"] = rc.completed
            c["total"] = rc.total
        except Exception:
            pass
    all_terminal = all(c.get("last_status") in ("completed", "failed", "expired", "cancelled") for c in chunks)
    return {"provider": "openai", "total": total, "done": done, "failed": failed, "terminal": all_terminal}


def check_gemini(state):
    """Check Slurm workers + any batch jobs."""
    # Count output rows
    out_path = os.path.join(BASE, "batch_outputs", "gemini_raw.jsonl")
    n_success = 0
    if os.path.exists(out_path):
        with open(out_path) as f:
            for line in f:
                try:
                    r = json.loads(line)
                    if r.get("status") == "success":
                        n_success += 1
                except Exception:
                    pass
    # Also count worker files
    import glob
    for wf in glob.glob(os.path.join(BASE, "batch_outputs", "gemini_raw_w*.jsonl")):
        with open(wf) as f:
            for line in f:
                try:
                    r = json.loads(line)
                    if r.get("status") == "success":
                        n_success += 1
                except Exception:
                    pass
    target = 107900
    return {"provider": "gemini", "total": target, "done": n_success, "failed": 0,
            "terminal": n_success >= target}


def check_xai(state):
    from openai import OpenAI
    client = OpenAI(api_key=os.environ["XAI_API_KEY"], base_url="https://api.x.ai/v1")
    chunks = state.get("xai", {}).get("chunks", [])
    total = done = failed = 0
    for c in chunks:
        try:
            b = client.batches.retrieve(c["batch_id"])
            rc = b.request_counts
            total += rc.total
            done += rc.completed
            failed += rc.failed
            c["last_status"] = b.status
        except Exception:
            pass
    all_terminal = all(c.get("last_status") in ("completed", "failed", "expired", "cancelled") for c in chunks) if chunks else False
    return {"provider": "xai", "total": total, "done": done, "failed": failed, "terminal": all_terminal}


def check_mistral(state):
    from mistralai.client import Mistral
    client = Mistral(api_key=os.environ["MISTRAL_API_KEY"])
    chunks = state.get("mistral", {}).get("chunks", [])
    total_done = 0
    all_terminal = True
    for c in chunks:
        try:
            job = client.batch.jobs.get(job_id=c["batch_id"])
            st = str(job.status).upper()
            c["last_status"] = st
            if "SUCCESS" in st or "COMPLETED" in st:
                total_done += c["n_rows"]
            elif "FAIL" in st or "CANCEL" in st or "EXPIRE" in st:
                pass
            else:
                all_terminal = False
        except Exception:
            all_terminal = False
    target = 107900
    return {"provider": "mistral", "total": target, "done": total_done, "failed": 0, "terminal": all_terminal}


def send_email(subject, body):
    try:
        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = "monitor@calibration"
        msg["To"] = os.environ.get("NOTIFY_EMAIL", "anonymous@example.invalid")
        # Try local sendmail
        import subprocess
        proc = subprocess.run(
            ["sendmail", "-t"],
            input=msg.as_string(),
            capture_output=True, text=True, timeout=30,
        )
        if proc.returncode == 0:
            print("Email sent.", flush=True)
        else:
            # Fallback: write to file
            with open(os.path.join(BASE, "NOTIFICATION.txt"), "w") as f:
                f.write(f"Subject: {subject}\n\n{body}\n")
            print("Email failed, wrote NOTIFICATION.txt", flush=True)
    except Exception as e:
        with open(os.path.join(BASE, "NOTIFICATION.txt"), "w") as f:
            f.write(f"Subject: {subject}\n\n{body}\n")
        print(f"Email error: {e}, wrote NOTIFICATION.txt", flush=True)


def main():
    print("Phase 2 HLE Monitor started", flush=True)
    email_sent = False

    while True:
        try:
            with open(STATE_FILE) as f:
                state = json.load(f)
        except Exception:
            state = {}

        results = []
        for checker in [check_openai, check_gemini, check_xai, check_mistral]:
            try:
                r = checker(state)
                results.append(r)
            except Exception as e:
                results.append({"provider": checker.__name__.replace("check_", ""),
                               "total": 0, "done": 0, "failed": 0, "terminal": False,
                               "error": str(e)[:100]})

        # Save updated state
        with open(STATE_FILE, "w") as f:
            json.dump(state, f, indent=2)

        # Print status
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        print(f"\n[{ts}] Phase 2 HLE Generation Status:", flush=True)
        all_done = True
        for r in results:
            pct = r["done"] * 100 / r["total"] if r["total"] > 0 else 0
            status = "DONE" if r["terminal"] else "running"
            print(f"  {r['provider']:10s}: {r['done']:>6d}/{r['total']:<6d} ({pct:5.1f}%) [{status}]  fail={r['failed']}", flush=True)
            if not r["terminal"]:
                all_done = False

        if all_done and not email_sent:
            body = f"Phase 2 HLE Generation Complete\n\n"
            for r in results:
                body += f"  {r['provider']}: {r['done']}/{r['total']} (fail={r['failed']})\n"
            body += f"\nTimestamp: {ts}\n"
            send_email("[Calibration] Phase 2 HLE Generation COMPLETE", body)
            email_sent = True
            print("\nAll providers done. Exiting.", flush=True)
            break

        time.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    main()
