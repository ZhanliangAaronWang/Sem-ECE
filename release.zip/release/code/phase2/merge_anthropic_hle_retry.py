"""Merge Anthropic HLE retry results into the main raw file.

Reads:
  phase2/batch_outputs/anthropic_hle_raw.jsonl        (107,900 original rows)
  phase2/batch_outputs/anthropic_hle_retry_raw.jsonl  (~71,599 retry rows)

Writes:
  phase2/batch_outputs/anthropic_hle_raw.jsonl        (merged in place)
  phase2/batch_outputs/anthropic_hle_raw.jsonl.bak_pre_retry  (backup)

Logic:
  - Load original by cid.
  - For each retry row: if it succeeded, REPLACE the original row.
  - If retry row also failed: keep original (so we have a stable record).
  - Original successes are never touched.
"""
import os, json, shutil, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = os.path.join(ROOT, "phase2", "batch_outputs", "anthropic_hle_raw.jsonl")
RETRY = os.path.join(ROOT, "phase2", "batch_outputs", "anthropic_hle_retry_raw.jsonl")
BACKUP = RAW + ".bak_pre_retry"


def main():
    if not os.path.exists(BACKUP):
        print(f"[backup] {RAW} -> {BACKUP}", flush=True)
        shutil.copy2(RAW, BACKUP)
    else:
        print(f"[backup] already exists at {BACKUP}, skipping", flush=True)

    print(f"[load] {BACKUP}", flush=True)
    rows_by_cid = {}
    order = []
    with open(BACKUP) as f:
        for line in f:
            r = json.loads(line)
            cid = r["custom_id"]
            rows_by_cid[cid] = r
            order.append(cid)
    print(f"  original rows: {len(rows_by_cid)}", flush=True)

    print(f"[load] {RETRY}", flush=True)
    n_retry = n_replaced = n_retry_failed = 0
    with open(RETRY) as f:
        for line in f:
            r = json.loads(line)
            n_retry += 1
            cid = r["custom_id"]
            if cid not in rows_by_cid:
                print(f"  WARN: retry cid not in original: {cid}", flush=True)
                continue
            if r.get("result", {}).get("type") == "succeeded":
                rows_by_cid[cid] = r
                n_replaced += 1
            else:
                n_retry_failed += 1
    print(f"  retry rows: {n_retry}, replaced (succeeded): {n_replaced}, still-failed: {n_retry_failed}", flush=True)

    tmp = RAW + ".tmp"
    print(f"[write] -> {tmp}", flush=True)
    with open(tmp, "w") as f:
        for cid in order:
            f.write(json.dumps(rows_by_cid[cid], ensure_ascii=False, default=str) + "\n")
    os.replace(tmp, RAW)

    ok = sum(1 for r in rows_by_cid.values() if r.get("result", {}).get("type") == "succeeded")
    err = len(rows_by_cid) - ok
    print(f"\n=== Merged ===", flush=True)
    print(f"  total rows: {len(rows_by_cid)}", flush=True)
    print(f"  succeeded: {ok}", flush=True)
    print(f"  errored: {err}", flush=True)
    print(f"  -> {RAW}", flush=True)


if __name__ == "__main__":
    main()
