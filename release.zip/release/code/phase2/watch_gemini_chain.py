"""P2 HLE Gemini pipeline chain: poll clustering -> collect -> grade -> ECE."""
import os, json, time, subprocess
from dotenv import load_dotenv
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
load_dotenv(os.path.join(ROOT, "phase1", ".env"), override=True)
from openai import OpenAI
client = OpenAI()

P2 = os.path.join(ROOT, "phase2")
POLL = 300
TERM = {"completed","failed","expired","cancelled"}
DONE = os.path.join(P2, ".gemini_pipeline_done")


def log(m):
    print(f"[{time.strftime('%H:%M:%S')}] {m}", flush=True)


def poll(bid, label):
    while True:
        b = client.batches.retrieve(bid)
        rc = b.request_counts
        log(f"  {label}: {b.status} {rc.completed}/{rc.total}")
        if b.status in TERM: return b
        time.sleep(POLL)


def run(cmd):
    log(f"$ {cmd}")
    r = subprocess.run(cmd, shell=True, cwd=ROOT)
    if r.returncode != 0: raise RuntimeError(cmd)


state = json.load(open(os.path.join(P2, "clustering", "gemini_chunks.json")))
for c in state["chunks"]:
    b = poll(c["batch_id"], f"cluster_c{c['chunk']}")
    c["final_status"] = b.status
    if b.status == "completed":
        c["output_file_id"] = b.output_file_id
        c["error_file_id"] = b.error_file_id
with open(os.path.join(P2, "clustering", "gemini_chunks.json"), "w") as f:
    json.dump(state, f, indent=2)

run("python phase2/clustering/collect_gemini.py")
run("python phase2/grading/prep_and_submit.py --providers gemini --submit")

ids = json.load(open(os.path.join(P2, "grading", "batch_ids.json")))
poll(ids["gemini"]["batch_id"], "grade_gemini")

run("python phase2/grading/collect_and_check.py --providers gemini")

# ECE: need compute_confidence + compute_ece
run("python phase2/confidence/compute_confidence.py")
run("python phase2/confidence/compute_ece.py")

with open(DONE, "w") as f:
    f.write(time.strftime("%Y-%m-%dT%H:%M:%S"))
log("P2 GEMINI PIPELINE DONE")
