"""Build Phase 2 (HLE) generation batch input for Anthropic claude-opus-4-6.

Same setup as SimpleQA Anthropic run:
  - temperature 1.0, thinking off (param omitted)
  - system prompt identical to other providers
  - 50 samples per question
  - max_tokens = 16384 (no truncation — let Opus reason as long as needed)

Output: phase2/batch_inputs/anthropic_hle.jsonl (107,900 rows)
"""
import os, json

BASE = os.path.dirname(os.path.abspath(__file__))
CAL_BASE = os.path.dirname(BASE)
INPUT = os.path.join(CAL_BASE, "data", "phase2", "hle_preprocessed.jsonl")
OUT = os.path.join(BASE, "batch_inputs", "anthropic_hle.jsonl")
os.makedirs(os.path.dirname(OUT), exist_ok=True)

SYSTEM_PROMPT = """You are answering questions for a research benchmark. Be concise and precise.

Your response MUST end with EXACTLY these two lines, with nothing after them:
Answer: <your final answer>
Confidence: <integer between 0 and 100>%

Keep <your final answer> as short as possible — ideally a single name, number, date, or short phrase. Do not put explanations or reasoning on the Answer line itself.

If you genuinely do not know, write:
Answer: I don't know
Confidence: 0%"""

N_SAMPLES = 50
MAX_TOKENS = 16384

questions = [json.loads(l) for l in open(INPUT)]
print(f"Loaded {len(questions)} HLE questions", flush=True)

n = 0
with open(OUT, "w") as f:
    for q in questions:
        for si in range(N_SAMPLES):
            row = {
                "custom_id": f"{q['qid']}__sample{si:02d}",
                "params": {
                    "model": "claude-opus-4-6",
                    "max_tokens": MAX_TOKENS,
                    "temperature": 1.0,
                    "system": SYSTEM_PROMPT,
                    "messages": [
                        {"role": "user", "content": q["question_final"]},
                    ],
                },
            }
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            n += 1

print(f"Wrote {n} rows -> {OUT}", flush=True)
print(f"  expected: {len(questions)} questions × {N_SAMPLES} samples = {len(questions)*N_SAMPLES}", flush=True)
assert n == len(questions) * N_SAMPLES
