"""Build Anthropic HLE retry batch input.

Reads:
  phase2/batch_inputs/anthropic_hle.jsonl       (original 107,900 cids)
  phase2/batch_outputs/anthropic_hle_raw.jsonl  (107,900 result rows)

Writes:
  phase2/batch_inputs/anthropic_hle_retry.jsonl

Logic:
  - For each cid in original input, look up its result row.
  - If result.type == 'succeeded' -> SKIP (do not retry).
  - If error message contains 'content filtering' -> SKIP (deterministic).
  - Otherwise -> emit retry row with original params + max_tokens=1500.
"""
import os, json

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ORIG_INPUT = os.path.join(ROOT, "phase2", "batch_inputs", "anthropic_hle.jsonl")
RAW = os.path.join(ROOT, "phase2", "batch_outputs", "anthropic_hle_raw.jsonl")
RETRY_OUT = os.path.join(ROOT, "phase2", "batch_inputs", "anthropic_hle_retry.jsonl")

NEW_MAX_TOKENS = 1500


def classify_result(r):
    """Returns 'ok', 'content_filter', or 'retryable'."""
    res = r.get("result", {})
    if res.get("type") == "succeeded":
        return "ok"
    err = res.get("error", {})
    err_obj = err.get("error", {}) if isinstance(err.get("error"), dict) else {}
    msg = err_obj.get("message", "") if isinstance(err_obj, dict) else ""
    if "content filtering" in msg.lower() or "content_filter" in msg.lower():
        return "content_filter"
    return "retryable"


def main():
    print(f"[load] {RAW}", flush=True)
    status_by_cid = {}
    with open(RAW) as f:
        for line in f:
            r = json.loads(line)
            cid = r.get("custom_id", "")
            status_by_cid[cid] = classify_result(r)

    n_ok = sum(1 for v in status_by_cid.values() if v == "ok")
    n_cf = sum(1 for v in status_by_cid.values() if v == "content_filter")
    n_retry = sum(1 for v in status_by_cid.values() if v == "retryable")
    print(f"  ok={n_ok}, content_filter={n_cf}, retryable={n_retry}", flush=True)

    print(f"[load] {ORIG_INPUT}", flush=True)
    n_emitted = n_skipped_ok = n_skipped_cf = 0
    with open(ORIG_INPUT) as fin, open(RETRY_OUT, "w") as fout:
        for line in fin:
            row = json.loads(line)
            cid = row["custom_id"]
            status = status_by_cid.get(cid)
            if status == "ok":
                n_skipped_ok += 1
                continue
            if status == "content_filter":
                n_skipped_cf += 1
                continue
            row["params"]["max_tokens"] = NEW_MAX_TOKENS
            fout.write(json.dumps(row, ensure_ascii=False) + "\n")
            n_emitted += 1

    print(f"\n=== Build retry summary ===", flush=True)
    print(f"  emitted (retry): {n_emitted}", flush=True)
    print(f"  skipped already-ok: {n_skipped_ok}", flush=True)
    print(f"  skipped content_filter: {n_skipped_cf}", flush=True)
    print(f"  max_tokens override: {NEW_MAX_TOKENS}", flush=True)
    print(f"  -> {RETRY_OUT}", flush=True)


if __name__ == "__main__":
    main()
