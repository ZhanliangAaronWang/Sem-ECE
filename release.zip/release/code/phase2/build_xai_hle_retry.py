"""Identify xAI HLE samples that failed or truncated (no Confidence: line)
and build a retry input file with max_tokens=16384.

Inputs:
  phase2/batch_outputs/xai_raw_w*.jsonl + xai_raw_retry*.jsonl
  phase2/batch_inputs/xai_hle.jsonl  (original 107,900 rows)

Outputs:
  phase2/batch_inputs/xai_hle_retry3.jsonl  (only failed/truncated rows, max_tokens=16384)
  phase2/batch_outputs/xai_failed_retry3_ids.json
"""
import os, json, glob

BASE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(BASE, "batch_inputs", "xai_hle.jsonl")
OUT = os.path.join(BASE, "batch_inputs", "xai_hle_retry3.jsonl")
FAILED = os.path.join(BASE, "batch_outputs", "xai_failed_retry3_ids.json")

# Aggregate latest result per custom_id across all output files
# (a later "success" overrides earlier "error"/truncate of same cid)
results = {}
for fn in sorted(glob.glob(os.path.join(BASE, "batch_outputs", "xai_raw_*.jsonl"))):
    for line in open(fn):
        try:
            r = json.loads(line)
        except Exception:
            continue
        cid = r.get("custom_id")
        if not cid:
            continue
        if r.get("status") == "success":
            text = r.get("text") or ""
            if "Confidence:" in text:
                results[cid] = "ok"
            else:
                # success but truncated — count as failed for retry
                results[cid] = "truncated"
        else:
            # only set to error if not already ok
            if cid not in results:
                results[cid] = "error"

# Original input
all_rows = []
with open(SRC) as f:
    for line in f:
        all_rows.append(json.loads(line))
print(f"original rows: {len(all_rows)}")

# Stats
from collections import Counter
status_counts = Counter()
for r in all_rows:
    s = results.get(r["custom_id"], "missing")
    status_counts[s] += 1
print(f"status: {dict(status_counts)}")

# Build retry: anything not "ok"
needs_retry = [r for r in all_rows if results.get(r["custom_id"], "missing") != "ok"]
print(f"needs retry: {len(needs_retry)}")

# Override max_tokens
n = 0
with open(OUT, "w") as f:
    for r in needs_retry:
        new = json.loads(json.dumps(r))  # deep copy
        new["body"]["max_tokens"] = 16384
        f.write(json.dumps(new, ensure_ascii=False) + "\n")
        n += 1
with open(FAILED, "w") as f:
    json.dump([r["custom_id"] for r in needs_retry], f)
print(f"wrote {n} retry rows -> {OUT}")
print(f"failed ids -> {FAILED}")
