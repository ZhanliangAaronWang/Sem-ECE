"""Submit Phase 2 HLE Anthropic batch (107,900 rows -> 2 sub-batches).

Idempotent — if batches already submitted, resumes polling.

Output:
  phase2/batch_outputs/anthropic_hle_raw.jsonl   (concatenated successes)
  phase2/batch_ids_anthropic.json                (state)
"""
import os, json, time, sys
from dotenv import load_dotenv

BASE = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(os.path.dirname(BASE), "phase1", ".env"))

from anthropic import Anthropic
client = Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

INPUT = os.path.join(BASE, "batch_inputs", "anthropic_hle.jsonl")
STATE = os.path.join(BASE, "batch_ids_anthropic.json")
OUT = os.path.join(BASE, "batch_outputs", "anthropic_hle_raw.jsonl")
os.makedirs(os.path.dirname(OUT), exist_ok=True)

CHUNK_SIZE = 100_000   # Anthropic Message Batches API hard limit per batch

state = {}
if os.path.exists(STATE):
    with open(STATE) as f:
        state = json.load(f)

if not state.get("sub_batches"):
    print(f"[load] reading {INPUT}...", flush=True)
    requests = []
    with open(INPUT) as f:
        for line in f:
            requests.append(json.loads(line))
    print(f"  {len(requests)} requests", flush=True)

    chunks = [requests[i : i + CHUNK_SIZE] for i in range(0, len(requests), CHUNK_SIZE)]
    print(f"  splitting into {len(chunks)} sub-batches: {[len(c) for c in chunks]}", flush=True)

    sub_batches = []
    for ci, chunk in enumerate(chunks):
        # sanity: every request opus-4-6 + no thinking
        for r in chunk:
            assert r["params"]["model"] == "claude-opus-4-6"
            assert "thinking" not in r["params"]
        print(f"[submit] chunk {ci} ({len(chunk)} rows)...", flush=True)
        b = client.messages.batches.create(requests=chunk)
        sub_batches.append({
            "chunk": ci,
            "batch_id": b.id,
            "n_rows": len(chunk),
            "submitted_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "final_status": None,
        })
        print(f"  chunk {ci} batch_id: {b.id}", flush=True)

    state = {"sub_batches": sub_batches, "n_total": sum(c["n_rows"] for c in sub_batches)}
    with open(STATE, "w") as f:
        json.dump(state, f, indent=2)
else:
    print(f"[resume] state has {len(state['sub_batches'])} sub-batch(es)", flush=True)

# Poll
print("[poll] every 5 min until all sub-batches end...", flush=True)
while True:
    all_done = True
    for sb in state["sub_batches"]:
        if sb.get("final_status") == "ended":
            continue
        s = client.messages.batches.retrieve(sb["batch_id"])
        c = s.request_counts
        print(f"  {time.strftime('%H:%M:%S')} chunk{sb['chunk']} {sb['batch_id'][:18]}.. "
              f"status={s.processing_status} succ={c.succeeded} proc={c.processing} "
              f"err={c.errored} cancel={c.canceled} expired={c.expired}", flush=True)
        if s.processing_status == "ended":
            sb["final_status"] = "ended"
            with open(STATE, "w") as f:
                json.dump(state, f, indent=2)
        else:
            all_done = False
    if all_done:
        break
    time.sleep(300)

# Download all
print("[download] concatenating results...", flush=True)
total = 0
with open(OUT, "w") as out:
    for sb in state["sub_batches"]:
        n = 0
        for result in client.messages.batches.results(sb["batch_id"]):
            out.write(json.dumps(result.model_dump(), default=str) + "\n")
            n += 1
        print(f"  chunk {sb['chunk']}: {n} rows", flush=True)
        total += n
print(f"  wrote {total} total -> {OUT}", flush=True)

# Validate
ok = err = max_tok_hit = 0
for line in open(OUT):
    r = json.loads(line)
    msg = r.get("result", {}).get("message")
    if msg is None:
        err += 1
    else:
        ok += 1
        if msg.get("stop_reason") == "max_tokens":
            max_tok_hit += 1
print(f"[validate] ok={ok}, err={err}, max_tokens_hit={max_tok_hit} ({max_tok_hit*100/max(ok,1):.2f}%)", flush=True)

state["status"] = "completed"
state["completed_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
state["ok"] = ok
state["err"] = err
state["max_tokens_hit"] = max_tok_hit
with open(STATE, "w") as f:
    json.dump(state, f, indent=2)

print("[done] anthropic HLE batch complete.", flush=True)
